/* tslint:disable */
/* eslint-disable */
export function create_tree_js(areas_json: any, area_contests_json: any): any;
export function get_contest_matches_js(contests_tree_js: any, contest_id_js: any): any;
export function set_hooks(): void;
export function to_hashable_ballot_js(auditable_ballot_json: any): any;
export function to_hashable_multi_ballot_js(auditable_multi_ballot_json: any): any;
export function hash_auditable_ballot_js(auditable_ballot_json: any): any;
export function hash_auditable_multi_ballot_js(auditable_multi_ballot_json: any): any;
export function encrypt_decoded_contest_js(decoded_contests_json: any, election_json: any): any;
export function encrypt_decoded_multi_contest_js(decoded_multi_contests_json: any, election_json: any): any;
export function decode_auditable_ballot_js(auditable_ballot_json: any): any;
export function decode_auditable_multi_ballot_js(auditable_multi_ballot_json: any): any;
export function sort_candidates_list_js(all_candidates: any, order: any, apply_random: any): any;
export function sort_contests_list_js(contests_json: any, order: any, apply_random: any): any;
export function sort_elections_list_js(elections_json: any, order: any, apply_random: any): any;
export function get_layout_properties_from_contest_js(contest_json: any): any;
export function get_candidate_points_js(contest_json: any, candidate_val: any): any;
export function is_preferential_js(counting_algorithm_js: any): any;
export function test_contest_reencoding_js(decoded_contest_json: any, ballot_style_json: any): any;
export function test_multi_contest_reencoding_js(decoded_multi_contest_json: any, ballot_style_json: any): any;
export function get_write_in_available_characters_js(decoded_contest_json: any, ballot_style_json: any): any;
export function generate_sample_auditable_ballot_js(): any;
export function check_is_blank_js(decoded_contest_json: any): any;
export function check_voting_not_allowed_next(is_multi_contest: boolean, contests: any, decoded_contests: any): any;
export function check_voting_error_dialog(is_multi_contest: boolean, contests: any, decoded_contests: any): any;
export function get_auth_url_js(base_url_json: any, tenant_id_json: any, event_id_json: any, auth_action_json: any): any;
export function sign_hashable_ballot_with_ephemeral_voter_signing_key_js(ballot_id: any, election_id: any, content: any): any;
export function sign_hashable_multi_ballot_with_ephemeral_voter_signing_key_js(ballot_id: any, election_id: any, auditable_multi_ballot_json: any): any;
export function get_default_duplicated_rank_policy_js(is_multi_contest: boolean): any;
export function get_default_preference_gaps_policy_js(): any;
export function verify_ballot_signature_js(ballot_id: any, election_id: any, content: any): any;
export function verify_multi_ballot_signature_js(ballot_id: any, election_id: any, auditable_multi_ballot_json: any): any;
export function get_default_consolidated_report_policy_js(): any;
export function get_default_language_detection_policy_js(): any;
export function iso_639_2t_to_bcp47_js(lang: string): string;
export function locale_to_internal_language_code_js(lang: string): string;
export function bench_enc_pok(n: number): void;
export function bench_modpow(n: number): void;
export function bench(n: number): void;
export function test_vdecryption(): void;
export function test_schnorr(): void;
export function test_elgamal(): void;
export function test_rerand(): void;
export function test_chaumpedersen(): void;
export function test(): void;

enum IAudienceSelection {
    ALL_USERS = "ALL_USERS",
    NOT_VOTED = "NOT_VOTED",
    VOTED = "VOTED",
    SELECTED = "SELECTED"
}



enum ITemplateType {
    CREDENTIALS = "CREDENTIALS",
    BALLOT_RECEIPT = "BALLOT_RECEIPT",
    PARTICIPATION_REPORT = "PARTICIPATION_REPORT",
    ELECTORAL_RESULTS = "ELECTORAL_RESULTS",
    OTP = "OTP",
    MANUALLY_VERIFY_VOTER = "MANUALLY_VERIFY_VOTER",
}



enum ITemplateMethod {
    EMAIL = "EMAIL",
    SMS = "SMS"
}



interface IEmailConfig {
    subject: string;
    plaintext_body: string;
    html_body: string;
}



interface ISmsConfig {
    message: string;
}



interface ICommTemplates {
    email: IEmail;
    sms: ISmsConfig;
}



interface IExtraConfig {
    pdf_options: string;
    report_options: string;
    communication_templates: ICommTemplates;
}



interface ISendTemplateBody {
    audience_selection: IAudienceSelection;
    audience_voter_ids?: Array<string>;
    type: ITemplateType;
    communication_method: ITemplateMethod;
    schedule_now: boolean;
    schedule_date?: string;
    name?: string;
    alias?: string;
    document?: string;
    extra_config?: IExtraConfig;
}



enum IInvalidPlaintextErrorType {
    Explicit = "Explicit",
    Implicit = "Implicit",
    EncodingError = "EncodingError"
}



interface IInvalidPlaintextError {
    error_type: IInvalidPlaintextErrorType;
    candidate_id?: string;
    message?: string;
    message_map: { [key: string]: string };
}



interface IDecodedVoteContest {
    contest_id: string;
    is_explicit_invalid: boolean;
    invalid_errors: Array<IInvalidPlaintextError>;
    invalid_alerts: Array<IInvalidPlaintextError>;
    choices: Array<IDecodedVoteChoice>;
}



interface IDecodedVoteChoice {
    id: string;
    selected: number;
    write_in_text?: string;
}



export enum IPermissions {
    TENANT_CREATE = "tenant-create",
    TENANT_READ = "tenant-read",
    TENANT_WRITE = "tenant-write",
    ELECTION_EVENT_CREATE = "election-event-create",
    ELECTION_EVENT_READ = "election-event-read",
    ELECTION_EVENT_WRITE = "election-event-write",
    ELECTION_EVENT_DELETE = "election-event-delete",
    VOTER_CREATE  = "voter-create",
    VOTER_READ = "voter-read",
    VOTER_WRITE = "voter-write",
    USER_CREATE = "user-create",
    USER_READ = "user-read",
    USER_WRITE = "user-write",
    USER_PERMISSION_CREATE = "user-permission-create",
    USER_PERMISSION_READ = "user-permission-read",
    USER_PERMISSION_WRITE = "user-permission-write",
    ROLE_CREATE = "role-create",
    ROLE_READ = "role-read",
    ROLE_WRITE = "role-write",
    ROLE_ASSIGN = "role-assign",
    template_CREATE = "communication-template-create",
    template_READ = "communication-template-read",
    template_WRITE = "communication-template-write",
    NOTIFICATION_READ = "notification-read",
    NOTIFICATION_WRITE = "notification-write",
    NOTIFICATION_SEND = "notification-send",
    AREA_READ = "area-read",
    AREA_WRITE = "area-write",
    ELECTION_STATE_WRITE = "election-state-write",
    ELECTION_TYPE_CREATE = "election-type-create",
    ELECTION_TYPE_READ = "election-type-read",
    ELECTION_TYPE_WRITE = "election-type-write",
    VOTING_CHANNEL_READ = "voting-channel-read",
    VOTING_CHANNEL_WRITE = "voting-channel-write",
    TRUSTEE_CREATE = "trustee-create",
    TRUSTEE_READ = "trustee-read",
    TRUSTEE_WRITE = "trustee-write",
    TRUSTEE_CEREMONY = "trustee-ceremony",
    TALLY_READ = "tally-read",
    TALLY_START = "tally-start",
    TALLY_WRITE = "tally-write",
    TALLY_RESULTS_READ = "tally-results-read",
    PUBLISH_READ = "publish-read",
    PUBLISH_WRITE = "publish-write",
    LOGS_READ = "logs-read",
    TASKS_READ = "tasks-read",
    KEYS_READ = "keys-read",
    DOCUMENT_UPLOAD = "document-upload",
    DOCUMENT_DOWNLOAD = "document-download",
    ADMIN_CEREMONY = "admin-ceremony",
    ADMIN_DASHBOARD_VIEW = "admin-dashboard-view",
    TALLY_RESOLUTION_SUBMIT = "tally-resolution-submit",
}



interface IVotingChannels {
    online?: boolean;
    kiosk?: boolean;
    telephone?: boolean;
    paper?: boolean;
}



enum IContestStateEnum {
    ElectionChooserScreen = "ElectionChooserScreen",
    ReceivingElection = "ReceivingElection",
    ErrorScreen = "ErrorScreen",
    HelpScreen = "HelpScreen",
    StartScreen = "StartScreen",
    MultiContest = "MultiContest",
    PairwiseBeta = "PairwiseBeta",
    DraftsElectionScreen = "DraftsElectionScreen",
    AuditBallotScreen = "AuditBallotScreen",
    PcandidatesElectionScreen = "PcandidatesElectionScreen",
    TwoContestsConditionalScreen = "TwoContestsConditionalScreen",
    SimultaneousContestsScreen = "SimultaneousContestsScreen",
    ConditionalAccordionScreen = "ConditionalAccordionScreen",
    EncryptingBallotScreen = "EncryptingBallotScreen",
    CastOrCancelScreen = "CastOrCancelScreen",
    ReviewScreen = "ReviewScreen",
    CastingBallotScreen = "CastingBallotScreen",
    SuccessScreen = "SuccessScreen",
    ShowPdf = "ShowPdf"
}



interface ICandidateProperties {
    points?: number;
    write_in?: string;
}



interface IContestLayoutProperties {
    state: string;
    sorted: boolean;
    ordered: boolean;
}



interface IUserArea {
    id?: string;
    name?: string;
}



interface IVotesInfo {
    election_id: string;
    num_votes: Int;
    last_voted_at: string;
}



interface IUser {
    id?: string;
    attributes?: {[key: string]: any};
    email?: string;
    email_verified?: boolean;
    enabled?: boolean;
    first_name?: string;
    last_name?: string;
    username?: string;
    password?: string;
    area?: IUserArea;
    votes_info?: Array<IVotesInfo>;
}



interface IPermission {
    id?: string;
    attributes: {[key: string]: any};
    container_id?: string;
    description?: string;
    name?: string;
}



interface IRole {
    id?: string;
    name?: string;
    permissions?: Array<string>;
    access?: {[key: string]: any};
    attributes?: {[key: string]: any};
    client_roles?: {[key: string]: any};
}



export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly create_tree_js: (a: any, b: any) => [number, number, number];
  readonly get_contest_matches_js: (a: any, b: any) => [number, number, number];
  readonly to_hashable_ballot_js: (a: any) => [number, number, number];
  readonly to_hashable_multi_ballot_js: (a: any) => [number, number, number];
  readonly hash_auditable_ballot_js: (a: any) => [number, number, number];
  readonly hash_auditable_multi_ballot_js: (a: any) => [number, number, number];
  readonly encrypt_decoded_contest_js: (a: any, b: any) => [number, number, number];
  readonly encrypt_decoded_multi_contest_js: (a: any, b: any) => [number, number, number];
  readonly decode_auditable_ballot_js: (a: any) => [number, number, number];
  readonly decode_auditable_multi_ballot_js: (a: any) => [number, number, number];
  readonly sort_candidates_list_js: (a: any, b: any, c: any) => [number, number, number];
  readonly sort_contests_list_js: (a: any, b: any, c: any) => [number, number, number];
  readonly sort_elections_list_js: (a: any, b: any, c: any) => [number, number, number];
  readonly get_layout_properties_from_contest_js: (a: any) => [number, number, number];
  readonly get_candidate_points_js: (a: any, b: any) => [number, number, number];
  readonly is_preferential_js: (a: any) => [number, number, number];
  readonly test_contest_reencoding_js: (a: any, b: any) => [number, number, number];
  readonly test_multi_contest_reencoding_js: (a: any, b: any) => [number, number, number];
  readonly get_write_in_available_characters_js: (a: any, b: any) => [number, number, number];
  readonly generate_sample_auditable_ballot_js: () => [number, number, number];
  readonly check_is_blank_js: (a: any) => [number, number, number];
  readonly check_voting_not_allowed_next: (a: number, b: any, c: any) => [number, number, number];
  readonly check_voting_error_dialog: (a: number, b: any, c: any) => [number, number, number];
  readonly get_auth_url_js: (a: any, b: any, c: any, d: any) => [number, number, number];
  readonly sign_hashable_ballot_with_ephemeral_voter_signing_key_js: (a: any, b: any, c: any) => [number, number, number];
  readonly sign_hashable_multi_ballot_with_ephemeral_voter_signing_key_js: (a: any, b: any, c: any) => [number, number, number];
  readonly get_default_duplicated_rank_policy_js: (a: number) => [number, number, number];
  readonly get_default_preference_gaps_policy_js: () => [number, number, number];
  readonly verify_ballot_signature_js: (a: any, b: any, c: any) => [number, number, number];
  readonly verify_multi_ballot_signature_js: (a: any, b: any, c: any) => [number, number, number];
  readonly get_default_consolidated_report_policy_js: () => [number, number, number];
  readonly get_default_language_detection_policy_js: () => [number, number, number];
  readonly iso_639_2t_to_bcp47_js: (a: number, b: number) => [number, number];
  readonly locale_to_internal_language_code_js: (a: number, b: number) => [number, number];
  readonly set_hooks: () => void;
  readonly bench_enc_pok: (a: number) => void;
  readonly bench_modpow: (a: number) => void;
  readonly bench: (a: number) => void;
  readonly test_vdecryption: () => void;
  readonly test_schnorr: () => void;
  readonly test_elgamal: () => void;
  readonly test_rerand: () => void;
  readonly test_chaumpedersen: () => void;
  readonly test: () => void;
  readonly ring_core_0_17_14__bn_mul_mont: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_4: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
