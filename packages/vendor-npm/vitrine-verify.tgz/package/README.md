<!-- SPDX-License-Identifier: Apache-2.0 -->
# Browser verification

`@vitrine/verify` checks policies, receipts, receipt chains and offline
evidence. The default backend is independently implemented TypeScript;
`init({ backend })` selects another implementation of the same interface.
Verification helpers perform no network requests. The explicitly online
upgrade methods take a caller-supplied fetch function and send no cookies.

```ts
import { parsePolicy, policyIdDisplay, verifyEvidence } from "@vitrine/verify";

const policy = parsePolicy(policyNote);
policyIdDisplay(policy.id); // 13 groups of four: compare them (or the first four) independently
const result = verifyEvidence(evidenceFile, policy);
// Only result.outcome === "proven" establishes the claim.
```

The pure verifier handles every current evidence kind. Claims that require
reading a complete log return `not-proven` with `needs-scan`; custom profile
rules require the profile engine and return `rule-unsupported`. A parse rule
can prove a malformed logged envelope without accepting that envelope as a
valid entry. `buildEvidence(kind, objects, policy)` frames signed objects:
`objects.subject` is the policy's log or hub name, and keys such as
`"checkpoint a"` identify block types and arguments. Construction doesn't
establish validity. The `@vitrine/verify/pure` entry point also exposes
`parseEvidence`, `evidenceId` and a deterministic `now` verification option.

`PolicyHistory.serialize()` caches this client's accepted decisions in
trusted local storage. Restore it with
`PolicyHistory.deserialize(cache, independentlyPinnedPolicy)`. This is a
local cache, not a file to accept from another party: the quorum times are
decisions the client previously made. Restore checks the pin, signatures
and successor rules again, recomputes effective times and requires a fresh
policy discovery before reporting verified tiers.

`checkLoggedRelease(policy, { log, receipt, manifest, keys, files })` binds a
canonical release manifest to a witnessed release entry, checks the signing
key and required cosigners at the entry's sequencing time, and checks the
optional supplied files. `parseReleaseManifest` and `checkReleaseFiles` are
available separately. The caller supplies a keys log already checked through
the release's sequencing time; an incomplete keys log returns `needs-scan`.

Run `npm run check -w verify`, `npm test -w verify` and
`npm run build -w verify` from `packages/`. Shared vectors under `testdata/`
are run alongside the package's independent fixtures.

`parseOperatorList`, `verifyOperatorList` and `updateOperatorList` handle
signed infrastructure lists using explicit authority keys and a persisted
sequence/hash pin. Only the final list must be fresh; historical links may
have expired. Persist the returned pin atomically. An organizational party
label is an assertion to review, not proof of independence.

The `shared` namespace exposes enrolment, authorization and submission
parsers and signature/namespace checks. The binary submission parser checks
per-block limits before copying bodies. `checkSharedNamespace` deliberately
does not execute profile rules or admit a queue row. Servers must also run
the full profile and atomically enforce activation, quotas, idempotence and
durability. `checkSharedBindings` additionally checks the shared policy and
the authenticated enrolment. Neither helper performs a request.

`authenticateProfileMinimums` hashes a package's canonical semantic JSON
and optional rules module, rather than accepting an unauthenticated
minimums summary. `validateProfileMinimums` requires exact metadata for
every named version, including future sizes; unknown metadata is unresolved.
Known election tags retain their minimums even under an unknown hash.
Structural parsing and checking an already pinned historical signature
remain distinct from final policy/profile validation.

For a new policy pin, call `pinPolicy(note, { profileMetadata })`; `parsePolicy` only checks structural and signature rules. The eight published core meanings are bundled. Custom and future meanings require canonical metadata, authenticated against each pinned hash. Election ballots and election events require two app hubs, at least one independent of the operator, and two monitor parties.

Receipt results expose `profileMetadataResolved`. When a historical profile meaning cannot be established, cryptographic tier results remain available, while otherwise completed facts and the overall verified claim stay pending. Explicit canonical metadata may resolve a custom meaning; that flag does not claim arbitrary profile rule execution.


Private `policy-proofs/v1` responses are supplementary inclusion evidence.
`history.applyPolicyProofs` accepts optional `{eventsPrefix}` bytes and verifies
their count, Merkle root and complete ordered policy-entry set before updating
any discovery cache. Selective proofs never refresh it. A new authenticated
candidate stays unapplied while its first quorum time is unresolved and clears
cached freshness. Complete public scans with no unresolved candidates can
refresh independently accepted history. The online upgrader supplies the
prefix it actually reads; voter forwarding never returns private event bodies.

## Ballots, stages and Tracking IDs

A `vitrine/election/ballots/v1` entry has a `stage` (`received`, `cast` or
`audited`; `BALLOT_STAGES`). `buildElectionEntry` and `ballotExpect` take it
as a required field, so a receipt for one stage never answers for another.
The application's answer to a ballot at review is the log's receipt or
promise for the `received` entry. Check it as any other: rebuild the entry
with `stage: "received"`, call `verifyChain` with that `expect`, and for a
promise call `acceptPromise` with the same `expect`, which also requires
`|time - now| <= 60` seconds. A `received` entry says the ballot reached the
log, not that it was cast.

The Tracking ID is the 32-byte ballot ID in Crockford base32, 52 characters in
groups of four. `trackingId(id)` writes it, `shortTrackingId(id)` gives the
first 8 characters (`FTBE-MHRX`), `decodeTrackingId(text)` reads a full one,
and `parseTrackingPrefix(text)` / `trackingIdMatches(prefix, id)` match what a
person typed (at least 8 characters, any case, hyphens ignored, `I` and `L`
read as `1`, `O` as `0`). A prefix can match several entries: list them all.
