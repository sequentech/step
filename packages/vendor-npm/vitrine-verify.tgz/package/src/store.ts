// SPDX-License-Identifier: Apache-2.0
//
// ReceiptStore: receipt chains kept on the voter's device, in IndexedDB, one
// per election (docs/api.md, section 8). Nothing leaves the device unless the
// caller exports a file.

import { MAX_DOC_SIZE as MAX_CHAIN_SIZE } from "./pure/blocks.js";
import { CHAIN_FILE_EXTENSION, CHAIN_MEDIA_TYPE, parseChain, type ReceiptChain } from "./pure/chain.js";
import { fromUtf8 } from "./pure/bytes.js";
import { fieldText, parseEntry } from "./pure/entry.js";
import { parsePromise } from "./pure/promise.js";
import { ELECTION_TAG } from "./pure/tags.js";
import { parseTlogProof } from "./pure/tlogproof.js";

export const STORE_DB_NAME = "vitrine-receipts";
const STORE_NAME = "receipts";

export interface StoredReceipt {
  /** The key: `<event_id>/<election_id>` for election entries, or the
   * caller's own key. */
  election: string;
  /** The receipt chain document. */
  chain: string;
  policyId: string;
  log: string;
  /** When it was saved, milliseconds since the epoch. */
  savedAt: number;
}

export interface ReceiptStoreOptions {
  /** The IndexedDB factory; default `globalThis.indexedDB`. */
  indexedDB?: IDBFactory;
  /** The database name; default "vitrine-receipts". */
  name?: string;
  /** Ask the browser to keep the data (`navigator.storage.persist()`) on the
   * first `put`. Default true. */
  persist?: boolean;
  /** The clock for `savedAt`; default Date.now. */
  now?: () => number;
}

export interface PutOptions {
  /** The key to store the chain under. Required when the chain's entry isn't
   * a `vitrine/election/ballots/v1` entry, or the chain holds only a promise. */
  election?: string;
}

function request<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error ?? new Error("IndexedDB request failed"));
  });
}

function done(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("IndexedDB transaction failed"));
    tx.onabort = () => reject(tx.error ?? new Error("IndexedDB transaction aborted"));
  });
}

/** The election a chain's entry is for: `<event_id>/<election_id>`. */
export function electionOf(chain: ReceiptChain): string | undefined {
  for (const body of [chain.record, chain.issued]) {
    if (!body) continue;
    try {
      const extra = parseTlogProof(body).extra;
      if (!extra) continue;
      const e = parseEntry(extra);
      if (e.tag !== ELECTION_TAG) return undefined;
      const ev = fieldText(e, "event_id");
      const el = fieldText(e, "election_id");
      if (ev !== undefined && el !== undefined) return `${ev}/${el}`;
    } catch {
      // Try the other receipt.
    }
  }
  return undefined;
}

/** A file name for a stored chain: the election, with anything but letters,
 * digits, dots, dashes and underscores replaced. */
export function chainFileName(election: string): string {
  const base = election.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^[._]+/, "").slice(0, 100) || "receipt";
  return `${base}${CHAIN_FILE_EXTENSION}`;
}

export class ReceiptStore {
  private readonly factory: IDBFactory | undefined;
  private readonly name: string;
  private readonly persist: boolean;
  private readonly now: () => number;
  private db: Promise<IDBDatabase> | undefined;
  private asked = false;

  constructor(opts: ReceiptStoreOptions = {}) {
    this.factory = opts.indexedDB ?? (globalThis as { indexedDB?: IDBFactory }).indexedDB;
    this.name = opts.name ?? STORE_DB_NAME;
    this.persist = opts.persist ?? true;
    this.now = opts.now ?? Date.now;
  }

  private open(): Promise<IDBDatabase> {
    if (!this.db) {
      const f = this.factory;
      if (!f) return Promise.reject(new Error("ReceiptStore needs IndexedDB"));
      const r = f.open(this.name, 1);
      r.onupgradeneeded = () => {
        if (!r.result.objectStoreNames.contains(STORE_NAME)) r.result.createObjectStore(STORE_NAME, { keyPath: "election" });
      };
      this.db = request(r);
      this.db.catch(() => {
        this.db = undefined;
      });
    }
    return this.db;
  }

  private async askPersist(): Promise<void> {
    if (this.asked || !this.persist) return;
    this.asked = true;
    const storage = (globalThis as { navigator?: { storage?: { persist?: () => Promise<boolean> } } }).navigator?.storage;
    try {
      if (storage?.persist) await storage.persist();
    } catch {
      // Best effort.
    }
  }

  /** Stores a chain, replacing the one for the same election. Throws
   * VerifyError for a document that isn't a receipt chain. */
  async put(chain: string | Uint8Array, opts: PutOptions = {}): Promise<StoredReceipt> {
    const text = typeof chain === "string" ? chain : fromUtf8(chain);
    const c = parseChain(text);
    const election = opts.election ?? electionOf(c);
    if (election === undefined || election === "") {
      throw new TypeError(c.promise && !c.issued && !c.record ? "a promise-only chain needs opts.election" : "this chain's entry names no election; pass opts.election");
    }
    if (c.promise && !c.issued && !c.record) parsePromise(c.promise);
    const rec: StoredReceipt = { election, chain: text, policyId: c.policyId, log: c.log, savedAt: this.now() };
    const db = await this.open();
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(rec);
    await done(tx);
    await this.askPersist();
    return rec;
  }

  async get(election: string): Promise<StoredReceipt | undefined> {
    const db = await this.open();
    const tx = db.transaction(STORE_NAME, "readonly");
    const v = (await request(tx.objectStore(STORE_NAME).get(election))) as StoredReceipt | undefined;
    return v ?? undefined;
  }

  /** Every stored chain, by election. */
  async list(): Promise<StoredReceipt[]> {
    const db = await this.open();
    const tx = db.transaction(STORE_NAME, "readonly");
    return (await request(tx.objectStore(STORE_NAME).getAll())) as StoredReceipt[];
  }

  async delete(election: string): Promise<void> {
    const db = await this.open();
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(election);
    await done(tx);
  }

  /** The stored chain as a `.vitrine-receipt` file, for the user to keep. */
  async exportFile(election: string): Promise<File> {
    const rec = await this.get(election);
    if (!rec) throw new Error(`no receipt stored for ${election}`);
    return new File([rec.chain], chainFileName(election), { type: CHAIN_MEDIA_TYPE });
  }

  /** Reads a `.vitrine-receipt` file (at most 4 MiB) and stores it. */
  async importFile(file: Blob | string | Uint8Array, opts: PutOptions = {}): Promise<StoredReceipt> {
    let text: string;
    if (typeof file === "string") text = file;
    else if (file instanceof Uint8Array) {
      if (file.length > MAX_CHAIN_SIZE) throw new RangeError("a receipt chain is at most 4 MiB");
      text = fromUtf8(file);
    } else {
      if (file.size > MAX_CHAIN_SIZE) throw new RangeError("a receipt chain is at most 4 MiB");
      text = fromUtf8(new Uint8Array(await file.arrayBuffer()));
    }
    return this.put(text, opts);
  }

  /** Closes the database connection. */
  async close(): Promise<void> {
    const db = this.db;
    this.db = undefined;
    if (db) (await db).close();
  }
}
