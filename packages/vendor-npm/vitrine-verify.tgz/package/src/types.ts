// SPDX-License-Identifier: Apache-2.0
//
// Result types shared by @vitrine/verify (both verifiers) and @vitrine/ui.
// The UI kit renders these objects and nothing else, so every verifier must
// fill them the same way. Words never appear here: reasons and steps carry
// codes, and the UI kit turns codes into text (specs/receipt.md, section 3.1).

/** The four tiers of a receipt chain, in order. */
export type TierName = "record" | "witnesses" | "hubs" | "browser";

/** A tier's status (specs/receipt.md, section 3.1). `invalid` means an object
 * didn't parse, verify or match (damaged data, not evidence); `failed` means
 * validly signed objects contradict each other or the policy (evidence). */
export type TierStatus = "verified" | "pending" | "late" | "invalid" | "failed" | "unused";

/** How the UI shows one of the three facts. */
export type FactState = "done" | "promised" | "pending" | "late" | "invalid" | "failed";

/** Where a check ran: in the operator's page, or in an independent verifier. */
export type Where = "page" | "independent";

/** The one-line status of `<vitrine-status>`. */
export type OverallStatus = "verified" | "checking" | "pending" | "late" | "invalid" | "failed";

/** A machine-readable reason. `code` is a stable kebab-case identifier that
 * the UI kit maps to a Fluent message `reason-<code>`; `params` fill the
 * message's variables. `objects` name the signed objects that are evidence
 * when the reason is a failure (block types or note origins). */
export interface Reason {
  code: string;
  params?: Record<string, string | number>;
  objects?: string[];
}

/** One check, in the order the verifier ran it, for `<vitrine-proof-steps>`.
 * `ok` is null when the check didn't run (missing input, not yet due). The UI
 * kit maps `code` to the Fluent message `step-<code>`. */
export interface Step {
  code: string;
  tier: TierName | "policy" | "entry";
  ok: boolean | null;
  params?: Record<string, string | number>;
  reasons?: Reason[];
}

/** The per-hub part of the hubs and browser tiers. */
export interface HubTierDetail {
  hub: string;
  status: TierStatus;
  /** True when the hub or the browser-layer service is labelled as a test. */
  test?: boolean;
  reasons: Reason[];
}

export interface TierResult {
  tier: TierName;
  status: TierStatus;
  /** POSIX seconds after which a pending tier becomes late, by signed time. */
  deadline?: number;
  /** For hubs and browser: one detail per app hub. */
  hubs?: HubTierDetail[];
  reasons: Reason[];
}

/** The three facts of the UI kit, derived only from the tiers. */
export interface Facts {
  included: FactState;
  unchanged: FactState;
  sameForEveryone: FactState;
}

/** What the result says about the entry the expectation named. */
export interface EntryInfo {
  /** The log's name in the policy. */
  log: string;
  /** Lowercase hex of the leaf hash. */
  leafHash: string;
  /** Absent while only a promise exists. */
  index?: number;
  promised: boolean;
}

/** A short summary of the pinned policy, for display next to the result. */
export interface PolicySummary {
  /** Lowercase hex policy ID. */
  id: string;
  /** The six policy words, in the policy's language. */
  words: string[];
  /** BCP 47 code of the words' language. */
  lang: string;
  event: string;
  witnesses: { name: string; party?: string }[];
  hubs: string[];
  /** The policy in force at the result's `now` when it isn't the pinned
   * one: a successor the verifier applied (specs/policy.md, section 4). */
  inForce?: { id: string; words: string[] };
}

/** The identicon of specs/receipt.md section 5: a 5 x 5 grid, mirrored. */
export interface Identicon {
  hue: number;
  saturation: number;
  lightness: number;
  /** Row-major, 25 cells. */
  cells: boolean[];
}

export interface ChainResult {
  /** True when no tier is `failed` or `invalid`. */
  ok: boolean;
  status: OverallStatus;
  tiers: TierResult[];
  facts: Facts;
  reasons: Reason[];
  steps: Step[];
  where: Where;
  entry?: EntryInfo;
  /** The four receipt words and their language. */
  words: string[];
  wordsLang: string;
  identicon?: Identicon;
  /** The signed "now" used for deadlines, POSIX seconds. */
  now: number;
  /** True when the device clock is more than 60 s away from `now`. */
  clockWarning: boolean;
  /** Every profile/version in the accepted policy history has authenticated
   * meaning metadata and its minimum infrastructure is satisfied. This does
   * not claim execution of arbitrary domain rules. Crypto tiers stay separate. */
  profileMetadataResolved: boolean;
  policy: PolicySummary;
}

export type ReceiptResult = ChainResult;

/** Expectations (specs/receipt.md, section 1.1): the entry the caller
 * expects, as its bytes or as profile field values. */
export type Expect = { entry: Uint8Array } | { fields: Record<string, string> };

export interface EvidenceResult {
  /** `proven` only under a policy the caller pinned (or a successor of one);
   * `unpinned` when the file's policy isn't pinned (specs/evidence.md). */
  outcome: "proven" | "not-proven" | "unpinned" | "invalid";
  /** True when `outcome` is `proven`. */
  proven: boolean;
  /** The policy the outcome holds under: its ID and words. */
  policyId: string;
  policyWords: string[];
  /** The evidence kind (specs/evidence.md). */
  kind: string;
  /** The party the evidence blames, by the policy's party names. */
  parties: string[];
  reasons: Reason[];
}

/** What `<vitrine-alert>` shows: a proven failure and its evidence file. */
export interface EvidenceSummary {
  kind: string;
  /** The evidence file, as text (a block document). */
  file: string;
  result: EvidenceResult;
  /** Monitor URLs from the policy that accept evidence. */
  monitors: string[];
}
