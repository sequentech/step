// SPDX-License-Identifier: Apache-2.0
//
// Byte helpers: strict UTF-8, concatenation, comparison and big-endian
// integers. Sizes and indices are bigints below 2^63 (IT-25); times are
// numbers of seconds.

import { fail } from "./errors.js";

const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });

export const MAX_U63 = (1n << 63n) - 1n;
export const MAX_U64 = (1n << 64n) - 1n;

/** UTF-8 encoding of a well-formed string (lone surrogates are rejected). */
export function utf8(s: string): Uint8Array {
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c >= 0xd800 && c <= 0xdbff) {
      const d = s.charCodeAt(i + 1);
      if (!(d >= 0xdc00 && d <= 0xdfff)) fail("bad-text", { detail: "lone-surrogate" });
      i++;
    } else if (c >= 0xdc00 && c <= 0xdfff) {
      fail("bad-text", { detail: "lone-surrogate" });
    }
  }
  return encoder.encode(s);
}

/** Strict UTF-8 decoding: invalid sequences are an error, a BOM is kept. */
export function fromUtf8(b: Uint8Array): string {
  try {
    return decoder.decode(b);
  } catch {
    return fail("bad-text", { detail: "utf-8" });
  }
}

/** Latin-1 view of ASCII bytes, for parsers that only accept ASCII. */
export function ascii(b: Uint8Array): string {
  let s = "";
  for (let i = 0; i < b.length; i++) {
    const c = b[i]!;
    if (c > 0x7e) fail("bad-text", { detail: "non-ascii" });
    s += String.fromCharCode(c);
  }
  return s;
}

export function concat(...parts: Uint8Array[]): Uint8Array {
  let n = 0;
  for (const p of parts) n += p.length;
  const out = new Uint8Array(n);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return out;
}

export function equalBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i]! ^ b[i]!;
  return d === 0;
}

/** Lexicographic comparison, shorter first on a common prefix. */
export function compareBytes(a: Uint8Array, b: Uint8Array): number {
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    if (a[i] !== b[i]) return a[i]! - b[i]!;
  }
  return a.length - b.length;
}

export function u8(n: number): Uint8Array {
  return Uint8Array.of(n & 0xff);
}

export function u16be(n: number): Uint8Array {
  return Uint8Array.of((n >>> 8) & 0xff, n & 0xff);
}

export function u64be(n: bigint | number): Uint8Array {
  let v = BigInt(n);
  if (v < 0n || v > MAX_U64) throw new RangeError("u64 out of range");
  const out = new Uint8Array(8);
  for (let i = 7; i >= 0; i--) {
    out[i] = Number(v & 0xffn);
    v >>= 8n;
  }
  return out;
}

export function readU64(b: Uint8Array, off: number): bigint {
  if (off + 8 > b.length) fail("truncated");
  let v = 0n;
  for (let i = 0; i < 8; i++) v = (v << 8n) | BigInt(b[off + i]!);
  return v;
}

/** A u64 of seconds or milliseconds as a number; values beyond 2^53 become
 * Infinity, which every deadline treats as "in the future". */
export function u64ToNumber(v: bigint): number {
  return v <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(v) : Number.POSITIVE_INFINITY;
}

/** Parses an ASCII decimal with no leading zeros (except "0"), at most `max`. */
export function parseDecimal(s: string, max: bigint = MAX_U63): bigint {
  if (!/^(0|[1-9][0-9]{0,19})$/.test(s)) fail("bad-number", { value: s.slice(0, 32) });
  const v = BigInt(s);
  if (v > max) fail("bad-number", { value: s.slice(0, 32) });
  return v;
}

/** parseDecimal for small values (durations, thresholds, times). */
export function parseSmall(s: string, max: number = Number.MAX_SAFE_INTEGER): number {
  return Number(parseDecimal(s, BigInt(max)));
}

/** A bigint below 2^53 as a number (indices shown in results). */
export function bigToNumber(v: bigint): number {
  return v <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(v) : Number.MAX_SAFE_INTEGER;
}

/** A cursor over bytes for the TLS-style structures of the specs. */
export class Reader {
  private off = 0;
  constructor(private readonly b: Uint8Array) {}

  get remaining(): number {
    return this.b.length - this.off;
  }

  bytes(n: number): Uint8Array {
    if (n < 0 || this.off + n > this.b.length) fail("truncated");
    const out = this.b.subarray(this.off, this.off + n);
    this.off += n;
    return out;
  }

  u8(): number {
    return this.bytes(1)[0]!;
  }

  u16(): number {
    const b = this.bytes(2);
    return (b[0]! << 8) | b[1]!;
  }

  u24(): number {
    const b = this.bytes(3);
    return (b[0]! << 16) | (b[1]! << 8) | b[2]!;
  }

  u64(): bigint {
    const v = readU64(this.b, this.off);
    this.off += 8;
    return v;
  }

  end(): void {
    if (this.off !== this.b.length) fail("trailing-data");
  }
}
