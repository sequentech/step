// SPDX-License-Identifier: Apache-2.0
//
// Canonical JSON (RFC 8785) for the data-only manifests of the browser layer
// (specs/hub.md, section 6). ECMAScript's JSON.stringify is the reference
// serialisation for RFC 8785 strings and numbers; objects sort their keys by
// UTF-16 code units, which is JavaScript's default string order.

/** Serialises a JSON value canonically. Throws TypeError for values JSON
 * can't hold (non-finite numbers, undefined, functions). */
export function canonicalJson(v: unknown): string {
  if (v === null || typeof v === "boolean" || typeof v === "string") return JSON.stringify(v);
  if (typeof v === "number") {
    if (!Number.isFinite(v)) throw new TypeError("non-finite number in JSON");
    return JSON.stringify(v);
  }
  if (Array.isArray(v)) return `[${v.map(canonicalJson).join(",")}]`;
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    const keys = Object.keys(o).sort();
    return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(o[k])}`).join(",")}}`;
  }
  throw new TypeError("not a JSON value");
}

/** Parses JSON text that must already be in canonical form; returns
 * undefined when it isn't JSON or isn't canonical (duplicate keys, spacing,
 * key order or number forms). */
export function parseCanonicalJson(text: string): unknown {
  let v: unknown;
  try {
    v = JSON.parse(text);
  } catch {
    return undefined;
  }
  try {
    return canonicalJson(v) === text ? v : undefined;
  } catch {
    return undefined;
  }
}
