// SPDX-License-Identifier: Apache-2.0
//
// Every profile tag that the verifier knows (specs/entry.md, sections 4 and
// 5; specs/hub.md, section 2), the hash labels named after a profile, and
// the kinds of `events` entries, in one module. The other modules and the
// tests take them from here, so that renaming a profile (docs/decisions.md,
// decision 39) changes this file and the vectors, and nothing else by hand.
// Statement and file headers (`vitrine/policy-ack/v1` and the like) are
// formats, not profiles, and stay with their parsers.

/** Election ballots (specs/entry.md, section 4.1). */
export const ELECTION_TAG = "vitrine/election/ballots/v1";
/** Audit records (profiles/audit/v1). */
export const AUDIT_TAG = "vitrine/audit/v1";
/** A deployment's events: policies, configurations, milestones, notices
 * (specs/entry.md, section 5). */
export const EVENTS_TAG = "vitrine/events/v1";
export const ELECTION_EVENTS_TAG = "vitrine/election/events/v1";
export function isEventsTag(tag: string): boolean { return tag === EVENTS_TAG || tag === ELECTION_EVENTS_TAG; }
/** Keys logs (specs/profile.md, section 5.2). */
export const KEYS_TAG = "vitrine/keys/v1";
/** Release manifests (specs/entry.md, section 5.4). */
export const RELEASE_TAG = "vitrine/release/v1";
/** Registries (profiles/registry/v1). */
export const REGISTRY_TAG = "vitrine/registry/v1";

/** The tags of the six hub entry kinds (specs/hub.md, section 2). */
export const HUB_TAGS = {
  anchor: "vitrine/hub/v1",
  enroll: "vitrine/hub/v1/enroll",
  blinded: "vitrine/hub/v1/blinded",
  index: "vitrine/hub/v1/index",
  rotate: "vitrine/hub/v1/rotate",
  update: "vitrine/hub/v1/update",
} as const;

/** A hub's profile, as its logs and WAICT manifests name it: the tag of its
 * anchor entries. */
export const HUB_TAG = HUB_TAGS.anchor;

/** The labels of the hub map's hashes (specs/hub.md, sections 1 and 5): a
 * subject key, and a map value. */
export const HUB_SUBJECT_LABEL = "vitrine/hub/v1/subject";
export const HUB_VALUE_LABEL = "vitrine/hub/v1/value";

/** Generic deployment events. Domain-only kinds are excluded. */
export const EVENT_KINDS = {
  policy: "policy",
  checkpoint: "checkpoint",
  notice: "notice",
  redaction: "redaction",
  readAccess: "read-access",
  milestone: "milestone",
} as const;

/** Election events are a strict superset, retaining the specified order. */
export const ELECTION_EVENT_KINDS = {
  policy: "policy",
  config: "config",
  votingOpened: "voting-opened",
  votingClosed: "voting-closed",
  checkpoint: "checkpoint",
  tallyCommitment: "tally-commitment",
  results: "results",
  notice: "notice",
  redaction: "redaction",
  ballotVoid: "ballot-void",
  readAccess: "read-access",
  milestone: "milestone",
} as const;
