// SPDX-License-Identifier: Apache-2.0
//
// tlog-proofs (c2sp.org/tlog-proof, pinned at C2SP commit fea9004f) and the
// promise layout that reuses them (specs/receipt.md, sections 1 and 2).

import { b64decode, b64encode } from "./base64.js";
import { fromUtf8, parseDecimal, utf8 } from "./bytes.js";
import { fail } from "./errors.js";
import { MAX_INCLUSION_HASHES } from "./merkle.js";

export const TLOG_PROOF_HEADER = "c2sp.org/tlog-proof@v1";

export interface TlogProof {
  extra?: Uint8Array;
  index: bigint;
  proof: Uint8Array[];
  /** The checkpoint note, verbatim. */
  checkpoint: string;
}

/** Splits a "proof layout" document: a header line, keyed lines, hash lines,
 * an empty line and a note. Returns the keyed lines' values in order. */
export function parseProofLayout(
  input: Uint8Array | string,
  header: string,
  keys: readonly { key: string; optional: boolean }[],
  maxHashes: number,
): { values: (string | undefined)[]; hashes: Uint8Array[]; note: string } {
  const s = typeof input === "string" ? input : fromUtf8(input);
  if (typeof input === "string") utf8(input);
  let pos = 0;
  const next = (): string => {
    const nl = s.indexOf("\n", pos);
    if (nl < 0) fail("bad-proof", { detail: "truncated" });
    const line = s.slice(pos, nl);
    pos = nl + 1;
    return line;
  };
  if (next() !== header) fail("bad-proof", { detail: "header" });
  const values: (string | undefined)[] = [];
  let line = next();
  for (const k of keys) {
    const prefix = `${k.key} `;
    if (line.startsWith(prefix)) {
      values.push(line.slice(prefix.length));
      line = next();
    } else if (k.optional) {
      values.push(undefined);
    } else {
      fail("bad-proof", { detail: `missing-${k.key}` });
    }
  }
  const hashes: Uint8Array[] = [];
  while (line !== "") {
    if (hashes.length >= maxHashes) fail("too-large", { what: "proof-hashes", limit: maxHashes });
    hashes.push(b64decode(line, 32));
    line = next();
  }
  const note = s.slice(pos);
  if (note.length === 0) fail("bad-proof", { detail: "no-checkpoint" });
  return { values, hashes, note };
}

/** Serialises a tlog-proof (for tools and tests). */
export function formatTlogProof(p: TlogProof): string {
  const extra = p.extra === undefined ? "" : `extra ${b64encode(p.extra)}\n`;
  return `${TLOG_PROOF_HEADER}\n${extra}index ${p.index}\n${p.proof.map((h) => `${b64encode(h)}\n`).join("")}\n${p.checkpoint}`;
}

/** Parses a tlog-proof. Proofs with more than 63 hashes are rejected. */
export function parseTlogProof(input: Uint8Array | string): TlogProof {
  const { values, hashes, note } = parseProofLayout(
    input,
    TLOG_PROOF_HEADER,
    [
      { key: "extra", optional: true },
      { key: "index", optional: false },
    ],
    MAX_INCLUSION_HASHES,
  );
  const out: TlogProof = { index: parseDecimal(values[1]!), proof: hashes, checkpoint: note };
  if (values[0] !== undefined) out.extra = b64decode(values[0]);
  return out;
}
