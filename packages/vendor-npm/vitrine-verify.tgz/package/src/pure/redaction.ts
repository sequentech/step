// SPDX-License-Identifier: Apache-2.0
//
// Payloads and redaction (specs/redaction.md, sections 1 to 3). A payload is
// checked against its entry's commitment, H("vitrine/payload/v1" || salt ||
// payload) (specs/entry.md, section 2). A `vitrine/redaction/v1` notice
// restricts, erases or restores payloads without changing any leaf. It needs
// the signatures of the policy's `redaction` threshold. An entry's notices
// form a chain through their `previous` lines, and only the notices that
// continue the chain apply (section 2.1). A server that withholds a payload
// proves why with a notice bundle: the notice and a receipt for its `events`
// entry (section 3).

import type { Reason } from "../types.js";
import { b64decode, b64encode } from "./base64.js";
import { concat, equalBytes, parseDecimal, parseSmall, u64be, utf8 } from "./bytes.js";
import { formatBlockDoc, parseBlockDoc, pickBlocks, type Block } from "./blocks.js";
import { checkLayout, FIELD_COMMITMENT, fieldText, fieldValue, layoutOf, parseEntry, type Entry } from "./entry.js";
import { fail, reason, toReason, VerifyError, type Params } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { eventsLogName, judgeCheckpoint, logKeys, PolicyHistory } from "./history.js";
import { ELECTION_TAG, EVENT_KINDS, EVENTS_TAG, HUB_TAGS, isEventsTag } from "./tags.js";
import { verifyInclusion } from "./merkle.js";
import { isValidKeyName, parseNote, verifyNote, type Note } from "./note.js";
import { isReservedOrigin, profileAt, type Authority, type Policy, type PolicyLog, type Threshold } from "./policy.js";
import { asCode } from "./statements.js";
import { parseTlogProof, type TlogProof } from "./tlogproof.js";

export const NOTICE_HEADER = "vitrine/redaction/v1";
export const NOTICE_BUNDLE_HEADER = "vitrine/notice-bundle/v1";
export const PAYLOAD_BUNDLE_HEADER = "vitrine/payload-bundle/v1";
/** The hash label of payload commitments (specs/entry.md, section 1). */
export const PAYLOAD_LABEL = "vitrine/payload/v1";
export const PAYLOAD_MEDIA_TYPE = "application/vnd.vitrine.payload";
export const PAYLOAD_BUNDLE_MEDIA_TYPE = "application/vnd.vitrine.payload-bundle";
/** A payload bundle covers this many entries (section 1.1). */
export const PAYLOAD_BUNDLE_ENTRIES = 256;
export const SALT_BYTES = 32;
/** A notice's `basis` is at most this many bytes (section 2). */
export const MAX_BASIS_BYTES = 200;
export const NOTICE_ACTIONS = ["restrict", "erase", "restore"] as const;
export const NOTICE_REASONS = ["personal-data", "court-order", "illegal-content", "secret", "other"] as const;

export type NoticeAction = (typeof NOTICE_ACTIONS)[number];
export type NoticeReason = (typeof NOTICE_REASONS)[number];
/** The state of one payload (section 1). */
export type PayloadState = "public" | "restricted" | "erased";

const HUB_TAG_SET: ReadonlySet<string> = new Set(Object.values(HUB_TAGS));

// ---------------------------------------------------------------------------
// Section 1: payloads

/** H("vitrine/payload/v1" || salt || payload), the commitment an entry holds
 * for a payload (specs/entry.md, section 2). For tools that build entries. */
export function payloadCommitment(salt: Uint8Array, payload: Uint8Array): Uint8Array {
  if (salt.length !== SALT_BYTES) throw new TypeError("a payload salt is 32 bytes");
  return sha256(PAYLOAD_LABEL, salt, payload);
}

/** True when `salt` and `payload` open `commitment` (section 1.1). */
export function checkPayload(commitment: Uint8Array, salt: Uint8Array, payload: Uint8Array): boolean {
  return commitment.length === 32 && salt.length === SALT_BYTES && equalBytes(sha256(PAYLOAD_LABEL, salt, payload), commitment);
}

/** Opens a payload body, the 32-byte salt then the payload, as a `payload`
 * block or `GET <log>/payload/<index>/<field>` serves it (sections 1.1 and
 * 1.2). Returns the payload. Throws `payload-mismatch` when it doesn't open
 * `commitment`. */
export function openPayload(commitment: Uint8Array, body: Uint8Array): Uint8Array {
  if (body.length < SALT_BYTES) fail("payload-mismatch", { detail: "short" });
  const salt = body.subarray(0, SALT_BYTES);
  const payload = body.subarray(SALT_BYTES);
  if (!checkPayload(commitment, salt, payload)) fail("payload-mismatch", { detail: "commitment" });
  return payload;
}

/** A `payload` block: a payload the bundle serves. */
export interface PayloadBlock {
  kind: "payload";
  index: bigint;
  field: number;
  salt: Uint8Array;
  payload: Uint8Array;
}

/** A `withheld` block: a payload the server withholds under a notice. */
export interface WithheldBlock {
  kind: "withheld";
  index: bigint;
  field: number;
  state: "restricted" | "erased";
  /** The index of the notice's entry in the `events` log, for `GET
   * <log>/notice/<index>`. */
  notice: bigint;
}

export interface PayloadBundle {
  /** The log's origin. */
  log: string;
  /** The first index of the bundle's range, `256 N`. */
  start: bigint;
  /** The `payload` and `withheld` blocks, in index and field order. */
  blocks: (PayloadBlock | WithheldBlock)[];
}

const badBundle = (detail: string, p: Params = {}): never => fail("bad-payload-bundle", { detail, ...p });

/** Parses a `vitrine/payload-bundle/v1` document (section 1.1). Blocks must
 * be in strictly increasing index and field order, within the bundle's 256
 * entries. Unknown block types are ignored. The spec sets no size limit, so
 * none applies here: the caller already holds the bytes. */
export function parsePayloadBundle(input: Uint8Array | string): PayloadBundle {
  const doc = parseBlockDoc(input, {
    header: PAYLOAD_BUNDLE_HEADER,
    keys: ["log", "start"],
    code: "bad-payload-bundle",
    maxSize: Number.POSITIVE_INFINITY,
    maxBlock: Number.MAX_SAFE_INTEGER,
  });
  const [logArgs, startArgs] = doc.values as [string[], string[]];
  if (logArgs.length !== 1) badBundle("line-log");
  if (startArgs.length !== 1) badBundle("line-start");
  const log = logArgs[0]!;
  if (!isValidKeyName(log) || isReservedOrigin(log)) badBundle("log");
  const start = asCode("bad-payload-bundle", () => parseDecimal(startArgs[0]!));
  if (start % BigInt(PAYLOAD_BUNDLE_ENTRIES) !== 0n) badBundle("start");
  const end = start + BigInt(PAYLOAD_BUNDLE_ENTRIES);
  const out: PayloadBundle = { log, start, blocks: [] };
  let last: { index: bigint; field: number } | undefined;
  doc.blocks.forEach((b, i) => {
    if (b.type !== "payload" && b.type !== "withheld") return;
    const want = b.type === "payload" ? 2 : 4;
    if (b.args.length !== want) badBundle(`arguments-${b.type}`, { block: i });
    const { index, field } = asCode("bad-payload-bundle", () => ({ index: parseDecimal(b.args[0]!), field: parseSmall(b.args[1]!, 0xffff) }));
    if (index < start || index >= end) badBundle("index-range", { block: i });
    if (last && (index < last.index || (index === last.index && field <= last.field))) badBundle("order", { block: i });
    last = { index, field };
    if (b.type === "payload") {
      if (b.body.length < SALT_BYTES) badBundle("salt", { block: i });
      out.blocks.push({ kind: "payload", index, field, salt: b.body.slice(0, SALT_BYTES), payload: b.body.slice(SALT_BYTES) });
      return;
    }
    const state = b.args[2]!;
    if (state !== "restricted" && state !== "erased") badBundle("state", { block: i });
    if (b.body.length !== 0) badBundle("withheld-body", { block: i });
    const notice = asCode("bad-payload-bundle", () => parseDecimal(b.args[3]!));
    out.blocks.push({ kind: "withheld", index, field, state: state as WithheldBlock["state"], notice });
  });
  return out;
}

/** Serialises a payload bundle (for tools and tests). */
export function formatPayloadBundle(b: PayloadBundle): Uint8Array {
  const blocks: Block[] = b.blocks.map((x) =>
    x.kind === "payload"
      ? { type: "payload", args: [String(x.index), String(x.field)], body: concat(x.salt, x.payload) }
      : { type: "withheld", args: [String(x.index), String(x.field), x.state, String(x.notice)], body: new Uint8Array(0) },
  );
  return formatBlockDoc(PAYLOAD_BUNDLE_HEADER, [`log ${b.log}`, `start ${b.start}`], blocks);
}

/** One commitment field of an entry, as a payload bundle covers it. */
export interface PayloadCheck {
  index: bigint;
  field: number;
  /** The commitment the entry holds. */
  commitment: Uint8Array;
  /** `ok`: the bundle serves a payload that opens the commitment.
   * `mismatch`: it serves one that doesn't (a `payload-mismatch` report).
   * `withheld`: it withholds the payload; check the notice bundle with
   * verifyWithheld, and report `payload-missing` if it doesn't verify.
   * `missing`: the bundle has no block for the field (`payload-missing`). */
  status: "ok" | "mismatch" | "withheld" | "missing";
  /** `ok`: the payload. Render it as text, never as markup. */
  payload?: Uint8Array;
  /** `withheld`: what the bundle says. */
  withheld?: Pick<WithheldBlock, "state" | "notice">;
  /** `mismatch`: SHA-256 of the salt then the served bytes, which a
   * `payload-mismatch` report carries instead of the bytes (threat model,
   * IT-21). */
  served?: Uint8Array;
  /** `payload-mismatch` or `payload-missing`, for `mismatch` and `missing`. */
  reasons: Reason[];
}

/** Checks a payload bundle against the entries it covers (section 1.1):
 * `entries` are the entries from index `start` of the bundle on, as entry
 * bundle `N` holds them. Every commitment field of each entry gets one
 * result, in index and field order. Blocks for indices past `entries` are
 * left unchecked. Throws `bad-payload-bundle` when the bundle is malformed,
 * is for another log or bundle number, or has a block for a field that isn't
 * a commitment. */
export function checkPayloadBundle(
  input: Uint8Array | string,
  log: Pick<PolicyLog, "origin">,
  entries: readonly (Uint8Array | Entry)[],
  n?: bigint,
): PayloadCheck[] {
  const b = parsePayloadBundle(input);
  if (b.log !== log.origin) badBundle("log");
  if (n !== undefined && b.start !== n * BigInt(PAYLOAD_BUNDLE_ENTRIES)) badBundle("start");
  if (entries.length > PAYLOAD_BUNDLE_ENTRIES) throw new TypeError(`a payload bundle covers ${PAYLOAD_BUNDLE_ENTRIES} entries`);
  const blocks = new Map<string, PayloadBlock | WithheldBlock>();
  for (const x of b.blocks) blocks.set(`${x.index} ${x.field}`, x);
  const out: PayloadCheck[] = [];
  entries.forEach((raw, i) => {
    const index = b.start + BigInt(i);
    const e = raw instanceof Uint8Array ? parseEntry(raw) : raw;
    e.fields.forEach((f, field) => {
      if (f.kind !== FIELD_COMMITMENT) {
        if (blocks.has(`${index} ${field}`)) badBundle("not-commitment", { index: Number(index), field });
        return;
      }
      const key = `${index} ${field}`;
      const x = blocks.get(key);
      blocks.delete(key);
      const c: PayloadCheck = { index, field, commitment: f.value, status: "missing", reasons: [] };
      if (!x) {
        c.reasons.push(reason("payload-missing", { index: Number(index), field }));
      } else if (x.kind === "withheld") {
        c.status = "withheld";
        c.withheld = { state: x.state, notice: x.notice };
      } else if (checkPayload(f.value, x.salt, x.payload)) {
        c.status = "ok";
        c.payload = x.payload;
      } else {
        c.status = "mismatch";
        c.served = sha256(x.salt, x.payload);
        c.reasons.push(reason("payload-mismatch", { index: Number(index), field }));
      }
      out.push(c);
    });
  });
  // A block left over names an entry the caller has: no such field exists.
  const end = b.start + BigInt(entries.length);
  for (const x of blocks.values()) if (x.index < end) badBundle("not-commitment", { index: Number(x.index), field: x.field });
  return out;
}

// ---------------------------------------------------------------------------
// Section 2: notices

export interface NoticeField {
  /** The field's position in the entry. */
  field: number;
  /** Its commitment, as the entry holds it. */
  commitment: Uint8Array;
}

export interface Notice {
  /** The origin of the log that holds the entry. */
  log: string;
  index: bigint;
  /** In increasing field order; at least one. */
  fields: NoticeField[];
  action: NoticeAction;
  reason: NoticeReason;
  /** The legal basis, at most 200 bytes. Render it as text. */
  basis: string;
  /** The leaf hash of the `events` entry of the latest notice that applied
   * to the entry; undefined for `previous none`. */
  previous?: Uint8Array;
  time: number;
  note: Note;
}

/** The lines of a notice, in order; `field` is repeatable. */
const NOTICE_LINES = ["log", "index", "field", "action", "reason", "basis", "previous", "time"] as const;

const badNotice = (detail: string, p: Params = {}): never => fail("bad-notice", { detail, ...p });

/** A notice's `<key> <value>` lines: every key at least once, in order, and
 * only `field` more than once. */
function noticeLines(text: string): Map<string, string[]> {
  if (!text.endsWith("\n")) badNotice("no-final-newline");
  const lines = text.slice(0, -1).split("\n");
  if (lines[0] !== NOTICE_HEADER) badNotice("header");
  const out = new Map<string, string[]>(NOTICE_LINES.map((k) => [k, []]));
  let at = 0;
  for (const l of lines.slice(1)) {
    const sp = l.indexOf(" ");
    const key = sp < 0 ? l : l.slice(0, sp);
    const j = (NOTICE_LINES as readonly string[]).indexOf(key, at);
    if (j < 0 || sp < 0) badNotice(`line-${key.slice(0, 32)}`);
    // Passing a key leaves it behind: it must have been seen.
    for (; at < j; at++) if (out.get(NOTICE_LINES[at]!)!.length === 0) badNotice(`missing-${NOTICE_LINES[at]!}`);
    const values = out.get(key)!;
    if (key !== "field" && values.length > 0) badNotice(`repeated-${key}`);
    values.push(l.slice(sp + 1));
  }
  for (; at < NOTICE_LINES.length; at++) if (out.get(NOTICE_LINES[at]!)!.length === 0) badNotice(`missing-${NOTICE_LINES[at]!}`);
  return out;
}

/** Parses a `vitrine/redaction/v1` notice (section 2) without checking its
 * signatures. Throws `bad-notice`. */
export function parseNotice(input: Uint8Array | string): Notice {
  return asCode("bad-notice", () => {
    const note = parseNote(input);
    const m = noticeLines(note.text);
    const one = (k: string): string => m.get(k)![0]!;
    const value = <T>(detail: string, f: () => T): T => {
      try {
        return f();
      } catch (e) {
        if (e instanceof VerifyError) return badNotice(detail);
        throw e;
      }
    };
    const log = one("log");
    if (!isValidKeyName(log) || isReservedOrigin(log)) badNotice("log");
    const index = value("index", () => parseDecimal(one("index")));
    const fields = m.get("field")!.map((v) =>
      value("field", () => {
        const parts = v.split(" ");
        if (parts.length !== 2) throw new VerifyError("bad-notice");
        return { field: parseSmall(parts[0]!, 0xffff), commitment: b64decode(parts[1]!, 32) };
      }),
    );
    for (let i = 1; i < fields.length; i++) if (fields[i]!.field <= fields[i - 1]!.field) badNotice("field-order");
    const action = one("action");
    if (!(NOTICE_ACTIONS as readonly string[]).includes(action)) badNotice("action");
    const why = one("reason");
    if (!(NOTICE_REASONS as readonly string[]).includes(why)) badNotice("reason");
    const basis = one("basis");
    const basisBytes = utf8(basis).length;
    if (basisBytes === 0 || basisBytes > MAX_BASIS_BYTES) badNotice("basis", { length: basisBytes, limit: MAX_BASIS_BYTES });
    const prev = one("previous");
    const previous = prev === "none" ? undefined : value("previous", () => b64decode(prev, 32));
    const time = value("time", () => parseSmall(one("time")));
    const n: Notice = { log, index, fields, action: action as NoticeAction, reason: why as NoticeReason, basis, time, note };
    if (previous) n.previous = previous;
    return n;
  });
}

/** A notice's text (for tools and tests). */
export function formatNoticeText(n: Omit<Notice, "note">): string {
  const fields = n.fields.map((f) => `field ${f.field} ${b64encode(f.commitment)}\n`).join("");
  const previous = n.previous ? b64encode(n.previous) : "none";
  return `${NOTICE_HEADER}\nlog ${n.log}\nindex ${n.index}\n${fields}action ${n.action}\nreason ${n.reason}\nbasis ${n.basis}\nprevious ${previous}\ntime ${n.time}\n`;
}

/** The members of `threshold` whose keys, among `authorities`, verify
 * `note`, in the threshold's order. Members with the same key count once,
 * so each signer is a distinct key. */
export function noticeSigners(note: Note, threshold: Threshold, authorities: ReadonlyMap<string, Authority>): string[] {
  const members = threshold.names.map((name) => authorities.get(name)).filter((a): a is Authority => a !== undefined);
  const verified = verifyNote(
    note,
    members.map((a) => a.vkey),
  );
  const seen = new Set<string>();
  const out: string[] = [];
  for (const a of members) {
    if (seen.has(a.vkey.text) || !verified.some((v) => v.vkey === a.vkey)) continue;
    seen.add(a.vkey.text);
    out.push(a.name);
  }
  return out;
}

/** Checks that `note` carries valid signatures from at least `k` members of
 * a policy's `redaction` threshold (section 2). Returns the signers. Throws
 * `notice-unsigned`, also when there is no threshold: without a `redaction`
 * line, redaction isn't allowed. */
export function checkNoticeApprovals(note: Note, threshold: Threshold | undefined, authorities: ReadonlyMap<string, Authority>): string[] {
  if (!threshold) return fail("notice-unsigned", { detail: "no-redaction" });
  const signers = noticeSigners(note, threshold, authorities);
  if (signers.length < threshold.k) fail("notice-unsigned", { have: signers.length, need: threshold.k });
  return signers;
}

export interface VerifiedNotice extends Notice {
  /** The redaction approvers whose signatures verify, in the policy's order. */
  signers: string[];
}

/** Verifies a notice under `policy` (section 2): it parses, carries the
 * signatures of the policy's `redaction` threshold, and names a log of the
 * policy, an entry that isn't a `vitrine/election/ballots/v1` or hub entry, and, for
 * a core profile, only commitment fields. Throws `bad-notice`,
 * `notice-unsigned` or `notice-mismatch`. */
export function verifyNotice(input: Uint8Array | string, policy: Policy): VerifiedNotice {
  const n = parseNotice(input);
  const signers = checkNoticeApprovals(n.note, policy.redaction, policy.authorities);
  const log = [...policy.logs.values()].find((l) => l.origin === n.log);
  if (!log) fail("notice-mismatch", { detail: "log" });
  const tag = profileAt(log, n.index).tag;
  if (tag === ELECTION_TAG || HUB_TAG_SET.has(tag)) fail("notice-mismatch", { detail: "profile" });
  const layout = layoutOf(tag);
  for (const f of n.fields) if (layout && layout[f.field]?.kind !== "commitment") fail("notice-mismatch", { detail: "not-commitment", field: f.field });
  return { ...n, signers };
}

// ---------------------------------------------------------------------------
// Section 2.1: which notices apply

/** A notice that applied, with its `events` entry. */
export interface AppliedNotice {
  notice: Notice;
  /** The leaf hash of the notice's `events` entry. */
  leaf: Uint8Array;
  /** That entry's sequencing time (specs/receipt.md, section 1.3). */
  sequenced: number;
}

export type NoticeOutcome = { applies: true } | { applies: false; reason: Reason };

/** One entry's notices, taken in `events`-log order (section 2.1). A notice
 * applies only when its `previous` names the latest notice that applied (or
 * is `none` while none has), no notice with the same text applied before,
 * and, after a first notice, its `time` is after that notice's sequencing
 * time. One that doesn't apply has no effect. The chain also tracks each
 * field's payload state: `restrict` makes a public payload restricted,
 * `restore` makes a restricted one public, and `erase` is final. */
export class NoticeChain {
  private target: { log: string; index: bigint } | undefined;
  readonly applied: AppliedNotice[] = [];
  private readonly texts = new Set<string>();
  private readonly states = new Map<number, PayloadState>();

  /** `entry` is the entry the chain is for; without it, the first notice
   * taken names it. */
  constructor(entry?: { log: string; index: bigint }) {
    if (entry) this.target = { log: entry.log, index: entry.index };
  }

  /** The entry the chain is for, once known. */
  get entry(): { log: string; index: bigint } | undefined {
    return this.target ? { ...this.target } : undefined;
  }

  /** The latest notice that applied. */
  latest(): AppliedNotice | undefined {
    return this.applied[this.applied.length - 1];
  }

  /** Takes the next notice of the entry, whose `events` entry has leaf hash
   * `leaf` and was sequenced at `sequenced`. A notice that doesn't apply
   * gives `notice-not-applied`, with a `detail`: `other-entry`,
   * `previous-none`, `previous-unknown` (it names a notice while none has
   * applied), `previous-stale` (it names another than the latest),
   * `replayed` or `time-not-after`. */
  apply(notice: Notice, leaf: Uint8Array, sequenced: number): NoticeOutcome {
    if (leaf.length !== 32) throw new TypeError("a leaf hash is 32 bytes");
    const no = (detail: string): NoticeOutcome => ({ applies: false, reason: reason("notice-not-applied", { detail }) });
    if (!this.target) this.target = { log: notice.log, index: notice.index };
    else if (notice.log !== this.target.log || notice.index !== this.target.index) return no("other-entry");
    const last = this.latest();
    if (notice.previous === undefined) {
      if (last) return no("previous-none");
    } else {
      if (!last) return no("previous-unknown");
      if (!equalBytes(notice.previous, last.leaf)) return no("previous-stale");
    }
    if (this.texts.has(notice.note.text)) return no("replayed");
    if (last && !(notice.time > last.sequenced)) return no("time-not-after");
    this.applied.push({ notice, leaf: leaf.slice(), sequenced });
    this.texts.add(notice.note.text);
    for (const f of notice.fields) this.states.set(f.field, nextState(this.state(f.field), notice.action));
    return { applies: true };
  }

  /** The payload state of field `field` after the notices that applied. */
  state(field: number): PayloadState {
    return this.states.get(field) ?? "public";
  }
}

function nextState(s: PayloadState, a: NoticeAction): PayloadState {
  if (s === "erased" || a === "erase") return "erased";
  return a === "restrict" ? "restricted" : "public";
}

// ---------------------------------------------------------------------------
// Section 3: notice bundles

export interface NoticeBundle {
  notice: Uint8Array;
  /** The receipt for the notice's entry in the `events` log. */
  receipt: Uint8Array;
}

const badNoticeBundle = (detail: string, p: Params = {}): never => fail("bad-notice-bundle", { detail, ...p });

/** Parses a `vitrine/notice-bundle/v1` document (section 3). Unknown block
 * types are ignored. */
export function parseNoticeBundle(input: Uint8Array | string): NoticeBundle {
  const doc = parseBlockDoc(input, { header: NOTICE_BUNDLE_HEADER, keys: [], code: "bad-notice-bundle" });
  const b = pickBlocks(doc.blocks, { notice: 0, receipt: 0 }, "bad-notice-bundle");
  const notice = b.get("notice");
  const receipt = b.get("receipt");
  if (!notice) return badNoticeBundle("missing-notice");
  if (!receipt) return badNoticeBundle("missing-receipt");
  return { notice: notice.body, receipt: receipt.body };
}

/** Serialises a notice bundle (for tools and tests). */
export function formatNoticeBundle(b: NoticeBundle): Uint8Array {
  return formatBlockDoc(NOTICE_BUNDLE_HEADER, [], [
    { type: "notice", args: [], body: b.notice },
    { type: "receipt", args: [], body: b.receipt },
  ]);
}

/** The withheld payload a notice bundle must account for. */
export interface NoticeTarget {
  /** The policy's name for the log that holds the entry. */
  log: string;
  index: bigint;
  field: number;
  /** The commitment the entry holds for the field. */
  commitment: Uint8Array;
}

export interface VerifyNoticeBundleOptions {
  /** The pinned policy with the successors the client applied. Default: the
   * pinned policy alone. */
  history?: PolicyHistory;
  /** The device clock, POSIX seconds (default: now). Cosignatures dated more
   * than 300 seconds after it don't count. */
  now?: number;
}

export interface VerifiedNoticeBundle {
  notice: VerifiedNotice;
  /** The `events` log's name. */
  eventsLog: string;
  /** The index of the notice's entry in the `events` log. */
  entryIndex: bigint;
  /** That entry's leaf hash, which the entry's next notice names as
   * `previous`. */
  leaf: Uint8Array;
  /** The quorum time of the receipt's checkpoint: the entry was sequenced
   * at or before it. */
  quorumTime: number;
  /** The policy in force at that quorum time, whose `redaction` threshold
   * verified the notice. */
  policy: Policy;
}

/** The `ref` subject of an entry: type 3, its log's origin, then its index
 * (specs/entry.md, section 3). */
function refSubject(origin: string, index: bigint): Uint8Array {
  const o = utf8(origin);
  return concat(Uint8Array.of(3, o.length), o, u64be(index));
}

/** Verifies a notice bundle for a withheld payload (section 3): its receipt
 * verifies in the `events` log (specs/receipt.md, section 1.1) against a
 * checkpoint that meets the quorum, for a `redaction` entry whose subject is
 * the withheld entry and whose statement is the notice; the notice verifies
 * under the policy in force at that checkpoint's quorum time and names this
 * entry, field and commitment. It doesn't show that the notice still
 * applies: only a reader of the `events` log sees a later one. Throws
 * `bad-notice-bundle`, `bad-notice`, `notice-unsigned` or
 * `notice-mismatch`. */
export function verifyNoticeBundle(input: Uint8Array | string, policy: Policy, target: NoticeTarget, opts: VerifyNoticeBundleOptions = {}): VerifiedNoticeBundle {
  const h = opts.history ?? new PolicyHistory(policy);
  if (h.pinned.id !== policy.id) throw new TypeError("opts.history is for another pinned policy");
  const now = opts.now ?? Math.floor(Date.now() / 1000);
  const b = parseNoticeBundle(input);
  const events = eventsLogName(h.at(now)) ?? eventsLogName(policy);
  if (events === undefined) return badNoticeBundle("no-events-log");
  const cause = (detail: string) => (e: unknown): never => badNoticeBundle(detail, { cause: toReason(e).code });
  let tp: TlogProof;
  try {
    tp = parseTlogProof(b.receipt);
  } catch (e) {
    return cause("receipt")(e);
  }
  if (!tp.extra) return badNoticeBundle("missing-extra");
  const extra = tp.extra;
  let judged: ReturnType<typeof judgeCheckpoint>;
  try {
    judged = judgeCheckpoint(h, tp.checkpoint, logKeys(events), now, { requireLogTime: true });
  } catch (e) {
    return cause("checkpoint")(e);
  }
  if (!judged.meets) badNoticeBundle("quorum-not-met");
  const cp = judged.value.cp;
  const leaf = leafHash(extra);
  if (tp.index >= cp.size || !verifyInclusion(tp.index, cp.size, leaf, tp.proof, cp.root)) badNoticeBundle("inclusion-failed");
  let entry: Entry;
  try {
    entry = parseEntry(extra);
    checkLayout(entry);
  } catch (e) {
    return cause("entry")(e);
  }
  const el = judged.policy.logs.get(events)!;
  if (!isEventsTag(entry.tag) || entry.tag !== profileAt(el, tp.index).tag) badNoticeBundle("wrong-profile");
  if (fieldText(entry, "kind") !== EVENT_KINDS.redaction) badNoticeBundle("kind");
  const statement = fieldValue(entry, "statement");
  if (!statement || statement.length === 0) return badNoticeBundle("statement");
  const notice = verifyNotice(b.notice, judged.policy);
  let logged: string;
  try {
    logged = parseNote(statement).text;
  } catch (e) {
    return cause("statement")(e);
  }
  const mismatch = (detail: string): never => fail("notice-mismatch", { detail });
  if (logged !== notice.note.text) mismatch("statement");
  if (!equalBytes(fieldValue(entry, "subject")!, refSubject(notice.log, notice.index))) mismatch("subject");
  // The log's origin under any policy of the history, since a successor may
  // rename it.
  if (!h.epochs.some((e) => e.policy.logs.get(target.log)?.origin === notice.log)) mismatch("log");
  if (notice.index !== target.index) mismatch("index");
  const f = notice.fields.find((x) => x.field === target.field);
  if (!f) return mismatch("field");
  if (!equalBytes(f.commitment, target.commitment)) mismatch("commitment");
  return { notice, eventsLog: events, entryIndex: tp.index, leaf, quorumTime: judged.quorumTime!, policy: judged.policy };
}

/** Verifies the notice bundle for a payload that a server withholds: a
 * `withheld` block of a payload bundle (fetch the bundle with `GET
 * <log>/notice/<notice>`), or a 451 or 410 answer from `GET
 * <log>/payload/<index>/<field>` (section 1.2), whose body is the bundle.
 * Besides verifyNoticeBundle's checks, the notice's action gives the state
 * (`restrict` for `restricted`, `erase` for `erased`) and, when `notice` is
 * given, its entry is the one the block names. A failure is reported as
 * `payload-missing` (section 3). Throws like verifyNoticeBundle. */
export function verifyWithheld(
  input: Uint8Array | string,
  policy: Policy,
  target: NoticeTarget & { state: "restricted" | "erased"; notice?: bigint },
  opts: VerifyNoticeBundleOptions = {},
): VerifiedNoticeBundle {
  const v = verifyNoticeBundle(input, policy, target, opts);
  if (target.notice !== undefined && v.entryIndex !== target.notice) fail("notice-mismatch", { detail: "notice-index" });
  if (v.notice.action !== (target.state === "restricted" ? "restrict" : "erase")) fail("notice-mismatch", { detail: "action" });
  return v;
}
