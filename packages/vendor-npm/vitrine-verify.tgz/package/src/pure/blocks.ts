// SPDX-License-Identifier: Apache-2.0
//
// Block documents (specs/receipt.md, section 3): a header line, keyed lines,
// then blocks, each `<type> <args...> <length>`, a newline, exactly `length`
// bytes and a newline. Receipt chains, hub links, browser anchors, openings
// and evidence files share this framing.

import type { ReasonCode } from "../codes.js";
import { b64decode, b64encode } from "./base64.js";
import { concat, fromUtf8, parseDecimal, utf8 } from "./bytes.js";
import { fail } from "./errors.js";

/** Blocks are at most 1 MiB, and documents at most 4 MiB. */
export const MAX_BLOCK_SIZE = 1 << 20;
export const MAX_DOC_SIZE = 4 << 20;

export interface Block {
  type: string;
  args: string[];
  body: Uint8Array;
}

export interface BlockDocFormat {
  /** The first line, exactly. */
  header: string;
  /** Keywords of the lines between the header and the first block, in order;
   * each line is the keyword and at least one argument. */
  keys: readonly string[];
  /** The reason code for framing errors. */
  code: ReasonCode;
  /** The document's size limit (default 4 MiB); Infinity for none. */
  maxSize?: number;
  /** Each block's size limit (default 1 MiB). */
  maxBlock?: number;
}

export interface BlockDoc {
  /** The arguments of each keyed line, in the order of `keys`. */
  values: string[][];
  blocks: Block[];
}

/** Parses a block document. Unknown block types are returned like the others;
 * callers ignore the ones they don't know. */
export function parseBlockDoc(input: Uint8Array | string, f: BlockDocFormat): BlockDoc {
  const bytes = typeof input === "string" ? utf8(input) : input;
  const maxSize = f.maxSize ?? MAX_DOC_SIZE;
  const maxBlock = f.maxBlock ?? MAX_BLOCK_SIZE;
  if (bytes.length > maxSize) fail("too-large", { what: f.header, limit: maxSize });
  const bad = (detail: string): never => fail(f.code, { detail });
  let pos = 0;
  const line = (): string => {
    const nl = bytes.indexOf(0x0a, pos);
    if (nl < 0) bad("truncated");
    const raw = bytes.subarray(pos, nl);
    pos = nl + 1;
    let s = "";
    try {
      s = fromUtf8(raw);
    } catch {
      bad("text");
    }
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c < 0x20 || c === 0x7f) bad("control-character");
    }
    return s;
  };
  const tokens = (l: string, what: string): string[] => {
    const t = l.split(" ");
    if (t.length < 2 || t.some((x) => x === "")) bad(what);
    return t;
  };
  if (line() !== f.header) bad("header");
  const values: string[][] = [];
  for (const k of f.keys) {
    const t = tokens(line(), `line-${k}`);
    if (t[0] !== k) bad(`line-${k}`);
    values.push(t.slice(1));
  }
  const blocks: Block[] = [];
  while (pos < bytes.length) {
    const t = tokens(line(), "block-header");
    let len = 0n;
    try {
      len = parseDecimal(t[t.length - 1]!);
    } catch {
      bad("block-length");
    }
    // A document without a total limit (maxSize Infinity) still has one per block.
    if (len > BigInt(Math.min(maxSize, Number.MAX_SAFE_INTEGER))) bad("block-length");
    if (len > BigInt(maxBlock)) fail("too-large", { what: "block", limit: maxBlock });
    const n = Number(len);
    if (pos + n + 1 > bytes.length) bad("truncated");
    if (bytes[pos + n] !== 0x0a) bad("block-terminator");
    blocks.push({ type: t[0]!, args: t.slice(1, -1), body: bytes.slice(pos, pos + n) });
    pos += n + 1;
  }
  return { values, blocks };
}

/** Serialises a block document. `lines` are the keyed lines, without their
 * newlines. */
export function formatBlockDoc(header: string, lines: readonly string[], blocks: readonly Block[]): Uint8Array {
  const parts: Uint8Array[] = [utf8(`${header}\n`)];
  for (const l of lines) parts.push(utf8(`${l}\n`));
  for (const b of blocks) {
    parts.push(utf8(`${[b.type, ...b.args, String(b.body.length)].join(" ")}\n`), b.body, Uint8Array.of(0x0a));
  }
  return concat(...parts);
}

/** A block body that holds base64 hashes, one per line (consistency proofs).
 * The final newline is optional and an empty body is an empty proof. */
export function parseHashLines(body: Uint8Array, max: number): Uint8Array[] {
  if (body.length === 0) return [];
  let s = fromUtf8(body);
  if (s.endsWith("\n")) s = s.slice(0, -1);
  const lines = s.split("\n");
  if (lines.length > max) fail("too-large", { what: "proof-hashes", limit: max });
  return lines.map((l) => b64decode(l, 32));
}

export function formatHashLines(hashes: readonly Uint8Array[]): Uint8Array {
  return utf8(hashes.map((h) => `${b64encode(h)}\n`).join(""));
}

/** A block body that holds one base64 value, with an optional final newline. */
export function parseBase64Body(body: Uint8Array): Uint8Array {
  let s = fromUtf8(body);
  if (s.endsWith("\n")) s = s.slice(0, -1);
  return b64decode(s);
}

/** Picks the blocks of known types: each at most once (duplicates fail with
 * `duplicate-block`), with the argument count the type needs (else `code`).
 * Unknown types are skipped. */
export function pickBlocks(
  blocks: readonly Block[],
  arity: Readonly<Record<string, number>>,
  code: ReasonCode,
): Map<string, Block> {
  const out = new Map<string, Block>();
  for (const b of blocks) {
    if (!Object.hasOwn(arity, b.type)) continue;
    const n = arity[b.type]!;
    if (b.args.length !== n) fail(code, { detail: `arguments-${b.type}` });
    if (out.has(b.type)) fail("duplicate-block", { type: b.type });
    out.set(b.type, b);
  }
  return out;
}
