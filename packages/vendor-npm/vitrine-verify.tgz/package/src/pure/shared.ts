// SPDX-License-Identifier: Apache-2.0
// Independent implementation of specs/shared.md. Admission storage/rates are
// server responsibilities; these helpers check the signed public objects.
import { b64decode, hexEncode } from "./base64.js";
import { concat, equalBytes, fromUtf8, parseDecimal, utf8 } from "./bytes.js";
import { FIELD_COMMITMENT, FIELD_PUBLIC, fieldText, fieldValue, isValidId, isValidTag, layoutOf, parseEntry, type Entry } from "./entry.js";
import { fail, VerifyError } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { isValidKeyName, parseNote, parseVkey, SIG_ED25519, verifyNote, type Note, type Vkey } from "./note.js";
import { isReservedOrigin, parsePolicy, type Policy } from "./policy.js";
import { parseMilestoneStatement } from "./config.js";
import { EVENTS_TAG, EVENT_KINDS, KEYS_TAG, REGISTRY_TAG, RELEASE_TAG } from "./tags.js";

export const SHARED_ENROLMENT_HEADER = "vitrine/shared-enroll/v1";
export const SHARED_AUTHORIZATION_HEADER = "vitrine/shared-authorization/v1";
export const SHARED_SUBMISSION_HEADER = "vitrine/shared-submit/v1";
export const MAX_SHARED_SUBMISSION_BYTES = 256 << 10;
const MAX_NOTE = 16 << 10;
const HASH_ID = /^sha256:[0-9a-f]{64}$/;
const NAMESPACE = /^[a-z][a-z0-9._-]{0,63}$/;
const ENROLMENT_KEYS = ["origin", "namespace", "serial", "previous", "key", "profile", "quota-bytes", "pending-bytes", "rate", "burst"] as const;
const AUTHORIZATION_KEYS = ["origin", "policy", "namespace", "enrolment", "leaf"] as const;
export interface SharedEnrolment {
  raw: string; note: Note; id: string; origin: string; namespace: string; serial: bigint; previous?: string;
  key: Vkey; profile: string; quotaBytes: bigint; pendingBytes: bigint; rate: bigint; burst: bigint;
}
export interface SharedAuthorization { raw: string; note: Note; origin: string; policy: string; namespace: string; enrolment: string; leaf: Uint8Array }
export interface SharedSubmission { authorization: SharedAuthorization; entry: Uint8Array; parsed: Entry; document?: Uint8Array }
function bad(detail: string): never { return fail("bad-shared-submission", { detail }); }
function refused(detail: string): never { return fail("shared-submission-refused", { detail }); }
function hashId(s: string): string { return HASH_ID.test(s) ? s : bad("hash-id"); }
function integer(s: string): bigint { try { return parseDecimal(s); } catch { return bad("integer"); } }
function namespace(s: string): string { return NAMESPACE.test(s) ? s : bad("namespace"); }
function statement(input: string | Uint8Array, header: string, keys: readonly string[]): { raw: string; note: Note; values: string[] } {
  const bytes = typeof input === "string" ? utf8(input) : input;
  if (bytes.length > MAX_NOTE) bad("note-size");
  const raw = typeof input === "string" ? input : fromUtf8(input);
  const note = parseNote(raw); const lines = note.text.slice(0, -1).split("\n");
  if (lines.length !== keys.length + 1 || lines[0] !== header) bad("statement-lines");
  const values = keys.map((key, i) => {
    const parts = lines[i + 1]!.split(" ");
    if (parts.length !== 2 || parts[0] !== key || !parts[1]) bad(`line-${key}`);
    return parts[1]!;
  });
  if (!values[0] || isReservedOrigin(values[0]) || !isValidKeyName(values[0])) bad("origin");
  return { raw, note, values };
}
function guarded<T>(f: () => T): T {
  try { return f(); } catch (error) {
    if (error instanceof VerifyError && error.code !== "bad-shared-submission" && error.code !== "shared-submission-refused") return bad(error.code);
    throw error;
  }
}

export function parseSharedEnrolment(input: string | Uint8Array): SharedEnrolment {
  return guarded(() => {
    const { raw, note, values: v } = statement(input, SHARED_ENROLMENT_HEADER, ENROLMENT_KEYS);
    const serial = integer(v[2]!); const previous = v[3] === "none" ? undefined : hashId(v[3]!);
    if (serial < 1n || (serial === 1n) !== (previous === undefined)) bad("enrolment-order");
    const profile = v[5]!; if (!isValidTag(profile)) bad("profile");
    const rate = integer(v[8]!); const burst = integer(v[9]!);
    if (rate < 1n || burst < 1n) bad("rate-or-burst");
    return { raw, note, id: `sha256:${hexEncode(sha256(note.textBytes))}`, origin: v[0]!, namespace: namespace(v[1]!), serial, ...(previous ? { previous } : {}), key: parseVkey(v[4]!, [SIG_ED25519]), profile, quotaBytes: integer(v[6]!), pendingBytes: integer(v[7]!), rate, burst };
  });
}

export function verifySharedEnrolment(input: string | Uint8Array | SharedEnrolment, logKey: Vkey, previous?: SharedEnrolment): SharedEnrolment {
  return guarded(() => {
    const enrolment = parseSharedEnrolment(typeof input === "object" && !(input instanceof Uint8Array) ? input.raw : input);
    if (logKey.type !== SIG_ED25519 || enrolment.origin !== logKey.name) refused("enrolment-origin");
    const signed = (key: Vkey): boolean => verifyNote(enrolment.note, [key]).length > 0;
    if (!signed(logKey) || !signed(enrolment.key)) refused("enrolment-signatures");
    if (equalBytes(logKey.key, enrolment.key.key)) refused("enrolment-key-reuse");
    if (previous) {
      const prior = parseSharedEnrolment(previous.raw);
      if (!verifyNote(prior.note, [logKey]).length || !verifyNote(prior.note, [prior.key]).length) refused("enrolment-previous-signatures");
      if (enrolment.namespace !== prior.namespace || enrolment.origin !== prior.origin || enrolment.serial !== prior.serial + 1n || enrolment.previous !== prior.id) refused("enrolment-chain");
      if (prior.key.text !== enrolment.key.text && !signed(prior.key)) refused("enrolment-old-key");
    } else if (enrolment.serial !== 1n) refused("enrolment-history-required");
    return enrolment;
  });
}

export function parseSharedAuthorization(input: string | Uint8Array): SharedAuthorization {
  return guarded(() => {
    const { raw, note, values: v } = statement(input, SHARED_AUTHORIZATION_HEADER, AUTHORIZATION_KEYS);
    if (note.sigs.length !== 1) bad("authorization-signature-count");
    return { raw, note, origin: v[0]!, policy: hashId(v[1]!), namespace: namespace(v[2]!), enrolment: hashId(v[3]!), leaf: b64decode(v[4]!, 32) };
  });
}

export function verifySharedAuthorization(input: string | Uint8Array | SharedAuthorization, enrolment: SharedEnrolment, policyId: string): SharedAuthorization {
  return guarded(() => {
    const auth = parseSharedAuthorization(typeof input === "object" && !(input instanceof Uint8Array) ? input.raw : input);
    const enrolled = parseSharedEnrolment(enrolment.raw);
    if (auth.policy !== policyId || auth.origin !== enrolled.origin || auth.namespace !== enrolled.namespace || auth.enrolment !== enrolled.id) refused("authorization-binding");
    if (!verifyNote(auth.note, [enrolled.key]).length) refused("authorization-signature");
    return auth;
  });
}

export function parseSharedSubmission(input: string | Uint8Array): SharedSubmission {
  return guarded(() => {
    const bytes = typeof input === "string" ? utf8(input) : input;
    if (bytes.length > MAX_SHARED_SUBMISSION_BYTES) bad("request-size");
    let position = 0;
    const line = (): string => {
      const end = bytes.indexOf(10, position);
      if (end < 0 || end - position > 128) bad("block-header");
      const text = fromUtf8(bytes.subarray(position, end)); position = end + 1;
      return text;
    };
    const block = (type: string, limit: number): Uint8Array => {
      const parts = line().split(" ");
      if (parts.length !== 2 || parts[0] !== type || !parts[1]) bad("block-order");
      const length = integer(parts[1]);
      if (length > BigInt(limit)) bad(`${type}-size`);
      const n = Number(length);
      if (position + n >= bytes.length || bytes[position + n] !== 10) bad("truncated-block");
      const body = bytes.slice(position, position + n); position += n + 1;
      return body;
    };
    if (line() !== SHARED_SUBMISSION_HEADER) bad("header");
    const authorization = block("authorization", MAX_NOTE);
    const entry = block("entry", 65535);
    const document = position < bytes.length ? block("document", 64 << 10) : undefined;
    if (position !== bytes.length) bad("trailing-bytes");
    const parsed = parseEntry(entry);
    if (document && (parsed.tag !== REGISTRY_TAG || fieldText(parsed, "change") !== "policy")) bad("unexpected-document");
    if (parsed.tag === REGISTRY_TAG && fieldText(parsed, "change") === "policy" && !document) bad("missing-document");
    return { authorization: parseSharedAuthorization(authorization), entry, parsed, ...(document ? { document } : {}) };
  });
}

/** Check public namespace/statement/document bindings against an already
 * validated shared policy. Storage, historical activation and quotas still
 * require the service's atomic admission state. Profile rules are a
 * separate validation step, with the full profile and key-log context. */
export function checkSharedBindings(submission: SharedSubmission, enrolment: SharedEnrolment, policy: Policy, logName: string): void {
  guarded(() => {
    const enrolled = parseSharedEnrolment(enrolment.raw);
    const log = policy.logs.get(logName); if (!log) refused("unknown-log");
    if (policy.draft || policy.visibility !== "public" || policy.strict || policy.quiet || log.entries !== "public" || log.blinded) refused("shared-policy");
    if (enrolled.origin !== log.origin || equalBytes(enrolled.key.key, log.vkey.key) || !verifyNote(enrolled.note, [log.vkey]).length || !verifyNote(enrolled.note, [enrolled.key]).length) refused("enrolment-signatures");
    const auth = verifySharedAuthorization(submission.authorization, enrolled, policy.id);
    if (auth.origin !== log.origin || !equalBytes(auth.leaf, leafHash(submission.entry))) refused("leaf-or-origin");
    if (!log.profiles.some((p) => p.tag === enrolled.profile)) refused("profile");
    checkSharedNamespace(submission, enrolled, policy);
  });
}

/** Namespace/layout checks, separate from enrolment/authorization verification
 * and profile rules. Milestones additionally need their shared-policy context. */
export function checkSharedNamespace(submission: SharedSubmission, enrolment: SharedEnrolment, policy?: Policy): void {
  guarded(() => {
    const enrolled = parseSharedEnrolment(enrolment.raw);
    const entry = parseEntry(submission.entry);
    if (entry.tag !== enrolled.profile) refused("profile");
    if (entry.fields.some((f) => f.kind === FIELD_COMMITMENT)) refused("commitment-payload");
    const prefix = `${enrolled.namespace}/`;
    const hasPrefix = (value: string | undefined): void => { if (!value || !isValidId(value) || !value.startsWith(prefix)) refused("namespace"); };
    const publicText = (name: string): string | undefined => {
      const position = layoutOf(entry.tag)?.findIndex((field) => field.name === name);
      if (position === undefined || position < 0 || entry.fields[position]?.kind !== FIELD_PUBLIC) refused("namespace-field");
      return fieldText(entry, name);
    };
    if (entry.tag === REGISTRY_TAG) {
      hasPrefix(publicText("record"));
      if (fieldText(entry, "change") === "policy") {
        if (!submission.document || !equalBytes(sha256(submission.document), fieldValue(entry, "document")!)) refused("document-digest");
        const published = parsePolicy(submission.document);
        if (published.visibility !== "public") refused("private-policy");
        hasPrefix(published.name);
      } else if (submission.document) refused("document-kind");
    } else if (entry.tag === RELEASE_TAG) hasPrefix(publicText("package"));
    else if (entry.tag === KEYS_TAG) hasPrefix(publicText("holder"));
    else if (entry.tag === EVENTS_TAG) {
      const kind = fieldText(entry, "kind"); const raw = fieldValue(entry, "statement");
      if (!raw?.length) refused("event-statement");
      if (kind === EVENT_KINDS.policy) {
        const published = parsePolicy(raw);
        if (published.visibility !== "public") refused("private-policy");
        hasPrefix(published.name);
        if (!equalBytes(fieldValue(entry, "subject")!, concat(Uint8Array.of(1), published.idHash))) refused("policy-subject");
      } else if (kind === EVENT_KINDS.milestone) {
        const note = parseNote(raw); const milestone = parseMilestoneStatement(note.text);
        hasPrefix(milestone.event);
        if (!equalBytes(fieldValue(entry, "subject")!, Uint8Array.of(0))) refused("milestone-subject");
        if (!policy) refused("milestone-policy-required");
        if (!verifyNote(note, [...policy.authorities.values()].map((a) => a.vkey)).length) refused("milestone-authority");
      } else refused("event-kind");
    } else refused("unsupported-profile");
  });
}
