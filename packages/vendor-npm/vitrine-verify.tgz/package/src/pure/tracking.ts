// SPDX-License-Identifier: Apache-2.0
//
// The Tracking ID of a ballot (specs/entry.md, section 4.1): the 32-byte
// `ballot_id` in Crockford base32, 52 characters in groups of four, and its
// 8-character short form. Written from the spec; no I/O.

import { decodeHash32 } from "./entry.js";

const ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
/** Characters in the full Tracking ID. */
export const TRACKING_ID_LENGTH = 52;
/** Characters in the short Tracking ID, and the least a lookup takes. */
export const TRACKING_SHORT_LENGTH = 8;

/** The 52 base32 characters of a ballot ID, without separators. */
function base32(id: Uint8Array): string {
  let out = "";
  // Walk the bits: character i is bits 5i..5i+4, zero past the 256th.
  for (let i = 0; i < TRACKING_ID_LENGTH; i++) {
    let v = 0;
    for (let j = 0; j < 5; j++) {
      const bit = i * 5 + j;
      const byte = bit < 256 ? id[bit >> 3]! : 0;
      v = (v << 1) | (bit < 256 ? (byte >> (7 - (bit & 7))) & 1 : 0);
    }
    out += ALPHABET[v]!;
  }
  return out;
}

function idBytes(id: Uint8Array | string): Uint8Array {
  return decodeHash32(id);
}

/** The full Tracking ID: 52 characters in groups of four joined by `-`. */
export function trackingId(ballotId: Uint8Array | string): string {
  return base32(idBytes(ballotId)).match(/.{4}/g)!.join("-");
}

/** The short Tracking ID: the first 8 characters, such as `FTBE-MHRX`. */
export function shortTrackingId(ballotId: Uint8Array | string): string {
  const s = base32(idBytes(ballotId));
  return `${s.slice(0, 4)}-${s.slice(4, 8)}`;
}

/** A typed Tracking ID prefix, normalised. */
export interface TrackingPrefix {
  /** Upper case, no hyphens, `I` and `L` read as `1`, `O` as `0`. */
  chars: string;
  /** The first `bitLength` bits, most significant first, zeros after them. */
  bits: Uint8Array;
  /** 5 bits per character: 40 to 260. */
  bitLength: number;
}

/** Parses what a user typed: case is ignored, hyphens are dropped, `I` and
 * `L` read as `1` and `O` as `0`. At least 8 and at most 52 characters of the
 * alphabet; anything else throws a TypeError. */
export function parseTrackingPrefix(typed: string): TrackingPrefix {
  let chars = "";
  for (const raw of typed) {
    const c = raw.toUpperCase();
    if (c === "-") continue;
    const n = c === "I" || c === "L" ? "1" : c === "O" ? "0" : c;
    if (n.length !== 1 || !ALPHABET.includes(n)) throw new TypeError("a Tracking ID has only base32 characters");
    chars += n;
    if (chars.length > TRACKING_ID_LENGTH) throw new TypeError("a Tracking ID has at most 52 characters");
  }
  if (chars.length < TRACKING_SHORT_LENGTH) throw new TypeError("type at least 8 characters of a Tracking ID");
  const bitLength = chars.length * 5;
  const bits = new Uint8Array(Math.ceil(bitLength / 8));
  for (let i = 0; i < chars.length; i++) {
    const v = ALPHABET.indexOf(chars[i]!);
    for (let j = 0; j < 5; j++) {
      if ((v >> (4 - j)) & 1) {
        const bit = i * 5 + j;
        bits[bit >> 3]! |= 0x80 >> (bit & 7);
      }
    }
  }
  return { chars, bits, bitLength };
}

/** The ballot ID a full Tracking ID stands for (52 characters, hyphens and
 * case ignored). Throws a TypeError for a shorter prefix, other characters or
 * non-zero pad bits. */
export function decodeTrackingId(typed: string): Uint8Array {
  const p = parseTrackingPrefix(typed);
  if (p.chars.length !== TRACKING_ID_LENGTH) throw new TypeError("a full Tracking ID has 52 characters");
  if ((p.bits[32]! & 0xf0) !== 0) throw new TypeError("a Tracking ID ends in zero bits");
  return p.bits.slice(0, 32);
}

/** Like {@link parseTrackingPrefix}, but `undefined` for input that isn't one. */
export function tryParseTrackingPrefix(typed: string): TrackingPrefix | undefined {
  try {
    return parseTrackingPrefix(typed);
  } catch {
    return undefined;
  }
}

/** Whether a ballot ID starts with the prefix (a string is parsed first;
 * input that isn't a prefix matches nothing). */
export function trackingIdMatches(prefix: TrackingPrefix | string, ballotId: Uint8Array | string): boolean {
  const p = typeof prefix === "string" ? tryParseTrackingPrefix(prefix) : prefix;
  if (!p) return false;
  let id: Uint8Array;
  try {
    id = idBytes(ballotId);
  } catch {
    return false;
  }
  return base32(id).startsWith(p.chars);
}
