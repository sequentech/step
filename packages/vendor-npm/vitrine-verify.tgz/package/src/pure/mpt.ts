// SPDX-License-Identifier: Apache-2.0
//
// The Merkle Patricia tree of the WAICT prefix-tree spec
// (merkle-patricia-tree.md at the commit in testdata/waict/COMMIT): roots and
// inclusion proofs over 32-byte keys and values. Hubs use it for their subject
// maps (specs/hub.md, section 4), WAICT services for their prefix trees.

import { compareBytes, concat, equalBytes, utf8 } from "./bytes.js";
import { sha256 } from "./hash.js";

export interface MptLeaf {
  key: Uint8Array;
  value: Uint8Array;
}

const PROOF_PREFIX = utf8("mptproof");
const PROOF_VERSION = 0x01;

function bit(k: Uint8Array, i: number): number {
  return (k[i >>> 3]! >>> (7 - (i & 7))) & 1;
}

/** The number of leading bits `a` and `b` share (256 when equal). */
function sharedBits(a: Uint8Array, b: Uint8Array): number {
  for (let i = 0; i < 32; i++) {
    const x = a[i]! ^ b[i]!;
    if (x !== 0) return i * 8 + Math.clz32(x) - 24;
  }
  return 256;
}

function sortedLeaves(leaves: readonly MptLeaf[]): MptLeaf[] {
  for (const l of leaves) {
    if (l.key.length !== 32 || l.value.length !== 32) throw new RangeError("MPT keys and values are 32 bytes");
  }
  const s = [...leaves].sort((a, b) => compareBytes(a.key, b.key));
  for (let i = 1; i < s.length; i++) {
    if (equalBytes(s[i - 1]!.key, s[i]!.key)) throw new RangeError("duplicate MPT key");
  }
  return s;
}

/** The split of the sorted leaves `[lo, hi)`: the bit where they first differ
 * and the first index whose key has that bit set. */
function split(s: readonly MptLeaf[], lo: number, hi: number): { r: number; mid: number } {
  const r = sharedBits(s[lo]!.key, s[hi - 1]!.key);
  let a = lo;
  let b = hi - 1;
  while (a < b) {
    const m = (a + b) >>> 1;
    if (bit(s[m]!.key, r) === 0) a = m + 1;
    else b = m;
  }
  return { r, mid: a };
}

function nodeHash(s: readonly MptLeaf[], lo: number, hi: number): Uint8Array {
  if (hi - lo === 1) return sha256(s[lo]!.key, s[lo]!.value);
  const { r, mid } = split(s, lo, hi);
  return sha256(nodeHash(s, lo, mid), nodeHash(s, mid, hi), Uint8Array.of(r));
}

/** The root of the tree over `leaves` (any order, distinct keys). */
export function mptRoot(leaves: readonly MptLeaf[]): Uint8Array {
  if (leaves.length === 0) return sha256();
  const s = sortedLeaves(leaves);
  return nodeHash(s, 0, s.length);
}

/** The inclusion proof of the leaf with `key`:
 * `"mptproof" || 0x01 || value || (r || sibling)*`, from the leaf up. */
export function mptProve(leaves: readonly MptLeaf[], key: Uint8Array): Uint8Array {
  const s = sortedLeaves(leaves);
  const t = s.findIndex((l) => equalBytes(l.key, key));
  if (t < 0) throw new RangeError("key not in the tree");
  const path: Uint8Array[] = [];
  let lo = 0;
  let hi = s.length;
  while (hi - lo > 1) {
    const { r, mid } = split(s, lo, hi);
    if (t < mid) {
      path.push(concat(Uint8Array.of(r), nodeHash(s, mid, hi)));
      hi = mid;
    } else {
      path.push(concat(Uint8Array.of(r), nodeHash(s, lo, mid)));
      lo = mid;
    }
  }
  return concat(PROOF_PREFIX, Uint8Array.of(PROOF_VERSION), s[t]!.value, ...path.reverse());
}

/** Verifies an inclusion proof for `key` and `value` against `root`. The
 * prefix lengths must strictly decrease towards the root. */
export function verifyMptProof(proof: Uint8Array, key: Uint8Array, value: Uint8Array, root: Uint8Array): boolean {
  const head = PROOF_PREFIX.length + 1 + 32;
  if (key.length !== 32 || value.length !== 32 || root.length !== 32) return false;
  if (proof.length < head || (proof.length - head) % 33 !== 0) return false;
  if (!equalBytes(proof.subarray(0, PROOF_PREFIX.length), PROOF_PREFIX)) return false;
  if (proof[PROOF_PREFIX.length] !== PROOF_VERSION) return false;
  if (!equalBytes(proof.subarray(PROOF_PREFIX.length + 1, head), value)) return false;
  let h = sha256(key, value);
  let last = 256;
  for (let off = head; off < proof.length; off += 33) {
    const r = proof[off]!;
    if (r >= last) return false;
    const sibling = proof.subarray(off + 1, off + 33);
    h = bit(key, r) === 0 ? sha256(h, sibling, Uint8Array.of(r)) : sha256(sibling, h, Uint8Array.of(r));
    last = r;
  }
  return equalBytes(h, root);
}
