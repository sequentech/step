// SPDX-License-Identifier: Apache-2.0
//
// Checkpoints (c2sp.org/tlog-checkpoint) and their verification against a log
// key and a witness set: the log's own Ed25519 signature and cosignature/v1
// cosignatures (specs/receipt.md, section 1.1, steps 3 and 5).

import { b64decode } from "./base64.js";
import { parseDecimal } from "./bytes.js";
import { fail } from "./errors.js";
import { isValidKeyName, parseNote, verifyNote, type Note, type Vkey } from "./note.js";
import type { Cosig, WitnessSet } from "./quorum.js";

/** Cosignatures dated more than this after the device clock are rejected (AS5). */
export const MAX_COSIGNATURE_SKEW = 300;

export interface Checkpoint {
  origin: string;
  size: bigint;
  root: Uint8Array;
  /** The note text: the three lines above, each ending in a newline. */
  text: string;
}

/** Parses a checkpoint's note text (without signatures). Vitrine v1
 * checkpoints have no extension lines (crypto review). */
export function parseCheckpointText(text: string): Checkpoint {
  if (!text.endsWith("\n")) fail("bad-checkpoint", { detail: "no-final-newline" });
  const lines = text.slice(0, -1).split("\n");
  if (lines.length < 3) fail("bad-checkpoint", { detail: "too-few-lines" });
  if (lines.length > 3) fail("bad-checkpoint", { detail: "extension-lines" });
  const [origin, size, root] = lines as [string, string, string];
  if (!isValidKeyName(origin)) fail("bad-checkpoint", { detail: "origin" });
  let n: bigint;
  let r: Uint8Array;
  try {
    n = parseDecimal(size);
    r = b64decode(root, 32);
  } catch {
    return fail("bad-checkpoint", { detail: "size-or-root" });
  }
  return { origin, size: n, root: r, text };
}

export interface CheckedCheckpoint {
  note: Note;
  cp: Checkpoint;
  /** Valid cosignatures from the set's witnesses, dated (non-zero) and not
   * in the future. */
  cosigs: Cosig[];
  /** Witnesses whose valid cosignatures were dated in the future (ignored). */
  future: string[];
}

/** Verifies a checkpoint note: its origin is `logKey`'s name, it carries a
 * valid signature from `logKey`, and every cosignature from a witness of `set`
 * verifies. A cosignature with timestamp 0 makes no claim about time and
 * doesn't count at all (crypto review); one dated more than 300 seconds after
 * `deviceNow` (the device clock, POSIX seconds) is rejected (AS5). */
export function verifyCheckpoint(
  input: Uint8Array | string,
  logKey: Vkey,
  set: WitnessSet,
  deviceNow: number,
): CheckedCheckpoint {
  const note = parseNote(input);
  const cp = parseCheckpointText(note.text);
  if (cp.origin !== logKey.name) fail("wrong-origin", { expected: logKey.name, got: cp.origin.slice(0, 255) });
  const verified = verifyNote(note, [logKey, ...set.keys()]);
  if (!verified.some((v) => v.vkey === logKey)) fail("missing-signature", { name: logKey.name });
  const cosigs: Cosig[] = [];
  const future: string[] = [];
  for (const v of verified) {
    if (v.vkey === logKey || v.timestamp === undefined || v.timestamp === 0) continue;
    const w = set.witnessFor(v.vkey);
    if (!w) continue;
    if (v.timestamp > deviceNow + MAX_COSIGNATURE_SKEW) future.push(w.name);
    else cosigs.push({ witness: w.name, timestamp: v.timestamp });
  }
  return { note, cp, cosigs, future };
}

/** The cosignatures of several notes of one checkpoint, merged: each witness
 * once, with its earliest timestamp. */
export function mergeCosigs(...lists: readonly (readonly Cosig[])[]): Cosig[] {
  const by = new Map<string, number>();
  for (const l of lists) {
    for (const c of l) {
      const t = by.get(c.witness);
      if (t === undefined || c.timestamp < t) by.set(c.witness, c.timestamp);
    }
  }
  return [...by].map(([witness, timestamp]) => ({ witness, timestamp }));
}
