// SPDX-License-Identifier: Apache-2.0
//
// Checkpoints (c2sp.org/tlog-checkpoint) and their verification: the signer's
// Ed25519 signature, an app log's log-time cosignature, and the cosignature/v1
// cosignatures of the expected witnesses, after normalization
// (specs/receipt.md, sections 1.1 and 1.3; specs/entry.md, "Signatures").

import { b64decode } from "./base64.js";
import { equalBytes, parseDecimal } from "./bytes.js";
import { fail } from "./errors.js";
import { sha256 } from "./hash.js";
import { isValidKeyName, normalizeNote, parseNote, verifyNote, type Note, type VerifiedSignature, type Vkey } from "./note.js";
import type { Cosig, WitnessSet } from "./quorum.js";

/** Cosignatures dated more than this after the device clock don't count (AS5). */
export const MAX_COSIGNATURE_SKEW = 300;

/** The root of the empty tree: the SHA-256 of the empty string. */
export const EMPTY_TREE_ROOT: Uint8Array = sha256();

export interface Checkpoint {
  origin: string;
  size: bigint;
  root: Uint8Array;
  /** The note text: the three lines above, each ending in a newline. */
  text: string;
}

/** Parses a checkpoint's note text (without signatures). Vitrine v1
 * checkpoints have no extension lines, and verifiers reject any
 * (specs/entry.md, "Checkpoints"). */
export function parseCheckpointText(text: string): Checkpoint {
  if (!text.endsWith("\n")) fail("bad-checkpoint", { detail: "no-final-newline" });
  const lines = text.slice(0, -1).split("\n");
  if (lines.length < 3) fail("bad-checkpoint", { detail: "too-few-lines" });
  if (lines.length > 3) fail("bad-checkpoint", { detail: "extension-lines" });
  const [origin, size, root] = lines as [string, string, string];
  if (!isValidKeyName(origin)) fail("bad-checkpoint", { detail: "origin" });
  let n: bigint;
  let r: Uint8Array;
  try {
    n = parseDecimal(size);
    r = b64decode(root, 32);
  } catch {
    return fail("bad-checkpoint", { detail: "size-or-root" });
  }
  return { origin, size: n, root: r, text };
}

export interface CheckedCheckpoint {
  note: Note;
  cp: Checkpoint;
  /** Cosignatures that count: valid, from the set's witnesses, dated (not 0)
   * and at most 300 seconds after the device clock. */
  cosigs: Cosig[];
  /** Witnesses whose valid cosignatures were dated too far in the future. */
  future: string[];
  /** The log-time: the timestamp of the log-time cosignature, when the note
   * carries a valid one (app-log checkpoints). */
  logTime?: number;
  /** The normalized note: signer, log-time cosignature, witnesses. */
  normalized: string;
}

export interface VerifyCheckpointOptions {
  /** The log's `log-time` key. Its cosignature is the checkpoint's log-time. */
  logTime?: Vkey;
  /** Reject the checkpoint without a valid log-time cosignature dated other
   * than 0 (receipts, specs/receipt.md, section 1.1, step 3). */
  requireLogTime?: boolean;
}

/** Verifies a checkpoint note: its origin is `signer`'s key name, it carries
 * a valid signature from `signer`, and, normalized, the cosignatures of the
 * witnesses of `set` that count. A size-0 checkpoint must have the empty-tree
 * root; a signed one that doesn't is `bad-empty-tree` (evidence). `deviceNow`
 * is the device clock, POSIX seconds. */
export function verifyCheckpoint(
  input: Uint8Array | string,
  signer: Vkey,
  set: WitnessSet,
  deviceNow: number,
  opts: VerifyCheckpointOptions = {},
): CheckedCheckpoint {
  const note = parseNote(input);
  const cp = parseCheckpointText(note.text);
  if (cp.origin !== signer.name) fail("wrong-origin", { expected: signer.name, got: cp.origin.slice(0, 255) });
  const n = normalizeNote(note, signer, opts.logTime, set.keys());
  if (!n.signer) fail("missing-signature", { name: signer.name });
  if (cp.size === 0n && !equalBytes(cp.root, EMPTY_TREE_ROOT)) fail("bad-empty-tree", { origin: cp.origin.slice(0, 255) });
  if (opts.requireLogTime && !n.logTime) fail("log-time-missing", { name: signer.name });
  const { cosigs, future } = splitFuture(n.others, set, deviceNow);
  const out: CheckedCheckpoint = { note, cp, cosigs, future, normalized: n.text };
  if (n.logTime?.timestamp !== undefined) out.logTime = n.logTime.timestamp;
  return out;
}

function splitFuture(verified: readonly VerifiedSignature[], set: WitnessSet, deviceNow: number): { cosigs: Cosig[]; future: string[] } {
  const cosigs: Cosig[] = [];
  const future: string[] = [];
  for (const v of verified) {
    const w = set.witnessFor(v.vkey);
    if (!w || v.timestamp === undefined) continue;
    if (v.timestamp > deviceNow + MAX_COSIGNATURE_SKEW) future.push(w.name);
    else cosigs.push({ witness: w.name, timestamp: v.timestamp });
  }
  return { cosigs, future };
}

/** The cosignatures on `note` that count under `set` (specs/receipt.md,
 * section 1.1, step 5), for a note whose signer was already verified. */
export function countingCosigs(note: Note, set: WitnessSet, deviceNow: number): { cosigs: Cosig[]; future: string[] } {
  return splitFuture(verifyNote(note, set.keys()), set, deviceNow);
}

/** The cosignatures of several notes of one checkpoint, merged: each witness
 * once, with its earliest timestamp. */
export function mergeCosigs(...lists: readonly (readonly Cosig[])[]): Cosig[] {
  const by = new Map<string, number>();
  for (const l of lists) {
    for (const c of l) {
      const t = by.get(c.witness);
      if (t === undefined || c.timestamp < t) by.set(c.witness, c.timestamp);
    }
  }
  return [...by].map(([witness, timestamp]) => ({ witness, timestamp }));
}
