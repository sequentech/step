// SPDX-License-Identifier: Apache-2.0
//
// The browser layer (specs/hub.md, section 6): browser anchors, which put a
// hub checkpoint `B` into a WAICT transparency service, verified as in
// section 6.3, and the app log's pairs (section 6.5), which tie `B` to one
// of the log's own hub links with a consistency proof.

import { equalBytes, utf8 } from "./bytes.js";
import { formatBlockDoc, parseBase64Body, parseBlockDoc, parseHashLines, pickBlocks } from "./blocks.js";
import { verifyCheckpoint, type CheckedCheckpoint } from "./checkpoint.js";
import { b64encode } from "./base64.js";
import { fail, VerifyError, type Params } from "./errors.js";
import { bootstrapHubOf, hubSubject, parseBrowserPair, verifyHubLink, type BrowserPair, type Subject, type VerifiedHubLink } from "./hub.js";
import { MAX_CONSISTENCY_HASHES, verifyConsistency } from "./merkle.js";
import { verifyMptProof } from "./mpt.js";
import type { Policy, PolicyHub, WaictService } from "./policy.js";
import { chainValue, checkManifest, domainKey, parseChainHeadWithProof, resourceHash, verifyPrefixRoot } from "./waict.js";

export const BROWSER_ANCHOR_HEADER = "vitrine/browser-anchor/v1";

export interface BrowserAnchor {
  hubOrigin: string;
  service: string;
  domain: string;
  checkpoint: Uint8Array;
  manifest: Uint8Array;
  waict: Uint8Array;
}

export function parseBrowserAnchor(input: Uint8Array | string): BrowserAnchor {
  try {
    const doc = parseBlockDoc(input, { header: BROWSER_ANCHOR_HEADER, keys: ["hub", "service", "domain"], code: "bad-browser-anchor" });
    if (doc.values.some((v) => v.length !== 1)) fail("bad-browser-anchor", { detail: "lines" });
    const b = pickBlocks(doc.blocks, { checkpoint: 0, manifest: 0, waict: 0 }, "bad-browser-anchor");
    const cp = b.get("checkpoint");
    const m = b.get("manifest");
    const w = b.get("waict");
    if (!cp || !m || !w) fail("bad-browser-anchor", { detail: "blocks" });
    const [hub, service, domain] = doc.values.map((v) => v[0]!) as [string, string, string];
    return { hubOrigin: hub, service, domain, checkpoint: cp.body, manifest: m.body, waict: parseBase64Body(w.body) };
  } catch (e) {
    if (e instanceof VerifyError && (e.code === "bad-base64" || e.code === "bad-number" || e.code === "bad-text")) {
      throw new VerifyError("bad-browser-anchor", { detail: e.code });
    }
    throw e;
  }
}

export function formatBrowserAnchor(a: BrowserAnchor): Uint8Array {
  return formatBlockDoc(BROWSER_ANCHOR_HEADER, [`hub ${a.hubOrigin}`, `service ${a.service}`, `domain ${a.domain}`], [
    { type: "checkpoint", args: [], body: a.checkpoint },
    { type: "manifest", args: [], body: a.manifest },
    { type: "waict", args: [], body: utf8(b64encode(a.waict)) },
  ]);
}

/** The validly signed objects of a pair that fall short of their quorum,
 * in this order: the link's hub checkpoint `H` (the hub's quorum), the app
 * checkpoint it anchors (the app quorum), a bootstrap link's hub checkpoint
 * (the bootstrap hub's quorum) and `B` (the app hub's quorum). Such an
 * object doesn't count, but it isn't damaged either, so tier 3 is `pending`
 * for the hub rather than `invalid` (specs/hub.md, sections 6.3 to 6.5;
 * impl-20). */
export type BelowQuorum = "link-hub" | "link-app" | "bootstrap-hub" | "b";

export interface VerifiedBrowserAnchor {
  anchor: BrowserAnchor;
  /** `B`, the hub checkpoint in the browser layer. */
  hub: CheckedCheckpoint;
  /** `["b"]` when `B` falls short of the hub's quorum, else empty. */
  belowQuorum: BelowQuorum[];
  service: WaictService;
  /** True when the service's operator isn't the policy's operator. */
  independent: boolean;
  /** The manifest's `time`, in POSIX seconds. */
  manifestTime: number;
}

/** Verifies a browser anchor for app hub `hub` (specs/hub.md, section 6.3).
 * A `B` that is validly signed but short of the hub's quorum (step 1)
 * doesn't count, and `belowQuorum` says so: neither the WAICT service nor
 * the hub must refuse it, so it is no evidence, and the manifest fixes its
 * bytes, so it never gains a cosignature; a later browser anchor takes its
 * place. Anything else that doesn't hold throws. */
export function verifyBrowserAnchor(input: Uint8Array | string, policy: Policy, hub: PolicyHub, deviceNow: number): VerifiedBrowserAnchor {
  const a = parseBrowserAnchor(input);
  // Step 1
  if (a.hubOrigin !== hub.origin) fail("bad-browser-anchor", { detail: "hub" });
  const cp = verifyCheckpoint(a.checkpoint, hub.vkey, hub.set, deviceNow);
  const belowQuorum: BelowQuorum[] = hub.set.meets(cp.cosigs) ? [] : ["b"];
  // Step 5, and the service must be one the policy lists for this hub.
  const service = policy.waict.get(a.service);
  if (!service || !service.hubs.includes(hub.name)) fail("unknown-waict-service", { service: a.service.slice(0, 253) });
  if (hub.domain === undefined || a.domain !== hub.domain) fail("bad-browser-anchor", { detail: "domain" });
  // Step 2
  const manifestTime = checkManifest(a.manifest, hub.origin, a.domain, cp.cp.size, a.checkpoint);
  // Step 3
  const head = parseChainHeadWithProof(a.waict);
  if (!equalBytes(head.head.resourceHash, resourceHash(a.manifest))) fail("bad-waict-proof", { detail: "resource-hash" });
  // Step 4
  const pr = verifyPrefixRoot(head.signedPrefixRoot, service.domain, service.witnesses, service.quorum);
  if (!verifyMptProof(head.incProof, domainKey(a.domain), chainValue(head.head.bytes), pr.root)) {
    fail("bad-waict-proof", { detail: "inclusion" });
  }
  return { anchor: a, hub: cp, belowQuorum, service, independent: service.operator !== policy.operator, manifestTime };
}

/** A log's pair for an app hub that verifies (specs/hub.md, section 6.5). */
export interface VerifiedBrowserPair {
  pair: BrowserPair;
  /** The app hub, from the policy. */
  hub: PolicyHub;
  /** The pair's link (`browser-link`): an anchor entry of the subject under
   * a hub checkpoint `H`. */
  link: VerifiedHubLink;
  /** The app checkpoint that the link anchors, signed by the log. */
  anchored: CheckedCheckpoint;
  /** `B`: the hub checkpoint that the browser anchor shows, or the app hub
   * checkpoint that the bootstrap link anchors. It extends `H`. */
  b: CheckedCheckpoint;
  /** The objects short of their quorum, in order; empty when every quorum
   * is met, which a log checks before it serves the pair (section 6.5). */
  belowQuorum: BelowQuorum[];
  /** True when the pair counts for tier 3: a bootstrap link, or a browser
   * anchor from a service that the policy's operator doesn't run (section
   * 6.3). */
  counts: boolean;
  /** For a `browser` block: the browser anchor. */
  browser?: VerifiedBrowserAnchor;
  /** For a `bootstrap` block: the bootstrap hub and its link. */
  bootstrap?: { hub: PolicyHub; link: VerifiedHubLink };
}

const size = (n: bigint): number | string => (n <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(n) : n.toString());

/** Verifies a log's pair for an app hub under `policy` (specs/hub.md,
 * section 6.5; receipt.md, section 3.1, step 4), for the log's subject (one
 * of `subjects`), with the device clock in POSIX seconds for cosignature
 * dates. Every check must hold, or it throws, except that a validly signed
 * object short of its quorum is listed in `belowQuorum` (impl-20):
 *
 * - the pair is for an app hub of the policy (`unknown-hub`; a bootstrap
 *   hub is `bad-browser-pair`);
 * - `browser-link` verifies (section 5.2) under a hub checkpoint `H` that
 *   meets the hub's quorum (`link-hub`), and is an anchor entry whose
 *   checkpoint carries the log's signature and meets the app quorum
 *   (`link-app`);
 * - the `browser` block verifies (section 6.3), or the `bootstrap` block is
 *   a link from one of the policy's bootstrap hubs for the app hub's
 *   subject, under a checkpoint that meets that hub's quorum
 *   (`bootstrap-hub`), anchoring an app hub checkpoint; either way `B` meets
 *   the app hub's quorum (`b`; section 6.4);
 * - the checkpoint `B` that it shows is at least as large as `H`; at equal
 *   sizes the roots are equal and the pair has no `browser-consistency`
 *   block (`bad-browser-pair`), and otherwise the block goes from `H`'s
 *   size to `B`'s and verifies.
 *
 * Whether the pair covers an entry, and its consistency with a receipt, are
 * the caller's. A private event's pair rests on a blinded anchor, which only
 * its openings tie to a checkpoint: verifyChain checks those, and this
 * function refuses them (`hub-link-mismatch`). */
export function verifyBrowserPair(
  input: Uint8Array | string | BrowserPair,
  policy: Policy,
  subjects: Subject | readonly Subject[],
  deviceNow: number,
): VerifiedBrowserPair {
  const pair = typeof input === "string" || input instanceof Uint8Array ? parseBrowserPair(input) : input;
  const hub = policy.hubs.get(pair.hub);
  if (!hub) return fail("unknown-hub", { hub: pair.hub.slice(0, 64) });
  if (hub.bootstrap) fail("bad-browser-pair", { detail: "bootstrap-hub" });
  const P: Params = { hub: hub.name };
  const link = verifyHubLink(pair.link, hub, subjects, deviceNow);
  const belowQuorum: BelowQuorum[] = [];
  if (!link.hubQuorum) belowQuorum.push("link-hub");
  if (link.kind === "wrong") fail("hub-index-wrong", { ...P, detail: link.wrong ?? "entry" });
  if (link.kind !== "anchor") fail("hub-link-mismatch", { ...P, detail: link.kind });
  const anchored = verifyCheckpoint(link.anchored!, link.subject.vkey, policy.witnesses, deviceNow);
  if (!policy.witnesses.meets(anchored.cosigs)) belowQuorum.push("link-app");
  const out = { pair, hub, link, anchored, belowQuorum } as VerifiedBrowserPair;
  if (pair.browser) {
    const v = verifyBrowserAnchor(pair.browser, policy, hub, deviceNow);
    out.browser = v;
    out.b = v.hub;
    out.counts = v.independent;
    belowQuorum.push(...v.belowQuorum);
  } else {
    const boot = bootstrapHubOf(policy, pair.bootstrap!);
    const bl = verifyHubLink(pair.bootstrap!, boot, hubSubject(hub), deviceNow);
    if (!bl.hubQuorum) belowQuorum.push("bootstrap-hub");
    if (bl.kind === "wrong") fail("hub-index-wrong", { hub: boot.name, detail: bl.wrong ?? "entry" });
    // Rotating an app hub's key in a bootstrap hub is out of scope (v0.1).
    if (bl.kind !== "anchor") fail("bad-bootstrap-link", { detail: bl.kind });
    const b = verifyCheckpoint(bl.anchored!, hub.vkey, hub.set, deviceNow);
    if (!hub.set.meets(b.cosigs)) belowQuorum.push("b");
    out.bootstrap = { hub: boot, link: bl };
    out.b = b;
    out.counts = true;
  }
  const H = link.hub.cp;
  const B = out.b.cp;
  const sizes: Params = { ...P, from: size(H.size), to: size(B.size) };
  if (B.size < H.size) fail("browser-below-link", sizes);
  const c = pair.consistency;
  if (B.size === H.size) {
    if (c) fail("bad-browser-pair", { detail: "consistency-at-equal-sizes" });
    if (!equalBytes(B.root, H.root)) fail("split-view", { size: size(B.size) });
    return out;
  }
  if (!c) return fail("bad-browser-pair", { detail: "consistency-missing" });
  if (c.from !== H.size || c.to !== B.size) fail("consistency-mismatch", sizes);
  const proof = parseHashLines(c.body, MAX_CONSISTENCY_HASHES);
  if (!verifyConsistency(H.size, B.size, proof, H.root, B.root)) fail("consistency-failed", sizes);
  return out;
}
