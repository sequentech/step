// SPDX-License-Identifier: Apache-2.0
//
// The browser layer (specs/hub.md, section 6): browser anchors, which put a
// hub checkpoint into a WAICT transparency service, verified as in section
// 6.3.

import { equalBytes, utf8 } from "./bytes.js";
import { formatBlockDoc, formatHashLines, parseBase64Body, parseBlockDoc, parseHashLines, pickBlocks } from "./blocks.js";
import { verifyCheckpoint, type Checkpoint, type CheckedCheckpoint } from "./checkpoint.js";
import { b64encode } from "./base64.js";
import { parseDecimal } from "./bytes.js";
import { fail, VerifyError } from "./errors.js";
import { MAX_CONSISTENCY_HASHES, verifyConsistency } from "./merkle.js";
import { verifyMptProof } from "./mpt.js";
import type { Policy, PolicyHub, WaictService } from "./policy.js";
import { chainValue, checkManifest, domainKey, parseChainHeadWithProof, resourceHash, verifyPrefixRoot } from "./waict.js";

export const BROWSER_ANCHOR_HEADER = "vitrine/browser-anchor/v1";

export interface BrowserAnchor {
  hubOrigin: string;
  service: string;
  domain: string;
  from: bigint;
  to: bigint;
  consistency: Uint8Array[];
  checkpoint: Uint8Array;
  manifest: Uint8Array;
  waict: Uint8Array;
}

export function parseBrowserAnchor(input: Uint8Array | string): BrowserAnchor {
  try {
    const doc = parseBlockDoc(input, { header: BROWSER_ANCHOR_HEADER, keys: ["hub", "service", "domain"], code: "bad-browser-anchor" });
    if (doc.values.some((v) => v.length !== 1)) fail("bad-browser-anchor", { detail: "lines" });
    const b = pickBlocks(doc.blocks, { consistency: 2, checkpoint: 0, manifest: 0, waict: 0 }, "bad-browser-anchor");
    const c = b.get("consistency");
    const cp = b.get("checkpoint");
    const m = b.get("manifest");
    const w = b.get("waict");
    if (!c || !cp || !m || !w) fail("bad-browser-anchor", { detail: "blocks" });
    const [hub, service, domain] = doc.values.map((v) => v[0]!) as [string, string, string];
    return {
      hubOrigin: hub,
      service,
      domain,
      from: parseDecimal(c.args[0]!),
      to: parseDecimal(c.args[1]!),
      consistency: parseHashLines(c.body, MAX_CONSISTENCY_HASHES),
      checkpoint: cp.body,
      manifest: m.body,
      waict: parseBase64Body(w.body),
    };
  } catch (e) {
    if (e instanceof VerifyError && (e.code === "bad-base64" || e.code === "bad-number" || e.code === "bad-text")) {
      throw new VerifyError("bad-browser-anchor", { detail: e.code });
    }
    throw e;
  }
}

export function formatBrowserAnchor(a: BrowserAnchor): Uint8Array {
  return formatBlockDoc(BROWSER_ANCHOR_HEADER, [`hub ${a.hubOrigin}`, `service ${a.service}`, `domain ${a.domain}`], [
    { type: "consistency", args: [String(a.from), String(a.to)], body: formatHashLines(a.consistency) },
    { type: "checkpoint", args: [], body: a.checkpoint },
    { type: "manifest", args: [], body: a.manifest },
    { type: "waict", args: [], body: utf8(b64encode(a.waict)) },
  ]);
}

export interface VerifiedBrowserAnchor {
  anchor: BrowserAnchor;
  /** The hub checkpoint in the browser layer. */
  hub: CheckedCheckpoint;
  /** True when it meets the hub's quorum. */
  hubQuorum: boolean;
  service: WaictService;
  /** True when the service's operator isn't the policy's operator. */
  independent: boolean;
  /** "behind" when the browser layer holds an older hub checkpoint than the
   * hub anchor; the consistency proof was then not checked. */
  position: "extends" | "behind";
}

/** Verifies a browser anchor for app hub `hub` (specs/hub.md, section 6.3).
 * `base` is the hub checkpoint of the chain's `anchor` block. */
export function verifyBrowserAnchor(
  input: Uint8Array | string,
  policy: Policy,
  hub: PolicyHub,
  base: Checkpoint,
  deviceNow: number,
): VerifiedBrowserAnchor {
  const a = parseBrowserAnchor(input);
  // Step 1
  if (a.hubOrigin !== hub.origin) fail("bad-browser-anchor", { detail: "hub" });
  const cp = verifyCheckpoint(a.checkpoint, hub.vkey, hub.set, deviceNow);
  if (cp.cp.size !== a.to) fail("bad-browser-anchor", { detail: "size" });
  // Step 5, domain; the service must be one the policy lists for this hub.
  const service = policy.waict.get(a.service);
  if (!service || !service.hubs.includes(hub.name)) fail("unknown-waict-service", { service: a.service.slice(0, 253) });
  if (hub.domain === undefined || a.domain !== hub.domain) fail("bad-browser-anchor", { detail: "domain" });
  // Step 2
  checkManifest(a.manifest, hub.origin, a.domain, a.to, a.checkpoint);
  // Step 3
  const head = parseChainHeadWithProof(a.waict);
  if (!equalBytes(head.head.resourceHash, resourceHash(a.manifest))) fail("bad-waict-proof", { detail: "resource-hash" });
  // Step 4
  const pr = verifyPrefixRoot(head.signedPrefixRoot, service.domain, service.witnesses, service.quorum);
  if (!verifyMptProof(head.incProof, domainKey(a.domain), chainValue(head.head.bytes), pr.root)) {
    fail("bad-waict-proof", { detail: "inclusion" });
  }
  // Step 5, consistency from the anchor block's hub checkpoint.
  let position: "extends" | "behind" = "extends";
  if (a.to < base.size) {
    position = "behind";
  } else {
    if (a.from !== base.size) fail("consistency-mismatch", { what: "browser" });
    if (a.from === a.to) {
      if (a.consistency.length !== 0 || !equalBytes(base.root, cp.cp.root)) fail("split-view", { what: "hub" });
    } else if (!verifyConsistency(a.from, a.to, a.consistency, base.root, cp.cp.root)) {
      fail("consistency-failed", { what: "browser" });
    }
  }
  return {
    anchor: a,
    hub: cp,
    hubQuorum: hub.set.meets(cp.cosigs),
    service,
    independent: service.operator !== policy.operator,
    position,
  };
}
