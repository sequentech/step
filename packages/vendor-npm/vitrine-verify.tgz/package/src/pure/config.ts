// SPDX-License-Identifier: Apache-2.0
//
// The booth's check of an election's configuration (specs/entry.md, section
// 5.2). Before it encrypts a ballot, the booth needs the election's
// `vitrine/config/v1` statement and the event's `voting-opened` milestone
// (section 5.3), each in an `events` entry with a receipt that meets the
// quorum, the milestone naming the config entry, and checks that the key,
// ballot styles, policy and its own release match. This is the one Vitrine
// check that stops the booth.

import { b64decode } from "./base64.js";
import { compareBytes, concat, equalBytes, parseDecimal, parseSmall } from "./bytes.js";
import { checkLayout, decodeHash32, fieldText, fieldU64, fieldValue, isValidId, parseEntry, type Entry } from "./entry.js";
import { fail, VerifyError, type Params } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { judgeCheckpoint, logKeys, PolicyHistory } from "./history.js";
import { verifyInclusion } from "./merkle.js";
import { parseNote, verifyNote, type Note } from "./note.js";
import type { Policy } from "./policy.js";
import { validateProfileMinimums, type ProfileMeaningPackage } from "./profiles.js";
import { ELECTION_EVENT_KINDS as EVENT_KINDS, ELECTION_EVENTS_TAG as EVENTS_TAG } from "./tags.js";
import { parseTlogProof } from "./tlogproof.js";

export const CONFIG_HEADER = "vitrine/config/v1";
export const MILESTONE_HEADER = "vitrine/milestone/v1";

const POLICY_ID_RE = /^sha256:[0-9a-f]{64}$/;
const TOKEN_RE = /^[a-z0-9-]{1,64}$/;

export interface Release {
  package: string;
  version: string;
}

/** A `vitrine/config/v1` statement. */
export interface ConfigStatement {
  event: string;
  election: string;
  /** SHA-256 of the election public key, as the booth encrypts to it. */
  key: Uint8Array;
  /** The hash of the election's ballot styles (stylesHash). */
  styles: Uint8Array;
  opens: number;
  closes: number;
  policy: string;
  releases: Release[];
  transparency: "public" | "private";
  demo: boolean;
  time: number;
}

/** A `vitrine/milestone/v1` statement. */
export interface MilestoneStatement {
  event: string;
  kind: string;
  time: number;
  /** `config` lines (voting-opened): election ID to the config entry's leaf hash. */
  configs: Map<string, Uint8Array>;
  /** `count` lines (voting-closed): election ID to its accepted ballots. */
  counts: Map<string, bigint>;
}

export interface LineSpec {
  key: string;
  repeatable?: boolean;
}

/** The `<key> <value>` lines of a statement (section 5): in the order given,
 * each once unless repeatable, which may also be absent. */
export function statementLines(text: string, header: string, specs: readonly LineSpec[], part: string): Map<string, string[]> {
  const bad = (detail: string): never => fail("bad-config", { part, detail });
  if (!text.endsWith("\n")) bad("no-final-newline");
  const lines = text.slice(0, -1).split("\n");
  if (lines[0] !== header) bad("header");
  const out = new Map<string, string[]>(specs.map((s) => [s.key, []]));
  // Leaving spec `j` behind: a line that isn't repeatable must have been seen.
  const leave = (j: number): void => {
    const s = specs[j]!;
    if (!s.repeatable && out.get(s.key)!.length === 0) bad(`missing-${s.key}`);
  };
  let at = 0;
  for (const l of lines.slice(1)) {
    const sp = l.indexOf(" ");
    const key = sp < 0 ? l : l.slice(0, sp);
    while (at < specs.length && specs[at]!.key !== key) leave(at++);
    if (at === specs.length || sp < 0) bad(`line-${key.slice(0, 32)}`);
    const values = out.get(key)!;
    if (!specs[at]!.repeatable && values.length > 0) bad(`repeated-${key}`);
    values.push(l.slice(sp + 1));
  }
  while (at < specs.length) leave(at++);
  return out;
}

export function asConfigError<T>(part: string, f: () => T): T {
  try {
    return f();
  } catch (e) {
    if (e instanceof VerifyError && e.code !== "bad-config" && e.code !== "config-mismatch") throw new VerifyError("bad-config", { part, detail: e.code });
    throw e;
  }
}

export const one = (m: Map<string, string[]>, k: string): string => m.get(k)![0]!;
// Times beyond 2^53 seconds are refused rather than rounded.
const time = (s: string): number => parseSmall(s);

/** Parses a `vitrine/config/v1` statement's text. Throws `bad-config`. */
export function parseConfigStatement(text: string): ConfigStatement {
  return asConfigError("config", () => {
    const m = statementLines(
      text,
      CONFIG_HEADER,
      [
        { key: "event" },
        { key: "election" },
        { key: "key" },
        { key: "styles" },
        { key: "opens" },
        { key: "closes" },
        { key: "policy" },
        { key: "release", repeatable: true },
        { key: "transparency" },
        { key: "demo" },
        { key: "time" },
      ],
      "config",
    );
    const bad = (detail: string): never => fail("bad-config", { part: "config", detail });
    const event = one(m, "event");
    const election = one(m, "election");
    if (!isValidId(event)) bad("event");
    if (!isValidId(election)) bad("election");
    const policy = one(m, "policy");
    if (!POLICY_ID_RE.test(policy)) bad("policy");
    const releases = m.get("release")!.map((r) => {
      const [pkg, version, ...rest] = r.split(" ");
      if (rest.length > 0 || !pkg || !version || !isValidId(pkg) || !isValidId(version)) bad("release");
      return { package: pkg!, version: version! };
    });
    const transparency = one(m, "transparency");
    if (transparency !== "public" && transparency !== "private") return bad("transparency");
    const demo = one(m, "demo");
    if (demo !== "yes" && demo !== "no") bad("demo");
    return {
      event,
      election,
      key: b64decode(one(m, "key"), 32),
      styles: b64decode(one(m, "styles"), 32),
      opens: time(one(m, "opens")),
      closes: time(one(m, "closes")),
      policy,
      releases,
      transparency,
      demo: demo === "yes",
      time: time(one(m, "time")),
    };
  });
}

/** Parses a `vitrine/milestone/v1` statement's text. Throws `bad-config`. */
export function parseMilestoneStatement(text: string): MilestoneStatement {
  return asConfigError("opened", () => {
    const m = statementLines(
      text,
      MILESTONE_HEADER,
      [{ key: "event" }, { key: "kind" }, { key: "time" }, { key: "config", repeatable: true }, { key: "count", repeatable: true }],
      "opened",
    );
    const bad = (detail: string): never => fail("bad-config", { part: "opened", detail });
    const event = one(m, "event");
    if (!isValidId(event)) bad("event");
    const kind = one(m, "kind");
    if (!TOKEN_RE.test(kind)) bad("kind");
    if (m.get("config")!.length > 0 && kind !== EVENT_KINDS.votingOpened) bad("config-lines");
    if (m.get("count")!.length > 0 && kind !== EVENT_KINDS.votingClosed) bad("count-lines");
    const configs = new Map<string, Uint8Array>();
    for (const l of m.get("config")!) {
      const [election, leaf, ...rest] = l.split(" ");
      if (rest.length > 0 || !election || !leaf || !isValidId(election)) bad("config");
      if (configs.has(election!)) bad("config-repeated");
      configs.set(election!, b64decode(leaf!, 32));
    }
    const counts = new Map<string, bigint>();
    for (const l of m.get("count")!) {
      const [election, n, ...rest] = l.split(" ");
      if (rest.length > 0 || !election || !n || !isValidId(election)) bad("count");
      if (counts.has(election!)) bad("count-repeated");
      counts.set(election!, parseDecimal(n!));
    }
    return { event, kind, time: time(one(m, "time")), configs, counts };
  });
}

/** The SHA-256 digest of one ballot style, over the exact bytes the booth
 * receives. */
export function styleDigest(style: Uint8Array): Uint8Array {
  return sha256(style);
}

/** A config statement's `styles` (specs/entry.md, section 5.2): SHA-256 over
 * the concatenation of the styles' 32-byte digests, in ascending byte order
 * and without repeats. One style hashes a list of one digest. */
export function stylesHash(digests: readonly (Uint8Array | string)[]): Uint8Array {
  const sorted = digests.map((d) => decodeHash32(d)).sort(compareBytes);
  const unique = sorted.filter((d, i) => i === 0 || !equalBytes(d, sorted[i - 1]!));
  return sha256(concat(...unique));
}

/** The booth's styles check: `rendered`, the digest of the style it renders
 * (styleDigest), is in the list served with the config, and the list hashes
 * to the config's `styles`. Throws `config-mismatch` (field `styles`). */
export function checkStyles(styles: Uint8Array, digests: readonly (Uint8Array | string)[], rendered: Uint8Array): void {
  let list: Uint8Array[];
  try {
    list = digests.map((d) => decodeHash32(d));
  } catch {
    return fail("config-mismatch", { field: "styles", detail: "digest" });
  }
  if (rendered.length !== 32) throw new TypeError("rendered is a style's 32-byte digest");
  if (!list.some((d) => equalBytes(d, rendered))) fail("config-mismatch", { field: "styles", detail: "not-listed" });
  if (!equalBytes(stylesHash(list), styles)) fail("config-mismatch", { field: "styles", detail: "hash" });
}

export interface BoothCheckInput {
  /** The receipt (a tlog-proof) for the config statement's `events` entry. */
  config: string | Uint8Array;
  /** The receipt for the event's `voting-opened` milestone, in the same log. */
  opened: string | Uint8Array;
  /** The event and election the booth is for. */
  event: string;
  election: string;
  /** The election public key, as the booth encrypts to it. */
  publicKey: Uint8Array;
  /** The digests of the election's ballot styles, as served with the config:
   * 32 bytes each, or lowercase hex, or base64. */
  styles: readonly (Uint8Array | string)[];
  /** The exact bytes of the style the booth renders. */
  style: Uint8Array;
  /** The booth's own release. */
  release: Release;
  /** The device clock, POSIX seconds, for cosignatures in the future. */
  now?: number;
  /** The pinned policy with the successors applied so far. */
  history?: PolicyHistory;
  profileMetadata?: readonly ProfileMeaningPackage[];
}

export interface BoothConfig {
  statement: ConfigStatement;
  /** The config entry's leaf hash. */
  leaf: Uint8Array;
  /** The policy the config names: the pinned one or an applied successor. */
  policy: Policy;
  /** Every Vitrine view says the event is a demonstration. */
  demo: boolean;
}

interface EventsEntry {
  entry: Entry;
  leaf: Uint8Array;
  policy: Policy;
  statement: Note;
}

/** An `events` entry of `kind` with a receipt that meets the quorum, and its
 * statement signed by at least one authority of the policy in force at the
 * receipt's quorum time (section 5.1). */
function eventsEntry(h: PolicyHistory, log: string, receipt: string | Uint8Array, kind: string, part: string, now: number): EventsEntry {
  const bad = (detail: string, p: Params = {}): never => fail("bad-config", { part, detail, ...p });
  return asConfigError(part, () => {
    const tp = parseTlogProof(receipt);
    if (!tp.extra) return bad("missing-extra");
    const judged = judgeCheckpoint(h, tp.checkpoint, logKeys(log), now, { requireLogTime: true });
    if (!judged.meets) bad("quorum-not-met");
    const cp = judged.value.cp;
    const leaf = leafHash(tp.extra);
    if (tp.index >= cp.size || !verifyInclusion(tp.index, cp.size, leaf, tp.proof, cp.root)) bad("inclusion-failed");
    const entry = parseEntry(tp.extra);
    if (entry.tag !== EVENTS_TAG) bad("wrong-profile");
    checkLayout(entry);
    if (fieldText(entry, "kind") !== kind) bad("kind");
    const st = fieldValue(entry, "statement");
    if (!st || st.length === 0) return bad("statement");
    const statement = parseNote(st);
    const keys = [...judged.policy.authorities.values()].map((a) => a.vkey);
    if (verifyNote(statement, keys).length === 0) bad("signature");
    return { entry, leaf, policy: judged.policy, statement };
  });
}

/** The booth's check before it encrypts a ballot (specs/entry.md, section
 * 5.2). Throws VerifyError: `bad-config` (with `part` `config` or `opened`
 * and a `detail`) when a statement, entry or receipt doesn't verify or the
 * receipt doesn't meet the quorum; `config-mismatch` (with the `field`) when
 * they verify but don't match the booth. */
export function checkBoothConfig(policy: Policy, input: BoothCheckInput): BoothConfig {
  const now = input.now ?? Math.floor(Date.now() / 1000);
  const h = input.history ?? new PolicyHistory(policy);
  if (h.pinned.id !== policy.id) throw new TypeError("input.history is for another pinned policy");
  try {
    for (const { policy } of h.epochs) validateProfileMinimums(policy, input.profileMetadata);
  } catch (e) { return fail("bad-config", { part: "policy", detail: "profile-minimums" }); }
  const electionEventsLog = (p: Policy) => [...p.logs.values()].find((log) => log.profiles.some((profile) => profile.tag === EVENTS_TAG))?.name;
  const log = electionEventsLog(h.at(now)) ?? electionEventsLog(policy);
  if (log === undefined) return fail("bad-config", { part: "config", detail: "no-events-log" });
  const mismatch = (field: string, p: Params = {}): never => fail("config-mismatch", { field, ...p });

  const cfg = eventsEntry(h, log, input.config, EVENT_KINDS.config, "config", now);
  if (!equalBytes(fieldValue(cfg.entry, "subject")!, Uint8Array.of(0))) fail("bad-config", { part: "config", detail: "subject" });
  const statement = parseConfigStatement(cfg.statement.text);
  const opened = eventsEntry(h, log, input.opened, EVENT_KINDS.votingOpened, "opened", now);
  const milestone = parseMilestoneStatement(opened.statement.text);
  // The `milestones` rule (section 4.3): the statement states the entry's
  // kind and time.
  if (milestone.kind !== EVENT_KINDS.votingOpened || BigInt(milestone.time) !== fieldU64(opened.entry, "time")) {
    fail("bad-config", { part: "opened", detail: "statement-mismatch" });
  }

  if (statement.event !== input.event) mismatch("event");
  if (milestone.event !== input.event) mismatch("event", { part: "opened" });
  if (statement.election !== input.election) mismatch("election");
  // The milestone names, for this election, the config entry in force when
  // voting opened.
  const inForce = milestone.configs.get(input.election);
  if (!inForce || !equalBytes(inForce, cfg.leaf)) mismatch("opened");
  if (!equalBytes(statement.key, sha256(input.publicKey))) mismatch("key");
  checkStyles(statement.styles, input.styles, styleDigest(input.style));
  // The pinned policy or a successor applied to it.
  const named = h.byId(statement.policy);
  if (!named) return mismatch("policy");
  if (!statement.releases.some((r) => r.package === input.release.package && r.version === input.release.version)) mismatch("release");
  return { statement, leaf: cfg.leaf, policy: named, demo: statement.demo };
}
