// SPDX-License-Identifier: Apache-2.0
//
// Witness sets: the witness, group and quorum lines of tlog-policy, as the
// app quorum and each hub's quorum use them (specs/policy.md, sections 2.3,
// 2.5 and 3). Quorum evaluation, quorum times, split costs and party split
// costs (section 3, rules 5 and 12).

import type { Vkey } from "./note.js";

export interface Witness {
  name: string;
  vkey: Vkey;
  /** Who runs it; its own name when the policy gives no party. */
  party: string;
  /** True when the policy names the party explicitly. */
  partyGiven: boolean;
  url?: string;
}

export interface Group {
  name: string;
  k: number;
  members: string[];
}

/** A valid cosignature from a witness of the set. */
export interface Cosig {
  witness: string;
  /** POSIX seconds, never 0 (a cosignature dated 0 doesn't count). */
  timestamp: number;
}

/** The shape of a quorum, which is all that split costs depend on. */
export interface QuorumShape {
  readonly witnesses: ReadonlyMap<string, { readonly party: string }>;
  readonly groups: ReadonlyMap<string, Group>;
  readonly quorum: string;
}

const NONE: ReadonlySet<string> = new Set();

function cost(q: QuorumShape, name: string, faultyParties: ReadonlySet<string>, faultyWitnesses: ReadonlySet<string>, depth: number): number {
  if (depth > 64) return 0;
  const w = q.witnesses.get(name);
  if (w) return faultyParties.has(w.party) || faultyWitnesses.has(name) ? 0 : 1;
  const g = q.groups.get(name);
  if (!g) return 0;
  const m = 2 * g.k - g.members.length;
  if (m <= 0) return 0;
  const costs = g.members.map((x) => cost(q, x, faultyParties, faultyWitnesses, depth + 1)).sort((a, b) => a - b);
  let sum = 0;
  for (let i = 0; i < m; i++) sum += costs[i]!;
  return sum;
}

/** The split cost of a quorum (specs/policy.md, section 3, rule 5): the
 * least number of honest witnesses that would have to become faulty for two
 * inconsistent checkpoints to both satisfy it, with the witnesses of
 * `faultyParties`, and those named in `faultyWitnesses`, counted as faulty.
 * Exact for the group trees that rule 1b allows. */
export function splitCostOf(q: QuorumShape, faultyParties: ReadonlySet<string>, faultyWitnesses: ReadonlySet<string> = NONE): number {
  return cost(q, q.quorum, faultyParties, faultyWitnesses, 0);
}

/** Subsets examined at most by partySplitCostOf. */
export const PARTY_SEARCH_LIMIT = 200_000;

export interface PartySplitCost {
  value: number;
  /** False when the search stopped at PARTY_SEARCH_LIMIT: `value` is then
   * only a lower bound. */
  exact: boolean;
}

/** The party split cost (rule 5): the least number of parties, besides the
 * faulty ones, whose witnesses would all have to become faulty for the split
 * cost to be 0. Brute force over sets of parties, smallest first. It is at
 * most the split cost (the parties of the witnesses that achieve it). */
export function partySplitCostOf(
  q: QuorumShape,
  faultyParties: ReadonlySet<string>,
  faultyWitnesses: ReadonlySet<string> = NONE,
  limit = PARTY_SEARCH_LIMIT,
): PartySplitCost {
  const c = splitCostOf(q, faultyParties, faultyWitnesses);
  if (c === 0) return { value: 0, exact: true };
  const parties = [
    ...new Set([...q.witnesses].filter(([n, w]) => !faultyParties.has(w.party) && !faultyWitnesses.has(n)).map(([, w]) => w.party)),
  ].sort();
  let examined = 0;
  for (let s = 1; s < c; s++) {
    const idx = Array.from({ length: s }, (_, i) => i);
    if (s > parties.length) break;
    for (;;) {
      if (++examined > limit) return { value: s, exact: false };
      const f = new Set(faultyParties);
      for (const i of idx) f.add(parties[i]!);
      if (splitCostOf(q, f, faultyWitnesses) === 0) return { value: s, exact: true };
      // Next combination of s indices out of parties.length.
      let i = s - 1;
      while (i >= 0 && idx[i] === parties.length - s + i) i--;
      if (i < 0) break;
      idx[i]!++;
      for (let j = i + 1; j < s; j++) idx[j] = idx[j - 1]! + 1;
    }
  }
  return { value: c, exact: true };
}

export class WitnessSet implements QuorumShape {
  readonly witnesses = new Map<string, Witness>();
  readonly groups = new Map<string, Group>();
  quorum = "";

  /** The witnesses' keys, for note verification. */
  keys(): Vkey[] {
    return [...this.witnesses.values()].map((w) => w.vkey);
  }

  /** The witness whose key is `vkey`. */
  witnessFor(vkey: Vkey): Witness | undefined {
    for (const w of this.witnesses.values()) if (w.vkey === vkey) return w;
    return undefined;
  }

  private sat(name: string, signed: ReadonlySet<string>, depth: number): boolean {
    if (depth > 64) return false;
    if (this.witnesses.has(name)) return signed.has(name);
    const g = this.groups.get(name);
    if (!g) return false;
    let n = 0;
    for (const m of g.members) if (this.sat(m, signed, depth + 1)) n++;
    return n >= g.k;
  }

  /** True when the witnesses in `signed` satisfy the quorum. */
  satisfied(signed: ReadonlySet<string>): boolean {
    return this.sat(this.quorum, signed, 0);
  }

  /** True when `cosigs` satisfy the quorum. */
  meets(cosigs: readonly Cosig[]): boolean {
    return this.satisfied(new Set(cosigs.map((c) => c.witness)));
  }

  /** The quorum time (specs/receipt.md, section 1.3): the least, over the
   * sets of cosignatures that satisfy the quorum, of the set's latest
   * timestamp, taking each witness's earliest cosignature; undefined when the
   * quorum isn't met. */
  quorumTime(cosigs: readonly Cosig[]): number | undefined {
    const earliest = new Map<string, number>();
    for (const c of cosigs) {
      if (c.timestamp <= 0) continue;
      const t = earliest.get(c.witness);
      if (t === undefined || c.timestamp < t) earliest.set(c.witness, c.timestamp);
    }
    const timed = [...earliest].sort((a, b) => a[1] - b[1]);
    const signed = new Set<string>();
    for (const [w, t] of timed) {
      signed.add(w);
      if (this.satisfied(signed)) return t;
    }
    return undefined;
  }

  /** The quorum-vouched time (specs/receipt.md, section 3.1): the largest
   * `t` such that the witnesses whose latest timestamp is at least `t`
   * satisfy the quorum, or undefined when no such time exists. `latest` maps
   * witness names to their latest counting timestamp. */
  vouchedTime(latest: ReadonlyMap<string, number>): number | undefined {
    const times = [...new Set(latest.values())].filter((t) => t > 0).sort((a, b) => b - a);
    for (const t of times) {
      const signed = new Set<string>();
      for (const [w, lt] of latest) if (lt >= t) signed.add(w);
      if (this.satisfied(signed)) return t;
    }
    return undefined;
  }

  /** True when the cosignatures dated at or before `deadline` satisfy the
   * quorum. */
  meetsBy(cosigs: readonly Cosig[], deadline: number): boolean {
    return this.meets(cosigs.filter((c) => c.timestamp > 0 && c.timestamp <= deadline));
  }

  /** The split cost of the quorum with the witnesses of `faultyParties`
   * (and those named in `faultyWitnesses`) counted as faulty. */
  splitCost(faultyParties: ReadonlySet<string>, faultyWitnesses?: ReadonlySet<string>): number {
    return splitCostOf(this, faultyParties, faultyWitnesses);
  }

  /** The party split cost, with the same faulty witnesses. */
  partySplitCost(faultyParties: ReadonlySet<string>, faultyWitnesses?: ReadonlySet<string>): PartySplitCost {
    return partySplitCostOf(this, faultyParties, faultyWitnesses);
  }
}
