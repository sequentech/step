// SPDX-License-Identifier: Apache-2.0
//
// Witness sets: the witness, group and quorum lines of tlog-policy, as the
// app quorum and each hub's quorum use them (specs/policy.md, sections 2.3,
// 2.5 and 3). Quorum evaluation, quorum times and split costs.

import type { Vkey } from "./note.js";

export interface Witness {
  name: string;
  vkey: Vkey;
  /** Who runs it; its own name when the policy gives no party. */
  party: string;
  /** True when the policy names the party explicitly. */
  partyGiven: boolean;
  url?: string;
}

export interface Group {
  name: string;
  k: number;
  members: string[];
}

/** A valid cosignature from a witness of the set. */
export interface Cosig {
  witness: string;
  /** POSIX seconds, never 0 (a cosignature dated 0 doesn't count). */
  timestamp: number;
}

export class WitnessSet {
  readonly witnesses = new Map<string, Witness>();
  readonly groups = new Map<string, Group>();
  quorum = "";

  /** The witnesses' keys, for note verification. */
  keys(): Vkey[] {
    return [...this.witnesses.values()].map((w) => w.vkey);
  }

  /** The witness whose key is `vkey`. */
  witnessFor(vkey: Vkey): Witness | undefined {
    for (const w of this.witnesses.values()) if (w.vkey === vkey) return w;
    return undefined;
  }

  private sat(name: string, signed: ReadonlySet<string>, depth: number): boolean {
    if (depth > 64) return false;
    if (this.witnesses.has(name)) return signed.has(name);
    const g = this.groups.get(name);
    if (!g) return false;
    let n = 0;
    for (const m of g.members) if (this.sat(m, signed, depth + 1)) n++;
    return n >= g.k;
  }

  /** True when the witnesses in `signed` satisfy the quorum. */
  satisfied(signed: ReadonlySet<string>): boolean {
    return this.sat(this.quorum, signed, 0);
  }

  /** True when `cosigs` satisfy the quorum. */
  meets(cosigs: readonly Cosig[]): boolean {
    return this.satisfied(new Set(cosigs.map((c) => c.witness)));
  }

  /** The quorum time: the least, over the sets of cosignatures that satisfy
   * the quorum, of the set's latest timestamp, taking each witness's earliest
   * cosignature; undefined when the quorum isn't met. */
  quorumTime(cosigs: readonly Cosig[]): number | undefined {
    const timed = cosigs.filter((c) => c.timestamp > 0).sort((a, b) => a.timestamp - b.timestamp);
    const signed = new Set<string>();
    for (const c of timed) {
      signed.add(c.witness);
      if (this.satisfied(signed)) return c.timestamp;
    }
    return undefined;
  }

  /** The quorum-vouched time: the largest `t` such that the witnesses whose
   * latest valid timestamp is at least `t` satisfy the quorum, or 0 when no
   * such time exists. `latest` maps witness names to their latest timestamp. */
  vouchedTime(latest: ReadonlyMap<string, number>): number {
    const times = [...new Set(latest.values())].filter((t) => t > 0).sort((a, b) => b - a);
    for (const t of times) {
      const signed = new Set<string>();
      for (const [w, lt] of latest) if (lt >= t) signed.add(w);
      if (this.satisfied(signed)) return t;
    }
    return 0;
  }

  /** True when the cosignatures dated (non-zero) at or before `deadline`
   * satisfy the quorum (promise deadlines, specs/receipt.md, section 2). */
  meetsBy(cosigs: readonly Cosig[], deadline: number): boolean {
    return this.meets(cosigs.filter((c) => c.timestamp > 0 && c.timestamp <= deadline));
  }

  private cost(name: string, faulty: ReadonlySet<string>, depth: number): number {
    if (depth > 64) return 0;
    const w = this.witnesses.get(name);
    if (w) return faulty.has(w.party) ? 0 : 1;
    const g = this.groups.get(name);
    if (!g) return 0;
    const m = 2 * g.k - g.members.length;
    if (m <= 0) return 0;
    const costs = g.members.map((x) => this.cost(x, faulty, depth + 1)).sort((a, b) => a - b);
    let sum = 0;
    for (let i = 0; i < m; i++) sum += costs[i]!;
    return sum;
  }

  /** The split cost of the quorum with the witnesses of `faultyParties`
   * counted as faulty (specs/policy.md, section 3, rule 5). */
  splitCost(faultyParties: ReadonlySet<string>): number {
    return this.cost(this.quorum, faultyParties, 0);
  }
}
