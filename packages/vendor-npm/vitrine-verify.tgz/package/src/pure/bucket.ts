// SPDX-License-Identifier: Apache-2.0
//
// Bucket lookups (specs/entry.md, section 4.1): a log server or monitor lists
// the entries of a ballots log whose `ballot_id` lies in a bucket, the first
// 3 characters of the Tracking ID, and the client keeps the ones that share
// the Tracking ID it holds. What the server answers is untrusted data: each
// entry is parsed and checked against its bucket here, and a client that
// wants proof of an entry asks for its inclusion proof as for any other. No
// I/O.

import { b64decode } from "./base64.js";
import { BALLOT_STAGES, checkLayout, fieldText, fieldU64, fieldValue, parseEntry, type BallotStage } from "./entry.js";
import { VerifyError } from "./errors.js";
import { ELECTION_TAG } from "./tags.js";
import {
  bucketOf,
  parseBucket,
  parseTrackingPrefix,
  sharedGroups,
  trackingId,
  TRACKING_SHORT_GROUPS,
  type Bucket,
} from "./tracking.js";

/** The most ballots a lookup lists; the rest are counted in `more`. */
export const MAX_BUCKET_MATCHES = 5;
/** The most entries read from one answer. */
export const MAX_BUCKET_ENTRIES = 4096;
/** The largest answer, in bytes. */
export const MAX_BUCKET_ANSWER = 4 << 20;
/** The largest entry of an answer, in bytes: a ballots entry is well below. */
const MAX_BUCKET_ENTRY = 1024;

/** One entry of a bucket, as the server listed it. */
export interface BucketEntry {
  index: number;
  entry: Uint8Array;
}

/** A bucket answer, read but not trusted. */
export interface BucketAnswer {
  bucket: Bucket;
  /** The tree size the answer covers: every entry below it is listed, up to the
   * server's limit. Absent from a server that doesn't say. */
  size: number | undefined;
  /** The server stopped at its limit: the bucket has more entries than listed. */
  truncated: boolean;
  entries: BucketEntry[];
}

/** Reads the JSON a server answered to `lookup/<log>/tracking-bucket/<bucket>`.
 * Throws a TypeError when it isn't one. */
export function parseBucketAnswer(text: string, bucket: Bucket | string): BucketAnswer {
  const b = typeof bucket === "string" ? parseBucket(bucket) : bucket;
  if (text.length > MAX_BUCKET_ANSWER) throw new TypeError("bucket answer too large");
  let v: unknown;
  try {
    v = JSON.parse(text);
  } catch {
    throw new TypeError("not a bucket answer");
  }
  if (typeof v !== "object" || v === null || Array.isArray(v)) throw new TypeError("not a bucket answer");
  const o = v as Record<string, unknown>;
  if (o["lookup"] !== undefined && o["lookup"] !== "tracking-bucket") throw new TypeError("not a bucket answer");
  if (o["bucket"] !== undefined && (typeof o["bucket"] !== "string" || parseBucket(o["bucket"]).number !== b.number)) {
    throw new TypeError("the answer is for another bucket");
  }
  const raw = o["entries"];
  if (!Array.isArray(raw)) throw new TypeError("not a bucket answer");
  if (raw.length > MAX_BUCKET_ENTRIES) throw new TypeError("bucket answer has too many entries");
  const entries: BucketEntry[] = [];
  for (const e of raw as unknown[]) {
    if (typeof e !== "object" || e === null) throw new TypeError("not a bucket answer");
    const r = e as Record<string, unknown>;
    const index = r["index"];
    const entry = r["entry"];
    if (typeof index !== "number" || !Number.isSafeInteger(index) || index < 0 || typeof entry !== "string") {
      throw new TypeError("not a bucket answer");
    }
    // A string too long for an entry of the profile is no match for anything.
    if (entry.length > (MAX_BUCKET_ENTRY * 4) / 3 + 4) continue;
    try {
      entries.push({ index, entry: b64decode(entry) });
    } catch {
      /* not base64: not an entry */
    }
  }
  const size = o["size"];
  if (size !== undefined && (typeof size !== "number" || !Number.isSafeInteger(size) || size < 0)) {
    throw new TypeError("not a bucket answer");
  }
  return { bucket: b, size: size as number | undefined, truncated: o["truncated"] === true, entries };
}

/** The stage entries of one ballot that a bucket lists. */
export interface BallotStageEntry {
  index: number;
  stage: BallotStage;
  /** When the ballot box accepted this stage, POSIX seconds. */
  acceptedAt: number;
}

/** A ballot whose Tracking ID shares at least the short ID's groups with
 * the typed one. */
export interface BallotMatch {
  /** The ballot ID, 64 lowercase hex digits. */
  ballotId: string;
  /** The full Tracking ID, `FTBE-MHRX-...`. */
  trackingId: string;
  /** Whole groups of four characters, from the start, shared with the typed
   * ID, counting only the groups it completes: 2 for a short ID, up to 13
   * for a full one. */
  shared: number;
  /** Whether the whole typed ID is the start of this ballot's. */
  exact: boolean;
  event: string;
  election: string;
  /** Its `received`, `cast` and `audited` entries, by index. */
  entries: BallotStageEntry[];
}

export interface BucketMatches {
  /** At most MAX_BUCKET_MATCHES ballots: those that share more groups first,
   * then the one logged first. */
  matches: BallotMatch[];
  /** How many more ballots share at least the short ID. */
  more: number;
  /** The server hit its limit, so the bucket may hold more ballots than it
   * listed. Ask another server, or use the full lookup. */
  truncated: boolean;
  size: number | undefined;
}

const HEX = (b: Uint8Array): string => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");

/** What a ballots entry says, or undefined for an entry that isn't one. */
function ballotOf(bytes: Uint8Array): { id: Uint8Array; event: string; election: string; stage: BallotStage; acceptedAt: number } | undefined {
  try {
    const e = parseEntry(bytes);
    if (e.tag !== ELECTION_TAG) return undefined;
    checkLayout(e);
    const id = fieldValue(e, "ballot_id");
    const stage = fieldText(e, "stage");
    const at = fieldU64(e, "accepted_at");
    const event = fieldText(e, "event_id");
    const election = fieldText(e, "election_id");
    if (!id || id.length !== 32 || !stage || at === undefined || event === undefined || election === undefined) return undefined;
    if (!(BALLOT_STAGES as readonly string[]).includes(stage)) return undefined;
    return { id, event, election, stage: stage as BallotStage, acceptedAt: Number(at) };
  } catch (e) {
    if (e instanceof VerifyError) return undefined;
    throw e;
  }
}

/** Filters a bucket for what the user typed: a short or full Tracking ID (a
 * TypeError for anything else, or for a bucket the typed ID isn't in).
 * Lists one match for each ballot that shares at least the short ID's two
 * groups with it, the ballots that share more groups first. */
export function findInBucket(answer: BucketAnswer, typed: string): BucketMatches {
  const prefix = parseTrackingPrefix(typed);
  if (parseBucket(prefix.chars.slice(0, 3)).number !== answer.bucket.number) {
    throw new TypeError("the Tracking ID is in another bucket");
  }
  const byBallot = new Map<string, BallotMatch>();
  for (const { index, entry } of answer.entries) {
    if (entry.length > MAX_BUCKET_ENTRY) continue;
    const b = ballotOf(entry);
    // The server is not trusted to list only this bucket.
    if (!b || bucketOf(b.id).number !== answer.bucket.number) continue;
    const shared = sharedGroups(prefix, b.id);
    if (shared < TRACKING_SHORT_GROUPS) continue;
    const key = HEX(b.id);
    let m = byBallot.get(key);
    if (!m) {
      const full = trackingId(b.id);
      m = {
        ballotId: key,
        trackingId: full,
        shared,
        exact: full.replaceAll("-", "").startsWith(prefix.chars),
        event: b.event,
        election: b.election,
        entries: [],
      };
      byBallot.set(key, m);
    }
    if (!m.entries.some((x) => x.index === index)) m.entries.push({ index, stage: b.stage, acceptedAt: b.acceptedAt });
  }
  const all = [...byBallot.values()];
  for (const m of all) m.entries.sort((a, b) => a.index - b.index);
  all.sort((a, b) => b.shared - a.shared || a.entries[0]!.index - b.entries[0]!.index);
  return {
    matches: all.slice(0, MAX_BUCKET_MATCHES),
    more: Math.max(0, all.length - MAX_BUCKET_MATCHES),
    truncated: answer.truncated,
    size: answer.size,
  };
}
