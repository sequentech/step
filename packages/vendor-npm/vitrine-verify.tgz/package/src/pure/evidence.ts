// SPDX-License-Identifier: Apache-2.0
//
// Offline evidence verification, written from specs/evidence.md. A signed
// observation is never promoted to proof merely because a scan is unavailable.

import type { EvidenceResult } from "../types.js";
import { hexEncode } from "./base64.js";
import { parseHashLines, formatBlockDoc, parseBlockDoc, type Block } from "./blocks.js";
import { concat, equalBytes, fromUtf8, utf8 } from "./bytes.js";
import { EMPTY_TREE_ROOT, parseCheckpointText, verifyCheckpoint, type CheckedCheckpoint } from "./checkpoint.js";
import { checkLayout, fieldText, fieldU64, fieldValue, isValidId, parseEntry, type Entry } from "./entry.js";
import { fail, reason, toReason, VerifyError } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { authoritiesSigned, checkDeclaration, HubState, parseBlindedStatement, parseEnrollStatement, parseRotateStatement, parseUpdateStatement } from "./hubstate.js";
import { MAX_CONSISTENCY_HASHES, verifyConsistency, verifyInclusion } from "./merkle.js";
import { normalizeNote, parseNote, parseVkey, verifyNote, type Vkey } from "./note.js";
import { authorizedBy, parsePolicy, policyWords, profileAt, successorSigners, type Policy, type PolicyHub, type PolicyLog } from "./policy.js";
import { verifyPromise } from "./promise.js";
import { verifyPolicyAck } from "./statements.js";
import { EVENTS_TAG, EVENT_KINDS, HUB_TAGS, isEventsTag } from "./tags.js";
import { parseTlogProof, type TlogProof } from "./tlogproof.js";
import type { WitnessSet } from "./quorum.js";

export const EVIDENCE_HEADER = "vitrine/evidence/v1";
export const EVIDENCE_MEDIA_TYPE = "application/vnd.vitrine.evidence";
export const EVIDENCE_FILE_EXTENSION = ".vitrine-evidence";
export const EVIDENCE_KINDS = ["split-view", "broken-promise", "bad-entry", "hub-entry", "time-regression", "policy-equivocation", "bad-checkpoint"] as const;
export type EvidenceKind = (typeof EVIDENCE_KINDS)[number];
export interface Evidence { kind: EvidenceKind; policy: string; subject: string; blocks: Block[] }
export interface EvidenceOptions { now?: number }
export type EvidenceObjects = Record<string, string | Uint8Array | readonly (string | Uint8Array)[]>;

function bad(detail: string): never { return fail("bad-evidence", { detail }); }

/** Check the file's framing and required blocks before consulting any pin. */
export function parseEvidence(input: string | Uint8Array): Evidence {
  const doc = parseBlockDoc(input, { header: EVIDENCE_HEADER, keys: ["kind", "policy", "subject"], code: "bad-evidence" });
  if (doc.values.some((v) => v.length !== 1)) bad("headers");
  const [kind, policy, subject] = doc.values.map((v) => v[0]!) as [EvidenceKind, string, string];
  if (!EVIDENCE_KINDS.includes(kind)) fail("evidence-unknown-kind", { kind });
  if (!/^sha256:[0-9a-f]{64}$/.test(policy) || !isValidId(subject)) bad("policy-or-subject");
  const e = { kind, policy, subject, blocks: doc.blocks };
  switch (kind) {
    case "split-view": case "time-regression":
      one(e, "checkpoint", ["a"]); one(e, "checkpoint", ["b"]);
      if (kind === "time-regression") one(e, "policy-ack");
      break;
    case "broken-promise": one(e, "promise"); one(e, "checkpoint"); optional(e, "receipt"); break;
    case "bad-entry": one(e, "rule"); one(e, "policy-ack"); repeated(e, "receipt"); break;
    case "hub-entry": repeated(e, "receipt"); break;
    case "policy-equivocation":
      one(e, "policy", ["a"]); one(e, "policy", ["b"]); one(e, "receipt", ["a"]); one(e, "receipt", ["b"]); break;
    case "bad-checkpoint": one(e, "checkpoint"); break;
  }
  optional(e, "prefix");
  return e;
}
function matching(e: Evidence, type: string, args: readonly string[] = []): Block[] {
  return e.blocks.filter((b) => b.type === type && b.args.length === args.length && b.args.every((a, i) => a === args[i]));
}
function optional(e: Evidence, type: string, args: readonly string[] = []): Uint8Array | undefined {
  const bs = matching(e, type, args);
  if (bs.length > 1) bad(`duplicate-${type}`);
  return bs[0]?.body;
}
function one(e: Evidence, type: string, args: readonly string[] = []): Uint8Array {
  return optional(e, type, args) ?? bad(`missing-${type}`);
}
function repeated(e: Evidence, type: string): Block[] {
  const bs = matching(e, type);
  if (!bs.length) bad(`missing-${type}`);
  return bs;
}

interface Subject { vkey: Vkey; set: WitnessSet; log?: PolicyLog; hub?: PolicyHub }
interface Receipt { proof: TlogProof; checkpoint: CheckedCheckpoint; bytes: Uint8Array }
function signedCheckpoint(raw: Uint8Array, s: Subject, now: number, times = false): CheckedCheckpoint {
  return verifyCheckpoint(raw, s.vkey, s.set, now, { logTime: s.log?.logTime, requireLogTime: times });
}
function receipt(raw: Uint8Array, s: Subject, now: number, times = s.log !== undefined): Receipt {
  const proof = parseTlogProof(raw);
  if (!proof.extra) fail("missing-extra");
  const checkpoint = signedCheckpoint(utf8(proof.checkpoint), s, now, times);
  if (!verifyInclusion(proof.index, checkpoint.cp.size, leafHash(proof.extra), proof.proof, checkpoint.cp.root)) fail("inclusion-failed");
  return { proof, checkpoint, bytes: proof.extra };
}
function inconsistent(a: CheckedCheckpoint["cp"], b: CheckedCheckpoint["cp"], prefix?: Uint8Array): boolean {
  if (a.origin !== b.origin || b.size < a.size) bad("checkpoint-order-or-origin");
  if (a.size === b.size) return !equalBytes(a.root, b.root);
  if (a.size === 0n) return false;
  if (!prefix) bad("missing-prefix");
  const hashes = parseHashLines(prefix, MAX_CONSISTENCY_HASHES + 1);
  const root = hashes.shift() ?? bad("prefix-root");
  if (!verifyConsistency(a.size, b.size, hashes, root, b.root)) fail("consistency-failed");
  return !equalBytes(a.root, root);
}

/** A policy argument is already pinned; passing a successor means the caller
 * has accepted it. No policy embedded in the file creates a new trust root. */
export function verifyEvidence(input: string | Uint8Array, pinned: readonly Policy[], options: EvidenceOptions = {}): EvidenceResult {
  const out: EvidenceResult = { outcome: "invalid", proven: false, policyId: "", policyWords: [], kind: "", parties: [], reasons: [] };
  try {
    const e = parseEvidence(input);
    out.kind = e.kind; out.policyId = e.policy;
    const p = pinned.find((p) => p.id === e.policy && !p.draft);
    if (!p) { out.outcome = "unpinned"; out.reasons.push(reason("evidence-unpinned", { policy: e.policy })); return out; }
    out.policyWords = policyWords(p);
    const log = p.logs.get(e.subject); const hub = p.hubs.get(e.subject);
    const s: Subject | undefined = log ? { vkey: log.vkey, set: p.witnesses, log } : hub ? { vkey: hub.vkey, set: hub.set, hub } : undefined;
    if (!s) fail("evidence-wrong-subject");
    const now = options.now ?? Math.floor(Date.now() / 1000);
    const prove = (parties = [s.vkey.name]): EvidenceResult => {
      out.outcome = "proven"; out.proven = true; out.parties = [...new Set(parties)]; out.reasons.unshift(reason("misbehaviour-proven")); return out;
    };
    const not = (why: "not-proven" | "needs-scan" | "rule-unsupported" = "not-proven"): EvidenceResult => {
      out.outcome = "not-proven"; out.reasons.push(reason(why)); return out;
    };
    const faulty = (cp: CheckedCheckpoint, other?: CheckedCheckpoint): void => {
      const ids = new Set(other?.cosigs.map((c) => c.witness));
      for (const c of cp.cosigs) if (!other || ids.has(c.witness)) {
        const w = s.set.witnesses.get(c.witness)!;
        out.reasons.push(reason("faulty-witness", { witness: c.witness, party: w.party }));
      }
      if (s.set.meets(cp.cosigs) && (!other || s.set.meets(other.cosigs))) out.reasons.push(reason("trust-assumption-failed"));
    };
    switch (e.kind) {
      case "split-view": {
        const a = signedCheckpoint(one(e, "checkpoint", ["a"]), s, now);
        const b = signedCheckpoint(one(e, "checkpoint", ["b"]), s, now);
        if (!inconsistent(a.cp, b.cp, optional(e, "prefix"))) return not();
        faulty(a, b); return prove([s.vkey.name, ...a.cosigs.filter((c) => b.cosigs.some((d) => d.witness === c.witness)).map((c) => c.witness)]);
      }
      case "bad-checkpoint": {
        const n = parseNote(one(e, "checkpoint")); const cp = parseCheckpointText(n.text);
        if (cp.origin !== s.vkey.name) fail("wrong-origin");
        if (!normalizeNote(n, s.vkey, undefined, s.set.keys()).signer) fail("missing-signature");
        return cp.size === 0n && !equalBytes(cp.root, EMPTY_TREE_ROOT) ? prove() : not();
      }
      case "time-regression": {
        if (!log) fail("evidence-wrong-subject");
        verifyPolicyAck(one(e, "policy-ack"), log, p.id);
        const a = signedCheckpoint(one(e, "checkpoint", ["a"]), s, now, true);
        const b = signedCheckpoint(one(e, "checkpoint", ["b"]), s, now, true);
        if (b.cp.size <= a.cp.size) bad("checkpoint-order");
        return b.logTime! < a.logTime! ? prove() : not();
      }
      case "broken-promise": {
        if (!log) fail("evidence-wrong-subject");
        const promised = verifyPromise(one(e, "promise"), log.vkey, (id) => pinned.find((p) => p.id === id));
        // A second independently pinned policy isn't necessarily an ancestor.
        let ancestor: Policy | undefined = p;
        const seen = new Set<string>();
        while (ancestor.id !== promised.batch.policy && ancestor.supersedes) {
          if (seen.has(ancestor.id)) fail("evidence-policy-mismatch");
          seen.add(ancestor.id);
          ancestor = pinned.find((x) => x.id === ancestor!.supersedes);
          if (!ancestor) break;
        }
        if (!ancestor || ancestor.id !== promised.batch.policy) fail("evidence-policy-mismatch");
        const cp = signedCheckpoint(one(e, "checkpoint"), s, now, true);
        const raw = optional(e, "receipt");
        if (raw) {
          const r = receipt(raw, s, now, true);
          checkLayout(parseEntry(r.bytes));
          if (parseEntry(r.bytes).tag !== profileAt(log, r.proof.index).tag) fail("wrong-profile");
          if (!equalBytes(leafHash(r.bytes), promised.leaf)) fail("promise-leaf-mismatch");
          return cp.cp.size <= r.proof.index && cp.logTime! > promised.deadline ? prove() : not();
        }
        return cp.logTime! > promised.deadline + 3600 ? not("needs-scan") : not();
      }
      case "bad-entry": {
        if (!log) fail("evidence-wrong-subject");
        verifyPolicyAck(one(e, "policy-ack"), log, p.id);
        const rule = fromUtf8(one(e, "rule")).trimEnd().split(" ");
        if (rule.length !== 2 || !/^sha256:[0-9a-f]{64}$/.test(rule[0]!)) bad("rule");
        const rs = repeated(e, "receipt").map((b) => receipt(b.body, s, now));
        for (const b of e.blocks.filter((b) => b.type === "context")) {
          if (b.args.length !== 1) bad("context");
          const l = p.logs.get(b.args[0]!); if (!l) fail("evidence-wrong-subject");
          const r = receipt(b.body, { vkey: l.vkey, set: p.witnesses, log: l }, now);
          if (!p.witnesses.meets(r.checkpoint.cosigs)) fail("quorum-not-met");
        }
        for (const r of rs) if (profileAt(log, r.proof.index).meaningHash !== rule[0]) fail("evidence-policy-mismatch");
        // A staged successor's acknowledgement cannot change the profile
        // of entries sequenced before it took effect. Standalone evidence
        // lacks the accepted history and earliest-time scans needed here.
        if (p.supersedes) {
          out.outcome = "not-proven";
          out.reasons.push(reason("not-proven", { detail: "policy-history-required" }));
          return out;
        }
        if (rule[1] !== "vitrine/parse") return not("rule-unsupported");
        let broken = false;
        for (const r of rs) try {
          const parsed = parseEntry(r.bytes); checkLayout(parsed);
          if (parsed.tag !== profileAt(log, r.proof.index).tag) broken = true;
        } catch (err) { if (!(err instanceof VerifyError)) throw err; broken = true; }
        return broken ? prove() : not();
      }
      case "policy-equivocation": {
        if (!log || !log.profiles.some((pr) => isEventsTag(pr.tag))) fail("evidence-wrong-subject");
        const aRaw = one(e, "policy", ["a"]); const bRaw = one(e, "policy", ["b"]);
        // Rule 6 counts an authorized candidate even if it breaks another
        // policy rule. Parse its signed text without validating those rules.
        const candidate = (raw: Uint8Array): { id: string; idHash: Uint8Array; supersedes?: string } => {
          const note = parseNote(raw); const lines = note.text.trimEnd().split("\n");
          if (lines[0] !== "vitrine/policy/v1") bad("candidate-header");
          const supersedes = lines.filter((l) => l.startsWith("supersedes "));
          if (supersedes.length > 1) bad("candidate-supersedes");
          const idHash = sha256(note.text);
          return { id: `sha256:${hexEncode(idHash)}`, idHash, supersedes: supersedes[0]?.slice(11) };
        };
        const a = candidate(aRaw); const b = candidate(bRaw);
        const ra = receipt(one(e, "receipt", ["a"]), s, now); const rb = receipt(one(e, "receipt", ["b"]), s, now);
        for (const [candidate, raw, r] of [[a, aRaw, ra], [b, bRaw, rb]] as const) {
          if (candidate.supersedes !== p.id || !authorizedBy(p, raw)) fail("evidence-policy-mismatch");
          const entry = parseEntry(r.bytes); checkLayout(entry);
          if (!isEventsTag(entry.tag) || fieldText(entry, "kind") !== EVENT_KINDS.policy || !equalBytes(fieldValue(entry, "statement")!, raw) || !equalBytes(fieldValue(entry, "subject")!, concat(Uint8Array.of(1), candidate.idHash))) bad("policy-receipt");
          if (!p.witnesses.meets(r.checkpoint.cosigs)) fail("quorum-not-met");
        }
        if (ra.proof.index >= rb.proof.index) bad("policy-order");
        if (a.id === b.id) return not();
        out.reasons.push(reason("policy-equivocation", { successor: a.id }));
        const sa = successorSigners(p, aRaw); const sb = successorSigners(p, bRaw);
        const common = sa.filter((name) => sb.includes(name));
        return prove(common.length ? common : sb);
      }
      case "hub-entry": {
        if (!hub) fail("evidence-wrong-subject");
        const rs = repeated(e, "receipt").map((b) => receipt(b.body, s, now)).sort((a, b) => a.proof.index < b.proof.index ? -1 : a.proof.index > b.proof.index ? 1 : 0);
        const entries = rs.map((r) => { const entry = parseEntry(r.bytes); checkLayout(entry); return entry; });
        let offender = -1; let needsScan = false;
        const signed = (note: ReturnType<typeof parseNote>, key: Vkey): boolean => verifyNote(note, [key]).length > 0;
        const previousAnchors: { entry: Entry; cp: ReturnType<typeof parseCheckpointText> }[] = [];
        for (let i = 0; i < entries.length; i++) {
          const entry = entries[i]!; const r = rs[i]!;
          if (i && rs[i - 1]!.proof.index === r.proof.index) bad("duplicate-receipt");
          if (!Object.values(HUB_TAGS).includes(entry.tag as typeof HUB_TAGS.anchor)) bad("hub-profile");
          const text = (name: string): string => fieldText(entry, name)!;
          const val = (name: string): Uint8Array => fieldValue(entry, name)!;
          if (i && rs[i - 1]!.proof.index + 1n === r.proof.index) {
            const prev = entries[i - 1]!;
            if (fieldU64(entry, entry.tag === HUB_TAGS.index ? "time" : "received_at")! < fieldU64(prev, prev.tag === HUB_TAGS.index ? "time" : "received_at")!) offender = i;
          }
          if (entry.tag === HUB_TAGS.anchor) {
            const key = parseVkey(text("key")); const note = parseNote(val("checkpoint")); const cp = parseCheckpointText(note.text);
            if (cp.origin !== text("origin") || key.name !== text("origin")) bad("anchor-origin");
            if (!signed(note, key)) offender = i;
            for (const prev of previousAnchors) if (fieldText(prev.entry, "origin") === text("origin") && fieldText(prev.entry, "key") === text("key")) {
              if (inconsistent(prev.cp, cp, optional(e, "prefix"))) offender = i;
            }
            previousAnchors.push({ entry, cp }); needsScan = true;
          } else if (entry.tag === HUB_TAGS.enroll) {
            const st = parseEnrollStatement(val("statement"));
            if (st.hub !== hub.origin || st.kind !== text("kind") || st.name !== text("name") || st.key !== text("key")) offender = i;
          } else if (entry.tag === HUB_TAGS.blinded) {
            const st = parseBlindedStatement(val("statement")); const pseudo = hexEncode(val("pseudo_origin"));
            if (st.hub !== hub.origin || st.pseudo !== pseudo || st.seq !== fieldU64(entry, "seq") || !equalBytes(st.commitment, val("commitment"))) offender = i;
            for (let j = 0; j < i; j++) { const prev = entries[j]!;
              if (prev.tag === HUB_TAGS.blinded && equalBytes(fieldValue(prev, "pseudo_origin")!, val("pseudo_origin")) && fieldText(prev, "key") === text("key") && fieldU64(prev, "seq") === fieldU64(entry, "seq")) offender = i;
            }
          } else if (entry.tag === HUB_TAGS.rotate || entry.tag === HUB_TAGS.update) {
            const rotate = entry.tag === HUB_TAGS.rotate;
            const st = rotate ? parseRotateStatement(val("statement")) : parseUpdateStatement(val("statement"));
            const name = text(rotate ? "origin" : "origin");
            const key = parseVkey(text(rotate ? "old" : "key"));
            if (st.hub !== hub.origin || st.name !== name) offender = i;
            if (!signed(st.note, key)) offender = i;
            if (rotate) { const rot = parseRotateStatement(val("statement")); if (rot.old !== text("old") || rot.new !== text("new") || !signed(rot.note, parseVkey(text("new")))) offender = i; }
            const declaration = entries.slice(0, i).find((x) => x.tag === HUB_TAGS.enroll && fieldText(x, "name") === name && fieldText(x, "key") === key.text);
            if (declaration) {
              const enrolled = parseEnrollStatement(fieldValue(declaration, "statement")!);
              if (!signed(enrolled.note, key) || !enrolled.declaration) bad("enrolment");
              checkDeclaration(enrolled.declaration, key);
              if (authoritiesSigned(st.note, enrolled.declaration.authorities) < enrolled.declaration.rotation) offender = i;
            } else needsScan = true;
          } else needsScan = true;
        }
        if (offender >= 0) { faulty(rs[offender]!.checkpoint); return prove(); }
        // A complete prefix can be replayed without guessing missing state.
        if (rs.every((r, i) => r.proof.index === BigInt(i))) {
          const state = new HubState(hub.origin);
          for (let i = 0; i < rs.length; i++) try { state.apply(rs[i]!.bytes); } catch (err) {
            if (!(err instanceof VerifyError)) throw err;
            // An incomplete prefix cannot rule out an intervening declaration.
            if (i !== rs.length - 1) return not("needs-scan");
            faulty(rs[i]!.checkpoint); return prove();
          }
          return not();
        }
        return not(needsScan ? "needs-scan" : "not-proven");
      }
    }
  } catch (err) {
    // Preserve the readable identity of a framed but incomplete file for
    // display. This lookup never changes the invalid verdict or verifies
    // an object under an unpinned policy.
    if (!out.kind) try {
      const doc = parseBlockDoc(input, { header: EVIDENCE_HEADER, keys: ["kind", "policy", "subject"], code: "bad-evidence" });
      out.kind = doc.values[0]!.join(" "); out.policyId = doc.values[1]!.join(" ");
      const p = pinned.find((p) => p.id === out.policyId && !p.draft);
      if (p) out.policyWords = policyWords(p);
    } catch { /* The file has no usable framing metadata. */ }
    out.reasons.push(toReason(err)); return out;
  }
}

/** Frame the caller's signed objects. Construction doesn't confer validity. */
export function buildEvidence(kind: string, objects: EvidenceObjects, policy: Policy): string {
  const subject = objects.subject;
  if (typeof subject !== "string") bad("subject");
  const blocks: Block[] = [];
  for (const [label, value] of Object.entries(objects)) {
    if (label === "subject") continue;
    const [type, ...args] = label.split(" ");
    for (const body of Array.isArray(value) ? value : [value]) blocks.push({ type: type!, args, body: typeof body === "string" ? utf8(body) : body });
  }
  const file = fromUtf8(formatBlockDoc(EVIDENCE_HEADER, [`kind ${kind}`, `policy ${policy.id}`, `subject ${subject}`], blocks));
  parseEvidence(file);
  return file;
}

export function evidenceId(input: string | Uint8Array): string { return `sha256:${hexEncode(sha256(input))}`; }
