// SPDX-License-Identifier: Apache-2.0
//
// C2SP signed notes and verifier keys (c2sp.org/signed-note), with the two
// signature types Vitrine verifies here: 0x01 (Ed25519 over the note text) and
// 0x04 (timestamped Ed25519 checkpoint cosignatures, c2sp.org/tlog-cosignature).
// WAICT's 0x06 signatures are parsed by separate code (waict.ts, IT-23).

import { b64decode, b64encode, hexEncode } from "./base64.js";
import { concat, equalBytes, fromUtf8, readU64, u64ToNumber, utf8 } from "./bytes.js";
import { Ed25519Key } from "./ed25519.js";
import { fail } from "./errors.js";
import { sha256 } from "./hash.js";

export const SIG_ED25519 = 0x01;
export const SIG_COSIGNATURE_V1 = 0x04;

/** Limit on signature lines per note (the spec requires at least 16). */
export const MAX_NOTE_SIGNATURES = 100;

const EM_DASH_SPACE = "— ";

/** Go's unicode.IsSpace set: the "Unicode spaces" of the signed-note spec. */
function isUnicodeSpace(c: number): boolean {
  return (
    (c >= 0x09 && c <= 0x0d) ||
    c === 0x20 ||
    c === 0x85 ||
    c === 0xa0 ||
    c === 0x1680 ||
    (c >= 0x2000 && c <= 0x200a) ||
    c === 0x2028 ||
    c === 0x2029 ||
    c === 0x202f ||
    c === 0x205f ||
    c === 0x3000
  );
}

/** Key names and cosigner names: non-empty, at most 255 bytes, no Unicode
 * spaces, no plus signs and no control characters. */
export function isValidKeyName(name: string): boolean {
  if (name.length === 0) return false;
  for (const ch of name) {
    const c = ch.codePointAt(0)!;
    if (c < 0x20 || c === 0x7f || c === 0x2b || isUnicodeSpace(c)) return false;
  }
  try {
    return utf8(name).length <= 255;
  } catch {
    return false;
  }
}

export interface NoteSignature {
  name: string;
  keyId: number;
  /** The signature bytes after the 4-byte key ID. */
  sig: Uint8Array;
}

export interface Note {
  /** The note text, including its final newline. */
  text: string;
  textBytes: Uint8Array;
  sigs: NoteSignature[];
}

/** Parses a signed note. `input` is the whole note, signatures included. */
export function parseNote(input: Uint8Array | string): Note {
  const s = typeof input === "string" ? input : fromUtf8(input);
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 0x20 && c !== 0x0a) fail("bad-text", { detail: "control-character" });
  }
  // A string input must be well-formed UTF-16 (utf8 rejects lone surrogates).
  if (typeof input === "string") utf8(input);
  if (!s.endsWith("\n")) fail("bad-note", { detail: "no-final-newline" });
  const sep = s.lastIndexOf("\n\n");
  if (sep < 0) fail("bad-note", { detail: "no-signatures" });
  const text = s.slice(0, sep + 1);
  const sigBlock = s.slice(sep + 2);
  if (sigBlock.length === 0) fail("bad-note", { detail: "no-signatures" });
  const lines = sigBlock.slice(0, -1).split("\n");
  if (lines.length > MAX_NOTE_SIGNATURES) fail("too-large", { what: "signatures", limit: MAX_NOTE_SIGNATURES });
  const sigs: NoteSignature[] = [];
  for (const line of lines) {
    if (!line.startsWith(EM_DASH_SPACE)) fail("bad-note", { detail: "bad-signature-line" });
    const rest = line.slice(EM_DASH_SPACE.length);
    const sp = rest.indexOf(" ");
    if (sp < 0) fail("bad-note", { detail: "bad-signature-line" });
    const name = rest.slice(0, sp);
    const b64 = rest.slice(sp + 1);
    if (!isValidKeyName(name)) fail("bad-key-name");
    const raw = b64decode(b64);
    if (raw.length < 5) fail("bad-note", { detail: "short-signature" });
    const keyId = ((raw[0]! << 24) | (raw[1]! << 16) | (raw[2]! << 8) | raw[3]!) >>> 0;
    // Several lines may name one key: relays append lines, and normalization
    // (verifyNote, normalizeNote) keeps the earliest valid one.
    sigs.push({ name, keyId, sig: raw.subarray(4) });
  }
  return { text, textBytes: utf8(text), sigs };
}

/** Serialises a note from its text and signatures. */
export function formatNote(text: string, sigs: NoteSignature[]): string {
  let s = `${text}\n`;
  for (const sg of sigs) {
    const raw = concat(Uint8Array.of(sg.keyId >>> 24, (sg.keyId >>> 16) & 0xff, (sg.keyId >>> 8) & 0xff, sg.keyId & 0xff), sg.sig);
    s += `${EM_DASH_SPACE}${sg.name} ${b64encode(raw)}\n`;
  }
  return s;
}

/** The key ID of the signed-note spec: SHA-256(name || 0x0A || type || key)[:4]. */
export function keyId(name: string, type: number, key: Uint8Array): number {
  const h = sha256(name, "\n", Uint8Array.of(type), key);
  return ((h[0]! << 24) | (h[1]! << 16) | (h[2]! << 8) | h[3]!) >>> 0;
}

export interface Vkey {
  /** The vkey text. */
  text: string;
  name: string;
  keyId: number;
  type: number;
  /** The 32-byte Ed25519 public key. */
  key: Uint8Array;
  ed: Ed25519Key;
}

/** Parses a verifier key `<name>+<hex key ID>+<base64(type || key)>`. The key
 * ID must be the one the spec computes; the Ed25519 key must be canonical and
 * not of small order (rule 1 of specs/entry.md, "Signatures"). */
export function parseVkey(text: string, types: readonly number[] = [SIG_ED25519, SIG_COSIGNATURE_V1]): Vkey {
  const p1 = text.indexOf("+");
  if (p1 <= 0) fail("bad-vkey");
  const name = text.slice(0, p1);
  if (!isValidKeyName(name)) fail("bad-key-name");
  const hex = text.slice(p1 + 1, p1 + 9);
  if (text[p1 + 9] !== "+" || !/^[0-9a-f]{8}$/.test(hex)) fail("bad-vkey");
  const raw = b64decode(text.slice(p1 + 10));
  if (raw.length !== 33) fail("bad-vkey", { detail: "length" });
  const type = raw[0]!;
  if (!types.includes(type)) fail("bad-vkey", { detail: "type", type });
  const key = raw.slice(1);
  const id = keyId(name, type, key);
  if (id !== parseInt(hex, 16)) fail("bad-vkey", { detail: "key-id" });
  const ed = Ed25519Key.parse(key);
  if (!ed) fail("bad-public-key");
  return { text, name, keyId: id, type, key, ed };
}

/** Builds the vkey text for an Ed25519 key (used by tools and tests). */
export function formatVkey(name: string, type: number, key: Uint8Array): string {
  const id = keyId(name, type, key);
  return `${name}+${id.toString(16).padStart(8, "0")}+${b64encode(concat(Uint8Array.of(type), key))}`;
}

/** The message a cosignature/v1 signs for a checkpoint text. */
export function cosignatureMessage(timestamp: bigint, checkpointText: string): Uint8Array {
  return utf8(`cosignature/v1\ntime ${timestamp.toString()}\n${checkpointText}`);
}

export interface VerifiedSignature {
  vkey: Vkey;
  /** The signature line that verified (the one normalization keeps). */
  line: NoteSignature;
  /** Cosignature time in POSIX seconds (0x04 only); Infinity past 2^53. */
  timestamp?: number;
  /** The cosignature's u64 timestamp as written (0x04 only). */
  ts?: bigint;
}

function verifyLine(note: Note, vk: Vkey, sg: NoteSignature): VerifiedSignature | undefined {
  if (vk.type === SIG_ED25519) {
    return sg.sig.length === 64 && vk.ed.verify(note.textBytes, sg.sig) ? { vkey: vk, line: sg } : undefined;
  }
  if (vk.type === SIG_COSIGNATURE_V1) {
    if (sg.sig.length !== 72) return undefined;
    const ts = readU64(sg.sig, 0);
    // A cosignature dated 0 makes no claim about time and doesn't count at
    // all in v0.1 (specs/policy.md, section 2.3), so it never displaces a
    // dated line of the same key.
    if (ts === 0n) return undefined;
    if (!vk.ed.verify(cosignatureMessage(ts, note.text), sg.sig.subarray(8))) return undefined;
    return { vkey: vk, line: sg, timestamp: u64ToNumber(ts), ts };
  }
  return undefined;
}

/** Verifies the signatures of `note` from the known `keys`, as normalization
 * does (specs/entry.md, "Signatures"): for each key, of the lines that
 * verify, the one with the earliest timestamp, or the first one for a
 * signature without a timestamp. Lines from unknown keys are ignored, and so
 * is a line from a known key that doesn't verify: it counts as absent, so
 * nobody can veto a note by appending a bad line, and a relay can't make a
 * note look later than it was by appending a later one. 0x04 keys verify
 * cosignature/v1 messages, so they apply to checkpoints only. The result
 * follows the order of `keys`. */
export function verifyNote(note: Note, keys: readonly Vkey[]): VerifiedSignature[] {
  const best = new Map<Vkey, VerifiedSignature>();
  for (const sg of note.sigs) {
    for (const vk of keys) {
      if (vk.name !== sg.name || vk.keyId !== sg.keyId) continue;
      const have = best.get(vk);
      // An undated signature keeps its first valid line.
      if (have && have.ts === undefined) continue;
      const v = verifyLine(note, vk, sg);
      if (!v) continue;
      if (!have || (v.ts !== undefined && have.ts !== undefined && v.ts < have.ts)) best.set(vk, v);
    }
  }
  const out: VerifiedSignature[] = [];
  for (const vk of keys) {
    const v = best.get(vk);
    if (v && !out.includes(v)) out.push(v);
  }
  return out;
}

/** Byte order of key names, then of key IDs (specs/entry.md, normalization). */
export function compareSignatureLines(a: NoteSignature, b: NoteSignature): number {
  const an = utf8(a.name);
  const bn = utf8(b.name);
  const n = Math.min(an.length, bn.length);
  for (let i = 0; i < n; i++) if (an[i] !== bn[i]) return an[i]! - bn[i]!;
  if (an.length !== bn.length) return an.length - bn.length;
  return a.keyId - b.keyId;
}

export interface NormalizedNote {
  /** The normalized note: its text, an empty line, then the kept lines. */
  text: string;
  signer?: VerifiedSignature;
  logTime?: VerifiedSignature;
  /** The other expected keys' lines, sorted by key name and key ID. */
  others: VerifiedSignature[];
}

/** Normalizes a note (specs/entry.md, "Signatures"): the signer's line, then
 * (for an app-log checkpoint) the log-time cosignature, then one line per
 * other expected key, sorted by key name and then by key ID. Every other line
 * is dropped. Whether a missing signer is an error is the caller's call. */
export function normalizeNote(note: Note, signer: Vkey | undefined, logTime: Vkey | undefined, others: readonly Vkey[]): NormalizedNote {
  const keys = [...(signer ? [signer] : []), ...(logTime ? [logTime] : []), ...others];
  const verified = verifyNote(note, keys);
  const out: NormalizedNote = { text: "", others: [] };
  for (const v of verified) {
    if (signer && v.vkey === signer && !out.signer) out.signer = v;
    else if (logTime && v.vkey === logTime && !out.logTime) out.logTime = v;
    else out.others.push(v);
  }
  out.others.sort((a, b) => compareSignatureLines(a.line, b.line));
  const lines = [out.signer, out.logTime, ...out.others].filter((v): v is VerifiedSignature => v !== undefined).map((v) => v.line);
  out.text = lines.length > 0 ? formatNote(note.text, lines) : "";
  return out;
}

/** True when the same key appears twice in `keys` (by key bytes). */
export function sameKey(a: Vkey, b: Vkey): boolean {
  return equalBytes(a.key, b.key);
}

export function keyIdHex(id: number): string {
  return hexEncode(Uint8Array.of(id >>> 24, (id >>> 16) & 0xff, (id >>> 8) & 0xff, id & 0xff));
}
