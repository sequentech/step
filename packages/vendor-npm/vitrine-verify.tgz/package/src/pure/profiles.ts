// SPDX-License-Identifier: Apache-2.0
// Profile minimums from authenticated canonical meaning data (profile.md 2.1/3).
// TOML loading and rule execution are separate; these checks perform no I/O.
import { hexEncode } from "./base64.js";
import { fromUtf8, utf8 } from "./bytes.js";
import { fail } from "./errors.js";
import { sha256 } from "./hash.js";
import { parseCanonicalJson } from "./json.js";
import { anchorHubsHold, parsePolicy, type ParsePolicyOptions, type Policy } from "./policy.js";
import { isValidTag } from "./entry.js";

export interface ProfileMinimums { appHubs: number; independentHubs: number; monitorParties: number }
export interface ProfileMeaningPackage { canonicalMeaning: string | Uint8Array; rulesWasm?: Uint8Array; meaningHash?: string }
export interface AuthenticatedProfileMinimums { tag: string; meaningHash: string; minimums: ProfileMinimums }
const ELECTION_TAGS = new Set(["vitrine/election/ballots/v1", "vitrine/election/events/v1"]);
const ZERO: ProfileMinimums = { appHubs: 0, independentHubs: 0, monitorParties: 0 };
/** Published profile meanings, independently cross-checked against the complete
 * profile packages by the conformance tests. Hashes include optional rules.wasm. */
export const CORE_PROFILE_METADATA: readonly AuthenticatedProfileMinimums[] = [
  ["vitrine/audit/v1", "443a151ebf4290b52625b29a837fc6c8829e6259e6b3ea4d1690da0b85cba5aa", 0, 0, 0],
  ["vitrine/election/ballots/v1", "b77e087d44cf4621cb2ca2cdf982abb5c46f3b964ce79f9ff2b04ef645624ab1", 2, 1, 2],
  ["vitrine/election/events/v1", "a76f20437d3846a9cb930a379fe545c218e9e80f35c186fff6dd79e870b5ba51", 2, 1, 2],
  ["vitrine/events/v1", "8cb17e402b727a897e9ec69a0ff10645322174e7378f7b8675490114cec2e47e", 0, 0, 0],
  ["vitrine/hub/v1", "8fe391f04c23c7f3f82e8bf68d87b154cccb763a6f980ee6b551f61941169650", 0, 0, 0],
  ["vitrine/keys/v1", "e51060a15d9766d87d34f598b5e35f8eb854ae0cf19d6f511668c9688f00264d", 0, 0, 0],
  ["vitrine/registry/v1", "27a9e2c2d5fedccb6cc1133086f36446798d5deacf75eecf3aba3f4163340dc8", 0, 0, 0],
  ["vitrine/release/v1", "1db6c7ba6ccc4eb0c7aba8711141c416afe5a859beb4cb1efdc768266e8a1fa3", 0, 0, 0],
].map(([tag, hash, appHubs, independentHubs, monitorParties]) => Object.freeze({ tag: tag as string, meaningHash: `sha256:${hash}`, minimums: Object.freeze({ appHubs: appHubs as number, independentHubs: independentHubs as number, monitorParties: monitorParties as number }) }));
Object.freeze(CORE_PROFILE_METADATA);
function bad(detail: string): never { return fail("policy-invalid", { rule: 17, detail }); }
function maximum(a: ProfileMinimums, b: ProfileMinimums): ProfileMinimums {
  return { appHubs: Math.max(a.appHubs, b.appHubs), independentHubs: Math.max(a.independentHubs, b.independentHubs), monitorParties: Math.max(a.monitorParties, b.monitorParties) };
}

/** Hash every semantic section and optional module, not a caller-provided
 * hash label or a minimums summary. Omitted defaults remain omitted. */
export function authenticateProfileMinimums(pkg: ProfileMeaningPackage): AuthenticatedProfileMinimums {
  if (pkg.canonicalMeaning.length > 1 << 20 || (pkg.rulesWasm?.length ?? 0) > 1 << 20) bad("profile-metadata-size");
  const text = typeof pkg.canonicalMeaning === "string" ? pkg.canonicalMeaning : fromUtf8(pkg.canonicalMeaning);
  const bytes = utf8(text);
  if (bytes.length > 1 << 20) bad("profile-meaning-size");
  const value = parseCanonicalJson(text);
  if (!value || typeof value !== "object" || Array.isArray(value)) bad("profile-meaning-json");
  const o = value as Record<string, unknown>;
  if (Object.keys(o).some((key) => !["profile", "minimums", "field", "param", "lookup", "rule"].includes(key))) bad("profile-meaning-sections");
  const pending = [value];
  while (pending.length) {
    const node = pending.pop();
    if (typeof node === "number" && !Number.isSafeInteger(node)) bad("profile-meaning-number");
    if (node && typeof node === "object") for (const child of Object.values(node)) pending.push(child);
  }
  const profile = o.profile;
  if (!profile || typeof profile !== "object" || Array.isArray(profile)) bad("profile-identity");
  const tag = (profile as Record<string, unknown>).tag;
  if (typeof tag !== "string" || !isValidTag(tag)) bad("profile-tag");
  const minimums = { ...ZERO };
  if (o.minimums !== undefined) {
    if (!o.minimums || typeof o.minimums !== "object" || Array.isArray(o.minimums)) bad("profile-minimums");
    for (const [key, value] of Object.entries(o.minimums)) {
      if (!["app-hubs", "independent-hubs", "monitor-parties"].includes(key) || typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > 16) bad("profile-minimums");
      if (key === "app-hubs") minimums.appHubs = value;
      if (key === "independent-hubs") minimums.independentHubs = value;
      if (key === "monitor-parties") minimums.monitorParties = value;
    }
  }
  if (minimums.independentHubs > minimums.appHubs) bad("profile-minimums-independence");
  const length = new Uint8Array(4); new DataView(length.buffer).setUint32(0, bytes.length);
  const meaningHash = `sha256:${hexEncode(sha256("vitrine/profile-meaning/v1", length, bytes, pkg.rulesWasm ?? new Uint8Array()))}`;
  if (pkg.meaningHash !== undefined && pkg.meaningHash !== meaningHash) bad("profile-meaning-hash");
  return { tag, meaningHash, minimums };
}

function enforce(p: Policy, minimums: ProfileMinimums): void {
  if (!anchorHubsHold(p, minimums.appHubs, minimums.independentHubs)) bad("profile-hubs");
  if (new Set([...p.monitors.values()].map((m) => m.party)).size < minimums.monitorParties || p.monitorQuorum < minimums.monitorParties) bad("profile-monitors");
}

/** Known election tags cannot evade their floor with an unknown hash. */
export function enforceBuiltinProfileMinimums(p: Policy): ProfileMinimums {
  const minimums = [...p.logs.values()].some((log) => log.profiles.some((profile) => ELECTION_TAGS.has(profile.tag)))
    ? { appHubs: 2, independentHubs: 1, monitorParties: 2 } : { ...ZERO };
  enforce(p, minimums);
  return minimums;
}

/** Final minimum validation requires authenticated metadata for every
 * profile/version, including future `from` sizes. Unknown means unresolved. */
export function validateProfileMinimums(p: Policy, packages: readonly ProfileMeaningPackage[] = []): ProfileMinimums {
  let minimums = enforceBuiltinProfileMinimums(p);
  const profiles = [...CORE_PROFILE_METADATA, ...packages.map(authenticateProfileMinimums)];
  for (const log of p.logs.values()) for (const pin of log.profiles) {
    const profile = profiles.find((profile) => profile.tag === pin.tag && profile.meaningHash === pin.meaningHash);
    if (!profile) bad("profile-metadata-required");
    minimums = maximum(minimums, profile.minimums);
  }
  enforce(p, minimums);
  return minimums;
}

export interface PinPolicyOptions extends ParsePolicyOptions { profileMetadata?: readonly ProfileMeaningPackage[] }
/** New-pin admission: parsing alone only checks the signed policy structure.
 * Reserved tags must name a published core meaning. Custom meanings require
 * authenticated metadata; this does not claim to execute their domain rules. */
export function pinPolicy(input: string | Uint8Array, opts: PinPolicyOptions = {}): Policy {
  const p = parsePolicy(input, opts);
  if (p.draft) bad("draft-pin");
  validateProfileMinimums(p, opts.profileMetadata);
  for (const log of p.logs.values()) for (const pin of log.profiles) {
    if (pin.tag.startsWith("vitrine/") && !CORE_PROFILE_METADATA.some((m) => m.tag === pin.tag && m.meaningHash === pin.meaningHash)) bad("unknown-core-profile-meaning");
  }
  return p;
}
