// SPDX-License-Identifier: Apache-2.0
//
// SHA-256 helpers. `H(x)` in the specs is SHA-256; string parts are ASCII
// labels and are hashed as their UTF-8 bytes.

import { sha256 as nobleSha256 } from "@noble/hashes/sha2.js";
import { utf8 } from "./bytes.js";

export type HashPart = Uint8Array | string;

/** SHA-256 of the concatenation of `parts`. */
export function sha256(...parts: HashPart[]): Uint8Array {
  const h = nobleSha256.create();
  for (const p of parts) h.update(typeof p === "string" ? utf8(p) : p);
  return h.digest();
}

const LEAF = Uint8Array.of(0x00);
const NODE = Uint8Array.of(0x01);

/** RFC 6962 leaf hash `H(0x00 || entry)`. */
export function leafHash(entry: Uint8Array): Uint8Array {
  return sha256(LEAF, entry);
}

/** RFC 6962 interior node hash `H(0x01 || left || right)`. */
export function nodeHash(left: Uint8Array, right: Uint8Array): Uint8Array {
  return sha256(NODE, left, right);
}
