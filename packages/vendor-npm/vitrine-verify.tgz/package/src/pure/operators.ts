// SPDX-License-Identifier: Apache-2.0
// Independent implementation of specs/operators.md. These functions do no I/O.
import { hexEncode } from "./base64.js";
import { fromUtf8, parseDecimal, utf8 } from "./bytes.js";
import { fail, VerifyError } from "./errors.js";
import { sha256 } from "./hash.js";
import { parseNote, parseVkey, SIG_COSIGNATURE_V1, SIG_ED25519, verifyNote, type Note, type Vkey } from "./note.js";

export const OPERATOR_LIST_HEADER = "vitrine/operators/v1";
export const MAX_OPERATOR_LIST_BYTES = 256 << 10;
export const MAX_OPERATOR_ENTRIES = 1024;
export const MAX_OPERATOR_SIGNATURES = 16;
const MAX_LIFETIME = 90n * 86400n;
const NAME = /^[A-Za-z0-9._-]{1,64}$/;
const ID = /^sha256:[0-9a-f]{64}$/;
export type OperatorKind = "shared-log" | "hub" | "witness" | "monitor";
export type OperatorState = "usable" | "retired" | "rejected";
export interface OperatorEntry { id: string; kind: OperatorKind; party: string; state: OperatorState; url: string; vkey: Vkey; policy?: string }
export interface OperatorList { raw: string; note: Note; id: string; sequence: bigint; issued: bigint; expires: bigint; previous?: string; entries: OperatorEntry[] }
export interface OperatorListPin { sequence: bigint; id: string }
export interface OperatorListTrust { authorities: readonly Vkey[]; threshold: number; now: number; expectedId?: string; fresh?: boolean }

function bad(detail: string): never { return fail("bad-operator-list", { detail }); }
function refused(detail: string): never { return fail("operator-list-refused", { detail }); }
function number(s: string): bigint { try { return parseDecimal(s); } catch { return bad("integer"); } }
function url(s: string): boolean {
  try {
    const u = new URL(s);
    return !u.username && !u.password && (u.protocol === "https:" && !!u.hostname || u.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(u.hostname));
  } catch { return false; }
}
function textId(s: string): string { return ID.test(s) ? s : bad("hash-id"); }

export function parseOperatorList(input: string | Uint8Array): OperatorList {
  try {
    const bytes = typeof input === "string" ? utf8(input) : input;
    if (bytes.length > MAX_OPERATOR_LIST_BYTES) bad("size");
    const raw = typeof input === "string" ? input : fromUtf8(input);
    const separator = raw.lastIndexOf("\n\n");
    if (separator < 0) bad("signatures");
    let signatures = 0;
    for (let i = separator + 2; i < raw.length; i++) if (raw[i] === "\n" && ++signatures > MAX_OPERATOR_SIGNATURES) bad("signature-count");
    let lineCount = 0;
    for (let i = 0; i <= separator; i++) if (raw[i] === "\n" && ++lineCount > MAX_OPERATOR_ENTRIES + 5) bad("entry-count");
    const note = parseNote(raw);
    const lines = note.text.slice(0, -1).split("\n");
    if (lines[0] !== OPERATOR_LIST_HEADER || lines.length < 5) bad("header");
    const value = (i: number, key: string): string => {
      const parts = lines[i]?.split(" ");
      if (!parts || parts.length !== 2 || parts[0] !== key || !parts[1]) bad(`line-${key}`);
      return parts[1]!;
    };
    const sequence = number(value(1, "sequence")); const issued = number(value(2, "issued")); const expires = number(value(3, "expires"));
    const previousText = value(4, "previous");
    const previous = previousText === "none" ? undefined : textId(previousText);
    if (sequence < 1n || (sequence === 1n) !== (previous === undefined)) bad("sequence-previous");
    if (issued >= expires || expires - issued > MAX_LIFETIME) bad("lifetime");
    const entries: OperatorEntry[] = []; const keys = new Set<string>(); let last = "";
    for (const line of lines.slice(5)) {
      const t = line.split(" ");
      if (t.length !== 8 || t.some((x) => !x) || t[0] !== "entry") bad("entry-line");
      const [, id, kind, party, state, address, key, policy] = t as [string, string, OperatorKind, string, OperatorState, string, string, string];
      if (!NAME.test(id) || !NAME.test(party) || id <= last) bad("entry-order-or-name");
      if (!["shared-log", "hub", "witness", "monitor"].includes(kind) || !["usable", "retired", "rejected"].includes(state) || !url(address)) bad("entry-values");
      const vkey = parseVkey(key, [kind === "witness" ? SIG_COSIGNATURE_V1 : SIG_ED25519]);
      const publicKey = hexEncode(vkey.key);
      if (keys.has(publicKey)) bad("duplicate-key");
      keys.add(publicKey); last = id;
      const policyId = kind === "hub" || kind === "shared-log" ? textId(policy) : policy === "none" ? undefined : bad("entry-policy");
      entries.push({ id, kind, party, state, url: address, vkey, ...(policyId ? { policy: policyId } : {}) });
    }
    return { raw, note, id: `sha256:${hexEncode(sha256(note.textBytes))}`, sequence, issued, expires, ...(previous ? { previous } : {}), entries };
  } catch (error) {
    if (error instanceof VerifyError && error.code !== "bad-operator-list") return bad(error.code);
    throw error;
  }
}

export function verifyOperatorList(input: string | Uint8Array | OperatorList, trust: OperatorListTrust): OperatorList {
  // Reparse object input: mutating a parsed object's fields cannot make a
  // signature authenticate values that aren't in its signed text.
  const list = parseOperatorList(typeof input === "object" && !(input instanceof Uint8Array) ? input.raw : input);
  if (!Number.isSafeInteger(trust.now) || trust.now < 0) throw new TypeError("operator-list now must be a nonnegative safe integer");
  if (!Number.isSafeInteger(trust.threshold) || trust.threshold < 1 || trust.threshold > trust.authorities.length) refused("authority-threshold");
  const unique = new Set(trust.authorities.map((k) => hexEncode(k.key)));
  if (unique.size !== trust.authorities.length || trust.authorities.some((k) => k.type !== SIG_ED25519)) refused("authority-keys");
  if (trust.expectedId !== undefined && list.id !== textId(trust.expectedId)) refused("hash");
  const signatures = new Set(verifyNote(list.note, trust.authorities).map((s) => hexEncode(s.vkey.key)));
  if (signatures.size < trust.threshold) refused("signatures");
  if (list.issued > BigInt(trust.now) + 300n) refused("future");
  if (trust.fresh !== false && list.expires <= BigInt(trust.now)) refused("expired");
  return list;
}

/** Authenticate every link, then check freshness only at the target. The
 * caller persists the returned pin atomically in its trusted local store. */
export function updateOperatorList(pin: OperatorListPin, chain: readonly (string | Uint8Array)[], trust: OperatorListTrust, maximum: OperatorListPin = pin): { list: OperatorList; pin: OperatorListPin } {
  if (!ID.test(pin.id) || pin.sequence < 1n || !ID.test(maximum.id) || maximum.sequence < pin.sequence || maximum.sequence === pin.sequence && maximum.id !== pin.id) refused("pin");
  if (!chain.length) refused("missing-chain");
  let head = { ...pin }; let target: OperatorList | undefined;
  for (let i = 0; i < chain.length; i++) {
    const list = verifyOperatorList(chain[i]!, { ...trust, expectedId: undefined, fresh: false });
    if (list.sequence === maximum.sequence && list.id !== maximum.id) refused("equivocation");
    if (i === 0 && list.sequence === pin.sequence && list.id === pin.id) { target = list; continue; }
    if (list.sequence !== head.sequence + 1n || list.previous !== head.id) refused("chain");
    head = { sequence: list.sequence, id: list.id }; target = list;
  }
  if (head.sequence < maximum.sequence || head.sequence === maximum.sequence && head.id !== maximum.id) refused("rollback-or-equivocation");
  const list = verifyOperatorList(target!, { ...trust, expectedId: head.id, fresh: true });
  if (trust.expectedId !== undefined && list.id !== trust.expectedId) refused("hash");
  return { list, pin: head };
}

export function checkOperatorSelection(list: OperatorList, selection: Omit<OperatorEntry, "id" | "state">): OperatorEntry {
  const entry = list.entries.find((e) => e.kind === selection.kind && e.state === "usable" && e.url === selection.url && e.party === selection.party && e.policy === selection.policy && e.vkey.text === selection.vkey.text);
  return entry ?? refused("selection");
}
