// SPDX-License-Identifier: Apache-2.0
//
// Canonical base64 (RFC 4648, section 4, with padding), base64url without
// padding, and lowercase hex. Decoders reject every non-canonical encoding
// (IT-24): wrong padding, characters outside the alphabet, and non-zero bits
// after the last byte.

import { fail } from "./errors.js";

const STD = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

function table(alphabet: string): Int16Array {
  const t = new Int16Array(128).fill(-1);
  for (let i = 0; i < alphabet.length; i++) t[alphabet.charCodeAt(i)] = i;
  return t;
}

const STD_T = table(STD);
const URL_T = table(URL);

function encodeWith(b: Uint8Array, alphabet: string, pad: boolean): string {
  let s = "";
  let i = 0;
  for (; i + 3 <= b.length; i += 3) {
    const n = (b[i]! << 16) | (b[i + 1]! << 8) | b[i + 2]!;
    s += alphabet[(n >>> 18) & 63]! + alphabet[(n >>> 12) & 63]! + alphabet[(n >>> 6) & 63]! + alphabet[n & 63]!;
  }
  const rest = b.length - i;
  if (rest === 1) {
    const n = b[i]! << 16;
    s += alphabet[(n >>> 18) & 63]! + alphabet[(n >>> 12) & 63]!;
    if (pad) s += "==";
  } else if (rest === 2) {
    const n = (b[i]! << 16) | (b[i + 1]! << 8);
    s += alphabet[(n >>> 18) & 63]! + alphabet[(n >>> 12) & 63]! + alphabet[(n >>> 6) & 63]!;
    if (pad) s += "=";
  }
  return s;
}

function decodeWith(s: string, t: Int16Array, padded: boolean): Uint8Array {
  let body = s;
  if (padded) {
    if (s.length % 4 !== 0) fail("bad-base64");
    if (s.endsWith("==")) body = s.slice(0, -2);
    else if (s.endsWith("=")) body = s.slice(0, -1);
  }
  const tail = body.length % 4;
  if (tail === 1) fail("bad-base64");
  if (padded && s.length > 0 && body.length === s.length && tail !== 0) fail("bad-base64");
  const vals = new Uint8Array(body.length);
  for (let i = 0; i < body.length; i++) {
    const c = body.charCodeAt(i);
    const v = c < 128 ? t[c]! : -1;
    if (v < 0) fail("bad-base64");
    vals[i] = v;
  }
  const out = new Uint8Array(Math.floor((body.length * 3) / 4));
  let o = 0;
  let i = 0;
  for (; i + 4 <= body.length; i += 4) {
    const n = (vals[i]! << 18) | (vals[i + 1]! << 12) | (vals[i + 2]! << 6) | vals[i + 3]!;
    out[o++] = (n >>> 16) & 0xff;
    out[o++] = (n >>> 8) & 0xff;
    out[o++] = n & 0xff;
  }
  if (tail === 2) {
    if ((vals[i + 1]! & 0x0f) !== 0) fail("bad-base64");
    out[o++] = (vals[i]! << 2) | (vals[i + 1]! >>> 4);
  } else if (tail === 3) {
    if ((vals[i + 2]! & 0x03) !== 0) fail("bad-base64");
    const n = (vals[i]! << 10) | (vals[i + 1]! << 4) | (vals[i + 2]! >>> 2);
    out[o++] = (n >>> 8) & 0xff;
    out[o++] = n & 0xff;
  }
  return out;
}

export function b64encode(b: Uint8Array): string {
  return encodeWith(b, STD, true);
}

/** Decodes canonical padded base64; `len` requires an exact decoded length. */
export function b64decode(s: string, len?: number): Uint8Array {
  const out = decodeWith(s, STD_T, true);
  if (len !== undefined && out.length !== len) fail("bad-base64", { length: out.length, want: len });
  return out;
}

export function b64urlEncode(b: Uint8Array): string {
  return encodeWith(b, URL, false);
}

/** Decodes canonical base64url without padding. */
export function b64urlDecode(s: string, len?: number): Uint8Array {
  if (s.includes("=")) fail("bad-base64");
  const out = decodeWith(s, URL_T, false);
  if (len !== undefined && out.length !== len) fail("bad-base64", { length: out.length, want: len });
  return out;
}

const HEX = "0123456789abcdef";

export function hexEncode(b: Uint8Array): string {
  let s = "";
  for (let i = 0; i < b.length; i++) s += HEX[b[i]! >>> 4]! + HEX[b[i]! & 15]!;
  return s;
}

/** Decodes lowercase hex; `len` requires an exact decoded length. */
export function hexDecode(s: string, len?: number): Uint8Array {
  if (s.length % 2 !== 0 || !/^[0-9a-f]*$/.test(s)) fail("bad-hex");
  const out = new Uint8Array(s.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(s.slice(2 * i, 2 * i + 2), 16);
  if (len !== undefined && out.length !== len) fail("bad-hex", { length: out.length, want: len });
  return out;
}
