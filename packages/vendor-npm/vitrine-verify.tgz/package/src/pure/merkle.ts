// SPDX-License-Identifier: Apache-2.0
//
// RFC 6962 / RFC 9162 Merkle trees: inclusion proof verification (RFC 9162,
// section 2.1.3.2), consistency proof verification (section 2.1.4.2) and the
// tree hash of a list of leaf hashes (section 2.1.1).

import { equalBytes } from "./bytes.js";
import { nodeHash, sha256 } from "./hash.js";

/** Inclusion proofs in receipts have at most 63 hashes (specs/receipt.md). */
export const MAX_INCLUSION_HASHES = 63;
/** Consistency proofs between sizes below 2^63 have at most 64 hashes. */
export const MAX_CONSISTENCY_HASHES = 64;

/** Verifies that `leaf` (a leaf hash) is at `index` in the tree of `size`
 * leaves with root `root`. */
export function verifyInclusion(
  index: bigint,
  size: bigint,
  leaf: Uint8Array,
  proof: readonly Uint8Array[],
  root: Uint8Array,
): boolean {
  if (index < 0n || index >= size || proof.length > MAX_INCLUSION_HASHES) return false;
  let fn = index;
  let sn = size - 1n;
  let r = leaf;
  for (const p of proof) {
    if (sn === 0n) return false;
    if ((fn & 1n) === 1n || fn === sn) {
      r = nodeHash(p, r);
      if ((fn & 1n) === 0n) {
        while ((fn & 1n) === 0n && fn !== 0n) {
          fn >>= 1n;
          sn >>= 1n;
        }
      }
    } else {
      r = nodeHash(r, p);
    }
    fn >>= 1n;
    sn >>= 1n;
  }
  return sn === 0n && equalBytes(r, root);
}

/** Verifies that the tree of size `second` with root `secondRoot` extends the
 * tree of size `first` with root `firstRoot`. `first` must be at least 1;
 * equal sizes need an empty proof and equal roots. */
export function verifyConsistency(
  first: bigint,
  second: bigint,
  proof: readonly Uint8Array[],
  firstRoot: Uint8Array,
  secondRoot: Uint8Array,
): boolean {
  if (first < 1n || first > second || proof.length > MAX_CONSISTENCY_HASHES) return false;
  if (first === second) return proof.length === 0 && equalBytes(firstRoot, secondRoot);
  if (proof.length === 0) return false;
  let path = proof;
  if ((first & (first - 1n)) === 0n) path = [firstRoot, ...proof];
  let fn = first - 1n;
  let sn = second - 1n;
  while ((fn & 1n) === 1n) {
    fn >>= 1n;
    sn >>= 1n;
  }
  let fr = path[0]!;
  let sr = path[0]!;
  for (let i = 1; i < path.length; i++) {
    const c = path[i]!;
    if (sn === 0n) return false;
    if ((fn & 1n) === 1n || fn === sn) {
      fr = nodeHash(c, fr);
      sr = nodeHash(c, sr);
      if ((fn & 1n) === 0n) {
        while ((fn & 1n) === 0n && fn !== 0n) {
          fn >>= 1n;
          sn >>= 1n;
        }
      }
    } else {
      sr = nodeHash(sr, c);
    }
    fn >>= 1n;
    sn >>= 1n;
  }
  return sn === 0n && equalBytes(fr, firstRoot) && equalBytes(sr, secondRoot);
}

/** The RFC 9162 tree hash over `leaves` (already leaf hashes). */
export function treeRoot(leaves: readonly Uint8Array[]): Uint8Array {
  if (leaves.length === 0) return sha256();
  if (leaves.length === 1) return leaves[0]!;
  let k = 1;
  while (k * 2 < leaves.length) k *= 2;
  return nodeHash(treeRoot(leaves.slice(0, k)), treeRoot(leaves.slice(k)));
}
