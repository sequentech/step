// SPDX-License-Identifier: Apache-2.0
//
// Promises and promise batches (specs/receipt.md, section 2): the log's signed
// commitment to include a leaf by `time + mmd + 30`.

import { b64decode, b64encode } from "./base64.js";
import { parseDecimal, u64ToNumber } from "./bytes.js";
import { fail, VerifyError } from "./errors.js";
import { leafHash } from "./hash.js";
import { verifyInclusion } from "./merkle.js";
import { parseNote, verifyNote, type Note, type Vkey } from "./note.js";
import { parseProofLayout } from "./tlogproof.js";

export const PROMISE_HEADER = "vitrine/promise/v1";
export const PROMISE_BATCH_HEADER = "vitrine/promise-batch/v1";
/** A promise's inclusion proof into its batch has at most 20 hashes. */
export const MAX_PROMISE_HASHES = 20;
/** A batch promises 1 to 2^20 leaves. */
export const MAX_PROMISE_BATCH = 1 << 20;
/** Allowed clock skew between the log and the witnesses, in seconds. */
export const PROMISE_SKEW = 30;

export interface PromiseBatch {
  origin: string;
  /** POSIX seconds when issued. */
  time: number;
  mmd: number;
  size: number;
  root: Uint8Array;
}

export interface ParsedPromise {
  /** The promised leaf hash. */
  leaf: Uint8Array;
  index: number;
  proof: Uint8Array[];
  /** The batch note, verbatim. */
  batchNote: string;
}

export interface VerifiedPromise extends ParsedPromise {
  batch: PromiseBatch;
  note: Note;
  /** `time + mmd + 30`, POSIX seconds. */
  deadline: number;
}

function asBadPromise<T>(f: () => T): T {
  try {
    return f();
  } catch (e) {
    if (e instanceof VerifyError && (e.code === "bad-proof" || e.code === "bad-number" || e.code === "bad-base64")) {
      throw new VerifyError("bad-promise", { detail: e.code });
    }
    throw e;
  }
}

/** Parses a promise: header, `leaf`, `index`, at most 20 hashes, an empty
 * line and the batch note. */
export function parsePromise(input: Uint8Array | string): ParsedPromise {
  return asBadPromise(() => {
    const { values, hashes, note } = parseProofLayout(
      input,
      PROMISE_HEADER,
      [
        { key: "leaf", optional: false },
        { key: "index", optional: false },
      ],
      MAX_PROMISE_HASHES,
    );
    const leaf = b64decode(values[0]!, 32);
    const index = Number(parseDecimal(values[1]!, BigInt(MAX_PROMISE_BATCH - 1)));
    return { leaf, index, proof: hashes, batchNote: note };
  });
}

/** Parses a promise batch's note text (without signatures). */
export function parsePromiseBatchText(text: string): PromiseBatch {
  return asBadPromise(() => {
    if (!text.endsWith("\n")) fail("bad-promise", { detail: "no-final-newline" });
    const lines = text.slice(0, -1).split("\n");
    if (lines.length !== 6 || lines[0] !== PROMISE_BATCH_HEADER) fail("bad-promise", { detail: "batch-lines" });
    const value = (i: number, key: string): string => {
      const l = lines[i]!;
      if (!l.startsWith(`${key} `)) fail("bad-promise", { detail: `batch-${key}` });
      return l.slice(key.length + 1);
    };
    const origin = value(1, "origin");
    const time = u64ToNumber(parseDecimal(value(2, "time")));
    const mmd = u64ToNumber(parseDecimal(value(3, "mmd")));
    const size = Number(parseDecimal(value(4, "size"), BigInt(MAX_PROMISE_BATCH)));
    if (size < 1) fail("bad-promise", { detail: "batch-size" });
    const root = b64decode(value(5, "root"), 32);
    return { origin, time, mmd, size, root };
  });
}

/** Checks a parsed promise's batch: the note is the log's, signed with its
 * key, and its `mmd` is within the policy's. */
export function checkPromiseBatch(p: ParsedPromise, logKey: Vkey, maxMmd: number): { batch: PromiseBatch; note: Note } {
  const note = asBadPromise(() => parseNote(p.batchNote));
  const batch = parsePromiseBatchText(note.text);
  if (batch.origin !== logKey.name) fail("wrong-origin", { expected: logKey.name, got: batch.origin.slice(0, 255) });
  if (!verifyNote(note, [logKey]).some((v) => v.vkey === logKey)) fail("missing-signature", { name: logKey.name });
  if (batch.mmd > maxMmd) fail("promise-mmd-too-large", { mmd: batch.mmd, max: maxMmd });
  return { batch, note };
}

/** Checks that the promised leaf is at `index` in the batch's tree. */
export function checkPromiseInclusion(p: ParsedPromise, batch: PromiseBatch): void {
  if (p.index >= batch.size) fail("index-out-of-range", { index: p.index, size: batch.size });
  if (!verifyInclusion(BigInt(p.index), BigInt(batch.size), leafHash(p.leaf), p.proof, batch.root)) {
    fail("inclusion-failed", { what: "promise" });
  }
}

/** Verifies a promise against the log key and the policy's `mmd`
 * (specs/receipt.md, section 2). */
export function verifyPromise(input: Uint8Array | string, logKey: Vkey, maxMmd: number): VerifiedPromise {
  const p = parsePromise(input);
  const { batch, note } = checkPromiseBatch(p, logKey, maxMmd);
  checkPromiseInclusion(p, batch);
  return { ...p, batch, note, deadline: promiseDeadline(batch) };
}

/** `time + mmd + 30` */
export function promiseDeadline(batch: PromiseBatch): number {
  return batch.time + batch.mmd + PROMISE_SKEW;
}

/** Serialises a promise (for tools and tests). */
export function formatPromise(leaf: Uint8Array, index: number, proof: readonly Uint8Array[], batchNote: string): string {
  return `${PROMISE_HEADER}\nleaf ${b64encode(leaf)}\nindex ${index}\n${proof.map((h) => `${b64encode(h)}\n`).join("")}\n${batchNote}`;
}

/** A promise batch's note text (for tools and tests). */
export function formatPromiseBatchText(b: PromiseBatch): string {
  return `${PROMISE_BATCH_HEADER}\norigin ${b.origin}\ntime ${b.time}\nmmd ${b.mmd}\nsize ${b.size}\nroot ${b64encode(b.root)}\n`;
}
