// SPDX-License-Identifier: Apache-2.0
// Hub evidence forms from evidence.md §2.6. Authenticated entry bytes are
// inputs; a missing declaration or a general replay refusal is never proof.
import { hexEncode } from "./base64.js";
import { equalBytes } from "./bytes.js";
import { EMPTY_TREE_ROOT, parseCheckpointText, type Checkpoint } from "./checkpoint.js";
import { checkLayout, fieldText, fieldU64, fieldValue, parseEntry, type Entry } from "./entry.js";
import { fail, VerifyError } from "./errors.js";
import { sha256 } from "./hash.js";
import { authoritiesSigned, checkDeclaration, parseBlindedStatement, parseEnrollStatement, parseRotateStatement, parseUpdateStatement, type Declaration, type RotateStatement } from "./hubstate.js";
import { verifyConsistency } from "./merkle.js";
import { parseNote, parseVkey, verifyNote, type Note, type Vkey } from "./note.js";
import { parseHashLines } from "./blocks.js";
import { HUB_TAGS } from "./tags.js";
export interface HubEvidenceEntry {
    index: bigint;
    bytes: Uint8Array;
}
export type HubEvidenceClaim = {
    state: "proven";
    index: bigint;
} | {
    state: "needs-scan" | "not-proven";
};
interface Row extends HubEvidenceEntry {
    entry?: Entry;
}
interface Anchor {
    row: Row;
    origin: string;
    key: Vkey;
    note: Note;
    cp: Checkpoint;
}
const text = (e: Entry, n: string): string => fieldText(e, n)!;
const data = (e: Entry, n: string): Uint8Array => fieldValue(e, n)!;
function maybe<T>(fn: () => T): T | undefined { try {
    return fn();
}
catch (err) {
    if (!(err instanceof VerifyError))
        throw err;
    return undefined;
} }
const signed = (n: Note, k: Vkey): boolean => verifyNote(n, [k]).length !== 0;
const identity = (origin: string, key: string): string => `${origin}\0${key}`;
export function hubEvidenceClaim(input: readonly HubEvidenceEntry[], hub: string, prefix?: Uint8Array): HubEvidenceClaim {
    const rows: Row[] = input.map((r) => ({ ...r, entry: maybe(() => { const e = parseEntry(r.bytes); checkLayout(e); return e; }) }))
        .sort((a, b) => a.index < b.index ? -1 : a.index > b.index ? 1 : 0);
    const seen = new Map<bigint, Uint8Array>();
    for (const r of rows) {
        const old = seen.get(r.index);
        if (old && !equalBytes(old, r.bytes))
            fail("bad-evidence", { detail: "conflicting-hub-entries" });
        seen.set(r.index, r.bytes);
    }
    const unique = rows.filter((r, i) => i === 0 || r.index !== rows[i - 1]!.index);
    const anchor = (r: Row): Anchor | undefined => maybe(() => {
        const e = r.entry;
        if (e?.tag !== HUB_TAGS.anchor)
            return undefined;
        const key = parseVkey(text(e, "key"));
        const note = parseNote(data(e, "checkpoint"));
        const cp = parseCheckpointText(note.text);
        if (cp.origin !== text(e, "origin") || !signed(note, key))
            return undefined;
        return { row: r, origin: cp.origin, key, note, cp };
    });
    const anchors = unique.map(anchor).filter((a): a is Anchor => a !== undefined);
    let usedPrefix = false;
    const hashes = prefix ? parseHashLines(prefix, 64) : undefined;
    if (hashes && !hashes.length)
        fail("bad-evidence", { detail: "prefix-root" });
    function fork(a: Checkpoint, b: Checkpoint): boolean {
        if (a.origin !== b.origin)
            return false;
        if (a.size > b.size)
            return fork(b, a);
        if (a.size === 0n)
            return false;
        if (a.size === b.size)
            return !equalBytes(a.root, b.root);
        if (!hashes)
            return false;
        const [root, ...proof] = hashes;
        if (!verifyConsistency(a.size, b.size, proof, root!, b.root))
            return false;
        usedPrefix = true;
        return !equalBytes(a.root, root!);
    }
    let forkIndex: bigint | undefined;
    for (let i = 0; i < anchors.length; i++)
        for (const b of anchors.slice(i + 1)) {
            const a = anchors[i]!;
            if (a.origin === b.origin && a.key.text === b.key.text && fork(a.cp, b.cp))
                forkIndex = b.row.index;
        }
    const declarations = new Map<string, Declaration>();
    const rotated = new Map<string, {
        index: bigint;
        statement: RotateStatement;
    }>();
    const updates = new Map<string, Set<string>>();
    const proof: bigint[] = [];
    let scan = false;
    const blinded = new Map<string, Set<bigint>>();
    for (let i = 0; i < unique.length; i++) {
        const row = unique[i]!;
        const e = row.entry;
        if (!e)
            continue;
        const at = fieldU64(e, e.tag === HUB_TAGS.index ? "time" : "received_at");
        const before = unique[i - 1];
        if (before?.entry && before.index + 1n === row.index && at !== undefined) {
            const prior = fieldU64(before.entry, before.entry.tag === HUB_TAGS.index ? "time" : "received_at");
            if (prior !== undefined && at < prior)
                proof.push(row.index);
        }
        if (e.tag === HUB_TAGS.enroll) {
            const st = maybe(() => parseEnrollStatement(data(e, "statement")));
            if (!st)
                continue;
            if (st.kind !== text(e, "kind") || st.name !== text(e, "name") || st.key !== text(e, "key")) {
                proof.push(row.index);
                continue;
            }
            if (st.hub === hub && st.kind === "origin" && st.declaration) {
                const key = parseVkey(st.key);
                if (!signed(st.note, key))
                    continue;
                const valid = maybe(() => { checkDeclaration(st.declaration!, key); return st.declaration!; });
                const id = identity(st.name, key.text);
                if (valid && !declarations.has(id))
                    declarations.set(id, valid);
            }
        }
        else if (e.tag === HUB_TAGS.anchor) {
            const key = parseVkey(text(e, "key"));
            const n = maybe(() => parseNote(data(e, "checkpoint")));
            const cp = n && maybe(() => parseCheckpointText(n.text));
            if (!n || !cp)
                continue;
            if (cp.origin !== text(e, "origin")) {
                proof.push(row.index);
                continue;
            }
            if (!signed(n, key)) {
                proof.push(row.index);
                continue;
            }
            const id = identity(cp.origin, key.text);
            const frozen = rotated.get(id);
            if (frozen && frozen.index < row.index)
                forkIndex = row.index;
            for (const rotation of rotated.values())
                if (rotation.index < row.index && rotation.statement.name === cp.origin && rotation.statement.new === key.text) {
                    const start: Checkpoint = { ...cp, size: rotation.statement.size, root: rotation.statement.root };
                    if (fork(start, cp))
                        forkIndex = row.index;
                }
            const decl = declarations.get(id);
            if (decl) {
                const set = checkDeclaration(decl, key);
                const sigs = verifyNote(n, set.keys()).filter((s) => (s.ts ?? 0n) > 0n);
                if (!set.meets(sigs.map((s) => ({ witness: [...set.witnesses.values()].find((w) => w.vkey.text === s.vkey.text)?.name ?? "", timestamp: s.timestamp ?? 0 }))))
                    scan = true;
            }
        }
        else if (e.tag === HUB_TAGS.blinded) {
            const st = maybe(() => parseBlindedStatement(data(e, "statement")));
            if (!st)
                continue;
            const pseudo = hexEncode(data(e, "pseudo_origin"));
            if (st.pseudo !== pseudo || st.seq !== fieldU64(e, "seq") || !equalBytes(st.commitment, data(e, "commitment"))) {
                proof.push(row.index);
                continue;
            }
            const key = parseVkey(text(e, "key"));
            if (st.hub !== hub || key.name !== pseudo || !signed(st.note, key))
                continue;
            const id = identity(pseudo, key.text);
            const seqs = blinded.get(id) ?? new Set<bigint>();
            if (seqs.has(st.seq))
                proof.push(row.index);
            seqs.add(st.seq);
            blinded.set(id, seqs);
        }
        else if (e.tag === HUB_TAGS.rotate) {
            const st = maybe(() => parseRotateStatement(data(e, "statement")));
            if (!st)
                continue;
            if (st.name !== text(e, "origin") || st.old !== text(e, "old") || st.new !== text(e, "new")) {
                proof.push(row.index);
                continue;
            }
            if (st.hub !== hub)
                continue;
            const old = parseVkey(st.old), nw = parseVkey(st.new);
            if (!signed(st.note, old) || !signed(st.note, nw)) {
                proof.push(row.index);
                continue;
            }
            const previous = anchors.filter((a) => a.row.index < row.index && a.origin === st.name && a.key.text === st.old);
            const wrongRoot = previous.some((a) => a.cp.size > st.size || (a.cp.size === st.size && !equalBytes(a.cp.root, st.root)));
            if (wrongRoot) {
                proof.push(row.index);
                continue;
            }
            const id = identity(st.name, st.old), decl = declarations.get(id);
            if (!decl)
                continue;
            if (authoritiesSigned(st.note, decl.authorities) < decl.rotation) {
                proof.push(row.index);
                continue;
            }
            if (!maybe(() => { checkDeclaration(decl, nw); return true; }))
                continue;
            if (st.size === 0n && !equalBytes(st.root, EMPTY_TREE_ROOT))
                continue;
            if (!rotated.has(id))
                rotated.set(id, { index: row.index, statement: st });
            const next = identity(st.name, st.new);
            if (!declarations.has(next))
                declarations.set(next, decl);
        }
        else if (e.tag === HUB_TAGS.update) {
            const st = maybe(() => parseUpdateStatement(data(e, "statement")));
            if (!st)
                continue;
            if (st.name !== text(e, "origin")) {
                proof.push(row.index);
                continue;
            }
            if (st.hub !== hub)
                continue;
            const key = parseVkey(text(e, "key"));
            if (!signed(st.note, key)) {
                proof.push(row.index);
                continue;
            }
            const id = identity(st.name, key.text), decl = declarations.get(id);
            if (!decl)
                continue;
            if (authoritiesSigned(st.note, decl.authorities) < decl.rotation) {
                proof.push(row.index);
                continue;
            }
            if ((st.authorities ?? []).some((a) => !decl.authorities.some((b) => a.name === b.name && a.vkey.text === b.vkey.text)) || (st.rotation ?? decl.rotation) < decl.rotation)
                continue;
            const digest = hexEncode(sha256(st.note.text));
            const seen = updates.get(id) ?? new Set<string>();
            if (seen.has(digest))
                continue;
            const next: Declaration = { cosigners: st.cosigners, quorum: st.quorum, authorities: st.authorities ?? decl.authorities, rotation: st.rotation ?? decl.rotation };
            if (maybe(() => { checkDeclaration(next, key); return true; })) {
                declarations.set(id, next);
                seen.add(digest);
                updates.set(id, seen);
            }
        }
        else if (e.tag === HUB_TAGS.index)
            scan = true;
    }
    if (prefix && !usedPrefix)
        fail("bad-evidence", { detail: "unused-or-invalid-prefix" });
    const offender = proof[0] ?? forkIndex;
    return offender !== undefined ? { state: "proven", index: offender } : { state: scan ? "needs-scan" : "not-proven" };
}
