// SPDX-License-Identifier: Apache-2.0
//
// Strict Ed25519 verification (specs/entry.md, "Signatures"), on
// @noble/curves point arithmetic and never WebCrypto:
//
// 1. the public key A is a canonical encoding (y < p, and not x = 0 with the
//    sign bit set) of a point that is not of small order;
// 2. in R || S, S < L, and R is a canonical encoding of a point that is not of
//    small order;
// 3. cofactorless check: with k = SHA-512(R || A || M) mod L, the canonical
//    encoding of [S]B - [k]A equals the bytes of R.

import { ed25519 } from "@noble/curves/ed25519.js";
import { sha512 } from "@noble/hashes/sha2.js";
import { equalBytes } from "./bytes.js";

const Point = ed25519.Point;
type EdPoint = InstanceType<typeof Point>;
const L: bigint = Point.Fn.ORDER;

function leToBigint(b: Uint8Array): bigint {
  let v = 0n;
  for (let i = b.length - 1; i >= 0; i--) v = (v << 8n) | BigInt(b[i]!);
  return v;
}

/** Decodes a canonical, non-small-order point, or returns null. */
function decodeStrict(bytes: Uint8Array): EdPoint | null {
  if (bytes.length !== 32) return null;
  let p: EdPoint;
  try {
    p = Point.fromBytes(bytes, false);
  } catch {
    return null;
  }
  // fromBytes(…, false) rejects y >= p and x = 0 with the sign bit set; the
  // re-encoding check is a second guard for canonical form.
  if (!equalBytes(p.toBytes(), bytes)) return null;
  if (p.isSmallOrder()) return null;
  return p;
}

/** A parsed Ed25519 public key that passed rule 1. */
export class Ed25519Key {
  private constructor(
    readonly bytes: Uint8Array,
    private readonly point: EdPoint,
  ) {}

  /** Returns null when the key breaks rule 1. */
  static parse(bytes: Uint8Array): Ed25519Key | null {
    const p = decodeStrict(bytes);
    return p ? new Ed25519Key(Uint8Array.from(bytes), p) : null;
  }

  /** Strict verification of `sig` over `msg` (rules 2 and 3). */
  verify(msg: Uint8Array, sig: Uint8Array): boolean {
    if (sig.length !== 64) return false;
    const rBytes = sig.subarray(0, 32);
    const s = leToBigint(sig.subarray(32, 64));
    if (s >= L) return false;
    if (decodeStrict(rBytes) === null) return false;
    const h = sha512.create();
    h.update(rBytes);
    h.update(this.bytes);
    h.update(msg);
    const k = leToBigint(h.digest()) % L;
    const check = Point.BASE.multiplyUnsafe(s).subtract(this.point.multiplyUnsafe(k));
    return equalBytes(check.toBytes(), rBytes);
  }
}

/** Strict verification with a raw 32-byte key. */
export function verifyEd25519(publicKey: Uint8Array, msg: Uint8Array, sig: Uint8Array): boolean {
  const key = Ed25519Key.parse(publicKey);
  return key !== null && key.verify(msg, sig);
}
