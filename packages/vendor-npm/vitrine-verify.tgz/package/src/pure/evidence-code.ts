// SPDX-License-Identifier: Apache-2.0
//
// `unlogged-code` evidence (specs/evidence.md, section 2.10), written from the
// spec: a site's WAICT manifest names a script that no logged release of the
// site's package holds. What a file shows offline is the site's commitment;
// whether a release holds the script is a scan of the release log, so the
// verdict here is `needs-scan` (or `not-proven` when the log-time is too
// close to the manifest's).

import { b64decode, b64urlDecode } from "./base64.js";
import { equalBytes, fromUtf8 } from "./bytes.js";
import { fail } from "./errors.js";
import { isFormatChar } from "./entry.js";
import { sha256 } from "./hash.js";
import { parseCanonicalJson } from "./json.js";
import { verifyMptProof } from "./mpt.js";
import type { Policy, PolicyLog } from "./policy.js";
import { RELEASE_TAG } from "./tags.js";
import { chainValue, domainKey, parseChainHeadWithProof, resourceHash, verifyPrefixRoot } from "./waict.js";

/** The largest script, site manifest and path of an `unlogged-code` file. */
export const MAX_SCRIPT = 512 * 1024;
export const MAX_SITE_MANIFEST = 256 * 1024;
const MAX_PATH_LEN = 1024;
/** A release logged within this long of the manifest isn't a missing one. */
export const CODE_SLACK = 3600;

/** A domain in normal form: lowercase letters, digits, dots and hyphens, no
 * port and no empty or hyphen-edged labels (hub.md, section 6). */
const DOMAIN_RE = /^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/;

function bad(detail: string): never {
  return fail("bad-evidence", { detail });
}

/** A release manifest path (entry.md, section 5.4). */
function checkReleasePath(path: string): void {
  if (path.length === 0 || new TextEncoder().encode(path).length > MAX_PATH_LEN) bad("script-path");
  for (const ch of path) {
    const c = ch.codePointAt(0)!;
    if (c < 0x20 || (c >= 0x7f && c <= 0x9f) || c === 0x5c || isFormatChar(c)) bad("script-path");
  }
  if (path.split("/").some((s) => s === "" || s === "." || s === "..")) bad("script-path");
}

export interface ScriptUrl {
  /** `https://<host>` */
  origin: string;
  host: string;
  path: string;
}

/** The origin, host and path of a script URL: `https://<host>/<path>`, with a
 * host in normal form and a path a release manifest can hold. */
export function scriptUrl(url: string): ScriptUrl {
  if (!url.startsWith("https://")) bad("script-url");
  const rest = url.slice("https://".length);
  const slash = rest.indexOf("/");
  if (slash < 0) bad("script-url");
  const host = rest.slice(0, slash);
  const path = rest.slice(slash + 1);
  if (!DOMAIN_RE.test(host)) bad("script-url");
  if (/[?#%]/.test(path)) bad("script-url");
  checkReleasePath(path);
  return { origin: `https://${host}`, host, path };
}

/** The hash a site manifest lists for `url`: canonical JSON whose
 * `url_hashes` maps URLs to base64url SHA-256 without padding. */
export function siteManifestHash(manifest: Uint8Array, url: string): Uint8Array {
  if (manifest.length > MAX_SITE_MANIFEST) bad("manifest-size");
  let text = "";
  try {
    text = fromUtf8(manifest);
  } catch {
    bad("manifest-text");
  }
  const j = parseCanonicalJson(text);
  if (typeof j !== "object" || j === null || Array.isArray(j)) bad("manifest-json");
  const hashes = (j as Record<string, unknown>)["url_hashes"];
  if (typeof hashes !== "object" || hashes === null || Array.isArray(hashes)) bad("manifest-url-hashes");
  const h = Object.hasOwn(hashes as object, url) ? (hashes as Record<string, unknown>)[url] : undefined;
  if (typeof h !== "string" || h.length !== 43) bad("manifest-url-hash");
  return b64urlDecode(h as string, 32);
}

/** What a verified `unlogged-code` file claims: the release log's package has
 * no release that holds `script` for `origin`, as of the checkpoint. */
export interface CodeClaim {
  origin: string;
  package: string;
  path: string;
  script: Uint8Array;
  /** The WAICT service's time for the manifest, in POSIX seconds. */
  manifestTime: number;
}

/** The blocks of an `unlogged-code` file, as `parseEvidence` found them. */
export interface CodeBlocks {
  script: { url: string; body: Uint8Array }[];
  manifest: Uint8Array[];
  waict: { service: string; body: Uint8Array }[];
}

/** Checks everything about an `unlogged-code` file but the log-time and the
 * scan: the subject, the URL, the policy's site line, the manifest, and the
 * WAICT head. Throws `bad-evidence` and the WAICT errors. */
export function checkUnloggedCode(policy: Policy, log: PolicyLog | undefined, b: CodeBlocks): CodeClaim {
  if (!log || !log.profiles.some((p) => p.tag === RELEASE_TAG)) fail("evidence-wrong-subject");
  if (b.script.length !== 1) bad("script");
  const script = b.script[0]!;
  if (script.body.length > MAX_SCRIPT) bad("script-size");
  const u = scriptUrl(script.url);
  const site = policy.sites.find((s) => s.origin === u.origin);
  if (!site) bad("no-site-line");
  if (b.manifest.length !== 1) bad("manifest");
  const manifest = b.manifest[0]!;
  if (manifest.length > MAX_SITE_MANIFEST) bad("manifest-size");
  // The manifest says the site serves these bytes at this URL.
  const scriptHash = sha256(script.body);
  if (!equalBytes(siteManifestHash(manifest, script.url), scriptHash)) bad("manifest-script-mismatch");
  // The manifest is in a WAICT service that the policy trusts.
  if (b.waict.length !== 1) bad("waict");
  const w = b.waict[0]!;
  const svc = policy.waict.get(w.service);
  if (!svc) bad("no-waict-service");
  const head = parseChainHeadWithProof(b64decode(fromUtf8(w.body).trimEnd()));
  if (!equalBytes(head.head.resourceHash, resourceHash(manifest))) fail("bad-waict-proof", { detail: "resource-hash" });
  const pr = verifyPrefixRoot(head.signedPrefixRoot, svc!.domain, svc!.witnesses, svc!.quorum);
  if (!verifyMptProof(head.incProof, domainKey(u.host), chainValue(head.head.bytes), pr.root)) {
    fail("bad-waict-proof", { detail: "inclusion" });
  }
  return { origin: u.origin, package: site!.package, path: u.path, script: scriptHash, manifestTime: Number(head.head.timeCreated) };
}
