// SPDX-License-Identifier: Apache-2.0
//
// The client side of tlog-tiles (c2sp.org/tlog-tiles): which tiles hold the
// nodes of a tree, and RFC 9162 inclusion and consistency proofs computed
// from them (sections 2.1.3.1 and 2.1.4.1). The booth upgrades its receipt at
// cast this way (specs/receipt.md, section 1.2), from the tiles that every
// booth of a batch fetches, so the CDN in front of the log serves them.
//
// Tiles are unsigned: a caller verifies every proof computed here against
// the signed roots before it uses it.

import { nodeHash } from "./hash.js";

/** Tile height: a tile at level L holds hashes of nodes at tree height 8 L. */
export const TILE_HEIGHT = 8;
/** Hashes in a full tile. */
export const TILE_WIDTH = 256;
export const HASH_SIZE = 32;

/** A tile index in path form: groups of three digits, all but the last
 * prefixed with "x" (`1234067` is `x001/x234/067`). */
export function tileIndexPath(n: bigint): string {
  if (n < 0n) throw new RangeError("negative tile index");
  let s = n.toString();
  while (s.length % 3 !== 0) s = `0${s}`;
  const groups: string[] = [];
  for (let i = 0; i < s.length; i += 3) groups.push(s.slice(i, i + 3));
  return groups.map((g, i) => (i < groups.length - 1 ? `x${g}` : g)).join("/");
}

function widthSuffix(width: number): string {
  if (!Number.isInteger(width) || width < 1 || width > TILE_WIDTH) throw new RangeError("bad tile width");
  return width === TILE_WIDTH ? "" : `.p/${width}`;
}

/** The path of hash tile `n` at `level`, partial when `width` is below 256. */
export function tilePath(level: number, n: bigint, width: number = TILE_WIDTH): string {
  if (!Number.isInteger(level) || level < 0 || level > 63) throw new RangeError("bad tile level");
  return `tile/${level}/${tileIndexPath(n)}${widthSuffix(width)}`;
}

/** The path of entry bundle `n`, partial when `width` is below 256. */
export function entryBundlePath(n: bigint, width: number = TILE_WIDTH): string {
  return `tile/entries/${tileIndexPath(n)}${widthSuffix(width)}`;
}

/** The width of tile `n` at `level` in a tree of `size` leaves: 256 for a
 * full tile, 1 to 255 for a partial one, 0 when the tree has no such tile. */
export function tileWidth(level: number, n: bigint, size: bigint): number {
  const nodes = size >> BigInt(TILE_HEIGHT * level);
  const start = n * BigInt(TILE_WIDTH);
  if (nodes <= start) return 0;
  const w = nodes - start;
  return w >= BigInt(TILE_WIDTH) ? TILE_WIDTH : Number(w);
}

/** The entries of an entry bundle: each a big-endian uint16 length and
 * that many bytes. Throws on a malformed bundle or a wrong count. */
export function parseEntryBundle(b: Uint8Array, count: number): Uint8Array[] {
  const out: Uint8Array[] = [];
  let o = 0;
  while (o < b.length) {
    if (o + 2 > b.length) throw new RangeError("truncated entry bundle");
    const n = (b[o]! << 8) | b[o + 1]!;
    o += 2;
    if (o + n > b.length) throw new RangeError("truncated entry bundle");
    out.push(b.subarray(o, o + n));
    o += n;
  }
  if (out.length !== count) throw new RangeError("wrong number of entries in bundle");
  return out;
}

/** Gets the bytes of hash tile `n` at `level` with `width` hashes: exactly
 * `width × 32` bytes. */
export type TileSource = (level: number, n: bigint, width: number) => Promise<Uint8Array>;

const isPow2 = (n: bigint): boolean => n > 0n && (n & (n - 1n)) === 0n;

/** The largest power of two smaller than `n`, for `n` at least 2. */
function splitPoint(n: bigint): bigint {
  let k = 1n;
  while (k << 1n < n) k <<= 1n;
  return k;
}

function log2(n: bigint): number {
  let h = 0;
  while (1n << BigInt(h) < n) h++;
  return h;
}

/** A tree of `size` leaves read from its tiles. */
export class TileTree {
  private readonly tiles = new Map<string, Promise<Uint8Array>>();

  constructor(
    readonly size: bigint,
    private readonly source: TileSource,
  ) {
    if (size < 1n) throw new RangeError("empty tree");
  }

  private tile(level: number, n: bigint): Promise<Uint8Array> {
    const key = `${level}/${n}`;
    let t = this.tiles.get(key);
    if (!t) {
      const width = tileWidth(level, n, this.size);
      if (width === 0) return Promise.reject(new RangeError("no such tile"));
      t = this.source(level, n, width).then((b) => {
        if (b.length !== width * HASH_SIZE) throw new RangeError("tile of the wrong size");
        return b;
      });
      this.tiles.set(key, t);
    }
    return t;
  }

  /** The hash of the complete subtree of height `h` whose leaves are
   * `[i × 2^h, (i + 1) × 2^h)`. */
  async node(h: number, i: bigint): Promise<Uint8Array> {
    if ((i + 1n) << BigInt(h) > this.size) throw new RangeError("node outside the tree");
    const level = Math.floor(h / TILE_HEIGHT);
    const r = h % TILE_HEIGHT;
    const first = i << BigInt(r);
    const t = first / BigInt(TILE_WIDTH);
    const off = Number(first % BigInt(TILE_WIDTH));
    const tile = await this.tile(level, t);
    let hashes: Uint8Array[] = [];
    for (let j = 0; j < 1 << r; j++) hashes.push(tile.subarray((off + j) * HASH_SIZE, (off + j + 1) * HASH_SIZE));
    while (hashes.length > 1) {
      const up: Uint8Array[] = [];
      for (let j = 0; j < hashes.length; j += 2) up.push(nodeHash(hashes[j]!, hashes[j + 1]!));
      hashes = up;
    }
    return hashes[0]!;
  }

  /** MTH(D[a:b]) of RFC 9162, for the ranges its recursion produces. */
  async range(a: bigint, b: bigint): Promise<Uint8Array> {
    const n = b - a;
    if (n < 1n) throw new RangeError("empty range");
    if (isPow2(n) && a % n === 0n) return this.node(log2(n), a / n);
    const k = splitPoint(n);
    return nodeHash(await this.range(a, a + k), await this.range(a + k, b));
  }

  /** The tree's root. */
  root(): Promise<Uint8Array> {
    return this.range(0n, this.size);
  }

  /** The inclusion proof of leaf `index` (PATH of RFC 9162, 2.1.3.1). */
  async inclusionProof(index: bigint): Promise<Uint8Array[]> {
    if (index < 0n || index >= this.size) throw new RangeError("index outside the tree");
    const path = async (m: bigint, a: bigint, b: bigint): Promise<Uint8Array[]> => {
      if (b - a === 1n) return [];
      const k = splitPoint(b - a);
      if (m < k) return [...(await path(m, a, a + k)), await this.range(a + k, b)];
      return [...(await path(m - k, a + k, b)), await this.range(a, a + k)];
    };
    return path(index, 0n, this.size);
  }

  /** The consistency proof from size `from` to this tree (PROOF of RFC
   * 9162, 2.1.4.1). Empty when `from` is the tree's size. */
  async consistencyProof(from: bigint): Promise<Uint8Array[]> {
    if (from < 1n || from > this.size) throw new RangeError("bad consistency size");
    const sub = async (m: bigint, a: bigint, b: bigint, whole: boolean): Promise<Uint8Array[]> => {
      if (m === b - a) return whole ? [] : [await this.range(a, b)];
      const k = splitPoint(b - a);
      if (m <= k) return [...(await sub(m, a, a + k, whole)), await this.range(a + k, b)];
      return [...(await sub(m - k, a + k, b, false)), await this.range(a, a + k)];
    };
    return sub(from, 0n, this.size, true);
  }
}
