// SPDX-License-Identifier: Apache-2.0
//
// Receipt references (specs/receipt.md, section 4): short URLs for QR codes
// and printouts, from which the whole chain can be rebuilt.
//
//   https://<verifier>/#vitrine:receipt?p=<32 hex>&l=<log>&i=<index>&e=<base64url(entry)>

import { b64urlDecode, b64urlEncode, hexEncode } from "./base64.js";
import { parseDecimal } from "./bytes.js";
import { fail } from "./errors.js";
import { leafHash } from "./hash.js";
import { MAX_ENTRY_SIZE } from "./entry.js";
import type { Policy } from "./policy.js";

export const REFERENCE_PREFIX = "#vitrine:receipt?";

export interface ReceiptReference {
  /** The verifier app's base URL, up to and including the `/` before `#`. */
  verifier: string;
  /** The first 32 hex digits of the policy ID's hash: a locator, not a pin. */
  policyPrefix: string;
  log: string;
  index: bigint;
  entry: Uint8Array;
}

const NAME_RE = /^[A-Za-z0-9._-]{1,64}$/;
const PREFIX_RE = /^[0-9a-f]{32}$/;

function verifierBase(verifier: string): string {
  const u = new URL(/^[a-z][a-z0-9+.-]*:/i.test(verifier) ? verifier : `https://${verifier}`);
  if (u.protocol !== "https:" && u.protocol !== "http:") throw new TypeError("the verifier must be an https URL");
  if (u.username !== "" || u.password !== "" || u.search !== "") throw new TypeError("the verifier URL must not carry credentials or a query");
  const path = u.pathname.endsWith("/") ? u.pathname : `${u.pathname}/`;
  return `${u.origin}${path}`;
}

/** The first 32 hex digits of a policy ID (`sha256:<hex>`). */
export function policyPrefix(policyId: string): string {
  const m = /^sha256:([0-9a-f]{64})$/.exec(policyId);
  if (!m) throw new TypeError("not a policy ID");
  return m[1]!.slice(0, 32);
}

/** Builds a receipt reference. `verifier` is a host or a base URL. */
export function formatReceiptReference(verifier: string, policyId: string, log: string, index: bigint | number, entry: Uint8Array): string {
  if (!NAME_RE.test(log)) throw new TypeError("not a log name");
  const i = BigInt(index);
  if (i < 0n) throw new TypeError("negative index");
  if (entry.length < 1 || entry.length > MAX_ENTRY_SIZE) throw new TypeError("entry size");
  return `${verifierBase(verifier)}${REFERENCE_PREFIX}p=${policyPrefix(policyId)}&l=${log}&i=${i}&e=${b64urlEncode(entry)}`;
}

/** Parses a receipt reference. Unknown parameters are ignored; each known
 * one must appear once, in canonical form. */
export function parseReceiptReference(url: string): ReceiptReference {
  const bad = (detail: string): never => fail("bad-reference", { detail });
  const hash = url.indexOf("#");
  if (hash < 0 || !url.startsWith(REFERENCE_PREFIX, hash)) bad("prefix");
  let verifier = "";
  try {
    verifier = verifierBase(url.slice(0, hash));
  } catch {
    bad("verifier");
  }
  const values = new Map<string, string>();
  for (const part of url.slice(hash + REFERENCE_PREFIX.length).split("&")) {
    const eq = part.indexOf("=");
    if (eq < 1) bad("parameter");
    const k = part.slice(0, eq);
    if (!["p", "l", "i", "e"].includes(k)) continue;
    if (values.has(k)) bad(`duplicate-${k}`);
    values.set(k, part.slice(eq + 1));
  }
  const p = values.get("p");
  const l = values.get("l");
  const i = values.get("i");
  const e = values.get("e");
  if (p === undefined || !PREFIX_RE.test(p)) return bad("p");
  if (l === undefined || !NAME_RE.test(l)) return bad("l");
  if (i === undefined) return bad("i");
  if (e === undefined) return bad("e");
  let index = 0n;
  let entry: Uint8Array = new Uint8Array();
  try {
    index = parseDecimal(i);
    entry = b64urlDecode(e);
  } catch {
    bad("value");
  }
  if (entry.length < 1 || entry.length > MAX_ENTRY_SIZE) bad("entry");
  return { verifier, policyPrefix: p, log: l, index, entry };
}

/** True when `policy` is the one the reference locates (the caller then
 * relies on the full ID of the policy it pinned). */
export function referenceMatches(ref: ReceiptReference, policy: Policy): boolean {
  return policyPrefix(policy.id) === ref.policyPrefix;
}

/** The reference's leaf hash, in lowercase hex, as `GET <log>/receipt/<hex>` takes it. */
export function referenceLeafHex(ref: ReceiptReference): string {
  return hexEncode(leafHash(ref.entry));
}
