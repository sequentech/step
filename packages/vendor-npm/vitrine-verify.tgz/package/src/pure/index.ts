// SPDX-License-Identifier: Apache-2.0
//
// @vitrine/verify/pure: the independent TypeScript verifier, written from the
// specs alone (AGENTS.md), with the same verify* API as the SDK. The building
// blocks are exported as namespaces for tools and tests.

import { buildElectionEntry as buildEntry, type ElectionFields } from "./entry.js";
import { receiptWordsFor } from "./identicon.js";
import { parsePolicy as parse, policyWords as wordsOf, type ParsePolicyOptions, type Policy } from "./policy.js";

export type * from "../types.js";
export { REASON_CODES, STEP_CODES, type ReasonCode, type StepCode } from "../codes.js";
export { VerifyError } from "./errors.js";
export type { Policy, PolicyHub, PolicyLog, ParsePolicyOptions } from "./policy.js";
export type { ElectionFields, Entry } from "./entry.js";
export {
  CHAIN_FILE_EXTENSION,
  CHAIN_HEADER,
  CHAIN_MEDIA_TYPE,
  consistencyBlock,
  formatChain,
  parseChain,
  policySummary,
  verifyChain,
  verifyReceipt,
  type ConsistencyBlock,
  type HubBlocks,
  type ReceiptChain,
  type VerifyChainOptions,
} from "./chain.js";
export { identicon } from "./identicon.js";
export {
  checkBoothConfig,
  checkStyles,
  parseConfigStatement,
  parseMilestoneStatement,
  styleDigest,
  stylesHash,
  type BoothCheckInput,
  type BoothConfig,
  type ConfigStatement,
  type MilestoneStatement,
  type Release,
} from "./config.js";
export { PolicyHistory, type DiscoveryResult, type PolicyEpoch } from "./history.js";
export { keyEntryStatement, KeyLog, parseKeyStatement, type KeyStatement, type SignedBy } from "./keylog.js";
// The online upgrades and checks (src/upgrade.ts), built on this verifier.
export {
  chainFromReference,
  checkChain,
  upgradeAtCast,
  upgradeChain,
  upgradeChainReport,
  UpgradeError,
  type AtCastOptions,
  type AtCastResult,
  type CheckChainOptions,
  type CheckChainResult,
  type Contradiction,
  type UpgradeErrorCode,
  type UpgradeOptions,
  type UpgradeReport,
} from "../upgrade.js";
export {
  formatReceiptReference,
  parseReceiptReference,
  policyPrefix,
  referenceLeafHex,
  referenceMatches,
  resolveReference,
  type ReceiptReference,
} from "./reference.js";

export * as encoding from "./base64.js";
export * as bytes from "./bytes.js";
export * as blocks from "./blocks.js";
export * as browser from "./browser.js";
export * as checkpoints from "./checkpoint.js";
export * as entries from "./entry.js";
export * as hashes from "./hash.js";
export * as history from "./history.js";
export * as keylogs from "./keylog.js";
export * as hubs from "./hub.js";
export * as merkle from "./merkle.js";
export * as mpt from "./mpt.js";
export * as notes from "./note.js";
export * as policies from "./policy.js";
export * as promises from "./promise.js";
export * as statements from "./statements.js";
export * as proofs from "./tlogproof.js";
export * as quorum from "./quorum.js";
export * as tiles from "./tiles.js";
export * as waict from "./waict.js";
export * as words from "./words.js";

/** Parses and validates a policy (specs/policy.md). Throws VerifyError. */
export function parsePolicy(text: string | Uint8Array, opts?: ParsePolicyOptions): Policy {
  return parse(text, opts);
}

/** The six policy words, in the policy's `words` language. */
export function policyWords(policy: Policy): string[] {
  return wordsOf(policy);
}

/** The four receipt words of a leaf hash, in the policy's `words` language. */
export function receiptWords(leafHash: Uint8Array, policy: Policy): string[] {
  return receiptWordsFor(leafHash, policy.words);
}

/** Builds a `vitrine/election/v1` entry (specs/entry.md, section 4.1). */
export function buildElectionEntry(f: ElectionFields): Uint8Array {
  return buildEntry(f);
}
