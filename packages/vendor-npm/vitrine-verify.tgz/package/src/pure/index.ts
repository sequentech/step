// SPDX-License-Identifier: Apache-2.0
//
// @vitrine/verify/pure: the independent TypeScript verifier, written from the
// specs alone (AGENTS.md), with the same verify* API as the SDK. The building
// blocks are exported as namespaces for tools and tests.

import { buildElectionEntry as buildEntry, type ElectionFields } from "./entry.js";
import { receiptWordsFor } from "./identicon.js";
import { parsePolicy as parse, policyWords as wordsOf, type ParsePolicyOptions, type Policy } from "./policy.js";

export type * from "../types.js";
export { REASON_CODES, STEP_CODES, type ReasonCode, type StepCode } from "../codes.js";
export { VerifyError } from "./errors.js";
export { buildEvidence, evidenceId, parseEvidence, verifyEvidence, EVIDENCE_KINDS, EVIDENCE_HEADER, EVIDENCE_FILE_EXTENSION, EVIDENCE_MEDIA_TYPE, type Evidence, type EvidenceKind, type EvidenceOptions } from "./evidence.js";
export type { Policy, PolicyHub, PolicyLog, ParsePolicyOptions, SharedLogPin } from "./policy.js";
export type { ElectionFields, Entry } from "./entry.js";
export {
  CHAIN_FILE_EXTENSION,
  CHAIN_HEADER,
  CHAIN_MEDIA_TYPE,
  consistencyBlock,
  formatChain,
  parseChain,
  policySummary,
  verifyChain,
  verifyReceipt,
  type ConsistencyBlock,
  type HubBlocks,
  type ReceiptChain,
  type VerifyChainOptions,
} from "./chain.js";
export { identicon } from "./identicon.js";
export {
  checkBoothConfig,
  checkStyles,
  parseConfigStatement,
  parseMilestoneStatement,
  styleDigest,
  stylesHash,
  type BoothCheckInput,
  type BoothConfig,
  type ConfigStatement,
  type MilestoneStatement,
  type Release,
} from "./config.js";
export { PolicyHistory, type DiscoveryResult, type PolicyProofsContext, type PolicyEpoch, type SerializedPolicyHistory } from "./history.js";
export { checkLoggedRelease, checkReleaseFiles, parseReleaseManifest, parseReleaseStatement, type CheckLoggedReleaseOptions, type LoggedRelease, type ReleaseManifest, type ReleaseStatement } from "./release.js";
export { keyEntryStatement, KeyLog, parseKeyStatement, type KeyStatement, type SignedBy } from "./keylog.js";
export { acceptPromise, type AcceptPromiseOptions, type PromiseAcceptance } from "./accept.js";
// Payloads and redaction (specs/redaction.md).
export {
  checkNoticeApprovals,
  checkPayload,
  checkPayloadBundle,
  formatNoticeBundle,
  formatNoticeText,
  formatPayloadBundle,
  MAX_BASIS_BYTES,
  NOTICE_ACTIONS,
  NOTICE_BUNDLE_HEADER,
  NOTICE_HEADER,
  NOTICE_REASONS,
  NoticeChain,
  noticeSigners,
  openPayload,
  parseNotice,
  parseNoticeBundle,
  parsePayloadBundle,
  PAYLOAD_BUNDLE_ENTRIES,
  PAYLOAD_BUNDLE_HEADER,
  PAYLOAD_BUNDLE_MEDIA_TYPE,
  PAYLOAD_LABEL,
  PAYLOAD_MEDIA_TYPE,
  payloadCommitment,
  SALT_BYTES,
  verifyNotice,
  verifyNoticeBundle,
  verifyWithheld,
  type AppliedNotice,
  type Notice,
  type NoticeAction,
  type NoticeBundle,
  type NoticeField,
  type NoticeOutcome,
  type NoticeReason,
  type NoticeTarget,
  type PayloadBlock,
  type PayloadBundle,
  type PayloadCheck,
  type PayloadState,
  type VerifiedNotice,
  type VerifiedNoticeBundle,
  type VerifyNoticeBundleOptions,
  type WithheldBlock,
} from "./redaction.js";
// The online upgrades and checks (src/upgrade.ts), built on this verifier.
export {
  acceptPromiseOnline,
  chainFromReference,
  checkChain,
  upgradeAtCast,
  upgradeChain,
  upgradeChainReport,
  UpgradeError,
  type AcceptPromiseOnlineOptions,
  type AtCastOptions,
  type AtCastResult,
  type CheckChainOptions,
  type CheckChainResult,
  type Contradiction,
  type UpgradeErrorCode,
  type UpgradeOptions,
  type UpgradeReport,
} from "../upgrade.js";
export {
  formatReceiptReference,
  parseReceiptReference,
  policyPrefix,
  referenceLeafHex,
  referenceMatches,
  resolveReference,
  type ReceiptReference,
} from "./reference.js";

export * as encoding from "./base64.js";
export * as evidence from "./evidence.js";
export * as bytes from "./bytes.js";
export * as blocks from "./blocks.js";
export * as browser from "./browser.js";
export * as checkpoints from "./checkpoint.js";
export * as entries from "./entry.js";
export * as hashes from "./hash.js";
export * as history from "./history.js";
export * as keylogs from "./keylog.js";
export * as hubs from "./hub.js";
export * as merkle from "./merkle.js";
export * as mpt from "./mpt.js";
export * as notes from "./note.js";
export * as policies from "./policy.js";
export * as promises from "./promise.js";
export * as statements from "./statements.js";
export * as proofs from "./tlogproof.js";
export * as quorum from "./quorum.js";
export * as redaction from "./redaction.js";
export * as operators from "./operators.js";
export * as profiles from "./profiles.js";
export { CORE_PROFILE_METADATA, authenticateProfileMinimums, enforceBuiltinProfileMinimums, validateProfileMinimums, pinPolicy, type PinPolicyOptions, type ProfileMinimums, type ProfileMeaningPackage, type AuthenticatedProfileMinimums } from "./profiles.js";
export * as shared from "./shared.js";
export { parseOperatorList, verifyOperatorList, updateOperatorList, checkOperatorSelection, type OperatorList, type OperatorEntry, type OperatorListPin, type OperatorListTrust } from "./operators.js";
export { parseSharedEnrolment, verifySharedEnrolment, parseSharedAuthorization, verifySharedAuthorization, parseSharedSubmission, checkSharedBindings, checkSharedNamespace, type SharedEnrolment, type SharedAuthorization, type SharedSubmission } from "./shared.js";
export * as releases from "./release.js";
export * as tiles from "./tiles.js";
export * as waict from "./waict.js";
export * as words from "./words.js";

/** Parses a policy and checks signatures and structure. Use pinPolicy for new-pin admission. Throws VerifyError. */
export function parsePolicy(text: string | Uint8Array, opts?: ParsePolicyOptions): Policy {
  return parse(text, opts);
}

/** The six policy words, in the policy's `words` language. */
export function policyWords(policy: Policy): string[] {
  return wordsOf(policy);
}

/** The four receipt words of a leaf hash, in the policy's `words` language. */
export function receiptWords(leafHash: Uint8Array, policy: Policy): string[] {
  return receiptWordsFor(leafHash, policy.words);
}

/** Builds a `vitrine/election/ballots/v1` entry (specs/entry.md, section 4.1). */
export function buildElectionEntry(f: ElectionFields): Uint8Array {
  return buildEntry(f);
}
