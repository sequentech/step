// SPDX-License-Identifier: Apache-2.0
//
// Policy words (specs/policy.md, section 1) and receipt words
// (specs/receipt.md, section 5): 11-bit indices, most significant first, into
// the BIP-39 list of the policy's `words` language.

import { WORD_LISTS } from "./words.generated.js";

export type WordsLang = keyof typeof WORD_LISTS;

export const WORD_LANGS = Object.keys(WORD_LISTS) as WordsLang[];

export function isWordsLang(s: string): s is WordsLang {
  return Object.prototype.hasOwnProperty.call(WORD_LISTS, s);
}

const cache = new Map<WordsLang, string[]>();

/** The 2,048 words of a list. */
export function wordList(lang: WordsLang): string[] {
  let list = cache.get(lang);
  if (!list) {
    list = WORD_LISTS[lang].split(" ");
    cache.set(lang, list);
  }
  return list;
}

/** `count` words from the first `11 * count` bits of `bytes`. */
export function wordsFromBits(bytes: Uint8Array, count: number, lang: WordsLang): string[] {
  if (bytes.length * 8 < count * 11) throw new RangeError("not enough bits for the words");
  const list = wordList(lang);
  const out: string[] = [];
  for (let w = 0; w < count; w++) {
    let idx = 0;
    for (let b = 0; b < 11; b++) {
      const bit = w * 11 + b;
      idx = (idx << 1) | ((bytes[bit >>> 3]! >>> (7 - (bit & 7))) & 1);
    }
    out.push(list[idx]!);
  }
  return out;
}

/** The BCP 47 tag of a policy `words` code. */
export function bcp47(lang: WordsLang): string {
  if (lang === "zh-hans") return "zh-Hans";
  if (lang === "zh-hant") return "zh-Hant";
  return lang;
}
