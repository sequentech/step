// SPDX-License-Identifier: Apache-2.0
//
// Logged software releases (specs/entry.md 4.5 and 5.4). Callers supply
// manifests, keys and files explicitly; these helpers perform no requests.
import { b64decode, b64urlDecode } from "./base64.js";
import { equalBytes, fromUtf8, parseDecimal, u64ToNumber, utf8 } from "./bytes.js";
import { verifyCheckpoint } from "./checkpoint.js";
import { checkLayout, fieldText, fieldValue, isValidId, parseEntry } from "./entry.js";
import { fail } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { parseCanonicalJson } from "./json.js";
import type { KeyLog } from "./keylog.js";
import { verifyInclusion } from "./merkle.js";
import { parseNote } from "./note.js";
import { profileAt, type Policy } from "./policy.js";
import { statementValues } from "./statements.js";
import { RELEASE_TAG } from "./tags.js";
import { parseTlogProof } from "./tlogproof.js";

export interface ReleaseManifest { package: string; version: string; files: Record<string, string>; sites: string[] }
export interface ReleaseStatement { package: string; version: string; manifest: Uint8Array; attestation?: Uint8Array; time: number }
function bad(detail: string): never { return fail("bad-entry", { detail: `release-${detail}` }); }

export function parseReleaseManifest(input: string | Uint8Array): ReleaseManifest {
  const text = typeof input === "string" ? input : fromUtf8(input);
  if (utf8(text).length > 1 << 20) bad("manifest-size");
  const value = parseCanonicalJson(text);
  if (!value || typeof value !== "object" || Array.isArray(value)) bad("manifest-json");
  const v = value as Partial<ReleaseManifest>;
  if (Object.keys(v).sort().join(",") !== "files,package,sites,version" || typeof v.package !== "string" || typeof v.version !== "string" || !isValidId(v.package) || !isValidId(v.version) || !v.files || typeof v.files !== "object" || Array.isArray(v.files) || !Array.isArray(v.sites)) bad("manifest-schema");
  for (const [path, digest] of Object.entries(v.files)) {
    if (!path || path.startsWith("/") || path.includes("\\") || path.split("/").some((part) => !part || part === "." || part === "..") || typeof digest !== "string") bad("manifest-path");
    b64urlDecode(digest, 32);
  }
  for (const origin of v.sites) {
    if (typeof origin !== "string") bad("manifest-site");
    let url: URL;
    try { url = new URL(origin); } catch { return bad("manifest-site"); }
    if (url.protocol !== "https:" || url.origin !== origin || url.username || url.password) bad("manifest-site");
  }
  return v as ReleaseManifest;
}

export function parseReleaseStatement(text: string): ReleaseStatement {
  const [pkg, version, manifest, attestation, time] = statementValues(text, RELEASE_TAG, ["package", "version", "manifest", "attestation", "time"], "bad-entry") as [string, string, string, string, string];
  if (!isValidId(pkg) || !isValidId(version)) bad("statement-id");
  return { package: pkg, version, manifest: b64decode(manifest, 32), ...(attestation === "none" ? {} : { attestation: b64decode(attestation, 32) }), time: u64ToNumber(parseDecimal(time)) };
}

/** Check any caller-supplied files against a validated manifest. Unlisted
 * files are refused, and the caller can require the entire file set. */
export function checkReleaseFiles(manifest: ReleaseManifest, files: ReadonlyMap<string, Uint8Array>, complete = false): void {
  for (const [path, bytes] of files) {
    const digest = Object.hasOwn(manifest.files, path) ? manifest.files[path] : undefined;
    if (!digest || !equalBytes(sha256(bytes), b64urlDecode(digest, 32))) bad("file-mismatch");
  }
  if (complete && Object.keys(manifest.files).some((path) => !files.has(path))) bad("file-missing");
}

export interface CheckLoggedReleaseOptions {
  log: string;
  receipt: string | Uint8Array;
  manifest: string | Uint8Array;
  keys: KeyLog;
  now?: number;
  files?: ReadonlyMap<string, Uint8Array>;
}
export interface LoggedRelease { manifest: ReleaseManifest; statement: ReleaseStatement; sequenced: number; signer: string; cosignedBy: string[] }

/** Verify the witnessed release entry, manifest digest, signed statement,
 * key validity at sequencing time and required independent cosigners. */
export function checkLoggedRelease(policy: Policy, options: CheckLoggedReleaseOptions): LoggedRelease {
  const log = policy.logs.get(options.log);
  if (!log) fail("unknown-log");
  if ((typeof options.receipt === "string" ? utf8(options.receipt).length : options.receipt.length) > 1 << 20) fail("too-large", { what: "release-receipt", limit: 1 << 20 });
  const proof = parseTlogProof(options.receipt);
  if (!proof.extra) fail("missing-extra");
  const cp = verifyCheckpoint(proof.checkpoint, log.vkey, policy.witnesses, options.now ?? Math.floor(Date.now() / 1000), { logTime: log.logTime, requireLogTime: true });
  if (!verifyInclusion(proof.index, cp.cp.size, leafHash(proof.extra), proof.proof, cp.cp.root)) fail("inclusion-failed");
  const sequenced = policy.witnesses.quorumTime(cp.cosigs);
  if (sequenced === undefined) fail("quorum-not-met");
  const entry = parseEntry(proof.extra); checkLayout(entry);
  if (entry.tag !== RELEASE_TAG || profileAt(log, proof.index).tag !== RELEASE_TAG) fail("wrong-profile");
  const manifest = parseReleaseManifest(options.manifest);
  const digest = sha256(options.manifest);
  const note = parseNote(fieldValue(entry, "signature")!);
  const statement = parseReleaseStatement(note.text);
  if (manifest.package !== fieldText(entry, "package") || manifest.version !== fieldText(entry, "version") || statement.package !== manifest.package || statement.version !== manifest.version || !equalBytes(digest, fieldValue(entry, "manifest")!) || !equalBytes(digest, statement.manifest)) bad("manifest-mismatch");
  const attestation = fieldValue(entry, "attestation")!;
  if (statement.attestation ? !equalBytes(statement.attestation, attestation) : attestation.length !== 0) bad("attestation-mismatch");
  const parameter = log.params.get("cosigners");
  if (parameter && parameter.length !== 1) bad("cosigners");
  const cosigners = parameter ? u64ToNumber(parseDecimal(parameter[0]!)) : 0;
  const signer = fieldText(entry, "signer")!;
  const check = options.keys.signedBy(note, signer, sequenced, cosigners);
  if (check.status === "waiting") fail("needs-scan");
  if (check.status === "failed") fail("signed-by-failed", check.reason.params);
  if (options.files) checkReleaseFiles(manifest, options.files);
  return { manifest, statement, sequenced, signer, cosignedBy: check.cosignedBy };
}
