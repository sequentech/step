// SPDX-License-Identifier: Apache-2.0
//
// Tally commitments and results (specs/entry.md, sections 5.10 and 5.11):
// `vitrine/tally-commitment/v1` names the ballots log checkpoint an election's
// tally starts from and commits to the list of counted leaf hashes;
// `vitrine/results/v1` states the totals and names the tally commitment they
// follow. Both are signed by at least one authority of the policy.

import { b64decode } from "./base64.js";
import { compareBytes, equalBytes, parseSmall } from "./bytes.js";
import { asConfigError, one, statementLines } from "./config.js";
import { decodeHash32, isValidId } from "./entry.js";
import { fail } from "./errors.js";
import { sha256 } from "./hash.js";
import { isValidKeyName, parseNote, verifyNote, type Note } from "./note.js";
import { isReservedOrigin, type Policy } from "./policy.js";
import { ELECTION_TAG } from "./tags.js";

export const TALLY_COMMITMENT_HEADER = "vitrine/tally-commitment/v1";
export const RESULTS_HEADER = "vitrine/results/v1";
/** The label of a tally commitment's `list` (section 5.10). */
export const TALLY_LIST_LABEL = "vitrine/tally-list/v1";

const TALLY_PART = "tally-commitment";
const RESULTS_PART = "results";
const MAX_REPEAT = 1024;

/** A `vitrine/tally-commitment/v1` statement. */
export interface TallyCommitment {
  event: string;
  election: string;
  /** The origin of the ballots log. */
  ballots: string;
  /** The size and root hash of the ballots log checkpoint the tally starts from. */
  size: number;
  root: Uint8Array;
  /** How many leaf hashes the tally counts. */
  counted: number;
  /** The commitment to the counted leaf hashes (`tallyListHash`). */
  list: Uint8Array;
  time: number;
}

/** One `total` line of a results statement. */
export interface ResultsTotal {
  contest: string;
  choice: string;
  votes: number;
}

/** A `vitrine/results/v1` statement. */
export interface ResultsStatement {
  event: string;
  election: string;
  /** The leaf hash of the `tally-commitment` entry the results follow. */
  tally: Uint8Array;
  /** The SHA-256 of the published results document. */
  document: Uint8Array;
  time: number;
  /** In ascending byte order of contest, then choice, without repeats. */
  totals: ResultsTotal[];
}

const small = (s: string): number => parseSmall(s);

/** Parses a `vitrine/tally-commitment/v1` statement's text. Throws `bad-config`
 * (part `tally-commitment`). */
export function parseTallyCommitment(text: string): TallyCommitment {
  return asConfigError(TALLY_PART, () => {
    const m = statementLines(
      text,
      TALLY_COMMITMENT_HEADER,
      [{ key: "event" }, { key: "election" }, { key: "ballots" }, { key: "size" }, { key: "root" }, { key: "counted" }, { key: "list" }, { key: "time" }],
      TALLY_PART,
    );
    const bad = (detail: string): never => fail("bad-config", { part: TALLY_PART, detail });
    const event = one(m, "event");
    const election = one(m, "election");
    const ballots = one(m, "ballots");
    if (!isValidId(event)) bad("event");
    if (!isValidId(election)) bad("election");
    if (!isValidKeyName(ballots) || isReservedOrigin(ballots)) bad("ballots");
    const size = small(one(m, "size"));
    const counted = small(one(m, "counted"));
    if (counted > size) bad("counted");
    return {
      event,
      election,
      ballots,
      size,
      root: b64decode(one(m, "root"), 32),
      counted,
      list: b64decode(one(m, "list"), 32),
      time: small(one(m, "time")),
    };
  });
}

/** Parses a `vitrine/results/v1` statement's text. Throws `bad-config` (part
 * `results`). */
export function parseResultsStatement(text: string): ResultsStatement {
  return asConfigError(RESULTS_PART, () => {
    const m = statementLines(
      text,
      RESULTS_HEADER,
      [{ key: "event" }, { key: "election" }, { key: "tally" }, { key: "document" }, { key: "time" }, { key: "total", repeatable: true }],
      RESULTS_PART,
    );
    const bad = (detail: string): never => fail("bad-config", { part: RESULTS_PART, detail });
    const event = one(m, "event");
    const election = one(m, "election");
    if (!isValidId(event)) bad("event");
    if (!isValidId(election)) bad("election");
    const lines = m.get("total")!;
    if (lines.length > MAX_REPEAT) bad("too-many-totals");
    const totals: ResultsTotal[] = [];
    for (const l of lines) {
      const parts = l.split(" ");
      if (parts.length !== 3) return bad("total");
      const [contest, choice, votes] = parts as [string, string, string];
      if (!isValidId(contest) || !isValidId(choice)) bad("total");
      const t = { contest, choice, votes: small(votes) };
      const last = totals[totals.length - 1];
      // Ids are ASCII, so code-unit order is byte order.
      if (last && (last.contest > t.contest || (last.contest === t.contest && last.choice >= t.choice))) bad("total-order");
      totals.push(t);
    }
    return {
      event,
      election,
      tally: b64decode(one(m, "tally"), 32),
      document: b64decode(one(m, "document"), 32),
      time: small(one(m, "time")),
      totals,
    };
  });
}

/** The text that a tally commitment's `list` commits to: the counted leaf
 * hashes in ascending byte order, each as 64 lowercase hexadecimal characters
 * and a line feed. The hashes (32 bytes, hex or base64) can be in any order.
 * Throws `bad-config` (detail `list-repeat`) for a hash that occurs twice. */
export function tallyListText(leaves: readonly (Uint8Array | string)[]): string {
  const sorted = leaves.map((l) => decodeHash32(l)).sort(compareBytes);
  let text = "";
  sorted.forEach((h, i) => {
    if (i > 0 && equalBytes(h, sorted[i - 1]!)) fail("bad-config", { part: TALLY_PART, detail: "list-repeat" });
    text += `${[...h].map((b) => b.toString(16).padStart(2, "0")).join("")}\n`;
  });
  return text;
}

/** `H("vitrine/tally-list/v1" || text)`, the `list` of a tally commitment
 * that counts `leaves` (section 5.10). */
export function tallyListHash(leaves: readonly (Uint8Array | string)[]): Uint8Array {
  return sha256(TALLY_LIST_LABEL, tallyListText(leaves));
}

/** Checks a list of leaf hashes against the tally commitment's `counted` and
 * `list`. Throws `bad-config` (part `tally-commitment`, detail `counted` or
 * `list`). */
export function checkTallyList(commitment: Pick<TallyCommitment, "counted" | "list">, leaves: readonly (Uint8Array | string)[]): void {
  if (leaves.length !== commitment.counted) fail("bad-config", { part: TALLY_PART, detail: "counted" });
  if (!equalBytes(tallyListHash(leaves), commitment.list)) fail("bad-config", { part: TALLY_PART, detail: "list" });
}

/** Checks that `results` follow the tally commitment in the events entry with
 * leaf hash `tallyLeaf` (section 5.11). Throws `bad-config` (part `results`). */
export function checkResultsFollow(results: ResultsStatement, tallyLeaf: Uint8Array, tally: Pick<TallyCommitment, "event" | "election">): void {
  if (!equalBytes(results.tally, tallyLeaf)) fail("bad-config", { part: RESULTS_PART, detail: "tally" });
  if (results.event !== tally.event || results.election !== tally.election) fail("bad-config", { part: RESULTS_PART, detail: "election" });
}

/** The policy's `election/ballots/v1` logs. */
const ballotsLogs = (policy: Policy) => [...policy.logs.values()].filter((l) => l.profiles.some((p) => p.tag === ELECTION_TAG));

/** The event and election are ones the policy's ballots logs name, when they
 * have `event-id` and `election-ids` parameters. */
function checkElection(policy: Policy, event: string, election: string, part: string): void {
  const logs = ballotsLogs(policy);
  const events = logs.flatMap((l) => l.params.get("event-id") ?? []);
  if (events.length > 0 && !events.includes(event)) fail("bad-config", { part, detail: "event" });
  const lists = logs.filter((l) => l.params.get("event-id")?.includes(event)).flatMap((l) => l.params.get("election-ids") ?? []);
  if (logs.some((l) => l.params.get("event-id")?.includes(event) && l.params.has("election-ids")) && !lists.includes(election)) fail("bad-config", { part, detail: "election" });
}

function checkSigned(note: Note, policy: Policy, part: string): void {
  const keys = [...policy.authorities.values()].map((a) => a.vkey);
  if (verifyNote(note, keys).length === 0) fail("bad-config", { part, detail: "signature" });
}

/** Parses a signed tally commitment and checks it against the policy: it names
 * an event and election of the policy and one of the policy's ballots logs for
 * them, and at least one authority signed it. Throws `bad-config`. */
export function verifyTallyCommitment(input: Uint8Array | string, policy: Policy): TallyCommitment {
  const note = parseNote(input);
  const t = parseTallyCommitment(note.text);
  checkElection(policy, t.event, t.election, TALLY_PART);
  const log = ballotsLogs(policy).find((l) => l.origin === t.ballots);
  if (!log) fail("bad-config", { part: TALLY_PART, detail: "ballots" });
  if (log!.params.get("event-id") && !log!.params.get("event-id")!.includes(t.event)) fail("bad-config", { part: TALLY_PART, detail: "ballots-event" });
  if (log!.params.get("election-ids") && !log!.params.get("election-ids")!.includes(t.election)) fail("bad-config", { part: TALLY_PART, detail: "ballots-election" });
  checkSigned(note, policy, TALLY_PART);
  return t;
}

/** Parses signed results and checks them against the policy: they name an
 * event and election of the policy, and at least one authority signed them.
 * Throws `bad-config`. */
export function verifyResultsStatement(input: Uint8Array | string, policy: Policy): ResultsStatement {
  const note = parseNote(input);
  const r = parseResultsStatement(note.text);
  checkElection(policy, r.event, r.election, RESULTS_PART);
  checkSigned(note, policy, RESULTS_PART);
  return r;
}
