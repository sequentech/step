// SPDX-License-Identifier: Apache-2.0
//
// Vitrine entries (specs/entry.md): the envelope, field types, the core
// profile layouts, election/v1 entries and checks against expectations.

import { b64decode, hexDecode } from "./base64.js";
import { concat, equalBytes, fromUtf8, MAX_U64, parseDecimal, Reader, readU64, u16be, u64be, utf8 } from "./bytes.js";
import { fail, VerifyError } from "./errors.js";
import { parseNote, parseVkey } from "./note.js";

/** Entries are served in tlog-tiles bundles with a uint16 length prefix. */
export const MAX_ENTRY_SIZE = 65535;

export const FIELD_PUBLIC = 0;
export const FIELD_COMMITMENT = 1;

export interface Field {
  kind: typeof FIELD_PUBLIC | typeof FIELD_COMMITMENT;
  /** The public value, or the 32-byte commitment digest. */
  value: Uint8Array;
}

export interface Entry {
  tag: string;
  fields: Field[];
  bytes: Uint8Array;
}

const TAG_RE = /^[a-z][a-z0-9._\-/]*$/;
const ID_RE = /^[A-Za-z0-9._\-:/@+]{1,255}$/;
const ENUM_RE = /^[a-z0-9-]+$/;

export function isValidTag(tag: string): boolean {
  return tag.length >= 1 && tag.length <= 255 && TAG_RE.test(tag);
}

export function isValidId(id: string): boolean {
  return ID_RE.test(id);
}

/** Parses an entry: tag, then the field vector, with no trailing bytes. */
export function parseEntry(bytes: Uint8Array): Entry {
  if (bytes.length > MAX_ENTRY_SIZE) fail("too-large", { what: "entry", limit: MAX_ENTRY_SIZE });
  try {
    const r = new Reader(bytes);
    const tagLen = r.u8();
    if (tagLen === 0) fail("bad-entry", { detail: "empty-tag" });
    let tag = "";
    for (const c of r.bytes(tagLen)) tag += String.fromCharCode(c);
    if (!isValidTag(tag)) fail("bad-entry", { detail: "tag" });
    const vecLen = r.u16();
    const fr = new Reader(r.bytes(vecLen));
    r.end();
    const fields: Field[] = [];
    while (fr.remaining > 0) {
      const kind = fr.u8();
      if (kind === FIELD_PUBLIC) {
        const n = fr.u16();
        fields.push({ kind, value: fr.bytes(n) });
      } else if (kind === FIELD_COMMITMENT) {
        fields.push({ kind, value: fr.bytes(32) });
      } else {
        fail("bad-entry", { detail: "field-kind", kind });
      }
    }
    return { tag, fields, bytes };
  } catch (e) {
    if (e instanceof VerifyError && e.code === "bad-entry") throw e;
    if (e instanceof VerifyError) throw new VerifyError("bad-entry", { detail: e.code });
    throw e;
  }
}

/** Encodes an entry from its tag and fields. */
export function encodeEntry(tag: string, fields: readonly Field[]): Uint8Array {
  if (!isValidTag(tag)) throw new TypeError(`invalid entry tag: ${tag}`);
  const parts: Uint8Array[] = [];
  for (const f of fields) {
    if (f.kind === FIELD_PUBLIC) {
      if (f.value.length > 0xffff) throw new TypeError("field value too long");
      parts.push(Uint8Array.of(FIELD_PUBLIC), u16be(f.value.length), f.value);
    } else {
      if (f.value.length !== 32) throw new TypeError("a commitment digest is 32 bytes");
      parts.push(Uint8Array.of(FIELD_COMMITMENT), f.value);
    }
  }
  const vec = concat(...parts);
  if (vec.length > 0xffff) throw new TypeError("field vector too long");
  const out = concat(Uint8Array.of(tag.length), utf8(tag), u16be(vec.length), vec);
  if (out.length > MAX_ENTRY_SIZE) throw new TypeError("entry too long");
  return out;
}

// ---------------------------------------------------------------------------
// Field types (specs/entry.md, section 3) and core layouts (section 4)

export type FieldType =
  | "id"
  | "text"
  | "enum"
  | "hash"
  | "time"
  | "time-ms"
  | "int"
  | "bytes"
  | "key-ref"
  | "ref"
  | "subject"
  | "note"
  | "hashes";

export interface FieldSpec {
  name: string;
  kind: "public" | "commitment";
  type?: FieldType;
  /** Values an `enum` field may take. */
  values?: readonly string[];
  /** Absent (empty) values are allowed. */
  optional?: boolean;
}

const pub = (name: string, type: FieldType, extra: Partial<FieldSpec> = {}): FieldSpec => ({
  name,
  kind: "public",
  type,
  ...extra,
});
const com = (name: string): FieldSpec => ({ name, kind: "commitment" });

/** The layouts of the core profiles and the hub entries. */
export const PROFILES: Readonly<Record<string, readonly FieldSpec[]>> = {
  "vitrine/election/v1": [pub("event_id", "id"), pub("election_id", "id"), pub("ballot_id", "hash"), pub("accepted_at", "time")],
  "vitrine/audit/v1": [pub("kind", "enum"), pub("time", "time"), pub("actor", "hash", { optional: true }), com("record")],
  "vitrine/events/v1": [
    pub("kind", "enum", {
      values: [
        "policy",
        "config",
        "voting-opened",
        "voting-closed",
        "checkpoint",
        "tally-commitment",
        "results",
        "notice",
        "redaction",
        "ballot-void",
        "read-access",
        "milestone",
      ],
    }),
    pub("time", "time"),
    pub("subject", "subject"),
    pub("statement", "note", { optional: true }),
    com("details"),
  ],
  "vitrine/keys/v1": [
    pub("action", "enum", { values: ["add", "revoke"] }),
    pub("key", "key-ref"),
    pub("holder", "id"),
    pub("not_before", "time"),
    pub("not_after", "time"),
    pub("statement", "note"),
  ],
  "vitrine/release/v1": [
    pub("package", "id"),
    pub("version", "id"),
    pub("manifest", "hash"),
    pub("attestation", "hash", { optional: true }),
    pub("signer", "key-ref"),
    pub("signature", "note"),
    com("notes"),
  ],
  "vitrine/registry/v1": [
    pub("record", "id"),
    pub("version", "int"),
    pub("previous", "hash", { optional: true }),
    pub("change", "enum"),
    pub("registrar", "key-ref"),
    pub("signature", "note"),
    pub("document", "hash"),
    pub("court_order", "ref", { optional: true }),
    com("holder"),
  ],
  "vitrine/hub/v1": [
    pub("origin", "id"),
    pub("key", "key-ref"),
    pub("old_size", "int"),
    pub("proof", "hashes", { optional: true }),
    pub("checkpoint", "note"),
    pub("received_at", "time-ms"),
  ],
  "vitrine/hub/v1/enroll": [
    pub("kind", "enum", { values: ["origin", "blinded"] }),
    pub("name", "id"),
    pub("key", "key-ref"),
    pub("statement", "note"),
    pub("received_at", "time-ms"),
  ],
  "vitrine/hub/v1/blinded": [
    pub("pseudo_origin", "hash"),
    pub("key", "key-ref"),
    pub("seq", "int"),
    pub("commitment", "hash"),
    pub("statement", "note"),
    pub("received_at", "time-ms"),
  ],
  "vitrine/hub/v1/index": [pub("covered", "int"), pub("root", "hash"), pub("time", "time-ms")],
  "vitrine/hub/v1/rotate": [
    pub("origin", "id"),
    pub("old", "key-ref"),
    pub("new", "key-ref"),
    pub("statement", "note"),
    pub("received_at", "time-ms"),
  ],
};

/** The layout of a core profile tag, or undefined (own properties only, so a
 * tag such as `constructor` is just unknown). */
export function layoutOf(tag: string): readonly FieldSpec[] | undefined {
  return Object.hasOwn(PROFILES, tag) ? PROFILES[tag] : undefined;
}

function hasFormatOrControl(s: string): boolean {
  for (const ch of s) {
    const c = ch.codePointAt(0)!;
    if ((c < 0x20 && c !== 0x0a) || (c >= 0x7f && c <= 0x9f)) return true;
    if (/\p{Cf}/u.test(ch)) return true;
  }
  return false;
}

/** Checks one public value against its type; throws bad-entry-layout. */
export function checkFieldType(spec: FieldSpec, v: Uint8Array): void {
  const bad = (detail: string): never => fail("bad-entry-layout", { field: spec.name, detail });
  if (v.length === 0) {
    if (spec.optional) return;
    bad("empty");
  }
  switch (spec.type) {
    case "id": {
      if (v.length > 255) bad("id");
      let s = "";
      for (const c of v) s += String.fromCharCode(c);
      if (!isValidId(s)) bad("id");
      return;
    }
    case "text": {
      let s = "";
      try {
        s = fromUtf8(v);
      } catch {
        bad("text");
      }
      if (hasFormatOrControl(s)) bad("text");
      return;
    }
    case "enum": {
      let s = "";
      for (const c of v) s += String.fromCharCode(c);
      if (!ENUM_RE.test(s)) bad("enum");
      if (spec.values && !spec.values.includes(s)) bad("enum-value");
      return;
    }
    case "hash":
      if (v.length !== 32) bad("hash");
      return;
    case "time":
    case "time-ms":
    case "int":
      if (v.length !== 8) bad(spec.type);
      return;
    case "hashes":
      if (v.length % 32 !== 0) bad("hashes");
      return;
    case "key-ref":
      try {
        parseVkey(fromUtf8(v));
      } catch {
        bad("key-ref");
      }
      return;
    case "note":
      try {
        parseNote(v);
      } catch {
        bad("note");
      }
      return;
    case "ref": {
      const r = new Reader(v);
      try {
        const n = r.u8();
        if (n === 0) bad("ref");
        r.bytes(n);
        r.u64();
        r.end();
      } catch (e) {
        if (e instanceof VerifyError && e.code === "bad-entry-layout") throw e;
        bad("ref");
      }
      return;
    }
    case "subject": {
      const t = v[0]!;
      if (t === 0 && v.length === 1) return;
      if (t === 1 && v.length === 33) return;
      if (t === 2) {
        let s = "";
        for (const c of v.subarray(1)) s += String.fromCharCode(c);
        if (isValidId(s)) return;
        bad("subject");
      }
      if (t === 3) {
        checkFieldType({ name: spec.name, kind: "public", type: "ref" }, v.subarray(1));
        return;
      }
      bad("subject");
      return;
    }
    case "bytes":
    case undefined:
      return;
  }
}

/** Checks an entry against the layout of its tag, when the tag is a core
 * profile. Unknown tags pass: a tool without the profile can still split the
 * entry into fields. */
export function checkLayout(e: Entry): void {
  const layout = layoutOf(e.tag);
  if (!layout) return;
  if (e.fields.length !== layout.length) fail("bad-entry-layout", { detail: "field-count", want: layout.length });
  layout.forEach((spec, i) => {
    const f = e.fields[i]!;
    if ((spec.kind === "public") !== (f.kind === FIELD_PUBLIC)) fail("bad-entry-layout", { field: spec.name, detail: "kind" });
    if (spec.kind === "public") checkFieldType(spec, f.value);
  });
}

/** The value of a public field by name, for core profiles. */
export function fieldValue(e: Entry, name: string): Uint8Array | undefined {
  const layout = layoutOf(e.tag);
  if (!layout) return undefined;
  const i = layout.findIndex((s) => s.name === name);
  return i < 0 ? undefined : e.fields[i]?.value;
}

export function fieldText(e: Entry, name: string): string | undefined {
  const v = fieldValue(e, name);
  return v === undefined ? undefined : fromUtf8(v);
}

export function fieldU64(e: Entry, name: string): bigint | undefined {
  const v = fieldValue(e, name);
  return v === undefined || v.length !== 8 ? undefined : readU64(v, 0);
}

// ---------------------------------------------------------------------------
// vitrine/election/v1

export const ELECTION_TAG = "vitrine/election/v1";

export interface ElectionFields {
  eventId: string;
  electionId: string;
  /** The ballot hash: 32 bytes, or 64 lowercase hex digits, or base64. */
  ballotId: Uint8Array | string;
  /** When the ballot box accepted it, POSIX seconds. */
  acceptedAt: number | bigint;
}

/** Decodes a 32-byte hash given as bytes, lowercase hex or base64. */
export function decodeHash32(v: Uint8Array | string): Uint8Array {
  if (typeof v !== "string") {
    if (v.length !== 32) throw new TypeError("a hash is 32 bytes");
    return v;
  }
  if (v.length === 64 && /^[0-9a-f]+$/.test(v)) return hexDecode(v, 32);
  return b64decode(v, 32);
}

/** Builds the `vitrine/election/v1` entry (specs/entry.md, section 4.1). */
export function buildElectionEntry(f: ElectionFields): Uint8Array {
  if (!isValidId(f.eventId)) throw new TypeError("eventId is not a valid id");
  if (!isValidId(f.electionId)) throw new TypeError("electionId is not a valid id");
  let ballot: Uint8Array;
  try {
    ballot = decodeHash32(f.ballotId);
  } catch {
    throw new TypeError("ballotId is not a 32-byte hash");
  }
  const t = BigInt(f.acceptedAt);
  if (t < 0n || t > MAX_U64) throw new TypeError("acceptedAt out of range");
  return encodeEntry(ELECTION_TAG, [
    { kind: FIELD_PUBLIC, value: utf8(f.eventId) },
    { kind: FIELD_PUBLIC, value: utf8(f.electionId) },
    { kind: FIELD_PUBLIC, value: ballot },
    { kind: FIELD_PUBLIC, value: u64be(t) },
  ]);
}

// ---------------------------------------------------------------------------
// Expectations (specs/receipt.md, section 1.1)

export type Expectation = { entry: Uint8Array } | { fields: Record<string, string> };

const CAMEL: Record<string, string> = {
  eventId: "event_id",
  electionId: "election_id",
  ballotId: "ballot_id",
  acceptedAt: "accepted_at",
};

function normaliseFields(fields: Record<string, string>): Map<string, string> {
  const out = new Map<string, string>();
  for (const [k, v] of Object.entries(fields)) out.set(Object.hasOwn(CAMEL, k) ? CAMEL[k]! : k, v);
  return out;
}

function expectedValue(spec: FieldSpec, s: string): Uint8Array {
  if (spec.kind === "commitment") return decodeHash32(s);
  switch (spec.type) {
    case "hash":
      return decodeHash32(s);
    case "time":
    case "time-ms":
    case "int":
      return u64be(parseDecimal(s, MAX_U64));
    case "bytes":
    case "hashes":
    case "ref":
    case "subject":
      return /^[0-9a-f]*$/.test(s) && s.length % 2 === 0 ? hexDecode(s) : b64decode(s);
    default:
      return utf8(s);
  }
}

/** The entry the expectations name, when they determine it completely. For
 * election/v1 field expectations, `accepted_at` may come from `fallback` (the
 * entry in the receipt's extra), as specs/receipt.md, section 1.1 says. */
export function expectedEntry(expect: Expectation, tag: string | undefined, fallback?: Entry): Uint8Array | undefined {
  if ("entry" in expect) return expect.entry;
  const fields = normaliseFields(expect.fields);
  const t = tag ?? fallback?.tag;
  if (t !== ELECTION_TAG) return undefined;
  for (const k of fields.keys()) {
    if (!["event_id", "election_id", "ballot_id", "accepted_at"].includes(k))
      fail("expectation-unknown-field", { field: k.slice(0, 64) });
  }
  const ev = fields.get("event_id");
  const el = fields.get("election_id");
  const b = fields.get("ballot_id");
  let at: bigint | undefined;
  const atStr = fields.get("accepted_at");
  if (atStr !== undefined) at = parseDecimal(atStr, MAX_U64);
  else if (fallback && fallback.tag === ELECTION_TAG) at = fieldU64(fallback, "accepted_at");
  if (ev === undefined || el === undefined || b === undefined || at === undefined) return undefined;
  try {
    return buildElectionEntry({ eventId: ev, electionId: el, ballotId: b, acceptedAt: at });
  } catch {
    return fail("entry-mismatch", { detail: "expectation-invalid" });
  }
}

/** Checks `e` against the expectations; throws entry-mismatch and friends. */
export function checkExpectation(e: Entry, expect: Expectation): void {
  if ("entry" in expect) {
    if (!equalBytes(expect.entry, e.bytes)) fail("entry-mismatch");
    return;
  }
  if (e.tag === ELECTION_TAG) {
    const want = expectedEntry(expect, e.tag, e);
    if (!want) fail("expectation-incomplete");
    if (!equalBytes(want, e.bytes)) fail("entry-mismatch");
    return;
  }
  const layout = layoutOf(e.tag);
  if (!layout) fail("expectation-unsupported", { tag: e.tag });
  const fields = normaliseFields(expect.fields);
  if (fields.size === 0) fail("expectation-incomplete");
  for (const [name, s] of fields) {
    const i = layout.findIndex((f) => f.name === name);
    if (i < 0) fail("expectation-unknown-field", { field: name.slice(0, 64) });
    let want: Uint8Array;
    try {
      want = expectedValue(layout[i]!, s);
    } catch {
      return fail("entry-mismatch", { field: name });
    }
    if (!equalBytes(want, e.fields[i]!.value)) fail("entry-mismatch", { field: name });
  }
}
