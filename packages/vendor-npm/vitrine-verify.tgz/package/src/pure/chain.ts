// SPDX-License-Identifier: Apache-2.0
//
// Receipt chains (specs/receipt.md, section 3): parsing and formatting, and
// the tier verification of section 3.1, which produces the ChainResult of
// src/types.ts.
//
// Statuses. `invalid`: a block didn't parse, verify or match, or the
// expectations can't confirm the entry (damaged or unverifiable input, not
// evidence). `failed`: validly signed objects contradict each other or the
// policy, which is evidence: two log-signed checkpoints of one size with
// different roots, a log-signed receipt for an entry that breaks the log's
// profile, a hub-cosigned entry its witnesses must have refused. Whatever is
// missing or not yet due is `pending`, and `late` once its deadline passed by
// signed time. Unsigned proofs that don't verify (inclusion, consistency)
// make a tier `invalid`, never `failed`.
//
// Policies. The chain names the policy it was made under: the pinned policy
// or a successor the verifier applied (a PolicyHistory). Every checkpoint is
// judged under the policy in force at its quorum time (specs/policy.md,
// section 4, rule 9); the hubs and the browser layer are those of the policy
// in force at the verifier's signed now. Until the verifier has read the
// events log for successors up to a recent checkpoint (rule 7), no tier is
// `verified`.

import type { ReasonCode, StepCode } from "../codes.js";
import type {
  BrowserLayer,
  ChainResult,
  EntryInfo,
  Expect,
  Facts,
  FactState,
  HubTierDetail,
  OverallStatus,
  PolicySummary,
  Reason,
  Step,
  TierName,
  TierResult,
  TierStatus,
  Where,
} from "../types.js";
import { hexEncode } from "./base64.js";
import { equalBytes, parseDecimal, utf8 } from "./bytes.js";
import { formatBlockDoc, formatHashLines, parseBlockDoc, parseHashLines, type Block } from "./blocks.js";
import { verifyBrowserAnchor, type VerifiedBrowserAnchor } from "./browser.js";
import type { CheckedCheckpoint, Checkpoint } from "./checkpoint.js";
import { checkExpectation, checkLayout, expectedEntry, parseEntry, type Entry } from "./entry.js";
import { fail, reason, toReason, VerifyError, type Params } from "./errors.js";
import { leafHash } from "./hash.js";
import {
  applyPolicyProofs,
  hubKeys,
  judgeCheckpoint,
  judgeWith,
  logKeys,
  needsDiscovery,
  PolicyHistory,
  vouchedNow,
  type Judged,
  type KeysOf,
} from "./history.js";
import {
  bootstrapHubOf,
  checkOpening,
  hubSubject,
  logSubject,
  parseOpening,
  verifyHubLink,
  verifyPreviousAnchor,
  type Subject,
  type VerifiedHubLink,
} from "./hub.js";
import { identicon } from "./identicon.js";
import { MAX_CONSISTENCY_HASHES, verifyConsistency, verifyInclusion } from "./merkle.js";
import { parseNote } from "./note.js";
import { appHubs, policyWords, profileAt, quietPeriod, type Policy, type PolicyHub, type PolicyLog } from "./policy.js";
import { enforceBuiltinProfileMinimums, validateProfileMinimums, type ProfileMeaningPackage } from "./profiles.js";
import {
  checkPromiseBatch,
  checkPromiseInclusion,
  keptBy,
  parsePromise,
  parsePromiseBatchText,
  promiseDeadline,
  PROMISE_GRACE,
  type PromiseBatch,
  type PromiseTerms,
} from "./promise.js";
import { attestationCovers, verifyAttestation, verifyPolicyAck } from "./statements.js";
import { ELECTION_TAG } from "./tags.js";
import { parseTlogProof, type TlogProof } from "./tlogproof.js";
import { bcp47, wordsFromBits } from "./words.js";

export const CHAIN_HEADER = "vitrine/receipt-chain/v1";
export const CHAIN_FILE_EXTENSION = ".vitrine-receipt";
export const CHAIN_MEDIA_TYPE = "application/vnd.vitrine.receipt-chain";
/** Verifiers warn when the device clock is further than this from signed time. */
export const CLOCK_WARNING_SECONDS = 60;
/** Tier 3 is due `browser period + 600` seconds after the hub tier's
 * deadline (specs/receipt.md, section 3.1, step 4). */
export const BROWSER_GRACE_SECONDS = 600;

/** The blocks of one app hub (specs/receipt.md, section 3). `browserLink`,
 * `browser` or `bootstrap`, and `browserConsistency` are the log's pair for
 * the hub (specs/hub.md, section 6.5), copied as the log served them. */
export interface HubBlocks {
  anchor?: Uint8Array;
  opening?: Uint8Array;
  previousAnchor?: Uint8Array;
  previousOpening?: Uint8Array;
  openingConsistency?: ConsistencyBlock;
  attestation?: Uint8Array;
  anchorConsistency?: ConsistencyBlock;
  browserLink?: Uint8Array;
  browserLinkConsistency?: ConsistencyBlock;
  browser?: Uint8Array;
  bootstrap?: Uint8Array;
  browserConsistency?: ConsistencyBlock;
}

/** Block types and their argument counts, chain-wide ones first. */
const ARITY: Readonly<Record<string, number>> = {
  "policy-ack": 0,
  promise: 0,
  issued: 0,
  record: 0,
  consistency: 2,
  anchor: 1,
  opening: 1,
  "previous-anchor": 1,
  "previous-opening": 1,
  "opening-consistency": 3,
  attestation: 1,
  "anchor-consistency": 3,
  "browser-link": 1,
  "browser-link-consistency": 3,
  browser: 1,
  bootstrap: 1,
  "browser-consistency": 3,
};

/** Per-hub block types, in the order of the spec's table, and their fields. */
const HUB_FIELD: Readonly<Record<string, keyof HubBlocks>> = {
  anchor: "anchor",
  opening: "opening",
  "previous-anchor": "previousAnchor",
  "previous-opening": "previousOpening",
  "opening-consistency": "openingConsistency",
  attestation: "attestation",
  "anchor-consistency": "anchorConsistency",
  "browser-link": "browserLink",
  "browser-link-consistency": "browserLinkConsistency",
  browser: "browser",
  bootstrap: "bootstrap",
  "browser-consistency": "browserConsistency",
};

/** A consistency block: its sizes and its body (base64 hashes). */
export interface ConsistencyBlock {
  from: bigint;
  to: bigint;
  body: Uint8Array;
}

export interface ReceiptChain {
  policyId: string;
  log: string;
  policyAck?: Uint8Array;
  promise?: Uint8Array;
  issued?: Uint8Array;
  record?: Uint8Array;
  consistency?: ConsistencyBlock;
  /** By hub name, in the order of first appearance. */
  hubs: Map<string, HubBlocks>;
  /** Blocks of types this verifier doesn't know, kept as they were. */
  unknown: Block[];
}

function consistencyOf(b: Block, at: number): ConsistencyBlock {
  try {
    return { from: parseDecimal(b.args[at]!), to: parseDecimal(b.args[at + 1]!), body: b.body };
  } catch {
    return fail("malformed-chain", { detail: `sizes-${b.type}` });
  }
}

/** Parses a receipt chain's framing. Block contents are checked by
 * verifyChain, so a damaged block only affects its own tier. */
export function parseChain(input: Uint8Array | string): ReceiptChain {
  const doc = parseBlockDoc(input, { header: CHAIN_HEADER, keys: ["policy", "log"], code: "malformed-chain" });
  const [policy, log] = doc.values as [string[], string[]];
  if (policy.length !== 1 || log.length !== 1) fail("malformed-chain", { detail: "lines" });
  const c: ReceiptChain = { policyId: policy[0]!, log: log[0]!, hubs: new Map(), unknown: [] };
  const seen = new Set<string>();
  for (const b of doc.blocks) {
    if (!Object.hasOwn(ARITY, b.type)) {
      c.unknown.push(b);
      continue;
    }
    if (b.args.length !== ARITY[b.type]) fail("malformed-chain", { detail: `arguments-${b.type}` });
    const field = Object.hasOwn(HUB_FIELD, b.type) ? HUB_FIELD[b.type] : undefined;
    const hub = field ? b.args[0]! : undefined;
    const key = hub === undefined ? b.type : `${b.type} ${hub}`;
    if (seen.has(key)) fail("duplicate-block", hub === undefined ? { type: b.type } : { type: b.type, hub: hub.slice(0, 64) });
    seen.add(key);
    if (field && hub !== undefined) {
      let h = c.hubs.get(hub);
      if (!h) {
        h = {};
        c.hubs.set(hub, h);
      }
      (h as Record<string, Uint8Array | ConsistencyBlock>)[field] = b.args.length === 3 ? consistencyOf(b, 1) : b.body;
      continue;
    }
    switch (b.type) {
      case "policy-ack":
        c.policyAck = b.body;
        break;
      case "promise":
        c.promise = b.body;
        break;
      case "issued":
        c.issued = b.body;
        break;
      case "record":
        c.record = b.body;
        break;
      case "consistency":
        c.consistency = consistencyOf(b, 0);
        break;
    }
  }
  if (!c.promise && !c.issued && !c.record) fail("no-receipt");
  return c;
}

/** Serialises a receipt chain, blocks in the order of the spec's table. */
export function formatChain(c: ReceiptChain): Uint8Array {
  const blocks: Block[] = [];
  const add = (type: string, body: Uint8Array | undefined): void => {
    if (body) blocks.push({ type, args: [], body });
  };
  add("policy-ack", c.policyAck);
  add("promise", c.promise);
  add("issued", c.issued);
  add("record", c.record);
  if (c.consistency) blocks.push({ type: "consistency", args: [String(c.consistency.from), String(c.consistency.to)], body: c.consistency.body });
  for (const [type, field] of Object.entries(HUB_FIELD)) {
    for (const [name, h] of c.hubs) {
      const v = h[field];
      if (!v) continue;
      if (v instanceof Uint8Array) blocks.push({ type, args: [name], body: v });
      else blocks.push({ type, args: [name, String(v.from), String(v.to)], body: v.body });
    }
  }
  blocks.push(...c.unknown);
  return formatBlockDoc(CHAIN_HEADER, [`policy ${c.policyId}`, `log ${c.log}`], blocks);
}

/** A consistency block from a proof's hashes. */
export function consistencyBlock(from: bigint, to: bigint, proof: readonly Uint8Array[]): ConsistencyBlock {
  return { from, to, body: formatHashLines(proof) };
}

export interface VerifyChainOptions {
  /** Authenticated canonical meanings for custom or future profile versions.
   * The immutable published core meanings are included automatically. */
  profileMetadata?: readonly ProfileMeaningPackage[];
  /** What the entry must be (specs/receipt.md, section 1.1). Mandatory. */
  expect: Expect;
  /** The device clock, POSIX seconds. Default: the current time. */
  now?: number;
  /** Where the check runs. Default "page". */
  where?: Where;
  /** Other checkpoints of the chain's log that the verifier holds, such as
   * the latest one it fetched and a mirror's; their cosignatures count
   * towards signed time, and two of one size with different roots are
   * split-view evidence. */
  checkpoints?: readonly (string | Uint8Array)[];
  /** The pinned policy with the successors the verifier applied, and when
   * it last read the events log (rule 7). Its pinned policy must be the
   * `policy` argument. Default: the pinned policy alone, not yet read. */
  history?: PolicyHistory;
  /** A `vitrine/policy-proofs/v1` document (the voter route of a private
   * event) to apply to the history before verifying. */
  policyProofs?: string | Uint8Array;
  /** The latest checkpoint of each app hub, by hub name, as fetched from the
   * hub (`GET <hub>/checkpoint`), for the staleness check of section 3.1. */
  hubCheckpoints?: Readonly<Record<string, string | Uint8Array>>;
  /** More links from each hub, by hub name, besides the chain's `anchor`
   * block: the links through which the verifier follows the subject's
   * rotations, one at a time (specs/hub.md, section 5.2, step 6). */
  hubLinks?: Readonly<Record<string, readonly (string | Uint8Array)[]>>;
  /** Pairs of the log's checkpoints between which the log's consistency
   * proof didn't verify, as an upgrade found them: the witnesses tier is
   * `invalid` (`failed` when the two are of one size: a split view). */
  inconsistencies?: readonly (readonly [string | Uint8Array, string | Uint8Array])[];
}

/** The policy summary shown next to a result: the pinned policy, and the
 * policy in force when it is another one. */
export function policySummary(p: Policy, inForce?: Policy): PolicySummary {
  const s: PolicySummary = {
    id: p.id,
    words: policyWords(p),
    lang: bcp47(p.words),
    event: p.name,
    witnesses: [...p.witnesses.witnesses.values()].map((w) => (w.partyGiven ? { name: w.name, party: w.party } : { name: w.name })),
    hubs: appHubs(p).map((h) => h.name),
    browser: browserLayer(p),
  };
  if (inForce && inForce.id !== p.id) s.inForce = { id: inForce.id, words: policyWords(inForce) };
  return s;
}

/** Verifies a receipt chain against a pinned policy (specs/receipt.md,
 * section 3.1). Never throws on bad input: problems become reasons. */
export function verifyChain(input: Uint8Array | string, policy: Policy, opts: VerifyChainOptions): ChainResult {
  if (!opts || !opts.expect) throw new TypeError("verifyChain needs expectations (opts.expect)");
  if (policy.draft) throw new TypeError("a draft policy is never valid; pin a sealed policy");
  if (opts.history && opts.history.pinned.id !== policy.id) throw new TypeError("opts.history is for another pinned policy");
  return new ChainVerifier(policy, opts).run(input);
}

/** Verifies a single receipt (specs/receipt.md, section 1.1) as a chain with
 * one `record` block. */
export function verifyReceipt(
  receipt: Uint8Array | string,
  policy: Policy,
  log: string,
  expect: Expect,
  opts: Omit<VerifyChainOptions, "expect"> = {},
): ChainResult {
  if (!expect) throw new TypeError("verifyReceipt needs expectations");
  const record = typeof receipt === "string" ? utf8(receipt) : receipt;
  const chain = formatChain({ policyId: policy.id, log, record, hubs: new Map(), unknown: [] });
  return verifyChain(chain, policy, { ...opts, expect });
}

// ---------------------------------------------------------------------------

const num = (b: bigint): number | string => (b <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(b) : b.toString());

interface Receipt {
  block: "issued" | "record";
  proof: TlogProof;
  extra: Uint8Array;
  judged: Judged<CheckedCheckpoint>;
  cp: Checkpoint;
  leaf: Uint8Array;
}

interface ValidPromise {
  batch: PromiseBatch;
  terms: PromiseTerms;
  leaf: Uint8Array;
  /** `time + mmd + 30`. */
  deadline: number;
  /** The deadline, moved to `closes + mmd + 30` when it falls in a quiet
   * period of an election log. */
  due: number;
}

interface RecordState {
  status: TierStatus;
  reasons: Reason[];
  invalid: boolean;
  failed: boolean;
  pending: boolean;
  receipts: Receipt[];
  /** The record receipt, or the issued one when there's no record. */
  best?: Receipt;
  promise?: ValidPromise;
  /** The user's leaf hash and index, once the expectations confirm them. */
  leaf?: Uint8Array;
  index?: bigint;
}

interface WitnessState {
  status: TierStatus;
  reasons: Reason[];
  deadline?: number;
  /** The record's quorum time when it is witnessed. */
  quorumTime?: number;
}

interface HubState {
  hub: PolicyHub;
  status: TierStatus;
  reasons: Reason[];
  deadline?: number;
  /** True when the hub is pending only for an attestation: never late. */
  neverLate?: boolean;
  /** The hub link the tier rests on, once it verified with the hub's quorum. */
  link?: Judged<VerifiedHubLink>;
  test?: boolean;
}

interface Draft {
  tier: TierName;
  status: TierStatus;
  reasons: Reason[];
  deadline?: number;
  hubs?: HubState[];
  lateCode?: ReasonCode;
  /** The hub tier's deadline, from which tier 3's counts. */
  tierDeadline?: number;
}

interface Outcome {
  status: TierStatus;
  reasons: Reason[];
  neverLate?: boolean;
}

/** A checkpoint of the chain's log that the verifier holds. */
interface Held {
  cp: Checkpoint;
  logTime?: number;
  /** The block or option it came from, for evidence. */
  source: string;
}

const RANK: Record<TierStatus, number> = { unused: -1, verified: 0, pending: 1, late: 2, invalid: 3, failed: 4 };

/** The worst status, ignoring `unused`; `unused` when nothing else is there. */
function combine(statuses: readonly TierStatus[]): TierStatus {
  let out: TierStatus = "unused";
  for (const s of statuses) if (RANK[s] > RANK[out]) out = s;
  return out;
}

/** How the policy uses the browser tier for a hub. */
function browserUse(p: Policy, h: PolicyHub): "counted" | "test" | "none" {
  const services = [...p.waict.values()].filter((s) => s.hubs.includes(h.name));
  const bootstrap = [...p.hubs.values()].some((x) => x.bootstrap);
  if (bootstrap || services.some((s) => s.operator !== p.operator)) return "counted";
  return services.length > 0 ? "test" : "none";
}

function browserLayer(p: Policy): BrowserLayer {
  if ([...p.hubs.values()].some((h) => h.bootstrap)) return "bootstrap";
  const uses = appHubs(p).map((h) => browserUse(p, h));
  if (uses.includes("counted")) return "waict";
  return uses.includes("test") ? "test" : "none";
}

function factOf(statuses: readonly TierStatus[], doneWhen: (s: TierStatus, i: number) => boolean): FactState {
  if (statuses.includes("failed")) return "failed";
  if (statuses.includes("invalid")) return "invalid";
  if (statuses.every(doneWhen)) return "done";
  if (statuses.includes("late")) return "late";
  return "pending";
}

class ChainVerifier {
  private readonly steps: Step[] = [];
  private readonly reasons: Reason[] = [];
  private readonly h: PolicyHistory;
  /** Notes of the chain's log's checkpoints that the verifier holds, for
   * signed time. */
  private readonly heldNotes: (string | Uint8Array)[] = [];
  /** The same checkpoints, verified, for split views and broken promises. */
  private readonly held: Held[] = [];
  private readonly deviceNow: number;
  private readonly where: Where;
  private chain!: ReceiptChain;
  private log!: PolicyLog;
  private keysOf!: KeysOf;
  private electionLog = false;
  /** The policy in force at the signed now (or the device clock). */
  private inForce!: Policy;
  private profileMetadataResolved = false;
  private ackPolicy?: string;

  constructor(
    private readonly pinned: Policy,
    private readonly opts: VerifyChainOptions,
  ) {
    this.deviceNow = opts.now ?? Math.floor(Date.now() / 1000);
    this.where = opts.where ?? "page";
    this.h = opts.history ?? new PolicyHistory(pinned);
  }

  private step(code: StepCode, tier: Step["tier"], ok: boolean | null, params?: Params, reasons?: Reason[]): void {
    const s: Step = { code, tier, ok };
    if (params) s.params = params;
    if (reasons && reasons.length > 0) s.reasons = reasons;
    this.steps.push(s);
  }

  run(input: Uint8Array | string): ChainResult {
    this.inForce = this.h.at(this.deviceNow);
    try {
      this.chain = parseChain(input);
    } catch (e) {
      return this.rejected("chain-format", toReason(e));
    }
    const chain = this.chain;
    this.step("chain-format", "policy", true);
    if (this.opts.policyProofs !== undefined) {
      try {
        applyPolicyProofs(this.h, this.opts.policyProofs, this.deviceNow);
      } catch (e) {
        delete this.h.readThrough;
        const r = toReason(e);
        this.step("policy-successors", "policy", false, undefined, [r]);
        this.reasons.push(r);
      }
    }
    try {
      for (const { policy } of this.h.epochs) enforceBuiltinProfileMinimums(policy);
    } catch (e) { return this.rejected("policy-pinned", toReason(e)); }
    try {
      for (const { policy } of this.h.epochs) validateProfileMinimums(policy, this.opts.profileMetadata);
      this.profileMetadataResolved = true;
    } catch (e) {
      this.reasons.push(reason("profile-meaning-unknown", { detail: toReason(e).params?.["detail"] ?? "metadata-required" }));
    }
    const chainPolicy = this.h.byId(chain.policyId);
    if (!chainPolicy) {
      return this.rejected("policy-pinned", reason("policy-mismatch", { chain: chain.policyId.slice(0, 80), pinned: this.pinned.id }));
    }
    this.step("policy-pinned", "policy", true, { policy: chainPolicy.id });
    const log = chainPolicy.logs.get(chain.log);
    if (!log) return this.rejected("log-known", reason("unknown-log", { log: chain.log.slice(0, 64) }));
    this.log = log;
    this.keysOf = logKeys(log.name);
    this.electionLog = log.profiles.some((p) => p.tag === ELECTION_TAG);
    this.step("log-known", "policy", true, { log: log.name });
    if (chain.policyAck) {
      try {
        verifyPolicyAck(chain.policyAck, log, chainPolicy.id);
        this.ackPolicy = chainPolicy.id;
        this.step("policy-ack", "policy", true);
      } catch (e) {
        const r = toReason(e, ["policy-ack"]);
        this.step("policy-ack", "policy", false, undefined, [r]);
        this.reasons.push(r);
      }
    }
    for (const x of this.opts.checkpoints ?? []) this.hold(x, "checkpoints");

    const rec = this.record(chain, log);
    const now0 = vouchedNow(this.h, this.heldNotes, this.keysOf, this.deviceNow);
    this.inForce = this.h.at(now0 ?? this.deviceNow);
    const app = appHubs(this.inForce);
    for (const name of chain.hubs.keys()) {
      if (!app.some((h) => h.name === name)) this.reasons.push(reason("unknown-hub", { hub: name.slice(0, 64) }));
    }
    const wit = this.witnesses(rec);
    const hubs = this.hubs(chain, rec, wit);
    const browser = this.browser(chain, rec, hubs);
    for (const browserHub of browser.hubs ?? []) {
      const fork = browserHub.reasons.find((r) => r.code === "split-view" &&
        (r.objects?.includes(`browser ${browserHub.hub.name}`) || r.objects?.includes(`bootstrap ${browserHub.hub.name}`)));
      if (fork) {
        const hub = hubs.hubs?.find((h) => h.hub.name === browserHub.hub.name);
        if (hub) { hub.status = "failed"; hub.reasons.push(fork); }
        hubs.status = "failed";
      }
    }

    const vouched = vouchedNow(this.h, this.heldNotes, this.keysOf, this.deviceNow);
    const signed = vouched !== undefined;
    const now = vouched ?? this.deviceNow;
    if (!signed) this.reasons.push(reason("no-signed-time"));
    // The tiers above were judged under the policy in force at the record's
    // signed time; the summary, the discovery rule and the words follow the
    // one in force at the result's `now`.
    this.inForce = this.h.at(now);
    this.splitViews(rec, wit);

    const onlyPromise = rec.status === "pending" && rec.receipts.length === 0 && rec.promise !== undefined;
    const drafts: Draft[] = [
      {
        tier: "record",
        status: rec.status,
        reasons: rec.reasons,
        ...(onlyPromise ? { deadline: rec.promise!.due, lateCode: "promise-deadline-passed" as const } : {}),
      },
      { tier: "witnesses", status: wit.status, reasons: wit.reasons, ...(wit.deadline !== undefined ? { deadline: wit.deadline } : {}) },
      hubs,
      browser,
    ];
    const tiers = drafts.map((d) => this.finish(d, now, signed));
    this.staleness(hubs, tiers);
    this.discovery(tiers, now);
    const result = this.result(tiers, now, signed, rec.receipts.length === 0 && rec.promise !== undefined);
    if (rec.leaf) {
      const entry: EntryInfo = { log: log.name, leafHash: hexEncode(rec.leaf), promised: rec.receipts.length === 0 };
      if (rec.index !== undefined) entry.index = Number(rec.index);
      result.entry = entry;
      result.words = wordsFromBits(rec.leaf, 4, this.inForce.words);
      result.wordsLang = bcp47(this.inForce.words);
      result.identicon = identicon(rec.leaf);
    }
    return result;
  }

  /** Keeps a checkpoint of the chain's log, if the log signed it under one
   * of the policies. */
  private hold(note: string | Uint8Array, source: string, judged?: Judged<CheckedCheckpoint>): void {
    this.heldNotes.push(note);
    let j = judged;
    if (!j) {
      try {
        j = judgeCheckpoint(this.h, note, this.keysOf, this.deviceNow);
      } catch {
        // Not a checkpoint of this log: it says nothing.
        return;
      }
    }
    const x: Held = { cp: j.value.cp, source };
    if (j.value.logTime !== undefined) x.logTime = j.value.logTime;
    this.held.push(x);
  }

  private result(tiers: TierResult[], now: number, signed: boolean, promised: boolean): ChainResult {
    const [r, w, h, b] = tiers.map((t) => t.status) as [TierStatus, TierStatus, TierStatus, TierStatus];
    const facts: Facts = {
      included: r === "pending" && promised ? "promised" : factOf([r], (s) => s === "verified"),
      unchanged: factOf([r, w], (s) => s === "verified"),
      sameForEveryone: factOf([w, h, b], (s, i) => s === "verified" || (i > 0 && s === "unused")),
    };
    if (!this.profileMetadataResolved) for (const key of ["included", "unchanged", "sameForEveryone"] as const) {
      if (facts[key] === "done") facts[key] = "pending";
    }
    const statuses = tiers.map((t) => t.status);
    let status: OverallStatus = "verified";
    for (const s of ["pending", "late", "invalid", "failed"] as const) if (statuses.includes(s)) status = s;
    if (status === "verified" && !this.profileMetadataResolved) status = "pending";
    return {
      ok: !statuses.includes("failed") && !statuses.includes("invalid"),
      status,
      tiers,
      facts,
      reasons: this.reasons,
      steps: this.steps,
      where: this.where,
      words: [],
      wordsLang: bcp47(this.inForce.words),
      now,
      clockWarning: signed && Math.abs(this.deviceNow - now) > CLOCK_WARNING_SECONDS,
      profileMetadataResolved: this.profileMetadataResolved,
      policy: policySummary(this.pinned, this.inForce),
    };
  }

  /** A result for a chain that can't be checked at all. */
  private rejected(code: StepCode, r: Reason): ChainResult {
    this.step(code, "policy", false, undefined, [r]);
    this.reasons.push(r);
    const app = appHubs(this.inForce);
    const detail = (h: PolicyHub, status: TierStatus): HubTierDetail => ({ hub: h.name, status, reasons: [] });
    const browserDetails = app.map((h) => detail(h, "invalid"));
    const tiers: TierResult[] = [
      { tier: "record", status: "invalid", reasons: [] },
      { tier: "witnesses", status: "invalid", reasons: [] },
      { tier: "hubs", status: "invalid", reasons: [], hubs: app.map((h) => detail(h, "invalid")) },
      { tier: "browser", status: "invalid", reasons: [], hubs: browserDetails },
    ];
    return this.result(tiers, this.deviceNow, false, false);
  }

  private finish(d: Draft, now: number, signed: boolean): TierResult {
    // Without signed time, nothing turns late (section 3.1).
    const late = (status: TierStatus, deadline: number | undefined, neverLate?: boolean): deadline is number =>
      signed && !neverLate && status === "pending" && deadline !== undefined && now > deadline;
    const out: TierResult = { tier: d.tier, status: d.status, reasons: [...d.reasons] };
    if (d.hubs) {
      const details = d.hubs.map((s) => {
        const x: HubTierDetail = { hub: s.hub.name, status: s.status, reasons: [...s.reasons] };
        if (late(s.status, s.deadline, s.neverLate)) {
          x.status = "late";
          x.reasons.push(reason("deadline-passed", { deadline: s.deadline }));
        }
        if (s.test) x.test = true;
        return x;
      });
      out.hubs = details;
      if (d.status !== "unused" && details.length > 0) out.status = combine(details.map((x) => x.status));
      const open = d.hubs.filter((s, i) => (details[i]!.status === "pending" || details[i]!.status === "late") && s.deadline !== undefined && !s.neverLate);
      if (open.length > 0) out.deadline = Math.min(...open.map((s) => s.deadline!));
    } else {
      if (late(d.status, d.deadline)) {
        out.status = "late";
        out.reasons.push(reason(d.lateCode ?? "deadline-passed", { deadline: d.deadline }));
      }
      if ((out.status === "pending" || out.status === "late") && d.deadline !== undefined) out.deadline = d.deadline;
    }
    return out;
  }

  /** Rule 7: until the events log was read up to a checkpoint whose quorum
   * time is at most `epoch` seconds before now, no tier is `verified`. A
   * policy without an events log can have no successor. */
  private discovery(tiers: TierResult[], now: number): void {
    if (!needsDiscovery(this.inForce)) return;
    const through = this.h.readThrough;
    const fresh = through !== undefined && through >= now - this.inForce.epoch;
    if (fresh) {
      this.step("policy-successors", "policy", true, { through });
      return;
    }
    const r = reason("successors-unchecked", through === undefined ? {} : { through });
    this.step("policy-successors", "policy", null, undefined, [r]);
    for (const t of tiers) {
      for (const d of t.hubs ?? []) {
        if (d.status === "verified") {
          d.status = "pending";
          d.reasons.push(r);
        }
      }
      if (t.status === "verified") {
        t.status = "pending";
        t.reasons.push(r);
      }
    }
  }

  // -- Tier 0: record --------------------------------------------------------

  /** The batch's policy's terms, and when a promise is due. */
  private promiseDue(batch: PromiseBatch, bp: Policy, terms: PromiseTerms): number {
    const d = promiseDeadline(batch, terms);
    const end = this.quietEnd(bp, d);
    return end === undefined ? d : end + bp.mmd + PROMISE_GRACE;
  }

  /** The end of the quiet period that `t` falls in, for an election log
   * (specs/policy.md, section 2.1: other logs are never quiet). */
  private quietEnd(p: Policy, t: number): number | undefined {
    if (!this.electionLog) return undefined;
    const q = quietPeriod(p);
    return q && t >= q.start && t <= q.end ? q.end : undefined;
  }

  private record(c: ReceiptChain, log: PolicyLog): RecordState {
    const st: RecordState = { status: "verified", reasons: [], invalid: false, failed: false, pending: false, receipts: [] };
    const bad = (r: Reason, kind: "invalid" | "failed" | "pending"): Reason => {
      st.reasons.push(r);
      st[kind] = true;
      return r;
    };

    let promise: ValidPromise | undefined;
    if (c.promise) promise = this.promise(c.promise, c.log, bad);

    for (const block of ["issued", "record"] as const) {
      const body = c[block];
      if (!body) continue;
      const r = this.receipt(block, body, bad);
      if (r) st.receipts.push(r);
    }
    const [first, second] = st.receipts;
    if (first && second) {
      if (!equalBytes(first.extra, second.extra) || first.proof.index !== second.proof.index) {
        this.step("receipts-match", "record", false, undefined, [bad(reason("receipts-disagree", undefined, ["issued", "record"]), "invalid")]);
      } else {
        this.step("receipts-match", "record", true);
      }
    }
    if (first) this.entry(first, log, st, bad);
    if (first && second) this.recordConsistency(first, second, c.consistency, bad);
    st.best = st.receipts[st.receipts.length - 1];

    if (promise) {
      if (first) {
        if (equalBytes(promise.leaf, first.leaf)) {
          this.step("promise-leaf", "record", true);
          st.promise = promise;
        } else {
          this.step("promise-leaf", "record", false, undefined, [bad(reason("promise-leaf-mismatch", undefined, ["promise", first.block]), "invalid")]);
        }
      } else {
        try {
          const want = expectedEntry(this.opts.expect, profileAt(log, undefined).tag);
          if (!want) {
            this.step("promise-leaf", "record", null, undefined, [bad(reason("expectation-incomplete"), "invalid")]);
          } else if (!equalBytes(leafHash(want), promise.leaf)) {
            this.step("promise-leaf", "record", false, undefined, [bad(reason("promise-leaf-mismatch", undefined, ["promise"]), "invalid")]);
          } else {
            this.step("promise-leaf", "record", true);
            st.promise = promise;
            st.leaf = promise.leaf;
          }
        } catch (e) {
          this.step("promise-leaf", "record", false, undefined, [bad(toReason(e), "invalid")]);
        }
      }
    }
    if (st.promise && st.receipts.length > 0) this.promiseKept(st, st.promise, bad);

    if (st.failed) st.status = "failed";
    else if (st.invalid) st.status = "invalid";
    else if (st.receipts.length === 0) {
      st.status = "pending";
      st.reasons.push(reason("promise-pending", { deadline: st.promise!.due }));
    } else if (st.pending) st.status = "pending";
    return st;
  }

  /** Verifies the promise against the log key of the policy its batch names
   * (specs/receipt.md, section 2). */
  private promise(body: Uint8Array, logName: string, bad: (r: Reason, kind: "invalid") => Reason): ValidPromise | undefined {
    const objects = ["promise"];
    try {
      const p = parsePromise(body);
      const batch = parsePromiseBatchText(parseNote(p.batchNote).text);
      const bp = this.h.byId(batch.policy);
      if (!bp) fail("promise-policy-unknown", { policy: batch.policy });
      const blog = bp.logs.get(logName);
      if (!blog) fail("unknown-log", { log: logName.slice(0, 64) });
      const terms: PromiseTerms = { mmd: bp.mmd, skew: bp.skew };
      checkPromiseBatch(p, blog.vkey, (id) => (id === bp.id ? terms : undefined));
      this.step("promise-signature", "record", true, { time: batch.time, mmd: batch.mmd });
      try {
        checkPromiseInclusion(p, batch);
      } catch (e) {
        this.step("promise-inclusion", "record", false, undefined, [bad(toReason(e, objects), "invalid")]);
        return undefined;
      }
      this.step("promise-inclusion", "record", true, { index: p.index, size: batch.size });
      return { batch, terms, leaf: p.leaf, deadline: promiseDeadline(batch, terms), due: this.promiseDue(batch, bp, terms) };
    } catch (e) {
      this.step("promise-signature", "record", false, undefined, [bad(toReason(e, objects), "invalid")]);
      return undefined;
    }
  }

  /** Kept and broken promises (specs/receipt.md, sections 2 and 3.1). */
  private promiseKept(st: RecordState, p: ValidPromise, bad: (r: Reason, kind: "failed") => Reason): void {
    const params = { deadline: p.deadline };
    // A log-signed checkpoint without the leaf, dated after the deadline by
    // the log's own log-time: broken-promise evidence.
    const index = st.receipts[0]!.proof.index;
    const broken = this.held.find((x) => x.logTime !== undefined && x.logTime > p.deadline && x.cp.size <= index);
    if (broken) {
      const r = reason("broken-promise", { ...params, size: num(broken.cp.size), logTime: broken.logTime! }, ["promise", st.receipts[0]!.block, broken.source]);
      this.step("promise-kept", "record", false, params, [bad(r, "failed")]);
      return;
    }
    if (st.receipts.some((r) => keptBy(p.deadline, p.terms, r.judged.value.logTime, r.judged.quorumTime))) {
      this.step("promise-kept", "record", true, params);
      return;
    }
    const r = reason("promise-kept-unproven", params);
    this.step("promise-kept", "record", null, params, [r]);
    st.reasons.push(r);
  }

  private receipt(block: "issued" | "record", body: Uint8Array, bad: (r: Reason, kind: "invalid" | "failed" | "pending") => Reason): Receipt | undefined {
    const sig = block === "issued" ? "issued-signature" : "record-signature";
    const inc = block === "issued" ? "issued-inclusion" : "record-inclusion";
    let r: Receipt;
    try {
      const proof = parseTlogProof(body);
      const extra = proof.extra;
      if (extra === undefined) return fail("missing-extra");
      const judged = judgeCheckpoint(this.h, proof.checkpoint, this.keysOf, this.deviceNow, { requireLogTime: true });
      r = { block, proof, extra, judged, cp: judged.value.cp, leaf: leafHash(extra) };
    } catch (e) {
      // A log-signed size-0 checkpoint with another root is bad-checkpoint
      // evidence; anything else is damage.
      const kind = e instanceof VerifyError && e.code === "bad-empty-tree" ? "failed" : "invalid";
      this.step(sig, "record", false, undefined, [bad(toReason(e, [block]), kind)]);
      return undefined;
    }
    this.hold(r.proof.checkpoint, block, r.judged);
    this.step(sig, "record", true, { size: num(r.cp.size), logTime: r.judged.value.logTime ?? 0 });
    try {
      if (r.proof.index >= r.cp.size) fail("index-out-of-range", { index: num(r.proof.index), size: num(r.cp.size) });
      if (!verifyInclusion(r.proof.index, r.cp.size, r.leaf, r.proof.proof, r.cp.root)) fail("inclusion-failed", { what: block });
    } catch (e) {
      this.step(inc, "record", false, undefined, [bad(toReason(e, [block]), "invalid")]);
      return undefined;
    }
    this.step(inc, "record", true, { index: num(r.proof.index) });
    return r;
  }

  /** The entry checks (specs/receipt.md, section 1.1, step 2), with the
   * profile of the policy that judges the receipt. A log-signed receipt for
   * an entry that breaks the profile is evidence (bad-entry, rule
   * vitrine/parse); one for another entry than the user's is not. */
  private entry(r: Receipt, log: PolicyLog, st: RecordState, bad: (r: Reason, kind: "invalid" | "failed") => Reason): void {
    const objects = [r.block];
    const profileFailure = this.ackPolicy === r.judged.policy.id && r.judged.policy.supersedes === undefined ? "failed" : "invalid";
    let entry: Entry;
    try {
      entry = parseEntry(r.extra);
    } catch (e) {
      const x = toReason(e, objects);
      const rr = x.code === "bad-entry" ? x : reason("bad-entry", { detail: x.code }, objects);
      this.step("entry-parse", "entry", false, undefined, [bad(rr, profileFailure)]);
      return;
    }
    this.step("entry-parse", "entry", true, { tag: entry.tag });
    const profile = profileAt(r.judged.policy.logs.get(log.name) ?? log, r.proof.index);
    try {
      if (entry.tag !== profile.tag) fail("wrong-profile", { tag: entry.tag, want: profile.tag });
      checkLayout(entry);
    } catch (e) {
      this.step("entry-profile", "entry", false, undefined, [bad(toReason(e, objects), profileFailure)]);
      return;
    }
    this.step("entry-profile", "entry", true, { tag: profile.tag });
    try {
      checkExpectation(entry, this.opts.expect);
    } catch (e) {
      const x = toReason(e);
      this.step("entry-expectation", "entry", x.code === "expectation-incomplete" ? null : false, undefined, [bad(x, "invalid")]);
      return;
    }
    this.step("entry-expectation", "entry", true);
    st.leaf = r.leaf;
    st.index = r.proof.index;
  }

  private recordConsistency(a: Receipt, b: Receipt, cb: ConsistencyBlock | undefined, bad: (r: Reason, kind: "invalid" | "failed" | "pending") => Reason): void {
    const A = a.cp;
    const B = b.cp;
    const sizes = { from: num(A.size), to: num(B.size) };
    if (B.size < A.size) {
      this.step("record-consistency", "record", false, sizes, [bad(reason("consistency-mismatch", sizes, ["issued", "record"]), "invalid")]);
    } else if (B.size === A.size) {
      if (equalBytes(A.root, B.root)) {
        this.step("record-consistency", "record", true, sizes);
      } else {
        this.step("record-consistency", "record", false, sizes, [bad(reason("split-view", { size: num(A.size) }, ["issued", "record"]), "failed")]);
      }
    } else if (!cb) {
      this.step("record-consistency", "record", null, sizes, [bad(reason("consistency-missing", sizes), "pending")]);
    } else if (cb.from !== A.size || cb.to !== B.size) {
      this.step("record-consistency", "record", false, sizes, [bad(reason("consistency-mismatch", sizes, ["consistency"]), "invalid")]);
    } else {
      try {
        const proof = parseHashLines(cb.body, MAX_CONSISTENCY_HASHES);
        if (!verifyConsistency(A.size, B.size, proof, A.root, B.root)) fail("consistency-failed", sizes);
        this.step("record-consistency", "record", true, sizes);
      } catch (e) {
        this.step("record-consistency", "record", false, sizes, [bad(toReason(e, ["consistency"]), "invalid")]);
      }
    }
  }

  // -- Tier 1: witnesses -----------------------------------------------------

  private witnesses(rec: RecordState): WitnessState {
    if (rec.status === "invalid") return { status: "invalid", reasons: [reason("record-invalid")] };
    if (rec.receipts.length === 0) {
      // With only a promise, the tier follows the record tier.
      const r = reason("waiting-for-record");
      this.step("record-quorum", "witnesses", null, undefined, [r]);
      const st: WitnessState = { status: rec.status === "failed" ? "pending" : rec.status, reasons: [r] };
      if (rec.promise) st.deadline = rec.promise.due;
      return st;
    }
    const reasons: Reason[] = [];
    const future = new Set(rec.receipts.flatMap((r) => r.judged.value.future));
    if (future.size > 0) reasons.push(reason("cosignature-in-future", { witnesses: [...future].join(" ") }));
    const witnessed = [...rec.receipts].reverse().find((r) => r.judged.meets);
    if (witnessed) {
      const qt = witnessed.judged.quorumTime!;
      this.step("record-quorum", "witnesses", true, { quorumTime: qt, cosignatures: witnessed.judged.cosigs.length });
      return { status: "verified", reasons, quorumTime: qt };
    }
    const best = rec.best!;
    this.step("record-quorum", "witnesses", null, { cosignatures: best.judged.cosigs.length }, [
      reason("quorum-not-met", { cosignatures: best.judged.cosigs.length }),
    ]);
    reasons.push(reason("waiting-for-cosignatures"));
    const st: WitnessState = { status: "pending", reasons };
    // Due `cosign-max` after the log-time of the issued checkpoint (or of
    // the record, without an issued one).
    const base = rec.receipts[0]!;
    if (base.judged.value.logTime !== undefined) st.deadline = base.judged.value.logTime + base.judged.policy.cosignMax;
    return st;
  }

  /** Two held checkpoints of one size with different roots are split-view
   * evidence: the witnesses tier fails (specs/receipt.md, section 3.1). A
   * consistency proof that failed between two of different sizes makes it
   * `invalid`: without the prefix it proves nothing. */
  private splitViews(rec: RecordState, wit: WitnessState): void {
    if (rec.status === "invalid") return;
    let inconsistent = false;
    for (const [a, b] of this.opts.inconsistencies ?? []) {
      let ja: Judged<CheckedCheckpoint>;
      let jb: Judged<CheckedCheckpoint>;
      try {
        ja = judgeCheckpoint(this.h, a, this.keysOf, this.deviceNow);
        jb = judgeCheckpoint(this.h, b, this.keysOf, this.deviceNow);
      } catch {
        continue;
      }
      // Equal sizes are a split view, which the loop below finds.
      this.hold(a, "checkpoints", ja);
      this.hold(b, "checkpoints", jb);
      if (ja.value.cp.size === jb.value.cp.size) continue;
      const [lo, hi] = ja.value.cp.size < jb.value.cp.size ? [ja.value.cp, jb.value.cp] : [jb.value.cp, ja.value.cp];
      const sizes = { from: num(lo.size), to: num(hi.size) };
      const r = reason("consistency-failed", sizes, ["checkpoints"]);
      this.step("log-consistent", "witnesses", false, sizes, [r]);
      if (wit.status !== "failed") {
        wit.status = "invalid";
        delete wit.deadline;
      }
      wit.reasons.push(r);
      inconsistent = true;
    }
    for (let i = 0; i < this.held.length; i++) {
      for (let j = i + 1; j < this.held.length; j++) {
        const a = this.held[i]!;
        const b = this.held[j]!;
        if (a.cp.size !== b.cp.size || equalBytes(a.cp.root, b.cp.root)) continue;
        const r = reason("split-view", { size: num(a.cp.size) }, [a.source, b.source]);
        this.step("log-consistent", "witnesses", false, { size: num(a.cp.size) }, [r]);
        wit.status = "failed";
        delete wit.deadline;
        wit.reasons.push(r);
        return;
      }
    }
    if (this.held.length > 1 && !inconsistent) this.step("log-consistent", "witnesses", true, { checkpoints: this.held.length });
  }

  // -- Tier 2: hubs ----------------------------------------------------------

  private hubs(c: ReceiptChain, rec: RecordState, wit: WitnessState): Draft {
    const p = this.inForce;
    const app = appHubs(p);
    if (rec.status === "invalid") return { tier: "hubs", status: "invalid", reasons: [reason("record-invalid")], hubs: app.map((hub) => ({ hub, status: "invalid", reasons: [reason("record-invalid")] })) };
    if (app.length === 0) return { tier: "hubs", status: "unused", reasons: [], hubs: [] };
    // Due 2 x anchor period + cosign-max after the record's quorum time (its
    // log-time while unwitnessed), counted from the end of a quiet period
    // that time falls in.
    let base: number | undefined = wit.quorumTime ?? rec.best?.judged.value.logTime;
    if (base === undefined && rec.promise) base = rec.promise.due;
    if (base !== undefined) base = this.quietEnd(p, base) ?? base;
    const deadline = base === undefined ? undefined : base + 2 * p.anchorPeriod + p.cosignMax;
    const withDeadline = (s: HubState): HubState => {
      if (s.status === "pending" && deadline !== undefined && !s.neverLate) s.deadline = deadline;
      return s;
    };
    const d: Draft = { tier: "hubs", status: "pending", reasons: [] };
    if (deadline !== undefined) d.tierDeadline = deadline;
    if (rec.receipts.length === 0) {
      d.reasons.push(reason("waiting-for-record"));
      d.hubs = app.map((h) => withDeadline({ hub: h, status: "pending", reasons: [reason("waiting-for-record")] }));
    } else {
      d.hubs = app.map((h) => withDeadline(this.hub(h, c.hubs.get(h.name) ?? {}, rec.best!)));
      d.status = combine(d.hubs.map((s) => s.status));
    }
    return d;
  }

  /** The subjects the chain's log may be anchored as: its subject under
   * each policy of the history, so a rotated key counts once the successor
   * that lists it is applied. */
  private logSubjects(): Subject[] {
    const out: Subject[] = [];
    for (const e of this.h.epochs) {
      if (!e.policy.logs.has(this.log.name)) continue;
      const s = logSubject(e.policy, this.log.name);
      if (!out.some((x) => x.kind === s.kind && x.name === s.name && x.vkey.text === s.vkey.text)) out.push(s);
    }
    return out;
  }

  /** A hub link judged under the policy in force at its hub checkpoint's
   * quorum time. */
  private judgeLink(hubName: string, body: Uint8Array | string, subjects: readonly Subject[]): Judged<VerifiedHubLink> {
    return judgeWith(
      this.h,
      hubKeys(hubName),
      (_k, p) => verifyHubLink(body, p.hubs.get(hubName)!, subjects, this.deviceNow),
      (v) => ({ cosigs: v.hub.cosigs }),
    );
  }

  /** Follows the subject's rotations (specs/hub.md, section 5.2, step 6):
   * each only under the successor its statement names, when the verifier
   * applied it and its `log` line has the new key, through the links it
   * holds for the new subject. Returns the link the tier rests on, or why
   * the hub is pending. */
  private followRotations(
    h: PolicyHub,
    first: Judged<VerifiedHubLink>,
    subjects: readonly Subject[],
    code: "hub-link" | "browser-link" = "hub-link",
  ): Judged<VerifiedHubLink> | Reason {
    const P = { hub: h.name };
    const tier = code === "hub-link" ? "hubs" : "browser";
    let cur = first;
    const others: Judged<VerifiedHubLink>[] = [];
    for (const x of this.opts.hubLinks?.[h.name] ?? []) {
      try {
        others.push(this.judgeLink(h.name, x, subjects));
      } catch {
        // A link that doesn't verify can't be followed.
      }
    }
    for (let hops = 0; cur.value.kind === "rotate"; hops++) {
      const rot = cur.value.rotation!;
      const y = this.h.byId(rot.policy);
      const ylog = y?.logs.get(this.log.name);
      if (!y || !ylog || ylog.vkey.text !== rot.newKey) return reason("rotation-unauthorized", { ...P, policy: rot.policy });
      const next = others.find((o) => o.value.subject.name === cur.value.subject.name && o.value.subject.vkey.text === rot.newKey);
      if (!next || hops >= 16) return reason("subject-rotated", { ...P, policy: rot.policy });
      this.step(code, tier, true, { ...P, rotated: num(rot.size) });
      cur = next;
    }
    return cur;
  }

  /** One app hub (specs/receipt.md, sections 3.1, step 3, and 3.3;
   * specs/hub.md, section 5.2). */
  private hub(h: PolicyHub, blocks: HubBlocks, best: Receipt): HubState {
    const P = { hub: h.name };
    const st: HubState = { hub: h, status: "pending", reasons: [] };
    const done = (status: TierStatus, r: Reason, neverLate?: boolean): HubState => {
      st.status = status;
      st.reasons.push(r);
      if (neverLate) st.neverLate = true;
      return st;
    };
    if (!blocks.anchor) {
      const r = reason("waiting-for-anchor", P);
      this.step("hub-link", "hubs", null, P, [r]);
      return done("pending", r);
    }
    const subjects = this.logSubjects();
    let judged: Judged<VerifiedHubLink>;
    try {
      judged = this.judgeLink(h.name, blocks.anchor, subjects);
    } catch (e) {
      const r = toReason(e, [`anchor ${h.name}`]);
      this.step("hub-link", "hubs", false, P, [r]);
      return done("invalid", r);
    }
    const followed = this.followRotations(h, judged, subjects);
    if (!("value" in followed)) {
      this.step("hub-link", "hubs", null, P, [followed]);
      return done("pending", followed);
    }
    judged = followed;
    const link = judged.value;
    const linkParams = { ...P, size: num(link.hub.cp.size), entry: num(link.entryIndex) };
    if (!judged.meets) {
      const r = reason("hub-quorum-not-met", P);
      this.step("hub-link", "hubs", null, linkParams, [r]);
      return done("pending", r);
    }
    if (link.kind === "wrong") {
      // The subject's map value points at an entry that isn't its anchor:
      // the hub's witnesses co-signed a wrong index (hub-entry evidence).
      const r = reason("hub-index-wrong", { ...P, detail: link.wrong ?? "entry" }, [`anchor ${h.name}`]);
      this.step("hub-link", "hubs", false, linkParams, [r]);
      return done("failed", r);
    }
    st.link = judged;
    this.step("hub-link", "hubs", true, linkParams);
    const hubDef = judged.policy.hubs.get(h.name) ?? h;
    let note: Uint8Array;
    let source: string;
    const outcomes: Outcome[] = [];
    if (link.kind === "blinded") {
      const o = this.opening(h, hubDef, blocks, judged, best);
      if ("status" in o) {
        st.status = o.status;
        st.reasons.push(...o.reasons);
        if (o.neverLate) st.neverLate = true;
        return st;
      }
      note = o.note;
      source = `opening ${h.name}`;
      outcomes.push(...o.outcomes);
    } else {
      note = link.anchored!;
      source = `anchor ${h.name}`;
    }
    let anchored: Judged<CheckedCheckpoint>;
    try {
      anchored = judgeCheckpoint(this.h, note, this.keysOf, this.deviceNow);
    } catch (e) {
      // A hub-cosigned anchor of a checkpoint its subject didn't sign is
      // hub-entry evidence (specs/evidence.md, section 2.6). An opening only
      // commits to the checkpoint text, so a bad one is damaged data.
      const opened = link.kind === "blinded";
      const r = toReason(e, [source]);
      this.step("hub-anchored-checkpoint", "hubs", false, P, [r]);
      return done(opened ? "invalid" : "failed", r);
    }
    this.hold(note, source, anchored);
    const cpParams = { ...P, size: num(anchored.value.cp.size) };
    if (!anchored.meets) {
      // The hub's witnesses must refuse an anchor below the app quorum; it
      // doesn't count, and the hub is pending until a monitor's scan of the
      // hub log turns it into hub-entry evidence.
      const r = reason("anchor-quorum-not-met", P);
      this.step("hub-anchored-checkpoint", "hubs", null, cpParams, [r]);
      return done("pending", r);
    }
    this.step("hub-anchored-checkpoint", "hubs", true, cpParams);
    if (link.kind === "blinded") {
      const prev = this.previousOpening(h, hubDef, blocks, judged, anchored);
      outcomes.push(prev);
      if (prev.status === "failed" || prev.status === "invalid") {
        st.status = prev.status;
        st.reasons.push(...prev.reasons);
        return st;
      }
      outcomes.push(this.attestation(h, hubDef, blocks, link.blinded!.seq, anchored.value.cp));
    }
    outcomes.push(
      this.extendsFrom("hub-anchor-consistency", "hubs", P, best.cp, anchored.value.cp, blocks.anchorConsistency, [best.block, source], "anchor-behind-record"),
    );
    st.status = combine(outcomes.map((o) => o.status));
    st.reasons.push(...outcomes.flatMap((o) => o.reasons));
    if (st.status === "pending") {
      const pending = outcomes.filter((o) => o.status === "pending");
      if (pending.every((o) => o.neverLate)) st.neverLate = true;
    }
    return st;
  }

  /** Step 2 of section 3.3: the opening of the blinded anchor. */
  private opening(
    h: PolicyHub,
    hubDef: PolicyHub,
    blocks: HubBlocks,
    judged: Judged<VerifiedHubLink>,
    _best: Receipt,
  ): { note: Uint8Array; outcomes: Outcome[] } | Outcome {
    const P = { hub: h.name };
    if (!blocks.opening) {
      const r = reason("opening-missing", P);
      this.step("hub-opening", "hubs", null, P, [r]);
      return { status: "pending", reasons: [r] };
    }
    try {
      const note = checkOpening(parseOpening(blocks.opening), hubDef, judged.value.blinded!);
      this.step("hub-opening", "hubs", true, { ...P, seq: num(judged.value.blinded!.seq) });
      return { note, outcomes: [] };
    } catch (e) {
      const r = toReason(e, [`opening ${h.name}`]);
      this.step("hub-opening", "hubs", false, P, [r]);
      return { status: "invalid", reasons: [r] };
    }
  }

  /** Step 3 of section 3.3: unless `seq` is 1, the previous blinded anchor
   * in the same hub checkpoint, its opening, and the two openings'
   * consistency. Inconsistent openings are split-view evidence. */
  private previousOpening(h: PolicyHub, hubDef: PolicyHub, blocks: HubBlocks, judged: Judged<VerifiedHubLink>, opened: Judged<CheckedCheckpoint>): Outcome {
    const P = { hub: h.name };
    const seq = judged.value.blinded!.seq;
    if (seq === 1n) return { status: "verified", reasons: [] };
    if (!blocks.previousAnchor || !blocks.previousOpening) {
      const r = reason("previous-anchor-missing", { ...P, seq: num(seq - 1n) });
      this.step("hub-previous-anchor", "hubs", null, P, [r]);
      return { status: "pending", reasons: [r] };
    }
    let prevNote: Uint8Array;
    let prev: Judged<CheckedCheckpoint>;
    try {
      const pb = verifyPreviousAnchor(blocks.previousAnchor, judged.value, hubDef);
      prevNote = checkOpening(parseOpening(blocks.previousOpening), hubDef, pb);
      prev = judgeCheckpoint(this.h, prevNote, this.keysOf, this.deviceNow);
    } catch (e) {
      const r = toReason(e, [`previous-anchor ${h.name}`, `previous-opening ${h.name}`]);
      this.step("hub-previous-anchor", "hubs", false, P, [r]);
      return { status: "invalid", reasons: [r] };
    }
    this.hold(prevNote, `previous-opening ${h.name}`, prev);
    this.step("hub-previous-anchor", "hubs", true, { ...P, seq: num(seq - 1n), size: num(prev.value.cp.size) });
    const a = prev.value.cp;
    const b = opened.value.cp;
    const [small, large, objects] = a.size <= b.size ? [a, b, [`previous-opening ${h.name}`, `opening ${h.name}`]] : [b, a, [`opening ${h.name}`, `previous-opening ${h.name}`]];
    return this.extendsFrom("hub-opening-consistency", "hubs", P, small, large, blocks.openingConsistency, objects);
  }

  /** Step 4 of section 3.3: an auditor's attestation that covers the
   * opening. Missing or not yet covering, the hub is pending, never late. */
  private attestation(h: PolicyHub, hubDef: PolicyHub, blocks: HubBlocks, seq: bigint, opened: Checkpoint): Outcome {
    const P = { hub: h.name };
    if (!blocks.attestation) {
      const r = reason("attestation-missing", P);
      this.step("hub-attestation", "hubs", null, P, [r]);
      return { status: "pending", reasons: [r], neverLate: true };
    }
    try {
      const a = verifyAttestation(blocks.attestation, (id) => this.h.byId(id));
      const cov = attestationCovers(a, this.log.origin, hubDef.origin, seq, opened);
      if (cov === "not-covering") {
        const r = reason("attestation-not-covering", { ...P, from: num(a.from), to: num(a.to), seq: num(seq) });
        this.step("hub-attestation", "hubs", null, P, [r]);
        return { status: "pending", reasons: [r], neverLate: true };
      }
      if (cov !== "covers") fail("bad-attestation", { detail: cov.contradiction });
      this.step("hub-attestation", "hubs", true, { ...P, auditor: a.auditor, from: num(a.from), to: num(a.to) });
      return { status: "verified", reasons: [] };
    } catch (e) {
      const r = toReason(e, [`attestation ${h.name}`]);
      this.step("hub-attestation", "hubs", false, P, [r]);
      return { status: "invalid", reasons: [r] };
    }
  }

  /** Checks that `base` and `next` (both signed by one log) are consistent:
   * equal roots at equal sizes, else the consistency block's proof from the
   * smaller to the larger, which catches a fork at once. With `behind`, a
   * `next` smaller than `base` is also pending, with that reason. */
  private extendsFrom(
    code: StepCode,
    tier: Step["tier"],
    P: Params,
    base: Checkpoint,
    next: Checkpoint,
    cb: ConsistencyBlock | undefined,
    splitObjects: string[],
    behind?: "anchor-behind-record",
  ): Outcome {
    const out = (status: TierStatus, ok: boolean | null, sizes: Params, r?: Reason): Outcome => {
      this.step(code, tier, ok, sizes, r ? [r] : undefined);
      return { status, reasons: r ? [r] : [] };
    };
    const [from, to] = next.size < base.size ? [next, base] : [base, next];
    const sizes = { ...P, from: num(from.size), to: num(to.size) };
    if (from.size === to.size) {
      if (equalBytes(from.root, to.root)) return out("verified", true, sizes);
      return out("failed", false, sizes, reason("split-view", { size: num(from.size) }, splitObjects));
    }
    const pending = behind !== undefined && next.size < base.size ? reason(behind, sizes) : undefined;
    if (!cb) {
      const r = reason("consistency-missing", sizes);
      this.step(code, tier, null, sizes, [r]);
      return { status: "pending", reasons: pending ? [pending, r] : [r] };
    }
    if (cb.from !== from.size || cb.to !== to.size) return out("invalid", false, sizes, reason("consistency-mismatch", sizes));
    try {
      const proof = parseHashLines(cb.body, MAX_CONSISTENCY_HASHES);
      if (!verifyConsistency(from.size, to.size, proof, from.root, to.root)) fail("consistency-failed", sizes);
    } catch (e) {
      return out("invalid", false, sizes, toReason(e));
    }
    if (pending) return out("pending", true, sizes, pending);
    return out("verified", true, sizes);
  }

  /** When the hub or browser tier turns late, or an `anchor` block's anchor
   * is older than the record, the hub checkpoint of the `anchor` block's
   * link must be at most `2 x anchor period` older than the hub's latest
   * checkpoint, by quorum time; the hub's reasons say so when it is older
   * (specs/receipt.md, section 3.1). A pair's link is older by design, so
   * the check never applies to `browser-link`. */
  private staleness(hubs: Draft, tiers: readonly TierResult[]): void {
    const latest = this.opts.hubCheckpoints;
    if (!latest) return;
    const late = tiers.some((t) => (t.tier === "hubs" || t.tier === "browser") && (t.status === "late" || (t.hubs ?? []).some((d) => d.status === "late")));
    const details = tiers.find((t) => t.tier === "hubs")?.hubs ?? [];
    for (const s of hubs.hubs ?? []) {
      const note = latest[s.hub.name];
      const qt = s.link?.quorumTime;
      const detail = details.find((d) => d.hub === s.hub.name);
      if (note === undefined || qt === undefined || !detail) continue;
      if (!late && !s.reasons.some((r) => r.code === "anchor-behind-record")) continue;
      let j: Judged<CheckedCheckpoint>;
      try {
        j = judgeCheckpoint(this.h, note, hubKeys(s.hub.name), this.deviceNow);
      } catch {
        continue;
      }
      if (!j.meets || j.quorumTime === undefined) continue;
      const period = j.policy.anchorPeriod;
      if (j.quorumTime - qt > 2 * period) {
        detail.reasons.push(reason("hub-link-stale", { hub: s.hub.name, link: qt, latest: j.quorumTime, limit: 2 * period }));
      }
    }
  }

  // -- Tier 3: browser -------------------------------------------------------

  /** Tier 3 (specs/receipt.md, section 3.1, step 4): for every app hub, the
   * log's pair for it (specs/hub.md, section 6.5). Pending until `browser
   * period + 600` seconds after the hub tier's deadline, then late, except
   * for a hub that waits only for an attestation. */
  private browser(c: ReceiptChain, rec: RecordState, hubs: Draft): Draft {
    const p = this.inForce;
    const app = appHubs(p);
    if (rec.status === "invalid") return { tier: "browser", status: "invalid", reasons: [reason("record-invalid")], hubs: app.map((hub) => ({ hub, status: "invalid", reasons: [reason("record-invalid")] })) };
    const uses = new Map(app.map((h) => [h.name, browserUse(p, h)]));
    const testOnly = ![...uses.values()].includes("counted");
    if (app.length === 0 || (testOnly && ![...uses.values()].includes("test"))) {
      return { tier: "browser", status: "unused", reasons: [], hubs: [] };
    }
    const deadline = hubs.tierDeadline === undefined ? undefined : hubs.tierDeadline + p.browserPeriod + BROWSER_GRACE_SECONDS;
    const states = new Map((hubs.hubs ?? []).map((s) => [s.hub.name, s]));
    const details: HubState[] = [];
    for (const h of app) {
      const use = uses.get(h.name)!;
      if (use === "none") {
        details.push({ hub: h, status: "unused", reasons: [] });
        continue;
      }
      let s: HubState;
      if (rec.receipts.length === 0) s = { hub: h, status: "pending", reasons: [reason("waiting-for-record")] };
      else s = this.browserHub(h, c.hubs.get(h.name) ?? {}, states.get(h.name), rec.best!);
      if (s.status === "pending" && !s.neverLate && deadline !== undefined) s.deadline = deadline;
      // A hub served only by the operator's own services is a test (specs/hub.md, section 6.3).
      if (use === "test") s = { hub: h, status: "unused", test: true, reasons: [reason("browser-test-only"), ...s.reasons] };
      details.push(s);
    }
    if (testOnly) return { tier: "browser", status: "unused", reasons: [reason("browser-test-only")], hubs: details };
    const d: Draft = { tier: "browser", status: combine(details.map((s) => s.status)), reasons: [], hubs: details };
    if (rec.receipts.length === 0) d.reasons.push(reason("waiting-for-record"));
    return d;
  }

  /** One app hub in tier 3. For a public log, the pair's link is its
   * `browser-link` block. In a private event it is the `anchor` block
   * (section 3.3), and the hub is verified here only when it is verified in
   * the hub tier. Either way, the pair's `browser` or `bootstrap` block
   * must show a hub checkpoint `B` that extends the link's. */
  private browserHub(h: PolicyHub, blocks: HubBlocks, hs: HubState | undefined, best: Receipt): HubState {
    const P = { hub: h.name };
    const outcomes: Outcome[] = [];
    let base: Checkpoint | undefined;
    let linkObject: string;
    if (this.inForce.visibility === "private") {
      linkObject = `anchor ${h.name}`;
      const link = hs?.link;
      if (link) {
        base = link.value.hub.cp;
      } else {
        const r = reason("waiting-for-anchor", P);
        this.step("browser-link", "browser", null, P, [r]);
        outcomes.push({ status: "pending", reasons: [r] });
      }
      if (link && hs?.status !== "verified") {
        const r = reason("waiting-for-hub-tier", P);
        this.step("browser-link", "browser", null, P, [r]);
        outcomes.push({ status: "pending", reasons: [r], ...(hs?.neverLate ? { neverLate: true } : {}) });
      } else if (link) {
        this.step("browser-link", "browser", true, { ...P, size: num(link.value.hub.cp.size) });
      }
    } else {
      linkObject = `browser-link ${h.name}`;
      const o = this.browserLink(h, blocks, best);
      if ("status" in o) {
        outcomes.push(o);
      } else {
        base = o.hub;
        outcomes.push(...o.outcomes);
      }
    }
    if (base !== undefined) outcomes.push(this.pairCovered(h, blocks, base, linkObject));
    const st: HubState = { hub: h, status: combine(outcomes.map((o) => o.status)), reasons: outcomes.flatMap((o) => o.reasons) };
    if (st.status === "unused") st.status = "pending";
    if (st.status === "pending" && outcomes.filter((o) => o.status === "pending").every((o) => o.neverLate)) st.neverLate = true;
    return st;
  }

  /** The pair's `browser-link` block: checked as the `anchor` block is in
   * the hub tier, except that its anchored checkpoint only has to be
   * consistent with the record (`browser-link-consistency`, from the
   * smaller to the larger), and the pair covers the entry when that
   * checkpoint contains it. Returns the link's hub checkpoint, or why the
   * hub can't go further. */
  private browserLink(h: PolicyHub, blocks: HubBlocks, best: Receipt): Outcome | { hub: Checkpoint; outcomes: Outcome[] } {
    const P = { hub: h.name };
    const object = `browser-link ${h.name}`;
    const stop = (status: TierStatus, ok: boolean | null, r: Reason, params: Params = P): Outcome => {
      this.step("browser-link", "browser", ok, params, [r]);
      return { status, reasons: [r] };
    };
    if (!blocks.browserLink) return stop("pending", null, reason("waiting-for-browser-anchor", P));
    const subjects = this.logSubjects();
    let judged: Judged<VerifiedHubLink>;
    try {
      judged = this.judgeLink(h.name, blocks.browserLink, subjects);
    } catch (e) {
      return stop("invalid", false, toReason(e, [object]));
    }
    const followed = this.followRotations(h, judged, subjects, "browser-link");
    if (!("value" in followed)) return stop("pending", null, followed);
    judged = followed;
    const link = judged.value;
    const linkParams = { ...P, size: num(link.hub.cp.size), entry: num(link.entryIndex) };
    if (!judged.meets) return stop("pending", null, reason("hub-quorum-not-met", P), linkParams);
    if (link.kind === "wrong") return stop("failed", false, reason("hub-index-wrong", { ...P, detail: link.wrong ?? "entry" }, [object]), linkParams);
    if (link.kind !== "anchor") return stop("invalid", false, reason("hub-link-mismatch", { ...P, detail: link.kind }, [object]), linkParams);
    let anchored: Judged<CheckedCheckpoint>;
    try {
      anchored = judgeCheckpoint(this.h, link.anchored!, this.keysOf, this.deviceNow);
    } catch (e) {
      // A hub-cosigned anchor of a checkpoint its subject didn't sign is
      // hub-entry evidence, as in the hub tier.
      return stop("failed", false, toReason(e, [object]), linkParams);
    }
    this.hold(link.anchored!, object, anchored);
    const cp = anchored.value.cp;
    const params = { ...linkParams, anchored: num(cp.size) };
    if (!anchored.meets) return stop("pending", null, reason("anchor-quorum-not-met", P), params);
    const outcomes: Outcome[] = [];
    if (cp.size > best.proof.index) {
      this.step("browser-link", "browser", true, params);
    } else {
      // The link is from before the entry: the next pair covers it.
      const r = reason("pair-not-covering", { ...P, size: num(cp.size), index: num(best.proof.index) });
      this.step("browser-link", "browser", null, params, [r]);
      outcomes.push({ status: "pending", reasons: [r] });
    }
    outcomes.push(this.extendsFrom("browser-link-consistency", "browser", P, best.cp, cp, blocks.browserLinkConsistency, [best.block, object]));
    return { hub: link.hub.cp, outcomes };
  }

  /** The pair's `browser` or `bootstrap` block, with `browser-consistency`
   * from `base`, the hub checkpoint of the pair's link. A pair holds one of
   * the two; a chain that holds both counts either. */
  private pairCovered(h: PolicyHub, blocks: HubBlocks, base: Checkpoint, linkObject: string): Outcome {
    const P = { hub: h.name };
    if (!blocks.browser && !blocks.bootstrap) {
      const r = reason("waiting-for-browser-anchor", P);
      this.step("browser-anchor", "browser", null, P, [r]);
      return { status: "pending", reasons: [r] };
    }
    const outs: Outcome[] = [];
    if (blocks.browser) outs.push(this.browserBlock(h, blocks.browser, base, blocks.browserConsistency, linkObject));
    if (blocks.bootstrap) outs.push(this.bootstrapBlock(h, blocks.bootstrap, base, blocks.browserConsistency, linkObject));
    const counted = outs.filter((o) => o.status !== "unused").map((o) => o.status);
    const reasons = outs.flatMap((o) => o.reasons);
    if (counted.includes("failed")) return { status: "failed", reasons };
    if (counted.includes("verified")) return { status: "verified", reasons };
    if (counted.includes("invalid")) return { status: "invalid", reasons };
    // Only a browser anchor from the operator's own service: it doesn't count.
    if (counted.length === 0) reasons.push(reason("waiting-for-browser-anchor", P));
    return { status: "pending", reasons };
  }

  /** `B` is at least as large as the hub checkpoint of the pair's link, and
   * `browser-consistency` verifies from that checkpoint to `B`; at equal
   * sizes the roots must be equal, else the hub signed a split view, and
   * the pair has no `browser-consistency` block (specs/hub.md, section
   * 6.5), so one is malformed. */
  private pairConsistency(h: PolicyHub, base: Checkpoint, b: Checkpoint, cb: ConsistencyBlock | undefined, objects: string[]): Outcome {
    const P = { hub: h.name };
    const sizes = { ...P, from: num(base.size), to: num(b.size) };
    if (b.size < base.size) {
      const r = reason("browser-below-link", sizes, objects);
      this.step("browser-consistency", "browser", false, sizes, [r]);
      return { status: "invalid", reasons: [r] };
    }
    if (b.size === base.size && cb) {
      const r = reason("bad-browser-pair", { detail: "consistency-at-equal-sizes" });
      this.step("browser-consistency", "browser", false, sizes, [r]);
      return { status: "invalid", reasons: [r] };
    }
    return this.extendsFrom("browser-consistency", "browser", P, base, b, cb, objects);
  }

  /** A `browser` block: a browser anchor (specs/hub.md, section 6.3). It
   * counts only from an independent service, and only when its `B` meets
   * the hub's quorum: a `B` short of it is validly signed, so the hub is
   * `pending` (impl-20), and a later browser anchor takes its place. */
  private browserBlock(h: PolicyHub, body: Uint8Array, base: Checkpoint, cb: ConsistencyBlock | undefined, linkObject: string): Outcome {
    const P = { hub: h.name };
    const object = `browser ${h.name}`;
    let v: VerifiedBrowserAnchor;
    try {
      v = verifyBrowserAnchor(body, this.inForce, h, this.deviceNow);
    } catch (e) {
      const r = toReason(e, [object]);
      this.step("browser-anchor", "browser", false, P, [r]);
      return { status: "invalid", reasons: [r] };
    }
    const params = { ...P, service: v.service.domain, size: num(v.hub.cp.size) };
    const reasons: Reason[] = [];
    if (!v.independent) reasons.push(reason("waict-service-not-independent", { service: v.service.domain }));
    const below = v.belowQuorum.length > 0;
    if (below) reasons.push(reason("hub-quorum-not-met", { ...P, detail: "b" }));
    this.step("browser-anchor", "browser", below ? null : true, params, reasons);
    const o = this.pairConsistency(h, base, v.hub.cp, cb, [linkObject, object]);
    reasons.push(...o.reasons);
    // A split view or a bad proof stands whoever runs the service, and
    // whatever B's cosignatures.
    if (o.status === "failed" || o.status === "invalid") return { status: o.status, reasons };
    if (!v.independent) return { status: "unused", reasons };
    return { status: below ? "pending" : o.status, reasons };
  }

  /** The app hub's subjects in a bootstrap hub, under every policy. */
  private hubSubjects(name: string): Subject[] {
    const out: Subject[] = [];
    for (const e of this.h.epochs) {
      const hd = e.policy.hubs.get(name);
      if (!hd) continue;
      const s = hubSubject(hd);
      if (!out.some((x) => x.name === s.name && x.vkey.text === s.vkey.text)) out.push(s);
    }
    return out;
  }

  /** A `bootstrap` block: a bootstrap hub's link for the app hub's subject,
   * checked as in specs/hub.md, section 5.2, with the app hub's quorum in
   * place of the app quorum (section 6.4). The app hub checkpoint it
   * anchors is `B`. A `B` short of the app hub's quorum doesn't count, and
   * the hub is `pending` (impl-20) until `hub-entry` evidence (below
   * quorum) against the bootstrap hub's witnesses makes it `failed`, as an
   * anchor short of the app quorum is in the hub tier. */
  private bootstrapBlock(h: PolicyHub, body: Uint8Array, base: Checkpoint, cb: ConsistencyBlock | undefined, linkObject: string): Outcome {
    const P = { hub: h.name };
    const object = `bootstrap ${h.name}`;
    let b: PolicyHub;
    let judged: Judged<VerifiedHubLink>;
    try {
      b = bootstrapHubOf(this.inForce, body);
      judged = this.judgeLink(b.name, body, this.hubSubjects(h.name));
    } catch (e) {
      const r = toReason(e, [object]);
      this.step("bootstrap-link", "browser", false, P, [r]);
      return { status: "invalid", reasons: [r] };
    }
    const link = judged.value;
    const params = { ...P, bootstrap: b.name, size: num(link.hub.cp.size) };
    const stop = (status: TierStatus, ok: boolean | null, r: Reason): Outcome => {
      this.step("bootstrap-link", "browser", ok, params, [r]);
      return { status, reasons: [r] };
    };
    if (!judged.meets) return stop("pending", null, reason("hub-quorum-not-met", { hub: b.name }));
    // Rotating an app hub's key in a bootstrap hub is out of scope in v0.1.
    if (link.kind === "rotate") return stop("pending", null, reason("subject-rotated", { hub: b.name }));
    if (link.kind !== "anchor") return stop("failed", false, reason("hub-index-wrong", { hub: b.name, detail: link.wrong ?? "entry" }, [object]));
    let anchored: Judged<CheckedCheckpoint>;
    try {
      anchored = judgeCheckpoint(this.h, link.anchored!, hubKeys(h.name), this.deviceNow);
    } catch (e) {
      // The bootstrap hub's quorum vouched for an anchor its subject didn't
      // sign: hub-entry evidence.
      return stop("failed", false, toReason(e, [object]));
    }
    const anchoredParams = { ...params, anchored: num(anchored.value.cp.size) };
    if (anchored.meets) {
      this.step("bootstrap-link", "browser", true, anchoredParams);
      return this.pairConsistency(h, base, anchored.value.cp, cb, [linkObject, object]);
    }
    const r = reason("hub-quorum-not-met", { ...P, detail: "b" });
    this.step("bootstrap-link", "browser", null, anchoredParams, [r]);
    const o = this.pairConsistency(h, base, anchored.value.cp, cb, [linkObject, object]);
    // A split view or a bad proof stands whatever B's cosignatures.
    return { status: o.status === "failed" || o.status === "invalid" ? o.status : "pending", reasons: [r, ...o.reasons] };
  }
}
