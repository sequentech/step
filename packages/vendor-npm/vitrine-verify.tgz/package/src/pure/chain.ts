// SPDX-License-Identifier: Apache-2.0
//
// Receipt chains (specs/receipt.md, section 3): parsing and formatting, and
// the tier verification of section 3.1, which produces the ChainResult of
// src/types.ts.
//
// Statuses. `invalid`: a block didn't parse, verify or match, or the
// expectations can't confirm the entry (damaged or unverifiable input, not
// evidence). `failed`: validly signed objects contradict each other or the
// policy, which is evidence: two log-signed checkpoints of one size with
// different roots, a log-signed receipt for an entry that breaks the log's
// profile, a hub-cosigned anchor of a checkpoint its subject didn't sign.
// Whatever is missing or not yet due is `pending`, and `late` once its
// deadline passed by signed time. Unsigned proofs that don't verify
// (inclusion, consistency) make a tier `invalid`, never `failed`.

import type { ReasonCode, StepCode } from "../codes.js";
import type {
  ChainResult,
  EntryInfo,
  Expect,
  Facts,
  FactState,
  HubTierDetail,
  OverallStatus,
  PolicySummary,
  Reason,
  Step,
  TierName,
  TierResult,
  TierStatus,
  Where,
} from "../types.js";
import { hexEncode } from "./base64.js";
import { equalBytes, parseDecimal, utf8 } from "./bytes.js";
import { formatBlockDoc, formatHashLines, parseBlockDoc, parseHashLines, type Block } from "./blocks.js";
import { verifyBrowserAnchor, type VerifiedBrowserAnchor } from "./browser.js";
import { verifyCheckpoint, type CheckedCheckpoint, type Checkpoint } from "./checkpoint.js";
import { checkExpectation, checkLayout, expectedEntry, parseEntry, type Entry } from "./entry.js";
import { fail, reason, toReason, VerifyError, type Params } from "./errors.js";
import { leafHash } from "./hash.js";
import { bootstrapHubOf, checkOpening, hubSubject, logSubject, parseOpening, verifyHubLink, type VerifiedHubLink } from "./hub.js";
import { identicon } from "./identicon.js";
import { MAX_CONSISTENCY_HASHES, verifyConsistency, verifyInclusion } from "./merkle.js";
import { appHubs, policyWords, profileAt, quietPeriod, type Policy, type PolicyHub, type PolicyLog } from "./policy.js";
import { checkPromiseBatch, checkPromiseInclusion, parsePromise, promiseDeadline, PROMISE_SKEW, type PromiseBatch } from "./promise.js";
import { parseTlogProof, type TlogProof } from "./tlogproof.js";
import { bcp47, wordsFromBits } from "./words.js";

export const CHAIN_HEADER = "vitrine/receipt-chain/v1";
export const CHAIN_FILE_EXTENSION = ".vitrine-receipt";
export const CHAIN_MEDIA_TYPE = "application/vnd.vitrine.receipt-chain";
/** Verifiers warn when the device clock is further than this from signed time. */
export const CLOCK_WARNING_SECONDS = 60;
/** A hub checkpoint is due in the browser layer `browser period + 600`
 * seconds after the hub anchor. */
export const BROWSER_GRACE_SECONDS = 600;
const DEFAULT_BROWSER_PERIOD = 600;

const ARITY: Readonly<Record<string, number>> = {
  promise: 0,
  issued: 0,
  record: 0,
  consistency: 2,
  anchor: 1,
  opening: 1,
  "anchor-consistency": 3,
  browser: 1,
  bootstrap: 1,
  "bootstrap-consistency": 3,
};
const PER_HUB = new Set(["anchor", "opening", "anchor-consistency", "browser", "bootstrap", "bootstrap-consistency"]);

/** A consistency block: its sizes and its body (base64 hashes). */
export interface ConsistencyBlock {
  from: bigint;
  to: bigint;
  body: Uint8Array;
}

/** The blocks of one app hub. */
export interface HubBlocks {
  anchor?: Uint8Array;
  opening?: Uint8Array;
  anchorConsistency?: ConsistencyBlock;
  browser?: Uint8Array;
  bootstrap?: Uint8Array;
  bootstrapConsistency?: ConsistencyBlock;
}

export interface ReceiptChain {
  policyId: string;
  log: string;
  promise?: Uint8Array;
  issued?: Uint8Array;
  record?: Uint8Array;
  consistency?: ConsistencyBlock;
  /** By hub name, in the order of first appearance. */
  hubs: Map<string, HubBlocks>;
  /** Blocks of types this verifier doesn't know, kept as they were. */
  unknown: Block[];
}

function consistencyOf(b: Block, at: number): ConsistencyBlock {
  try {
    return { from: parseDecimal(b.args[at]!), to: parseDecimal(b.args[at + 1]!), body: b.body };
  } catch {
    return fail("malformed-chain", { detail: `sizes-${b.type}` });
  }
}

/** Parses a receipt chain's framing. Block contents are checked by
 * verifyChain, so a damaged block only affects its own tier. */
export function parseChain(input: Uint8Array | string): ReceiptChain {
  const doc = parseBlockDoc(input, { header: CHAIN_HEADER, keys: ["policy", "log"], code: "malformed-chain" });
  const [policy, log] = doc.values as [string[], string[]];
  if (policy.length !== 1 || log.length !== 1) fail("malformed-chain", { detail: "lines" });
  const c: ReceiptChain = { policyId: policy[0]!, log: log[0]!, hubs: new Map(), unknown: [] };
  const seen = new Set<string>();
  for (const b of doc.blocks) {
    if (!Object.hasOwn(ARITY, b.type)) {
      c.unknown.push(b);
      continue;
    }
    if (b.args.length !== ARITY[b.type]) fail("malformed-chain", { detail: `arguments-${b.type}` });
    const hub = PER_HUB.has(b.type) ? b.args[0]! : undefined;
    const key = hub === undefined ? b.type : `${b.type} ${hub}`;
    if (seen.has(key)) fail("duplicate-block", hub === undefined ? { type: b.type } : { type: b.type, hub: hub.slice(0, 64) });
    seen.add(key);
    const hb = (): HubBlocks => {
      let h = c.hubs.get(hub!);
      if (!h) {
        h = {};
        c.hubs.set(hub!, h);
      }
      return h;
    };
    switch (b.type) {
      case "promise":
        c.promise = b.body;
        break;
      case "issued":
        c.issued = b.body;
        break;
      case "record":
        c.record = b.body;
        break;
      case "consistency":
        c.consistency = consistencyOf(b, 0);
        break;
      case "anchor":
        hb().anchor = b.body;
        break;
      case "opening":
        hb().opening = b.body;
        break;
      case "anchor-consistency":
        hb().anchorConsistency = consistencyOf(b, 1);
        break;
      case "browser":
        hb().browser = b.body;
        break;
      case "bootstrap":
        hb().bootstrap = b.body;
        break;
      case "bootstrap-consistency":
        hb().bootstrapConsistency = consistencyOf(b, 1);
        break;
    }
  }
  if (!c.promise && !c.issued && !c.record) fail("no-receipt");
  return c;
}

/** Serialises a receipt chain, blocks in the order of the spec's table. */
export function formatChain(c: ReceiptChain): Uint8Array {
  const blocks: Block[] = [];
  const add = (type: string, args: string[], body: Uint8Array | undefined): void => {
    if (body) blocks.push({ type, args, body });
  };
  const cons = (type: string, args: string[], cb: ConsistencyBlock | undefined): void => {
    if (cb) blocks.push({ type, args: [...args, String(cb.from), String(cb.to)], body: cb.body });
  };
  add("promise", [], c.promise);
  add("issued", [], c.issued);
  add("record", [], c.record);
  cons("consistency", [], c.consistency);
  const hubs = [...c.hubs];
  for (const [n, h] of hubs) add("anchor", [n], h.anchor);
  for (const [n, h] of hubs) add("opening", [n], h.opening);
  for (const [n, h] of hubs) cons("anchor-consistency", [n], h.anchorConsistency);
  for (const [n, h] of hubs) add("browser", [n], h.browser);
  for (const [n, h] of hubs) add("bootstrap", [n], h.bootstrap);
  for (const [n, h] of hubs) cons("bootstrap-consistency", [n], h.bootstrapConsistency);
  blocks.push(...c.unknown);
  return formatBlockDoc(CHAIN_HEADER, [`policy ${c.policyId}`, `log ${c.log}`], blocks);
}

/** A consistency block from a proof's hashes. */
export function consistencyBlock(from: bigint, to: bigint, proof: readonly Uint8Array[]): ConsistencyBlock {
  return { from, to, body: formatHashLines(proof) };
}

export interface VerifyChainOptions {
  /** What the entry must be (specs/receipt.md, section 1.1). Mandatory. */
  expect: Expect;
  /** The device clock, POSIX seconds. Default: the current time. */
  now?: number;
  /** Where the check runs. Default "page". */
  where?: Where;
  /** Other checkpoints of the chain's log that the verifier holds, such as
   * the latest one it fetched; their cosignatures count towards signed time. */
  checkpoints?: readonly (string | Uint8Array)[];
}

/** The policy summary shown next to a result. */
export function policySummary(p: Policy): PolicySummary {
  return {
    id: p.id,
    words: policyWords(p),
    lang: bcp47(p.words),
    event: p.name,
    witnesses: [...p.witnesses.witnesses.values()].map((w) => (w.partyGiven ? { name: w.name, party: w.party } : { name: w.name })),
    hubs: appHubs(p).map((h) => h.name),
  };
}

/** Verifies a receipt chain against a pinned policy (specs/receipt.md,
 * section 3.1). Never throws on bad input: problems become reasons. */
export function verifyChain(input: Uint8Array | string, policy: Policy, opts: VerifyChainOptions): ChainResult {
  if (!opts || !opts.expect) throw new TypeError("verifyChain needs expectations (opts.expect)");
  return new ChainVerifier(policy, opts).run(input);
}

/** Verifies a single receipt (specs/receipt.md, section 1.1) as a chain with
 * one `record` block. */
export function verifyReceipt(
  receipt: Uint8Array | string,
  policy: Policy,
  log: string,
  expect: Expect,
  opts: Omit<VerifyChainOptions, "expect"> = {},
): ChainResult {
  if (!expect) throw new TypeError("verifyReceipt needs expectations");
  const record = typeof receipt === "string" ? utf8(receipt) : receipt;
  const chain = formatChain({ policyId: policy.id, log, record, hubs: new Map(), unknown: [] });
  return verifyChain(chain, policy, { ...opts, expect });
}

// ---------------------------------------------------------------------------

const num = (b: bigint): number | string => (b <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(b) : b.toString());

interface Receipt {
  block: "issued" | "record";
  proof: TlogProof;
  extra: Uint8Array;
  cp: CheckedCheckpoint;
  leaf: Uint8Array;
}

interface ValidPromise {
  batch: PromiseBatch;
  leaf: Uint8Array;
  /** `time + mmd + 30`. */
  deadline: number;
  /** The deadline, moved to `closes + mmd + 30` when it falls in a quiet period. */
  due: number;
}

interface RecordState {
  status: TierStatus;
  reasons: Reason[];
  invalid: boolean;
  failed: boolean;
  pending: boolean;
  receipts: Receipt[];
  /** The record receipt, or the issued one when there's no record. */
  best?: Receipt;
  splitView: boolean;
  promise?: ValidPromise;
  /** The user's leaf hash and index, once the expectations confirm them. */
  leaf?: Uint8Array;
  index?: bigint;
}

interface WitnessState {
  status: TierStatus;
  reasons: Reason[];
  deadline?: number;
  quorumTime?: number;
}

interface HubState {
  hub: PolicyHub;
  status: TierStatus;
  reasons: Reason[];
  deadline?: number;
  /** The hub link, once it verified with the hub's quorum. */
  link?: VerifiedHubLink;
  test?: boolean;
}

interface Draft {
  tier: TierName;
  status: TierStatus;
  reasons: Reason[];
  deadline?: number;
  hubs?: HubState[];
  lateCode?: ReasonCode;
}

interface Outcome {
  status: TierStatus;
  reasons: Reason[];
}

const RANK: Record<TierStatus, number> = { unused: -1, verified: 0, pending: 1, late: 2, invalid: 3, failed: 4 };

/** The worst status, ignoring `unused`; `unused` when nothing else is there. */
function combine(statuses: readonly TierStatus[]): TierStatus {
  let out: TierStatus = "unused";
  for (const s of statuses) if (RANK[s] > RANK[out]) out = s;
  return out;
}

function isLate(status: TierStatus, deadline: number | undefined, now: number): deadline is number {
  return status === "pending" && deadline !== undefined && now > 0 && now > deadline;
}

/** How the policy uses the browser tier for a hub. */
function browserUse(p: Policy, h: PolicyHub): "counted" | "test" | "none" {
  const services = [...p.waict.values()].filter((s) => s.hubs.includes(h.name));
  const bootstrap = [...p.hubs.values()].some((x) => x.bootstrap);
  if (bootstrap || services.some((s) => s.operator !== p.operator)) return "counted";
  return services.length > 0 ? "test" : "none";
}

function factOf(statuses: readonly TierStatus[], doneWhen: (s: TierStatus, i: number) => boolean): FactState {
  if (statuses.includes("failed")) return "failed";
  if (statuses.includes("invalid")) return "invalid";
  if (statuses.every(doneWhen)) return "done";
  if (statuses.includes("late")) return "late";
  return "pending";
}

class ChainVerifier {
  private readonly steps: Step[] = [];
  private readonly reasons: Reason[] = [];
  /** Verified checkpoints of the chain's log, for signed time. */
  private readonly held: CheckedCheckpoint[] = [];
  private readonly deviceNow: number;
  private readonly where: Where;

  constructor(
    private readonly policy: Policy,
    private readonly opts: VerifyChainOptions,
  ) {
    this.deviceNow = opts.now ?? Math.floor(Date.now() / 1000);
    this.where = opts.where ?? "page";
  }

  private step(code: StepCode, tier: Step["tier"], ok: boolean | null, params?: Params, reasons?: Reason[]): void {
    const s: Step = { code, tier, ok };
    if (params) s.params = params;
    if (reasons && reasons.length > 0) s.reasons = reasons;
    this.steps.push(s);
  }

  run(input: Uint8Array | string): ChainResult {
    let chain: ReceiptChain;
    try {
      chain = parseChain(input);
    } catch (e) {
      return this.rejected("chain-format", toReason(e));
    }
    this.step("chain-format", "policy", true);
    if (chain.policyId !== this.policy.id) {
      return this.rejected("policy-pinned", reason("policy-mismatch", { chain: chain.policyId.slice(0, 80), pinned: this.policy.id }));
    }
    this.step("policy-pinned", "policy", true, { policy: this.policy.id });
    const log = this.policy.logs.get(chain.log);
    if (!log) return this.rejected("log-known", reason("unknown-log", { log: chain.log.slice(0, 64) }));
    this.step("log-known", "policy", true, { log: log.name });
    const app = appHubs(this.policy);
    for (const name of chain.hubs.keys()) {
      if (!app.some((h) => h.name === name)) this.reasons.push(reason("unknown-hub", { hub: name.slice(0, 64) }));
    }

    const rec = this.record(chain, log);
    const wit = this.witnesses(rec);
    const hubs = this.hubs(chain, log, rec, wit);
    const browser = this.browser(chain, rec, hubs);
    for (const x of this.opts.checkpoints ?? []) {
      try {
        this.held.push(verifyCheckpoint(x, log.vkey, this.policy.witnesses, this.deviceNow));
      } catch {
        // Not a checkpoint of this log: it says nothing about time.
      }
    }
    const now = this.signedNow();
    const onlyPromise = rec.status === "pending" && rec.receipts.length === 0 && rec.promise !== undefined;
    const drafts: Draft[] = [
      {
        tier: "record",
        status: rec.status,
        reasons: rec.reasons,
        ...(onlyPromise ? { deadline: rec.promise!.due, lateCode: "promise-deadline-passed" as const } : {}),
      },
      { tier: "witnesses", status: wit.status, reasons: wit.reasons, ...(wit.deadline !== undefined ? { deadline: wit.deadline } : {}) },
      hubs,
      browser,
    ];
    const tiers = drafts.map((d) => this.finish(d, now));
    if (now === 0 && tiers.some((t) => t.status === "pending" && t.deadline !== undefined)) this.reasons.push(reason("no-signed-time"));
    const result = this.result(tiers, now, rec.receipts.length === 0 && rec.promise !== undefined);
    if (rec.leaf) {
      const entry: EntryInfo = { log: log.name, leafHash: hexEncode(rec.leaf), promised: rec.receipts.length === 0 };
      if (rec.index !== undefined) entry.index = Number(rec.index);
      result.entry = entry;
      result.words = wordsFromBits(rec.leaf, 4, this.policy.words);
      result.identicon = identicon(rec.leaf);
    }
    return result;
  }

  private result(tiers: TierResult[], now: number, promised: boolean): ChainResult {
    const [r, w, h, b] = tiers.map((t) => t.status) as [TierStatus, TierStatus, TierStatus, TierStatus];
    const facts: Facts = {
      included: r === "pending" && promised ? "promised" : factOf([r], (s) => s === "verified"),
      unchanged: factOf([r, w], (s) => s === "verified"),
      sameForEveryone: factOf([w, h, b], (s, i) => s === "verified" || (i > 0 && s === "unused")),
    };
    const statuses = tiers.map((t) => t.status);
    let status: OverallStatus = "verified";
    for (const s of ["pending", "late", "invalid", "failed"] as const) if (statuses.includes(s)) status = s;
    return {
      ok: !statuses.includes("failed") && !statuses.includes("invalid"),
      status,
      tiers,
      facts,
      reasons: this.reasons,
      steps: this.steps,
      where: this.where,
      words: [],
      wordsLang: bcp47(this.policy.words),
      now,
      clockWarning: now > 0 && Math.abs(this.deviceNow - now) > CLOCK_WARNING_SECONDS,
      policy: policySummary(this.policy),
    };
  }

  /** A result for a chain that can't be checked at all. */
  private rejected(code: StepCode, r: Reason): ChainResult {
    this.step(code, "policy", false, undefined, [r]);
    this.reasons.push(r);
    const app = appHubs(this.policy);
    const detail = (h: PolicyHub, status: TierStatus): HubTierDetail => ({ hub: h.name, status, reasons: [] });
    const browserDetails = app.map((h) => {
      const use = browserUse(this.policy, h);
      return use === "counted" ? detail(h, "invalid") : { ...detail(h, "unused"), ...(use === "test" ? { test: true } : {}) };
    });
    const tiers: TierResult[] = [
      { tier: "record", status: "invalid", reasons: [] },
      { tier: "witnesses", status: "invalid", reasons: [] },
      { tier: "hubs", status: app.length > 0 ? "invalid" : "unused", reasons: [], hubs: app.map((h) => detail(h, "invalid")) },
      { tier: "browser", status: combine(browserDetails.map((d) => d.status)), reasons: [], hubs: browserDetails },
    ];
    return this.result(tiers, 0, false);
  }

  private finish(d: Draft, now: number): TierResult {
    const out: TierResult = { tier: d.tier, status: d.status, reasons: [...d.reasons] };
    if (d.hubs) {
      const details = d.hubs.map((s) => {
        const x: HubTierDetail = { hub: s.hub.name, status: s.status, reasons: [...s.reasons] };
        if (isLate(s.status, s.deadline, now)) {
          x.status = "late";
          x.reasons.push(reason("deadline-passed", { deadline: s.deadline }));
        }
        if (s.test) x.test = true;
        return x;
      });
      out.hubs = details;
      if (d.status !== "unused") out.status = combine(details.map((x) => x.status));
      const open = d.hubs.filter((s, i) => (details[i]!.status === "pending" || details[i]!.status === "late") && s.deadline !== undefined);
      if (open.length > 0) out.deadline = Math.min(...open.map((s) => s.deadline!));
    } else {
      if (isLate(d.status, d.deadline, now)) {
        out.status = "late";
        out.reasons.push(reason(d.lateCode ?? "deadline-passed", { deadline: d.deadline }));
      }
      if ((out.status === "pending" || out.status === "late") && d.deadline !== undefined) out.deadline = d.deadline;
    }
    return out;
  }

  /** The quorum-vouched time: the largest `t` such that the witnesses whose
   * latest valid cosignature (on any checkpoint of the log the verifier
   * holds) is at least `t` satisfy the quorum. Cosignatures more than 300 s
   * after the device clock were already set aside, which caps it. */
  private signedNow(): number {
    const latest = new Map<string, number>();
    for (const cp of this.held) {
      for (const c of cp.cosigs) if (c.timestamp > (latest.get(c.witness) ?? 0)) latest.set(c.witness, c.timestamp);
    }
    return this.policy.witnesses.vouchedTime(latest);
  }

  // -- Tier 0: record --------------------------------------------------------

  private promiseDue(batch: PromiseBatch): number {
    const d = promiseDeadline(batch);
    const q = quietPeriod(this.policy);
    return q && d >= q.start && d <= q.end ? q.end + batch.mmd + PROMISE_SKEW : d;
  }

  private record(c: ReceiptChain, log: PolicyLog): RecordState {
    const st: RecordState = { status: "verified", reasons: [], invalid: false, failed: false, pending: false, receipts: [], splitView: false };
    const bad = (r: Reason, kind: "invalid" | "failed" | "pending"): Reason => {
      st.reasons.push(r);
      st[kind] = true;
      return r;
    };

    let promise: ValidPromise | undefined;
    if (c.promise) {
      try {
        const p = parsePromise(c.promise);
        const { batch } = checkPromiseBatch(p, log.vkey, this.policy.mmd);
        this.step("promise-signature", "record", true, { time: batch.time, mmd: batch.mmd });
        try {
          checkPromiseInclusion(p, batch);
          this.step("promise-inclusion", "record", true, { index: p.index, size: batch.size });
          promise = { batch, leaf: p.leaf, deadline: promiseDeadline(batch), due: this.promiseDue(batch) };
        } catch (e) {
          this.step("promise-inclusion", "record", false, undefined, [bad(toReason(e), "invalid")]);
        }
      } catch (e) {
        this.step("promise-signature", "record", false, undefined, [bad(toReason(e), "invalid")]);
      }
    }

    for (const block of ["issued", "record"] as const) {
      const body = c[block];
      if (!body) continue;
      const r = this.receipt(block, body, log, bad);
      if (r) st.receipts.push(r);
    }
    const [first, second] = st.receipts;
    if (first && second) {
      if (!equalBytes(first.extra, second.extra) || first.proof.index !== second.proof.index) {
        this.step("receipts-match", "record", false, undefined, [bad(reason("receipts-disagree"), "invalid")]);
      } else {
        this.step("receipts-match", "record", true);
      }
    }
    if (first) this.entry(first, log, st, bad);
    if (first && second) this.recordConsistency(first, second, c.consistency, st, bad);
    st.best = st.receipts[st.receipts.length - 1];

    if (promise) {
      if (first) {
        if (equalBytes(promise.leaf, first.leaf)) {
          this.step("promise-leaf", "record", true);
          st.promise = promise;
        } else {
          this.step("promise-leaf", "record", false, undefined, [bad(reason("promise-leaf-mismatch"), "invalid")]);
        }
      } else {
        try {
          const want = expectedEntry(this.opts.expect, profileAt(log, undefined).tag);
          if (!want) {
            this.step("promise-leaf", "record", null, undefined, [bad(reason("expectation-incomplete"), "invalid")]);
          } else if (!equalBytes(leafHash(want), promise.leaf)) {
            this.step("promise-leaf", "record", false, undefined, [bad(reason("promise-leaf-mismatch"), "invalid")]);
          } else {
            this.step("promise-leaf", "record", true);
            st.promise = promise;
            st.leaf = promise.leaf;
          }
        } catch (e) {
          this.step("promise-leaf", "record", false, undefined, [bad(toReason(e), "invalid")]);
        }
      }
    }
    if (st.promise) {
      const set = this.policy.witnesses;
      const witnessed = st.receipts.filter((r) => set.meets(r.cp.cosigs));
      if (witnessed.length > 0) {
        const deadline = st.promise.deadline;
        if (witnessed.some((r) => set.meetsBy(r.cp.cosigs, deadline))) this.step("promise-kept", "record", true, { deadline });
        else this.step("promise-kept", "record", null, { deadline }, [reason("promise-kept-unproven", { deadline })]);
      }
    }

    if (st.failed) st.status = "failed";
    else if (st.invalid) st.status = "invalid";
    else if (st.receipts.length === 0) {
      st.status = "pending";
      st.reasons.push(reason("promise-pending", { deadline: st.promise!.due }));
    } else if (st.pending) st.status = "pending";
    return st;
  }

  private receipt(
    block: "issued" | "record",
    body: Uint8Array,
    log: PolicyLog,
    bad: (r: Reason, kind: "invalid" | "failed" | "pending") => Reason,
  ): Receipt | undefined {
    const sig = block === "issued" ? "issued-signature" : "record-signature";
    const inc = block === "issued" ? "issued-inclusion" : "record-inclusion";
    let r: Receipt;
    try {
      const proof = parseTlogProof(body);
      const extra = proof.extra;
      if (extra === undefined) return fail("missing-extra");
      const cp = verifyCheckpoint(proof.checkpoint, log.vkey, this.policy.witnesses, this.deviceNow);
      r = { block, proof, extra, cp, leaf: leafHash(extra) };
    } catch (e) {
      this.step(sig, "record", false, undefined, [bad(toReason(e), "invalid")]);
      return undefined;
    }
    this.held.push(r.cp);
    this.step(sig, "record", true, { size: num(r.cp.cp.size) });
    try {
      if (r.proof.index >= r.cp.cp.size) fail("index-out-of-range", { index: num(r.proof.index), size: num(r.cp.cp.size) });
      if (!verifyInclusion(r.proof.index, r.cp.cp.size, r.leaf, r.proof.proof, r.cp.cp.root)) fail("inclusion-failed", { what: block });
    } catch (e) {
      this.step(inc, "record", false, undefined, [bad(toReason(e), "invalid")]);
      return undefined;
    }
    this.step(inc, "record", true, { index: num(r.proof.index) });
    return r;
  }

  /** The entry checks (specs/receipt.md, section 1.1, step 2). A log-signed
   * receipt for an entry that breaks the profile is evidence (bad-entry,
   * rule vitrine/parse); one for another entry than the user's is not. */
  private entry(r: Receipt, log: PolicyLog, st: RecordState, bad: (r: Reason, kind: "invalid" | "failed") => Reason): void {
    const objects = [r.block];
    let entry: Entry;
    try {
      entry = parseEntry(r.extra);
    } catch (e) {
      const x = toReason(e, objects);
      const rr = x.code === "bad-entry" ? x : reason("bad-entry", { detail: x.code }, objects);
      this.step("entry-parse", "entry", false, undefined, [bad(rr, "failed")]);
      return;
    }
    this.step("entry-parse", "entry", true, { tag: entry.tag });
    const profile = profileAt(log, r.proof.index);
    try {
      if (entry.tag !== profile.tag) fail("wrong-profile", { tag: entry.tag, want: profile.tag });
      checkLayout(entry);
    } catch (e) {
      this.step("entry-profile", "entry", false, undefined, [bad(toReason(e, objects), "failed")]);
      return;
    }
    this.step("entry-profile", "entry", true, { tag: profile.tag });
    try {
      checkExpectation(entry, this.opts.expect);
    } catch (e) {
      const x = toReason(e);
      this.step("entry-expectation", "entry", x.code === "expectation-incomplete" ? null : false, undefined, [bad(x, "invalid")]);
      return;
    }
    this.step("entry-expectation", "entry", true);
    st.leaf = r.leaf;
    st.index = r.proof.index;
  }

  private recordConsistency(
    a: Receipt,
    b: Receipt,
    cb: ConsistencyBlock | undefined,
    st: RecordState,
    bad: (r: Reason, kind: "invalid" | "failed" | "pending") => Reason,
  ): void {
    const A = a.cp.cp;
    const B = b.cp.cp;
    const sizes = { from: num(A.size), to: num(B.size) };
    if (B.size < A.size) {
      this.step("record-consistency", "record", false, sizes, [bad(reason("consistency-mismatch", sizes), "invalid")]);
    } else if (B.size === A.size) {
      if (equalBytes(A.root, B.root)) {
        this.step("record-consistency", "record", true, sizes);
      } else {
        st.splitView = true;
        this.step("record-consistency", "record", false, sizes, [bad(reason("split-view", { size: num(A.size) }, ["issued", "record"]), "failed")]);
      }
    } else if (!cb) {
      this.step("record-consistency", "record", null, sizes, [bad(reason("consistency-missing", sizes), "pending")]);
    } else if (cb.from !== A.size || cb.to !== B.size) {
      this.step("record-consistency", "record", false, sizes, [bad(reason("consistency-mismatch", sizes), "invalid")]);
    } else {
      try {
        const proof = parseHashLines(cb.body, MAX_CONSISTENCY_HASHES);
        if (!verifyConsistency(A.size, B.size, proof, A.root, B.root)) fail("consistency-failed", sizes);
        this.step("record-consistency", "record", true, sizes);
      } catch (e) {
        this.step("record-consistency", "record", false, sizes, [bad(toReason(e), "invalid")]);
      }
    }
  }

  // -- Tier 1: witnesses -----------------------------------------------------

  private witnesses(rec: RecordState): WitnessState {
    if (rec.status === "invalid") return { status: "invalid", reasons: [reason("record-invalid")] };
    if (rec.receipts.length === 0) {
      const r = reason("waiting-for-record");
      this.step("record-quorum", "witnesses", null, undefined, [r]);
      const st: WitnessState = { status: "pending", reasons: [r] };
      if (rec.promise) st.deadline = rec.promise.due;
      return st;
    }
    const set = this.policy.witnesses;
    const reasons: Reason[] = [];
    const future = new Set(rec.receipts.flatMap((r) => r.cp.future));
    if (future.size > 0) reasons.push(reason("cosignature-in-future", { witnesses: [...future].join(" ") }));
    const witnessed = [...rec.receipts].reverse().find((r) => set.meets(r.cp.cosigs));
    if (witnessed) {
      const qt = set.quorumTime(witnessed.cp.cosigs) ?? 0;
      this.step("record-quorum", "witnesses", true, { quorumTime: qt, cosignatures: witnessed.cp.cosigs.length });
      if (rec.splitView && rec.receipts.length === 2 && rec.receipts.every((r) => set.meets(r.cp.cosigs))) {
        // Both sides of a split view satisfy the quorum: the policy's trust
        // assumption failed (specs/evidence.md, section 2.1).
        reasons.push(reason("split-view", { what: "quorum" }, ["issued", "record"]));
        return { status: "failed", reasons, quorumTime: qt };
      }
      return { status: "verified", reasons, quorumTime: qt };
    }
    const best = rec.best!;
    this.step("record-quorum", "witnesses", null, { cosignatures: best.cp.cosigs.length }, [
      reason("quorum-not-met", { cosignatures: best.cp.cosigs.length }),
    ]);
    reasons.push(reason("waiting-for-cosignatures"));
    const st: WitnessState = { status: "pending", reasons };
    const deadline = this.receiptDeadline(rec);
    if (deadline !== undefined) st.deadline = deadline;
    return st;
  }

  /** When an unwitnessed receipt becomes late: the promise's deadline, or
   * `cosign-max` after the earliest cosignature on it. A receipt with neither
   * carries no signed time, so it has no deadline yet. */
  private receiptDeadline(rec: RecordState): number | undefined {
    if (rec.promise) return rec.promise.due;
    let t: number | undefined;
    for (const r of rec.receipts) for (const c of r.cp.cosigs) if (t === undefined || c.timestamp < t) t = c.timestamp;
    return t === undefined ? undefined : t + this.policy.cosignMax;
  }

  // -- Tier 2: hubs ----------------------------------------------------------

  private hubs(c: ReceiptChain, log: PolicyLog, rec: RecordState, wit: WitnessState): Draft {
    const app = appHubs(this.policy);
    if (app.length === 0) return { tier: "hubs", status: "unused", reasons: [], hubs: [] };
    const base = wit.quorumTime ?? wit.deadline;
    const deadline = base === undefined ? undefined : base + 2 * this.policy.anchorPeriod + this.policy.cosignMax;
    const withDeadline = (s: HubState): HubState => {
      if (s.status === "pending" && deadline !== undefined) s.deadline = deadline;
      return s;
    };
    const d: Draft = { tier: "hubs", status: "pending", reasons: [] };
    if (deadline !== undefined) d.deadline = deadline;
    if (rec.status === "invalid") {
      d.status = "invalid";
      d.reasons.push(reason("record-invalid"));
      d.hubs = app.map((h) => ({ hub: h, status: "invalid", reasons: [reason("record-invalid")] }));
    } else if (rec.receipts.length === 0) {
      d.reasons.push(reason("waiting-for-record"));
      d.hubs = app.map((h) => withDeadline({ hub: h, status: "pending", reasons: [reason("waiting-for-record")] }));
    } else {
      d.hubs = app.map((h) => withDeadline(this.hub(h, c.hubs.get(h.name) ?? {}, log, rec.best!)));
      d.status = combine(d.hubs.map((s) => s.status));
    }
    return d;
  }

  /** One app hub (specs/receipt.md, section 3.1, step 3; specs/hub.md,
   * section 5.2). */
  private hub(h: PolicyHub, blocks: HubBlocks, log: PolicyLog, best: Receipt): HubState {
    const P = { hub: h.name };
    const st: HubState = { hub: h, status: "pending", reasons: [] };
    const done = (status: TierStatus, r: Reason): HubState => {
      st.status = status;
      st.reasons.push(r);
      return st;
    };
    if (!blocks.anchor) {
      const r = reason("waiting-for-anchor", P);
      this.step("hub-link", "hubs", null, P, [r]);
      return done("pending", r);
    }
    let link: VerifiedHubLink;
    try {
      link = verifyHubLink(blocks.anchor, h, logSubject(this.policy, log.name), this.deviceNow);
    } catch (e) {
      const r = toReason(e);
      this.step("hub-link", "hubs", false, P, [r]);
      return done("invalid", r);
    }
    const linkParams = { ...P, size: num(link.hub.cp.size), entry: num(link.entryIndex) };
    if (!link.hubQuorum) {
      const r = reason("hub-quorum-not-met", P);
      this.step("hub-link", "hubs", null, linkParams, [r]);
      return done("pending", r);
    }
    st.link = link;
    this.step("hub-link", "hubs", true, linkParams);
    if (link.kind === "rotate") {
      const r = reason("subject-rotated", P);
      this.step("hub-anchored-checkpoint", "hubs", null, P, [r]);
      return done("pending", r);
    }
    let note: Uint8Array;
    let opened = false;
    if (link.kind === "blinded") {
      if (!blocks.opening) {
        const r = reason("opening-missing", P);
        this.step("hub-opening", "hubs", null, P, [r]);
        return done("pending", r);
      }
      try {
        note = checkOpening(parseOpening(blocks.opening), h, link.blinded!);
      } catch (e) {
        const r = toReason(e);
        this.step("hub-opening", "hubs", false, P, [r]);
        return done("invalid", r);
      }
      this.step("hub-opening", "hubs", true, P);
      opened = true;
    } else {
      note = link.anchored!;
    }
    const source = opened ? `opening ${h.name}` : `anchor ${h.name}`;
    let anchored: CheckedCheckpoint;
    try {
      anchored = verifyCheckpoint(note, log.vkey, this.policy.witnesses, this.deviceNow);
    } catch (e) {
      // A hub-cosigned anchor of a checkpoint its subject didn't sign is
      // hub-entry evidence (specs/evidence.md, section 2.6). An opening only
      // commits to the checkpoint text, so a bad one is damaged data.
      const r = opened ? toReason(e) : toReason(e, [source]);
      this.step("hub-anchored-checkpoint", "hubs", false, P, [r]);
      return done(opened ? "invalid" : "failed", r);
    }
    this.held.push(anchored);
    const cpParams = { ...P, size: num(anchored.cp.size) };
    if (!this.policy.witnesses.meets(anchored.cosigs)) {
      const r = reason("anchor-quorum-not-met", P);
      this.step("hub-anchored-checkpoint", "hubs", null, cpParams, [r]);
      return done("pending", r);
    }
    this.step("hub-anchored-checkpoint", "hubs", true, cpParams);
    const o = this.extendsFrom("hub-anchor-consistency", "hubs", P, best.cp.cp, anchored.cp, blocks.anchorConsistency, [best.block, source], "anchor-behind-record");
    st.status = o.status;
    st.reasons.push(...o.reasons);
    return st;
  }

  /** Checks that `next` extends `base` (both signed by one log): equal roots
   * at equal sizes, else the consistency block's proof. */
  private extendsFrom(
    code: StepCode,
    tier: Step["tier"],
    P: Params,
    base: Checkpoint,
    next: Checkpoint,
    cb: ConsistencyBlock | undefined,
    splitObjects: string[],
    behind: "anchor-behind-record" | "browser-behind-anchor",
  ): Outcome {
    const sizes = { ...P, from: num(base.size), to: num(next.size) };
    const out = (status: TierStatus, ok: boolean | null, r?: Reason): Outcome => {
      this.step(code, tier, ok, sizes, r ? [r] : undefined);
      return { status, reasons: r ? [r] : [] };
    };
    if (next.size < base.size) return out("pending", null, reason(behind, sizes));
    if (next.size === base.size) {
      if (equalBytes(base.root, next.root)) return out("verified", true);
      return out("failed", false, reason("split-view", { size: num(base.size) }, splitObjects));
    }
    if (!cb) return out("pending", null, reason("consistency-missing", sizes));
    if (cb.from !== base.size || cb.to !== next.size) return out("invalid", false, reason("consistency-mismatch", sizes));
    try {
      const proof = parseHashLines(cb.body, MAX_CONSISTENCY_HASHES);
      if (!verifyConsistency(base.size, next.size, proof, base.root, next.root)) fail("consistency-failed", sizes);
    } catch (e) {
      return out("invalid", false, toReason(e));
    }
    return out("verified", true);
  }

  // -- Tier 3: browser -------------------------------------------------------

  private browser(c: ReceiptChain, rec: RecordState, hubs: Draft): Draft {
    const app = appHubs(this.policy);
    const uses = new Map(app.map((h) => [h.name, browserUse(this.policy, h)]));
    const testOnly = ![...uses.values()].includes("counted");
    if (app.length === 0 || (testOnly && ![...uses.values()].includes("test"))) {
      return { tier: "browser", status: "unused", reasons: [], hubs: [] };
    }
    const period = this.policy.browserPeriod ?? DEFAULT_BROWSER_PERIOD;
    const fallback = hubs.deadline === undefined ? undefined : hubs.deadline + period + BROWSER_GRACE_SECONDS;
    const states = new Map((hubs.hubs ?? []).map((s) => [s.hub.name, s]));
    const details: HubState[] = [];
    for (const h of app) {
      const use = uses.get(h.name)!;
      if (use === "none") {
        details.push({ hub: h, status: "unused", reasons: [] });
        continue;
      }
      let s: HubState;
      if (rec.status === "invalid") s = { hub: h, status: "invalid", reasons: [reason("record-invalid")] };
      else if (rec.receipts.length === 0) s = { hub: h, status: "pending", reasons: [reason("waiting-for-record")] };
      else s = this.browserHub(h, c.hubs.get(h.name) ?? {}, states.get(h.name), period);
      if (s.status === "pending" && s.deadline === undefined && fallback !== undefined) s.deadline = fallback;
      // A hub served only by the operator's own services is a test (specs/hub.md, section 6.3).
      if (use === "test") s = { hub: h, status: "unused", test: true, reasons: [reason("browser-test-only"), ...s.reasons] };
      details.push(s);
    }
    if (testOnly) return { tier: "browser", status: "unused", reasons: [reason("browser-test-only")], hubs: details };
    const d: Draft = { tier: "browser", status: combine(details.map((s) => s.status)), reasons: [], hubs: details };
    if (rec.status === "invalid") d.reasons.push(reason("record-invalid"));
    else if (rec.receipts.length === 0) d.reasons.push(reason("waiting-for-record"));
    return d;
  }

  /** One app hub in the browser tier: a browser anchor from an independent
   * service, or a bootstrap link, extending the hub checkpoint of its
   * `anchor` block (specs/receipt.md, section 3.1, step 4). */
  private browserHub(h: PolicyHub, blocks: HubBlocks, hs: HubState | undefined, period: number): HubState {
    const P = { hub: h.name };
    const link = hs?.link;
    if (!link) {
      const r = reason("waiting-for-anchor", P);
      this.step("browser-anchor", "browser", null, P, [r]);
      return { hub: h, status: "pending", reasons: [r] };
    }
    const outcomes: Outcome[] = [];
    if (blocks.browser) outcomes.push(this.browserBlock(h, blocks.browser, link.hub.cp));
    if (blocks.bootstrap) outcomes.push(this.bootstrapBlock(h, blocks.bootstrap, blocks.bootstrapConsistency, link.hub.cp));
    const counted = outcomes.filter((o) => o.status !== "unused").map((o) => o.status);
    const reasons = outcomes.flatMap((o) => o.reasons);
    let status: TierStatus = "pending";
    if (counted.includes("failed")) status = "failed";
    else if (counted.includes("verified")) status = "verified";
    else if (counted.includes("invalid")) status = "invalid";
    else if (counted.length === 0) {
      const r = reason("waiting-for-browser-anchor", P);
      if (outcomes.length === 0) this.step("browser-anchor", "browser", null, P, [r]);
      reasons.push(r);
    }
    const s: HubState = { hub: h, status, reasons };
    if (status === "pending" && link.hubQuorumTime !== undefined) s.deadline = link.hubQuorumTime + period + BROWSER_GRACE_SECONDS;
    return s;
  }

  private browserBlock(h: PolicyHub, body: Uint8Array, base: Checkpoint): Outcome {
    const P = { hub: h.name };
    let v: VerifiedBrowserAnchor;
    try {
      v = verifyBrowserAnchor(body, this.policy, h, base, this.deviceNow);
    } catch (e) {
      const code = e instanceof VerifyError ? e.code : undefined;
      if (code === "split-view") {
        // Two hub-signed checkpoints of one size with different roots.
        const r = toReason(e, [`anchor ${h.name}`, `browser ${h.name}`]);
        this.step("browser-anchor", "browser", true, P);
        this.step("browser-consistency", "browser", false, P, [r]);
        return { status: "failed", reasons: [r] };
      }
      const r = toReason(e);
      if (code === "consistency-mismatch" || code === "consistency-failed") {
        this.step("browser-anchor", "browser", true, P);
        this.step("browser-consistency", "browser", false, P, [r]);
      } else {
        this.step("browser-anchor", "browser", false, P, [r]);
      }
      return { status: "invalid", reasons: [r] };
    }
    const params = { ...P, service: v.service.domain, size: num(v.hub.cp.size) };
    if (!v.hubQuorum) {
      const r = reason("hub-quorum-not-met", P);
      this.step("browser-anchor", "browser", null, params, [r]);
      return { status: "pending", reasons: [r] };
    }
    const reasons: Reason[] = [];
    if (!v.independent) reasons.push(reason("waict-service-not-independent", { service: v.service.domain }));
    this.step("browser-anchor", "browser", true, params, reasons);
    if (v.position === "behind") {
      const r = reason("browser-behind-anchor", { ...P, from: num(base.size), to: num(v.hub.cp.size) });
      this.step("browser-consistency", "browser", null, P, [r]);
      return { status: v.independent ? "pending" : "unused", reasons: [...reasons, r] };
    }
    this.step("browser-consistency", "browser", true, { ...P, from: num(base.size), to: num(v.hub.cp.size) });
    return { status: v.independent ? "verified" : "unused", reasons };
  }

  private bootstrapBlock(h: PolicyHub, body: Uint8Array, cb: ConsistencyBlock | undefined, base: Checkpoint): Outcome {
    const P = { hub: h.name };
    let b: PolicyHub;
    let link: VerifiedHubLink;
    try {
      b = bootstrapHubOf(this.policy, body);
      link = verifyHubLink(body, b, hubSubject(h), this.deviceNow);
    } catch (e) {
      const r = toReason(e);
      this.step("bootstrap-link", "browser", false, P, [r]);
      return { status: "invalid", reasons: [r] };
    }
    const params = { ...P, bootstrap: b.name, size: num(link.hub.cp.size) };
    if (!link.hubQuorum || link.kind === "rotate") {
      const r = link.hubQuorum ? reason("subject-rotated", { hub: b.name }) : reason("hub-quorum-not-met", { hub: b.name });
      this.step("bootstrap-link", "browser", null, params, [r]);
      return { status: "pending", reasons: [r] };
    }
    let anchored: CheckedCheckpoint;
    try {
      anchored = verifyCheckpoint(link.anchored!, h.vkey, h.set, this.deviceNow);
    } catch (e) {
      // The bootstrap hub's quorum vouched for an anchor its subject didn't
      // sign: hub-entry evidence.
      const r = toReason(e, [`bootstrap ${h.name}`]);
      this.step("bootstrap-link", "browser", false, params, [r]);
      return { status: "failed", reasons: [r] };
    }
    this.step("bootstrap-link", "browser", true, params);
    return this.extendsFrom("bootstrap-consistency", "browser", P, base, anchored.cp, cb, [`anchor ${h.name}`, `bootstrap ${h.name}`], "browser-behind-anchor");
  }
}
