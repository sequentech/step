// SPDX-License-Identifier: Apache-2.0
//
// Parsers and verifiers throw VerifyError; the chain verifier turns it into a
// Reason (src/types.ts). Codes are listed in src/codes.ts.

import type { ReasonCode } from "../codes.js";
import type { Reason } from "../types.js";

export type Params = Record<string, string | number>;

export class VerifyError extends Error {
  readonly code: ReasonCode;
  readonly params: Params | undefined;
  /** Block types or note origins that are evidence when this is a failure. */
  objects: string[] | undefined;

  constructor(code: ReasonCode, params?: Params, objects?: string[]) {
    super(params ? `${code} ${JSON.stringify(params)}` : code);
    this.name = "VerifyError";
    this.code = code;
    this.params = params;
    this.objects = objects;
  }

  toReason(): Reason {
    const r: Reason = { code: this.code };
    if (this.params) r.params = { ...this.params };
    if (this.objects && this.objects.length > 0) r.objects = [...this.objects];
    return r;
  }
}

export function fail(code: ReasonCode, params?: Params): never {
  throw new VerifyError(code, params);
}

/** Runs `f`, adding `objects` to a VerifyError it throws. */
export function withObjects<T>(objects: string[], f: () => T): T {
  try {
    return f();
  } catch (e) {
    if (e instanceof VerifyError && !e.objects) e.objects = objects;
    throw e;
  }
}

export function reason(code: ReasonCode, params?: Params, objects?: string[]): Reason {
  const r: Reason = { code };
  if (params) r.params = params;
  if (objects && objects.length > 0) r.objects = objects;
  return r;
}

/** Converts anything thrown into a Reason; non-VerifyErrors are bugs, but a
 * verifier must still answer, so they become `malformed-chain`. */
export function toReason(e: unknown, objects?: string[]): Reason {
  if (e instanceof VerifyError) {
    const r = e.toReason();
    if (!r.objects && objects && objects.length > 0) r.objects = objects;
    return r;
  }
  return reason("malformed-chain", { detail: String((e as Error)?.message ?? e).slice(0, 200) }, objects);
}
