// SPDX-License-Identifier: Apache-2.0
//
// The domain normal form of specs/hub.md, section 6 ("Domains"), written from
// the spec and from RFC 3492 (Punycode). It must agree with `check_domain` in
// `vitrine-tlog`; testdata/policy-syntax/domains.json is the shared list.

const MAX_DOMAIN_LEN = 253;
const MAX_LABEL_LEN = 63;

// RFC 3492, section 5.
const BASE = 36;
const TMIN = 1;
const TMAX = 26;
const SKEW = 38;
const DAMP = 700;
const INITIAL_BIAS = 72;
const INITIAL_N = 0x80;
const U32_MAX = 0xffffffff;

function adapt(delta: number, points: number, first: boolean): number {
  delta = Math.floor(delta / (first ? DAMP : 2));
  delta += Math.floor(delta / points);
  let k = 0;
  while (delta > ((BASE - TMIN) * TMAX) / 2) {
    delta = Math.floor(delta / (BASE - TMIN));
    k += BASE;
  }
  return k + Math.floor(((BASE - TMIN + 1) * delta) / (delta + SKEW));
}

function threshold(k: number, bias: number): number {
  return k <= bias ? TMIN : k >= bias + TMAX ? TMAX : k - bias;
}

/** The value of a lowercase Punycode digit, or -1. */
function digit(c: number): number {
  if (c >= 0x61 && c <= 0x7a) return c - 0x61;
  if (c >= 0x30 && c <= 0x39) return c - 0x30 + 26;
  return -1;
}

function digitChar(d: number): number {
  return d < 26 ? 0x61 + d : 0x30 + (d - 26);
}

/** Whether `n` is a Unicode scalar value (not a surrogate, at most U+10FFFF). */
function isScalar(n: number): boolean {
  return n <= 0x10ffff && !(n >= 0xd800 && n <= 0xdfff);
}

/** Decodes lowercase Punycode to code points: the basic code points before
 * the last hyphen, then the insertions. `null` if it isn't valid or a 32-bit
 * value overflows. */
export function punycodeDecode(input: string): number[] | null {
  const hyphen = input.lastIndexOf("-");
  const basic = hyphen < 0 ? "" : input.slice(0, hyphen);
  const rest = hyphen < 0 ? input : input.slice(hyphen + 1);
  const out: number[] = [];
  for (let j = 0; j < basic.length; j++) {
    const c = basic.charCodeAt(j);
    if (c >= 0x80) return null;
    out.push(c);
  }
  let n = INITIAL_N;
  let i = 0;
  let bias = INITIAL_BIAS;
  let pos = 0;
  while (pos < rest.length) {
    const oldI = i;
    let w = 1;
    for (let k = BASE; ; k += BASE) {
      if (pos >= rest.length) return null;
      const d = digit(rest.charCodeAt(pos++));
      if (d < 0) return null;
      i += d * w;
      if (i > U32_MAX) return null;
      const t = threshold(k, bias);
      if (d < t) break;
      w *= BASE - t;
      if (w > U32_MAX) return null;
    }
    const len = out.length + 1;
    bias = adapt(i - oldI, len, oldI === 0);
    n += Math.floor(i / len);
    if (n > U32_MAX || !isScalar(n)) return null;
    i %= len;
    out.splice(i, 0, n);
    i += 1;
  }
  return out;
}

/** Encodes code points as lowercase Punycode. `null` on overflow. */
export function punycodeEncode(input: readonly number[]): string | null {
  let out = "";
  for (const c of input) if (c < 0x80) out += String.fromCharCode(c);
  const basic = out.length;
  const len = input.length;
  if (basic > 0) out += "-";
  let n = INITIAL_N;
  let delta = 0;
  let bias = INITIAL_BIAS;
  let h = basic;
  while (h < len) {
    let m = Infinity;
    for (const c of input) if (c >= n && c < m) m = c;
    if (m === Infinity) return null;
    delta += (m - n) * (h + 1);
    if (delta > U32_MAX) return null;
    n = m;
    for (const c of input) {
      if (c < n) {
        delta += 1;
        if (delta > U32_MAX) return null;
      }
      if (c === n) {
        let q = delta;
        for (let k = BASE; ; k += BASE) {
          const t = threshold(k, bias);
          if (q < t) break;
          out += String.fromCharCode(digitChar(t + ((q - t) % (BASE - t))));
          q = Math.floor((q - t) / (BASE - t));
        }
        out += String.fromCharCode(digitChar(q));
        bias = adapt(delta, h + 1, h === basic);
        delta = 0;
        h += 1;
      }
    }
    delta += 1;
    n += 1;
    if (delta > U32_MAX || n > U32_MAX) return null;
  }
  return out;
}

/** Whether the Punycode after an A-label's `xn--` is strict, encodes back to
 * itself and decodes to a U-label: some non-ASCII code point, and no C1
 * control, noncharacter or private-use code point. */
function isULabel(puny: string): boolean {
  const decoded = punycodeDecode(puny);
  if (decoded === null) return false;
  if (!decoded.some((c) => c >= 0x80)) return false;
  for (const c of decoded) {
    if (c >= 0x80 && c <= 0x9f) return false;
    if (c >= 0xfdd0 && c <= 0xfdef) return false;
    if ((c & 0xfffe) === 0xfffe) return false;
    if (c >= 0xe000 && c <= 0xf8ff) return false;
    if (c >= 0xf0000) return false;
  }
  return punycodeEncode(decoded) === puny;
}

/** Whether the WHATWG URL parser reads a last label as an IPv4 number: all
 * digits, or `0x` and hexadecimal digits (possibly none). */
function isIpv4Number(label: string): boolean {
  return /^[0-9]+$/.test(label) || /^0x[0-9a-f]*$/.test(label);
}

/** Whether `d` is a domain in normal form: the five rules of specs/hub.md,
 * section 6, "Domains". The same test as `check_domain` in `vitrine-tlog`. */
export function isDomain(d: string): boolean {
  if (d.length < 1 || d.length > MAX_DOMAIN_LEN || !/^[a-z0-9.-]+$/.test(d)) return false;
  const labels = d.split(".");
  for (const label of labels) {
    if (label.length < 1 || label.length > MAX_LABEL_LEN) return false;
    if (label.startsWith("-") || label.endsWith("-")) return false;
    if (label.slice(2, 4) === "--" && !label.startsWith("xn--")) return false;
  }
  if (isIpv4Number(labels[labels.length - 1]!)) return false;
  for (const label of labels) {
    if (label.startsWith("xn--") && !isULabel(label.slice(4))) return false;
  }
  return true;
}
