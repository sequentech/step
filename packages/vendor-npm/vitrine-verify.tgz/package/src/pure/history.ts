// SPDX-License-Identifier: Apache-2.0
//
// The policies in force over time (specs/policy.md, section 4): the pinned
// policy and the successors a verifier applied, in events-log order. Rule 9
// judges each checkpoint, of an app log or of a hub, under the policy in force
// at its quorum time; the quorum-vouched now (specs/receipt.md, section 3.1)
// is taken under the policy in force then; and rule 7's discovery applies the
// successors that a `vitrine/policy-proofs/v1` document proves
// (specs/redaction.md, section 4.3). For a public event, the upgrade code
// builds the same document from the events log's public routes.

import type { Reason } from "../types.js";
import { concat, equalBytes, parseDecimal } from "./bytes.js";
import { formatBlockDoc, parseBlockDoc, parseHashLines, type Block } from "./blocks.js";
import { MAX_COSIGNATURE_SKEW, parseCheckpointText, verifyCheckpoint, type CheckedCheckpoint, type Checkpoint } from "./checkpoint.js";
import { checkLayout, fieldText, fieldValue, parseEntry, type Entry } from "./entry.js";
import { fail, reason, toReason, VerifyError } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { MAX_CONSISTENCY_HASHES, verifyConsistency, verifyInclusion } from "./merkle.js";
import { parseNote, type Vkey } from "./note.js";
import { acceptSuccessor, authorizedBy, parsePolicy, type Policy } from "./policy.js";
import type { Cosig, WitnessSet } from "./quorum.js";
import { parseTlogProof, type TlogProof } from "./tlogproof.js";

export const POLICY_PROOFS_HEADER = "vitrine/policy-proofs/v1";
export const EVENTS_TAG = "vitrine/events/v1";

/** One policy of a history, and when it took effect. */
export interface PolicyEpoch {
  policy: Policy;
  /** effective(Y) (rule 4), never earlier than the previous policy's;
   * -Infinity for the pinned policy. */
  effective: number;
  /** T_c (rule 3); absent for the pinned policy. */
  tc?: number;
  /** The index of its `policy` entry in the events log. */
  entryIndex?: bigint;
}

/** The keys a checkpoint is checked with under one policy. */
export interface SignerKeys {
  signer: Vkey;
  set: WitnessSet;
  /** App logs only: the `log-time` key. */
  logTime?: Vkey;
}

/** The keys of one log or hub under a policy, or undefined when the policy
 * doesn't list it. */
export type KeysOf = (p: Policy) => SignerKeys | undefined;

/** An app log's keys: its log key, `log-time` key and the app quorum. */
export function logKeys(name: string): KeysOf {
  return (p) => {
    const l = p.logs.get(name);
    return l ? { signer: l.vkey, set: p.witnesses, logTime: l.logTime } : undefined;
  };
}

/** A hub's keys: its log key and its own quorum. */
export function hubKeys(name: string): KeysOf {
  return (p) => {
    const h = p.hubs.get(name);
    return h ? { signer: h.vkey, set: h.set } : undefined;
  };
}

/** The pinned policy and the successors applied to it. Successors are only
 * ever appended: a verifier never goes back to an earlier policy (rule 7). */
export class PolicyHistory {
  readonly epochs: PolicyEpoch[];
  /** The quorum time of the events checkpoint that discovery last read
   * through (rule 7), or undefined while no discovery ran. */
  readThrough?: number;
  /** Policies whose first candidate successor broke a rule: they have no
   * successor and stay in force (rule 6). */
  readonly frozen = new Set<string>();
  /** What discovery found besides successors: rejected candidates and
   * equivocations. */
  readonly reasons: Reason[] = [];

  constructor(pinned: Policy) {
    if (pinned.draft) throw new TypeError("a draft policy is never valid; pin a sealed policy");
    this.epochs = [{ policy: pinned, effective: Number.NEGATIVE_INFINITY }];
  }

  get pinned(): Policy {
    return this.epochs[0]!.policy;
  }

  get latest(): PolicyEpoch {
    return this.epochs[this.epochs.length - 1]!;
  }

  /** The policy with ID `id`, if it is the pinned one or an applied successor. */
  byId(id: string): Policy | undefined {
    return this.epochs.find((e) => e.policy.id === id)?.policy;
  }

  indexOf(id: string): number {
    return this.epochs.findIndex((e) => e.policy.id === id);
  }

  /** The index of the epoch in force at `t` (rule 4: until effective(Y), the
   * policy before it stays in force). */
  indexAt(t: number): number {
    let i = 0;
    for (let j = 1; j < this.epochs.length; j++) if (this.epochs[j]!.effective <= t) i = j;
    return i;
  }

  /** The policy in force at `t`. */
  at(t: number): Policy {
    return this.epochs[this.indexAt(t)]!.policy;
  }

  /** Applies `y`, a successor of the latest policy whose entry's T_c is `tc`
   * (rules 1, 2, 4, 5 and 8). Throws `successor-rejected`. */
  apply(y: Policy, tc: number, entryIndex?: bigint): PolicyEpoch {
    const x = this.latest;
    if (this.frozen.has(x.policy.id)) throw new VerifyError("successor-rejected", { rule: 6, detail: "frozen" });
    const { effective } = acceptSuccessor(x.policy, y, tc);
    const e: PolicyEpoch = { policy: y, effective: Math.max(effective, x.effective), tc };
    if (entryIndex !== undefined) e.entryIndex = entryIndex;
    this.epochs.push(e);
    return e;
  }

  /** A copy, so that a discovery can be applied all or nothing. */
  clone(): PolicyHistory {
    const c = new PolicyHistory(this.pinned);
    c.epochs.splice(0, 1, ...this.epochs.map((e) => ({ ...e })));
    if (this.readThrough !== undefined) c.readThrough = this.readThrough;
    for (const f of this.frozen) c.frozen.add(f);
    c.reasons.push(...this.reasons);
    return c;
  }

  /** Takes over the state of `other`, a clone of this history that went on. */
  adopt(other: PolicyHistory): void {
    this.epochs.splice(0, this.epochs.length, ...other.epochs);
    if (other.readThrough !== undefined) this.readThrough = other.readThrough;
    for (const f of other.frozen) this.frozen.add(f);
    this.reasons.splice(0, this.reasons.length, ...other.reasons);
  }

  /** The cosignatures of `cosigs`, made by witnesses of epoch `i`'s set, that
   * count under epoch `i` (rule 9): a key that the policy before doesn't
   * list counts only if dated at or after the effective time of the policy
   * that introduced it. */
  counting(i: number, keysOf: KeysOf, cosigs: readonly Cosig[]): Cosig[] {
    if (i === 0) return [...cosigs];
    const set = keysOf(this.epochs[i]!.policy)?.set;
    if (!set) return [];
    return cosigs.filter((c) => {
      const w = set.witnesses.get(c.witness);
      if (!w) return false;
      let j = i;
      while (j > 0) {
        const prev = keysOf(this.epochs[j - 1]!.policy)?.set;
        if (!prev || ![...prev.witnesses.values()].some((x) => x.vkey.text === w.vkey.text)) break;
        j--;
      }
      return j === 0 || c.timestamp >= this.epochs[j]!.effective;
    });
  }
}

/** A checkpoint (or hub link) judged under rule 9. */
export interface Judged<T> {
  value: T;
  /** The epoch that judges it. */
  epoch: number;
  policy: Policy;
  keys: SignerKeys;
  /** The cosignatures that count under that policy. */
  cosigs: Cosig[];
  /** True when it meets that policy's quorum with a quorum time at which
   * that policy is in force. */
  meets: boolean;
  /** Its quorum time, when `meets`. */
  quorumTime?: number;
}

const isEmptyTree = (e: unknown): boolean => e instanceof VerifyError && e.code === "bad-empty-tree";

/** Judges something signed by a log or hub under the policy in force at its
 * quorum time (rule 9). `verify` checks it with one policy's keys and
 * throws when it doesn't verify; `parts` gives its cosignatures and, for an
 * app checkpoint, its log-time. A checkpoint that meets no policy's quorum
 * that way is judged, unwitnessed, under the policy in force at its
 * log-time, or else the latest policy whose keys verify it. Throws when no
 * policy's keys verify it, preferring `bad-empty-tree` (evidence). */
export function judgeWith<T>(
  h: PolicyHistory,
  keysOf: KeysOf,
  verify: (keys: SignerKeys, policy: Policy) => T,
  parts: (v: T) => { cosigs: readonly Cosig[]; logTime?: number },
): Judged<T> {
  let firstError: unknown;
  let emptyTree: unknown;
  const unwitnessed: Judged<T>[] = [];
  for (let i = h.epochs.length - 1; i >= 0; i--) {
    const policy = h.epochs[i]!.policy;
    const keys = keysOf(policy);
    if (!keys) continue;
    let value: T;
    try {
      value = verify(keys, policy);
    } catch (e) {
      if (isEmptyTree(e) && emptyTree === undefined) emptyTree = e;
      if (firstError === undefined) firstError = e;
      continue;
    }
    const cosigs = h.counting(i, keysOf, parts(value).cosigs);
    const qt = keys.set.quorumTime(cosigs);
    if (qt !== undefined && h.indexAt(qt) === i) return { value, epoch: i, policy, keys, cosigs, meets: true, quorumTime: qt };
    unwitnessed.push({ value, epoch: i, policy, keys, cosigs, meets: false });
  }
  if (unwitnessed.length === 0) {
    if (emptyTree !== undefined) throw emptyTree;
    if (firstError !== undefined) throw firstError;
    throw new VerifyError("unknown-log", { log: "-" });
  }
  return (
    unwitnessed.find((j) => {
      const lt = parts(j.value).logTime;
      return lt !== undefined && h.indexAt(lt) === j.epoch;
    }) ?? unwitnessed[0]!
  );
}

export interface JudgeCheckpointOptions {
  /** Reject a checkpoint without a valid log-time cosignature (receipts). */
  requireLogTime?: boolean;
}

/** Judges a checkpoint note of one log or hub under rule 9. */
export function judgeCheckpoint(
  h: PolicyHistory,
  input: string | Uint8Array,
  keysOf: KeysOf,
  deviceNow: number,
  opts: JudgeCheckpointOptions = {},
): Judged<CheckedCheckpoint> {
  return judgeWith(
    h,
    keysOf,
    (keys) =>
      verifyCheckpoint(input, keys.signer, keys.set, deviceNow, {
        ...(keys.logTime ? { logTime: keys.logTime } : {}),
        ...(opts.requireLogTime ? { requireLogTime: true } : {}),
      }),
    (c) => (c.logTime === undefined ? { cosigs: c.cosigs } : { cosigs: c.cosigs, logTime: c.logTime }),
  );
}

/** The quorum-vouched now (specs/receipt.md, section 3.1) over the held
 * checkpoints of one log: under the latest policy for which a held
 * checkpoint meets the quorum and whose vouched time falls in its epoch, the
 * largest `t` such that the witnesses whose latest counting cosignature is
 * dated at least `t` satisfy the quorum. It never passes the next policy's
 * effective time, and is capped at the device clock plus 300 seconds.
 * Undefined when no held checkpoint meets the quorum: there is no signed
 * time. */
export function vouchedNow(h: PolicyHistory, held: readonly (string | Uint8Array)[], keysOf: KeysOf, deviceNow: number): number | undefined {
  for (let i = h.epochs.length - 1; i >= 0; i--) {
    const e = h.epochs[i]!;
    const keys = keysOf(e.policy);
    if (!keys) continue;
    const latest = new Map<string, number>();
    let anyMeets = false;
    for (const x of held) {
      let c: CheckedCheckpoint;
      try {
        c = verifyCheckpoint(x, keys.signer, keys.set, deviceNow, keys.logTime ? { logTime: keys.logTime } : {});
      } catch {
        continue;
      }
      const cosigs = h.counting(i, keysOf, c.cosigs);
      if (keys.set.meets(cosigs)) anyMeets = true;
      for (const cs of cosigs) if (cs.timestamp > (latest.get(cs.witness) ?? 0)) latest.set(cs.witness, cs.timestamp);
    }
    if (!anyMeets) continue;
    let t = keys.set.vouchedTime(latest);
    if (t === undefined || t < e.effective) continue;
    const next = h.epochs[i + 1];
    if (next && t > next.effective) t = next.effective;
    return Math.min(t, deviceNow + MAX_COSIGNATURE_SKEW);
  }
  return undefined;
}

// ---------------------------------------------------------------------------
// Rule 7: discovery from a vitrine/policy-proofs/v1 document

/** One `policy-entry` block with its `policy-consistency` block. */
export interface PolicyProofEntry {
  /** The tlog-proof for the entry, against the checkpoint with the earliest
   * quorum time among those that contain it and meet the superseded
   * policy's quorum (specs/redaction.md, section 4.3). */
  proof: Uint8Array;
  from: bigint;
  to: bigint;
  /** Consistency proof hashes, base64, one per line. */
  consistency: Uint8Array;
}

export interface PolicyProofs {
  /** The events log's name. */
  log: string;
  /** The events checkpoint the document reads through. */
  checkpoint: Uint8Array;
  entries: PolicyProofEntry[];
}

const bad = (detail: string, params: Record<string, string | number> = {}): never => fail("bad-policy-proofs", { detail, ...params });

/** Parses a `vitrine/policy-proofs/v1` document (specs/redaction.md, section
 * 4.3). Unknown block types are ignored. */
export function parsePolicyProofs(input: Uint8Array | string): PolicyProofs {
  const doc = parseBlockDoc(input, { header: POLICY_PROOFS_HEADER, keys: ["log"], code: "bad-policy-proofs" });
  const log = doc.values[0]!;
  if (log.length !== 1) bad("lines");
  const known = doc.blocks.filter((b) => b.type === "checkpoint" || b.type === "policy-entry" || b.type === "policy-consistency");
  const first = known[0];
  if (!first || first.type !== "checkpoint" || first.args.length !== 0) bad("checkpoint");
  const out: PolicyProofs = { log: log[0]!, checkpoint: first!.body, entries: [] };
  for (let i = 1; i < known.length; i += 2) {
    const e = known[i]!;
    const c = known[i + 1];
    if (e.type !== "policy-entry" || e.args.length !== 0) bad("policy-entry", { block: i });
    if (!c || c.type !== "policy-consistency" || c.args.length !== 2) bad("policy-consistency", { block: i + 1 });
    let from = 0n;
    let to = 0n;
    try {
      from = parseDecimal(c!.args[0]!);
      to = parseDecimal(c!.args[1]!);
    } catch {
      bad("sizes", { block: i + 1 });
    }
    out.entries.push({ proof: e.body, from, to, consistency: c!.body });
  }
  return out;
}

/** Serialises a `vitrine/policy-proofs/v1` document. */
export function formatPolicyProofs(p: PolicyProofs): Uint8Array {
  const blocks: Block[] = [{ type: "checkpoint", args: [], body: p.checkpoint }];
  for (const e of p.entries) {
    blocks.push({ type: "policy-entry", args: [], body: e.proof });
    blocks.push({ type: "policy-consistency", args: [String(e.from), String(e.to)], body: e.consistency });
  }
  return formatBlockDoc(POLICY_PROOFS_HEADER, [`log ${p.log}`], blocks);
}

/** The `supersedes` line of a policy note, read without validating it, so
 * that rule 6 can tell a candidate that breaks another rule. */
function supersedesOf(note: Uint8Array): string | undefined {
  let text: string;
  try {
    text = parseNote(note).text;
  } catch {
    return undefined;
  }
  for (const l of text.split("\n")) if (l.startsWith("supersedes ")) return l.slice("supersedes ".length);
  return undefined;
}

/** True when a policy note has the text of policy `p`, so its ID. */
function sameText(note: Uint8Array, p: Policy): boolean {
  try {
    return equalBytes(sha256(parseNote(note).text), p.idHash);
  } catch {
    return false;
  }
}

export interface DiscoveryResult {
  /** The successors applied by this document, in order. */
  applied: PolicyEpoch[];
  /** The quorum time of the document's events checkpoint, under the
   * resulting history, when it meets the quorum. */
  readThrough?: number;
  /** Rejected candidates and equivocations this document showed. */
  reasons: Reason[];
}

/** The verified parts of one policy entry. */
interface EntryProof {
  tp: TlogProof;
  entry: Entry;
  statement: Uint8Array;
}

function entryProof(e: PolicyProofEntry, n: number): EntryProof {
  let tp: TlogProof;
  try {
    tp = parseTlogProof(e.proof);
  } catch (x) {
    return bad("proof", { entry: n, cause: toReason(x).code });
  }
  if (!tp.extra) bad("extra", { entry: n });
  let entry: Entry;
  try {
    entry = parseEntry(tp.extra!);
    if (entry.tag !== EVENTS_TAG) bad("entry-tag", { entry: n });
    checkLayout(entry);
  } catch (x) {
    if (x instanceof VerifyError && x.code === "bad-policy-proofs") throw x;
    return bad("entry", { entry: n, cause: toReason(x).code });
  }
  if (fieldText(entry, "kind") !== "policy") bad("entry-kind", { entry: n });
  const statement = fieldValue(entry, "statement");
  if (!statement || statement.length === 0) bad("entry-statement", { entry: n });
  return { tp, entry, statement: statement! };
}

/** True when `e`'s consistency block proves `cp` a prefix of `served`. */
function provesPrefix(e: PolicyProofEntry, cp: Checkpoint, served: Checkpoint): boolean {
  if (e.from !== cp.size || e.to !== served.size || e.from > e.to) return false;
  let proof: Uint8Array[];
  try {
    proof = parseHashLines(e.consistency, MAX_CONSISTENCY_HASHES);
  } catch {
    return false;
  }
  if (e.from === e.to) return proof.length === 0 && equalBytes(cp.root, served.root);
  return verifyConsistency(e.from, e.to, proof, cp.root, served.root);
}

/** A checkpoint note that the document shows to be a prefix of its events
 * checkpoint, so it contains every entry below its size. */
interface Prefix {
  note: string | Uint8Array;
  size: bigint;
}

/** The document's events checkpoint, and every entry checkpoint whose
 * consistency block proves it a prefix of that one. */
function provenPrefixes(doc: PolicyProofs, served: Checkpoint): Prefix[] {
  const out: Prefix[] = [{ note: doc.checkpoint, size: served.size }];
  for (const e of doc.entries) {
    try {
      const note = parseTlogProof(e.proof).checkpoint;
      const cp = parseCheckpointText(parseNote(note).text);
      if (provesPrefix(e, cp, served)) out.push({ note, size: cp.size });
    } catch {
      // Not a checkpoint: it dates nothing.
    }
  }
  return out;
}

/** Checks that one entry is in the events log at its index, against a
 * checkpoint that meets `x`'s quorum, and that the document's checkpoint
 * extends it. Returns T_c (rule 3): the entry's sequencing time under `x`,
 * the earliest quorum time under `x`'s quorum among the checkpoints the
 * document holds that contain the entry (specs/receipt.md, section 1.3). A
 * witness can skip a checkpoint, so that needn't be the entry's own. */
function entryTime(
  h: PolicyHistory,
  xi: number,
  keysOf: KeysOf,
  ep: EntryProof,
  e: PolicyProofEntry,
  served: Checkpoint,
  prefixes: readonly Prefix[],
  deviceNow: number,
  n: number,
): number {
  const keys = keysOf(h.epochs[xi]!.policy);
  if (!keys) return bad("log", { entry: n });
  const opts = keys.logTime ? { logTime: keys.logTime } : {};
  let c: CheckedCheckpoint;
  try {
    c = verifyCheckpoint(ep.tp.checkpoint, keys.signer, keys.set, deviceNow, opts);
  } catch (x) {
    return bad("entry-checkpoint", { entry: n, cause: toReason(x).code });
  }
  let tc = keys.set.quorumTime(h.counting(xi, keysOf, c.cosigs));
  if (tc === undefined) return bad("entry-quorum", { entry: n });
  const size = c.cp.size;
  if (ep.tp.index >= size || !verifyInclusion(ep.tp.index, size, leafHash(ep.tp.extra!), ep.tp.proof, c.cp.root)) bad("entry-inclusion", { entry: n });
  if (e.from !== size || e.to !== served.size || e.from > e.to) bad("consistency-sizes", { entry: n });
  if (!provesPrefix(e, c.cp, served)) bad("consistency", { entry: n });
  for (const p of prefixes) {
    if (p.size <= ep.tp.index) continue;
    try {
      const pc = verifyCheckpoint(p.note, keys.signer, keys.set, deviceNow, opts);
      const qt = keys.set.quorumTime(h.counting(xi, keysOf, pc.cosigs));
      if (qt !== undefined && qt < tc) tc = qt;
    } catch {
      // Not signed with x's keys: it doesn't date the entry under x.
    }
  }
  return tc;
}

/** Applies the successors that a `vitrine/policy-proofs/v1` document proves
 * (rule 7), all or nothing: a damaged document throws `bad-policy-proofs`
 * and changes nothing. The first entry, in log order, whose policy
 * supersedes the latest policy X with X's signatures is X's only candidate
 * (rule 6); if it breaks a rule, X has no successor. A later such entry with
 * another policy is reported as `policy-equivocation`. `deviceNow` is the
 * device clock, for cosignatures in the future. */
export function applyPolicyProofs(h: PolicyHistory, input: Uint8Array | string, deviceNow: number): DiscoveryResult {
  const doc = parsePolicyProofs(input);
  const log = h.latest.policy.logs.get(doc.log);
  if (!log || !log.profiles.some((p) => p.tag === EVENTS_TAG)) bad("log");
  const keysOf = logKeys(doc.log);
  let served: Checkpoint;
  try {
    served = parseCheckpointText(parseNote(doc.checkpoint).text);
  } catch (x) {
    return bad("checkpoint", { cause: toReason(x).code });
  }
  const prefixes = provenPrefixes(doc, served);
  const cur = h.clone();
  const applied: PolicyEpoch[] = [];
  const reasons: Reason[] = [];
  doc.entries.forEach((e, n) => {
    const ep = entryProof(e, n);
    const sup = supersedesOf(ep.statement);
    if (sup === undefined) return;
    const xi = cur.indexOf(sup);
    if (xi < 0) return;
    const x = cur.epochs[xi]!.policy;
    // Rule 6: only an entry with X's signatures is a candidate.
    if (!authorizedBy(x, ep.statement)) return;
    const next = cur.epochs[xi + 1];
    if (next || cur.frozen.has(x.id)) {
      // X already has its one candidate: another policy is equivocation.
      if (next && sameText(ep.statement, next.policy)) return;
      entryTime(cur, xi, keysOf, ep, e, served, prefixes, deviceNow, n);
      reasons.push(reason("policy-equivocation", { policy: x.id, entry: Number(ep.tp.index) }));
      return;
    }
    const tc = entryTime(cur, xi, keysOf, ep, e, served, prefixes, deviceNow, n);
    try {
      let y: Policy;
      try {
        y = parsePolicy(ep.statement);
      } catch (x2) {
        throw new VerifyError("successor-rejected", { rule: 1, detail: toReason(x2).code });
      }
      // Rule 3: the entry's subject is the hash of the policy ID.
      if (!equalBytes(fieldValue(ep.entry, "subject")!, concat(Uint8Array.of(1), y.idHash))) {
        throw new VerifyError("successor-rejected", { rule: 3, detail: "subject" });
      }
      applied.push(cur.apply(y, tc, ep.tp.index));
    } catch (x2) {
      if (!(x2 instanceof VerifyError) || x2.code !== "successor-rejected") throw x2;
      cur.frozen.add(x.id);
      reasons.push(reason("successor-rejected", { ...(x2.params ?? {}), policy: x.id, entry: Number(ep.tp.index) }));
    }
  });
  // The document's checkpoint, judged under the history it led to.
  let judged: Judged<CheckedCheckpoint>;
  try {
    judged = judgeCheckpoint(cur, doc.checkpoint, keysOf, deviceNow);
  } catch (x) {
    return bad("checkpoint", { cause: toReason(x).code });
  }
  const out: DiscoveryResult = { applied, reasons };
  if (judged.meets) {
    out.readThrough = judged.quorumTime!;
    cur.readThrough = Math.max(cur.readThrough ?? Number.NEGATIVE_INFINITY, judged.quorumTime!);
  }
  cur.reasons.push(...reasons);
  h.adopt(cur);
  return out;
}

/** True when the policy has an events log, so that successors can exist and
 * discovery is needed before tiers are reported (rule 7). */
export function needsDiscovery(p: Policy): boolean {
  return [...p.logs.values()].some((l) => l.profiles.some((pr) => pr.tag === EVENTS_TAG));
}

/** The events log of a policy, by name (the first one when several exist). */
export function eventsLogName(p: Policy): string | undefined {
  for (const l of p.logs.values()) if (l.profiles.some((pr) => pr.tag === EVENTS_TAG)) return l.name;
  return undefined;
}
