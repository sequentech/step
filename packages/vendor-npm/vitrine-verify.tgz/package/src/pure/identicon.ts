// SPDX-License-Identifier: Apache-2.0
//
// Receipt words and the identicon (specs/receipt.md, section 5).

import type { Identicon } from "../types.js";
import { wordsFromBits, type WordsLang } from "./words.js";

function checkLeaf(leaf: Uint8Array): void {
  if (!(leaf instanceof Uint8Array) || leaf.length !== 32) throw new TypeError("a leaf hash is 32 bytes");
}

/** The four receipt words: the first 44 bits of the leaf hash, 11 bits per
 * word, most significant first, in the policy's `words` language. */
export function receiptWordsFor(leaf: Uint8Array, lang: WordsLang): string[] {
  checkLeaf(leaf);
  return wordsFromBits(leaf, 4, lang);
}

/** The identicon of a leaf hash `h`: hue `(h[0] * 256 + h[1]) mod 360`,
 * saturation 65 %, lightness 45 %; bit `j` (most significant first) of
 * `h[2..]` fills row `j div 3`, column `j mod 3`, for `j` below 15; columns 3
 * and 4 mirror columns 1 and 0. */
export function identicon(leaf: Uint8Array): Identicon {
  checkLeaf(leaf);
  const hue = ((leaf[0]! << 8) | leaf[1]!) % 360;
  const cells: boolean[] = new Array<boolean>(25).fill(false);
  for (let j = 0; j < 15; j++) {
    const bit = (leaf[2 + (j >>> 3)]! >>> (7 - (j & 7))) & 1;
    cells[Math.floor(j / 3) * 5 + (j % 3)] = bit === 1;
  }
  for (let r = 0; r < 5; r++) {
    cells[r * 5 + 3] = cells[r * 5 + 1]!;
    cells[r * 5 + 4] = cells[r * 5]!;
  }
  return { hue, saturation: 65, lightness: 45, cells };
}
