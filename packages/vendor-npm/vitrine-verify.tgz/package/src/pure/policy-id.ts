// SPDX-License-Identifier: Apache-2.0
//
// Showing a policy ID (specs/policy.md, section 1): the SHA-256 in
// `sha256:<hex>` as a ballot's full Tracking ID is shown (specs/entry.md,
// section 4.1), 13 groups of four Crockford base32 characters, and its short
// form of the first four groups (80 bits). A draft's draft hash is shown the
// same way; the tool labels it as a draft's. Written from the spec; no I/O.

import { hexDecode } from "./base64.js";
import { parseTrackingPrefix, trackingId, TRACKING_ID_LENGTH, type TrackingPrefix } from "./tracking.js";

/** Groups in the short policy ID. */
export const POLICY_SHORT_GROUPS = 4;
/** Characters in the short policy ID, without hyphens: 16, or 80 bits. */
export const POLICY_SHORT_LENGTH = POLICY_SHORT_GROUPS * 4;

/** The 32 bytes of a policy ID: given as `sha256:<64 lowercase hex>` (the
 * form of links and pins), as the 32 bytes, or as the 64 hex digits alone.
 * Throws a TypeError for anything else. */
function hashOf(id: string | Uint8Array): Uint8Array {
  if (typeof id !== "string") {
    if (id.length !== 32) throw new TypeError("a policy ID is 32 bytes");
    return id;
  }
  const hex = id.startsWith("sha256:") ? id.slice(7) : id;
  if (!/^[0-9a-f]{64}$/.test(hex)) throw new TypeError("a policy ID is sha256: and 64 lowercase hex digits");
  return hexDecode(hex, 32);
}

/** A policy ID in 13 groups of four joined by `-`, such as
 * `WEGH-F4YX-6MP1-3TFH-GCKR-5N4Y-EC1G-9ASR-7Q2C-FPT4-MPCY-Q3Q3-TFVG`. For a
 * draft, which has no policy ID, give its draft hash (a draft's `Policy.id`
 * is `sha256:` and that hash). */
export function policyIdDisplay(id: string | Uint8Array): string {
  return trackingId(hashOf(id));
}

/** The short policy ID: the first four groups of {@link policyIdDisplay}, 80
 * bits, such as `WEGH-F4YX-6MP1-3TFH`. It is a name people compare, not a
 * check; tools compare all 256 bits. Always label it ("Policy ID"). */
export function shortPolicyId(id: string | Uint8Array): string {
  return policyIdDisplay(id).split("-").slice(0, POLICY_SHORT_GROUPS).join("-");
}

/** What a person typed where a Tracking ID is expected, if it can only be a
 * policy ID's start: at least the first four groups (16 characters), at most
 * all 52. Case and hyphens are ignored, `I` and `L` read as `1`, `O` as `0`.
 * Returns the parsed prefix, or `undefined` for input that isn't one. */
export function parsePolicyIdPrefix(typed: string): TrackingPrefix | undefined {
  let p: TrackingPrefix;
  try {
    p = parseTrackingPrefix(typed);
  } catch {
    return undefined;
  }
  return p.chars.length >= POLICY_SHORT_LENGTH && p.chars.length <= TRACKING_ID_LENGTH ? p : undefined;
}

/** Whether what was typed is this policy's ID: its first four groups or
 * more, read as a Tracking ID is. Shorter input, and input that is not the
 * start of this ID, is not. */
export function policyIdMatches(typed: string, id: string | Uint8Array): boolean {
  const p = parsePolicyIdPrefix(typed);
  if (!p) return false;
  let shown: string;
  try {
    shown = policyIdDisplay(id).replaceAll("-", "");
  } catch {
    return false;
  }
  return shown.startsWith(p.chars);
}
