// SPDX-License-Identifier: Apache-2.0
//
// Signed statements that logs and auditors serve outside entries
// (specs/entry.md, sections 5.7 and 5.8): policy acknowledgements, signed by
// a log key, and audit attestations, signed by a policy auditor.

import type { ReasonCode } from "../codes.js";
import { b64decode, b64encode } from "./base64.js";
import { equalBytes, parseDecimal, u64ToNumber } from "./bytes.js";
import type { Checkpoint } from "./checkpoint.js";
import { fail, VerifyError } from "./errors.js";
import { parseNote, verifyNote, type Note } from "./note.js";
import { isReservedOrigin, type Policy, type PolicyLog } from "./policy.js";

export const POLICY_ACK_HEADER = "vitrine/policy-ack/v1";
export const ATTESTATION_HEADER = "vitrine/audit-attestation/v1";

const POLICY_ID_RE = /^sha256:[0-9a-f]{64}$/;

/** The values of a statement's `<key> <value>` lines (specs/entry.md,
 * section 5): every key once, in order, and no other line. Throws `code`. */
export function statementValues(text: string, header: string, keys: readonly string[], code: ReasonCode): string[] {
  if (!text.endsWith("\n")) fail(code, { detail: "no-final-newline" });
  const lines = text.slice(0, -1).split("\n");
  if (lines[0] !== header) fail(code, { detail: "header" });
  if (lines.length !== keys.length + 1) fail(code, { detail: "lines" });
  return keys.map((k, i) => {
    const l = lines[i + 1]!;
    if (!l.startsWith(`${k} `)) fail(code, { detail: `line-${k}` });
    return l.slice(k.length + 1);
  });
}

/** Runs `f`, turning another VerifyError it throws into `code`, with the
 * other code as `detail`. */
export function asCode<T>(code: ReasonCode, f: () => T): T {
  try {
    return f();
  } catch (e) {
    if (e instanceof VerifyError && e.code !== code) throw new VerifyError(code, { detail: e.code });
    throw e;
  }
}

export interface PolicyAck {
  origin: string;
  policy: string;
  time: number;
  note: Note;
}

/** Parses a `vitrine/policy-ack/v1` note. */
export function parsePolicyAck(input: Uint8Array | string): PolicyAck {
  return asCode("bad-policy-ack", () => {
    const note = parseNote(input);
    const [origin, policy, time] = statementValues(note.text, POLICY_ACK_HEADER, ["origin", "policy", "time"], "bad-policy-ack") as [string, string, string];
    if (isReservedOrigin(origin)) fail("bad-policy-ack", { detail: "reserved-origin" });
    if (!POLICY_ID_RE.test(policy)) fail("bad-policy-ack", { detail: "policy" });
    return { origin, policy, time: u64ToNumber(parseDecimal(time)), note };
  });
}

/** The route, under the log's prefix, that serves the log's acknowledgement
 * of `policyId`: `policy-ack/<hex>`, the ID without `sha256:` (section 5.7). */
export function policyAckPath(policyId: string): string {
  if (!POLICY_ID_RE.test(policyId)) throw new TypeError("not a policy ID");
  return `policy-ack/${policyId.slice("sha256:".length)}`;
}

/** Verifies that `input` is `log`'s acknowledgement of policy `policyId`:
 * its `origin` is the log's, its `policy` is `policyId`, and it verifies with
 * the log key (specs/entry.md, section 5.7; specs/evidence.md, section 1). */
export function verifyPolicyAck(input: Uint8Array | string, log: Pick<PolicyLog, "origin" | "vkey">, policyId: string): PolicyAck {
  const ack = parsePolicyAck(input);
  if (ack.origin !== log.origin) fail("bad-policy-ack", { detail: "origin" });
  if (ack.policy !== policyId) fail("bad-policy-ack", { detail: "policy" });
  if (!verifyNote(ack.note, [log.vkey]).some((v) => v.vkey === log.vkey)) fail("bad-policy-ack", { detail: "signature" });
  return ack;
}

/** A policy-ack note's text (for tools and tests). */
export function formatPolicyAckText(origin: string, policyId: string, time: number): string {
  return `${POLICY_ACK_HEADER}\norigin ${origin}\npolicy ${policyId}\ntime ${time}\n`;
}

export interface Attestation {
  policy: string;
  /** The private log's origin. */
  log: string;
  /** The hub's origin. */
  hub: string;
  from: bigint;
  to: bigint;
  /** Size and root of the checkpoint that the anchor with `seq` `to` opens. */
  size: bigint;
  root: Uint8Array;
  time: number;
  note: Note;
}

/** Parses a `vitrine/audit-attestation/v1` note. */
export function parseAttestation(input: Uint8Array | string): Attestation {
  return asCode("bad-attestation", () => {
    const note = parseNote(input);
    const v = statementValues(note.text, ATTESTATION_HEADER, ["policy", "log", "hub", "from", "to", "size", "root", "time"], "bad-attestation");
    const [policy, log, hub, from, to, size, root, time] = v as [string, string, string, string, string, string, string, string];
    if (!POLICY_ID_RE.test(policy)) fail("bad-attestation", { detail: "policy" });
    if (isReservedOrigin(log) || isReservedOrigin(hub)) fail("bad-attestation", { detail: "reserved-origin" });
    const a: Attestation = {
      policy,
      log,
      hub,
      from: parseDecimal(from),
      to: parseDecimal(to),
      size: parseDecimal(size),
      root: b64decode(root, 32),
      time: u64ToNumber(parseDecimal(time)),
      note,
    };
    if (a.from < 1n || a.from > a.to) fail("bad-attestation", { detail: "from-to" });
    return a;
  });
}

export interface VerifiedAttestation extends Attestation {
  /** The first auditor whose key verified it, in the policy the attestation
   * names. */
  auditor: string;
  /** Every auditor whose key verified it, in the policy's order. */
  auditors: string[];
}

/** Verifies an attestation: its `policy` is one `policyFor` knows (the pinned
 * policy or an accepted successor), and it verifies with an `auditor` key of
 * that policy (specs/receipt.md, section 3.3, step 4). */
export function verifyAttestation(input: Uint8Array | string, policyFor: (id: string) => Pick<Policy, "auditors"> | undefined): VerifiedAttestation {
  const a = parseAttestation(input);
  const p = policyFor(a.policy);
  if (!p) fail("bad-attestation", { detail: "policy-unknown" });
  const auditors = [...p.auditors.values()];
  const verified = verifyNote(
    a.note,
    auditors.map((x) => x.vkey),
  );
  const signers = auditors.filter((x) => verified.some((v) => v.vkey === x.vkey)).map((x) => x.name);
  if (signers.length === 0) fail("bad-attestation", { detail: "signature" });
  return { ...a, auditor: signers[0]!, auditors: signers };
}

/** Whether attestation `a` covers the opening of blinded anchor `seq` of the
 * log with origin `logOrigin` in the hub with origin `hubOrigin`, whose opened
 * checkpoint is `opened` (specs/receipt.md, section 3.3, step 4): `covers`;
 * `not-covering`, when `seq` is outside its range; or what contradicts it. */
export function attestationCovers(
  a: Attestation,
  logOrigin: string,
  hubOrigin: string,
  seq: bigint,
  opened: Pick<Checkpoint, "size" | "root">,
): "covers" | "not-covering" | { contradiction: string } {
  if (a.log !== logOrigin) return { contradiction: "log" };
  if (a.hub !== hubOrigin) return { contradiction: "hub" };
  if (seq < a.from || seq > a.to) return "not-covering";
  if (seq === a.to && (a.size !== opened.size || !equalBytes(a.root, opened.root))) return { contradiction: "size-root" };
  return "covers";
}

/** An attestation note's text (for tools and tests). */
export function formatAttestationText(a: Omit<Attestation, "note">): string {
  return `${ATTESTATION_HEADER}\npolicy ${a.policy}\nlog ${a.log}\nhub ${a.hub}\nfrom ${a.from}\nto ${a.to}\nsize ${a.size}\nroot ${b64encode(a.root)}\ntime ${a.time}\n`;
}
