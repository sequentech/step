// SPDX-License-Identifier: Apache-2.0
//
// Vitrine trust policies (specs/policy.md): parsing, the validation rules of
// section 3, authority signatures, the policy ID and the policy words.

import { b64decode, hexDecode, hexEncode } from "./base64.js";
import { fromUtf8, parseDecimal, utf8 } from "./bytes.js";
import { Ed25519Key } from "./ed25519.js";
import { fail, VerifyError } from "./errors.js";
import { isValidId, isValidTag } from "./entry.js";
import { sha256 } from "./hash.js";
import { parseNote, parseVkey, SIG_COSIGNATURE_V1, SIG_ED25519, verifyNote, type Note, type Vkey } from "./note.js";
import { WitnessSet, type Group, type Witness } from "./quorum.js";
import { isWordsLang, wordsFromBits, type WordsLang } from "./words.js";

/** A policy is at most 64 KiB. */
export const MAX_POLICY_SIZE = 65536;
export const POLICY_HEADER = "vitrine/policy/v1";

export interface Authority {
  name: string;
  vkey: Vkey;
}

export interface Threshold {
  k: number;
  names: string[];
}

export interface ProfileLine {
  tag: string;
  meaningHash: string;
  from: bigint;
}

export interface PolicyLog {
  name: string;
  vkey: Vkey;
  /** The log's origin: its key name. */
  origin: string;
  url?: string;
  mirrors: string[];
  profiles: ProfileLine[];
  params: Map<string, string[]>;
  entries: "public" | "restricted";
  blinded?: { pseudoOrigin: string; vkey: Vkey };
  keysAuthority?: Threshold;
}

export interface Monitor {
  name: string;
  vkey: Vkey;
  url: string;
  party: string;
}

export interface PolicyHub {
  name: string;
  vkey: Vkey;
  origin: string;
  url: string;
  operator: string;
  set: WitnessSet;
  bootstrap: boolean;
  /** The domain of its WAICT manifests. */
  domain?: string;
}

export interface WaictWitness {
  name: string;
  key: Uint8Array;
  ed: Ed25519Key;
}

export interface WaictService {
  domain: string;
  hubs: string[];
  operator: string;
  witnesses: WaictWitness[];
  quorum: number;
}

export interface Policy {
  /** The whole policy note. */
  note: string;
  /** The note text, without signatures. */
  text: string;
  /** `sha256:<lowercase hex>` */
  id: string;
  /** The SHA-256 in the ID. */
  idHash: Uint8Array;
  name: string;
  visibility: "public" | "private";
  required: boolean;
  strict: boolean;
  /** True when a `strict` line is present. */
  strictGiven: boolean;
  quiet: number;
  policySalt?: Uint8Array;
  operator: string;
  authorities: Map<string, Authority>;
  sign: Threshold;
  redaction?: Threshold;
  auditors: Map<string, Authority>;
  mmd: number;
  cosignMax: number;
  epoch: number;
  opens?: number;
  closes?: number;
  supersedes?: string;
  effective?: number;
  words: WordsLang;
  releases: { log: string; package: string; version: string }[];
  sites: { origin: string; package: string }[];
  logs: Map<string, PolicyLog>;
  witnesses: WitnessSet;
  monitors: Map<string, Monitor>;
  monitorQuorum: number;
  hubs: Map<string, PolicyHub>;
  anchorPeriod: number;
  anchorMaxGap: number;
  anchorHubs?: { min: number; minIndependent: number };
  browserPeriod?: number;
  waict: Map<string, WaictService>;
  /** Authorities whose signatures on this policy verified. */
  signedBy: string[];
  /** Split costs (specs/policy.md, section 3, rule 5). */
  splitCost: { app: number; hubs: Map<string, number> };
}

export interface ParsePolicyOptions {
  /** Require the `sign` threshold of valid authority signatures (default true). */
  requireSignatures?: boolean;
}

const NAME_RE = /^[A-Za-z0-9._-]{1,64}$/;
const HASH_ID_RE = /^sha256:[0-9a-f]{64}$/;
const DOMAIN_RE = /^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/;
const DEV_HOSTS = new Set(["localhost", "127.0.0.1", "[::1]"]);

class LineError extends Error {}

function syntax(line: number, detail: string): never {
  throw new VerifyError("policy-syntax", { line, detail });
}

/** The policy's pseudo-origin for a private log (specs/hub.md, section 1). */
export function pseudoOrigin(origin: string, salt: Uint8Array): string {
  return hexEncode(sha256("vitrine/origin/v1", origin, salt));
}

function isUrl(s: string): boolean {
  let u: URL;
  try {
    u = new URL(s);
  } catch {
    return false;
  }
  if (u.username !== "" || u.password !== "") return false;
  if (u.protocol === "https:") return u.hostname !== "";
  if (u.protocol === "http:") return DEV_HOSTS.has(u.hostname);
  return false;
}

function isWebOrigin(s: string): boolean {
  if (!isUrl(s)) return false;
  const u = new URL(s);
  return u.origin === s;
}

/** Parses and validates a policy note. Throws VerifyError with a `policy-*`
 * code (or a note/key code) when it isn't valid. */
export function parsePolicy(input: string | Uint8Array, opts: ParsePolicyOptions = {}): Policy {
  const bytes = typeof input === "string" ? utf8(input) : input;
  if (bytes.length > MAX_POLICY_SIZE) fail("too-large", { what: "policy", limit: MAX_POLICY_SIZE });
  const note: Note = parseNote(bytes);
  const p = new PolicyParser(note).run();
  p.note = typeof input === "string" ? input : fromUtf8(bytes);
  const verified = verifyNote(
    note,
    [...p.authorities.values()].map((a) => a.vkey),
  );
  const signedBy = new Set<string>();
  for (const v of verified) {
    for (const a of p.authorities.values()) if (a.vkey === v.vkey) signedBy.add(a.name);
  }
  p.signedBy = [...signedBy];
  const have = p.sign.names.filter((n) => signedBy.has(n)).length;
  if ((opts.requireSignatures ?? true) && have < p.sign.k) fail("policy-unsigned", { have, need: p.sign.k });
  return p;
}

/** The six policy words (specs/policy.md, section 1). */
export function policyWords(p: Policy): string[] {
  return wordsFromBits(p.idHash, 6, p.words);
}

/** The profile line of `log` in force at `index`. */
export function profileAt(log: PolicyLog, index: bigint | undefined): ProfileLine {
  let cur = log.profiles[0]!;
  if (index === undefined) return log.profiles[log.profiles.length - 1]!;
  for (const pr of log.profiles) if (pr.from <= index) cur = pr;
  return cur;
}

/** The app hubs: the hubs not named by `bootstrap`. */
export function appHubs(p: Policy): PolicyHub[] {
  return [...p.hubs.values()].filter((h) => !h.bootstrap);
}

/** The quiet period `[start, closes]`, if the policy has one. */
export function quietPeriod(p: Policy): { start: number; end: number } | undefined {
  if (p.closes === undefined) return undefined;
  if (p.strict && p.opens !== undefined) return { start: p.opens, end: p.closes };
  if (p.quiet > 0) return { start: p.closes - p.quiet, end: p.closes };
  return undefined;
}

class PolicyParser {
  private readonly text: string;
  private line = 0;
  private readonly seen = new Map<string, number>();
  private readonly p: Partial<Policy> & {
    authorities: Map<string, Authority>;
    auditors: Map<string, Authority>;
    logs: Map<string, PolicyLog>;
    monitors: Map<string, Monitor>;
    hubs: Map<string, PolicyHub>;
    waict: Map<string, WaictService>;
    releases: { log: string; package: string; version: string }[];
    sites: { origin: string; package: string }[];
    witnesses: WitnessSet;
  };
  private readonly witnessParty = new Set<string>();
  private readonly monitorParty = new Set<string>();
  private readonly hubWitnessParty = new Set<string>();
  private readonly memberUse = new Map<WitnessSet, Set<string>>();
  private readonly hubDomainSet = new Set<string>();
  private readonly allKeys = new Set<string>();
  private readonly bootstrapSet = new Set<string>();
  private readonly entriesSet = new Set<string>();
  private readonly releaseLines: { log: string; line: number }[] = [];
  private monitorQuorumGiven: number | undefined;
  private anchorGiven = false;
  private hasBlinded = false;

  constructor(private readonly note: Note) {
    this.text = note.text;
    this.p = {
      authorities: new Map(),
      auditors: new Map(),
      logs: new Map(),
      monitors: new Map(),
      hubs: new Map(),
      waict: new Map(),
      releases: [],
      sites: [],
      witnesses: new WitnessSet(),
    };
  }

  run(): Policy {
    const lines = this.text.slice(0, -1).split("\n");
    if (lines[0] !== POLICY_HEADER) syntax(1, "header");
    for (let i = 1; i < lines.length; i++) {
      this.line = i + 1;
      const l = lines[i]!;
      if (l === "" || l.startsWith("#")) continue;
      const toks = l.split(" ");
      if (toks.some((t) => t === "")) syntax(this.line, "spacing");
      try {
        this.handle(toks[0]!, toks.slice(1));
      } catch (e) {
        if (e instanceof LineError) syntax(this.line, e.message);
        if (e instanceof VerifyError && !e.code.startsWith("policy-")) {
          throw new VerifyError("policy-syntax", { line: this.line, detail: e.code });
        }
        throw e;
      }
    }
    return this.finish();
  }

  // -- helpers --------------------------------------------------------------

  private once(key: string): void {
    const n = (this.seen.get(key) ?? 0) + 1;
    this.seen.set(key, n);
    if (n > 1) fail("policy-count", { line: this.line, keyword: key.split("\u0000")[0]! });
  }

  private arity(args: string[], min: number, max: number = min): void {
    if (args.length < min || args.length > max) throw new LineError("arguments");
  }

  private name(s: string): string {
    if (!NAME_RE.test(s)) throw new LineError("name");
    return s;
  }

  private num(s: string, min = 0, max = Number.MAX_SAFE_INTEGER): number {
    let v: bigint;
    try {
      v = parseDecimal(s, BigInt(Number.MAX_SAFE_INTEGER));
    } catch {
      throw new LineError("number");
    }
    const n = Number(v);
    if (n < min || n > max) throw new LineError("number-range");
    return n;
  }

  private onOff(s: string): boolean {
    if (s === "on") return true;
    if (s === "off") return false;
    throw new LineError("on-off");
  }

  private url(s: string): string {
    if (!isUrl(s)) throw new LineError("url");
    return s;
  }

  /** Parses a vkey of `type`. Every key in a policy is distinct, whatever
   * its role (crypto review), so a key can't count twice in a quorum. */
  private vkey(s: string, type: number): Vkey {
    const v = parseVkey(s, [type]);
    this.uniqueKey(v.key, v.name);
    return v;
  }

  private uniqueKey(key: Uint8Array, name: string): void {
    const k = hexEncode(key);
    if (this.allKeys.has(k)) this.duplicate(name.slice(0, 64));
    this.allKeys.add(k);
  }

  private undefinedName(name: string): never {
    throw new VerifyError("policy-undefined-name", { line: this.line, name });
  }

  private duplicate(name: string): never {
    throw new VerifyError("policy-duplicate-name", { line: this.line, name });
  }

  private log(name: string): PolicyLog {
    return this.p.logs.get(name) ?? this.undefinedName(name);
  }

  private hub(name: string): PolicyHub {
    return this.p.hubs.get(name) ?? this.undefinedName(name);
  }

  private service(domain: string): WaictService {
    return this.p.waict.get(domain) ?? this.undefinedName(domain);
  }

  private threshold(args: string[], pool: Map<string, unknown>): Threshold {
    if (args.length < 2) throw new LineError("arguments");
    const names = args.slice(1);
    for (const n of names) if (!pool.has(n)) this.undefinedName(n);
    if (new Set(names).size !== names.length) this.duplicate(names.join(" "));
    const k = this.num(args[0]!, 1, names.length);
    return { k, names };
  }

  private addWitness(set: WitnessSet, name: string, vkey: Vkey, url: string | undefined): void {
    if (name === "none") throw new LineError("reserved-name");
    if (set.witnesses.has(name) || set.groups.has(name)) this.duplicate(name);
    const w: Witness = { name, vkey, party: name, partyGiven: false };
    if (url !== undefined) w.url = url;
    set.witnesses.set(name, w);
  }

  private addGroup(set: WitnessSet, args: string[]): void {
    if (args.length < 3) throw new LineError("arguments");
    const name = this.name(args[0]!);
    if (name === "none") throw new LineError("reserved-name");
    if (set.witnesses.has(name) || set.groups.has(name)) this.duplicate(name);
    const members = args.slice(2);
    let used = this.memberUse.get(set);
    if (!used) {
      used = new Set();
      this.memberUse.set(set, used);
    }
    for (const m of members) {
      if (!set.witnesses.has(m) && !set.groups.has(m)) this.undefinedName(m);
      if (used.has(m)) this.duplicate(m);
      used.add(m);
    }
    const t = args[1]!;
    const k = t === "any" ? 1 : t === "all" ? members.length : this.num(t, 1, members.length);
    const g: Group = { name, k, members };
    set.groups.set(name, g);
  }

  private setQuorum(set: WitnessSet, name: string): void {
    if (name === "none") throw new VerifyError("policy-invalid", { line: this.line, rule: 4 });
    if (!set.witnesses.has(name) && !set.groups.has(name)) this.undefinedName(name);
    set.quorum = name;
  }

  // -- lines ----------------------------------------------------------------

  private handle(kw: string, a: string[]): void {
    const p = this.p;
    switch (kw) {
      // 2.1 Event
      case "name":
        this.arity(a, 1);
        this.once(kw);
        if (!isValidId(a[0]!)) throw new LineError("id");
        p.name = a[0]!;
        return;
      case "visibility":
        this.arity(a, 1);
        this.once(kw);
        if (a[0] !== "public" && a[0] !== "private") throw new LineError("visibility");
        p.visibility = a[0];
        return;
      case "required":
        this.arity(a, 1);
        this.once(kw);
        p.required = this.onOff(a[0]!);
        return;
      case "strict":
        this.arity(a, 1);
        this.once(kw);
        p.strict = this.onOff(a[0]!);
        p.strictGiven = true;
        return;
      case "quiet":
        this.arity(a, 1);
        this.once(kw);
        p.quiet = this.num(a[0]!);
        return;
      case "policy-salt":
        this.arity(a, 1);
        this.once(kw);
        try {
          p.policySalt = hexDecode(a[0]!, 32);
        } catch {
          throw new LineError("policy-salt");
        }
        return;
      case "operator":
        this.arity(a, 1);
        this.once(kw);
        p.operator = this.name(a[0]!);
        return;
      case "authority": {
        this.arity(a, 2);
        const name = this.name(a[0]!);
        if (p.authorities.has(name)) this.duplicate(name);
        const vkey = this.vkey(a[1]!, SIG_ED25519);
        p.authorities.set(name, { name, vkey });
        return;
      }
      case "sign":
        this.once(kw);
        p.sign = this.threshold(a, p.authorities);
        return;
      case "redaction":
        this.once(kw);
        p.redaction = this.threshold(a, p.authorities);
        return;
      case "auditor": {
        this.arity(a, 2);
        const name = this.name(a[0]!);
        if (p.auditors.has(name)) this.duplicate(name);
        p.auditors.set(name, { name, vkey: this.vkey(a[1]!, SIG_ED25519) });
        return;
      }
      case "mmd":
        this.arity(a, 1);
        this.once(kw);
        p.mmd = this.num(a[0]!, 0, 3600);
        return;
      case "cosign-max":
        this.arity(a, 1);
        this.once(kw);
        p.cosignMax = this.num(a[0]!, 1);
        return;
      case "epoch":
        this.arity(a, 1);
        this.once(kw);
        p.epoch = this.num(a[0]!, 1);
        return;
      case "opens":
        this.arity(a, 1);
        this.once(kw);
        p.opens = this.num(a[0]!);
        return;
      case "closes":
        this.arity(a, 1);
        this.once(kw);
        p.closes = this.num(a[0]!);
        return;
      case "supersedes":
        this.arity(a, 1);
        this.once(kw);
        if (!HASH_ID_RE.test(a[0]!)) throw new LineError("policy-id");
        p.supersedes = a[0]!;
        return;
      case "effective":
        this.arity(a, 1);
        this.once(kw);
        p.effective = this.num(a[0]!);
        return;
      case "words":
        this.arity(a, 1);
        this.once(kw);
        if (!isWordsLang(a[0]!)) throw new LineError("words");
        p.words = a[0];
        return;
      case "release":
        this.arity(a, 3);
        this.name(a[0]!);
        if (!isValidId(a[1]!) || !isValidId(a[2]!)) throw new LineError("id");
        p.releases.push({ log: a[0]!, package: a[1]!, version: a[2]! });
        this.releaseLines.push({ log: a[0]!, line: this.line });
        return;
      case "site":
        this.arity(a, 2);
        if (!isWebOrigin(a[0]!)) throw new LineError("origin");
        if (!isValidId(a[1]!)) throw new LineError("id");
        p.sites.push({ origin: a[0]!, package: a[1]! });
        return;

      // 2.2 Logs
      case "log": {
        this.arity(a, 2, 3);
        const name = this.name(a[0]!);
        if (p.logs.has(name)) this.duplicate(name);
        const vkey = this.vkey(a[1]!, SIG_ED25519);
        const log: PolicyLog = {
          name,
          vkey,
          origin: vkey.name,
          mirrors: [],
          profiles: [],
          params: new Map(),
          entries: "public",
        };
        if (a[2] !== undefined) log.url = this.url(a[2]);
        p.logs.set(name, log);
        return;
      }
      case "mirror":
        this.arity(a, 2);
        this.log(a[0]!).mirrors.push(this.url(a[1]!));
        return;
      case "profile": {
        if (a.length !== 3 && a.length !== 5) throw new LineError("arguments");
        const log = this.log(a[0]!);
        if (!isValidTag(a[1]!)) throw new LineError("tag");
        if (!HASH_ID_RE.test(a[2]!)) throw new LineError("meaning-hash");
        let from = 0n;
        if (a.length === 5) {
          if (a[3] !== "from") throw new LineError("from");
          try {
            from = parseDecimal(a[4]!);
          } catch {
            throw new LineError("number");
          }
        }
        const prev = log.profiles[log.profiles.length - 1];
        if (!prev && from !== 0n) throw new VerifyError("policy-invalid", { line: this.line, rule: 2 });
        if (prev && from <= prev.from) throw new VerifyError("policy-invalid", { line: this.line, rule: 2 });
        log.profiles.push({ tag: a[1]!, meaningHash: a[2]!, from });
        return;
      }
      case "param": {
        if (a.length < 3) throw new LineError("arguments");
        const log = this.log(a[0]!);
        const pname = this.name(a[1]!);
        if (log.params.has(pname)) this.duplicate(pname);
        log.params.set(pname, a.slice(2));
        return;
      }
      case "entries": {
        this.arity(a, 2);
        const log = this.log(a[0]!);
        if (this.entriesSet.has(log.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.entriesSet.add(log.name);
        if (a[1] !== "public" && a[1] !== "restricted") throw new LineError("entries");
        log.entries = a[1];
        return;
      }
      case "blinded": {
        this.arity(a, 3);
        const log = this.log(a[0]!);
        if (log.blinded) fail("policy-count", { line: this.line, keyword: kw });
        if (!/^[0-9a-f]{64}$/.test(a[1]!)) throw new LineError("pseudo-origin");
        log.blinded = { pseudoOrigin: a[1]!, vkey: this.vkey(a[2]!, SIG_ED25519) };
        this.hasBlinded = true;
        return;
      }
      case "keys-authority": {
        if (a.length < 3) throw new LineError("arguments");
        const log = this.log(a[0]!);
        if (log.keysAuthority) fail("policy-count", { line: this.line, keyword: kw });
        log.keysAuthority = this.threshold(a.slice(1), p.authorities);
        return;
      }

      // 2.3 Witnesses
      case "witness":
        this.arity(a, 2, 3);
        this.addWitness(
          p.witnesses,
          this.name(a[0]!),
          this.vkey(a[1]!, SIG_COSIGNATURE_V1),
          a[2] === undefined ? undefined : this.url(a[2]),
        );
        return;
      case "witness-party": {
        this.arity(a, 2);
        const w = p.witnesses.witnesses.get(a[0]!) ?? this.undefinedName(a[0]!);
        if (this.witnessParty.has(w.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.witnessParty.add(w.name);
        w.party = this.name(a[1]!);
        w.partyGiven = true;
        return;
      }
      case "group":
        this.addGroup(p.witnesses, a);
        return;
      case "quorum":
        this.arity(a, 1);
        this.once(kw);
        this.setQuorum(p.witnesses, a[0]!);
        return;

      // 2.4 Monitors
      case "monitor": {
        this.arity(a, 3);
        const name = this.name(a[0]!);
        if (p.monitors.has(name)) this.duplicate(name);
        p.monitors.set(name, { name, vkey: this.vkey(a[1]!, SIG_ED25519), url: this.url(a[2]!), party: name });
        return;
      }
      case "monitor-quorum":
        this.arity(a, 1);
        this.once(kw);
        this.monitorQuorumGiven = this.num(a[0]!, 1);
        return;
      case "monitor-party": {
        this.arity(a, 2);
        const m = p.monitors.get(a[0]!) ?? this.undefinedName(a[0]!);
        if (this.monitorParty.has(m.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.monitorParty.add(m.name);
        m.party = this.name(a[1]!);
        return;
      }

      // 2.5 Hubs
      case "hub": {
        this.arity(a, 3);
        const name = this.name(a[0]!);
        if (p.hubs.has(name)) this.duplicate(name);
        const vkey = this.vkey(a[1]!, SIG_ED25519);
        p.hubs.set(name, {
          name,
          vkey,
          origin: vkey.name,
          url: this.url(a[2]!),
          operator: "",
          set: new WitnessSet(),
          bootstrap: false,
        });
        return;
      }
      case "hub-operator": {
        this.arity(a, 2);
        const h = this.hub(a[0]!);
        this.once(`${kw}\u0000${h.name}`);
        h.operator = this.name(a[1]!);
        return;
      }
      case "hub-witness": {
        this.arity(a, 3, 4);
        const h = this.hub(a[0]!);
        this.addWitness(
          h.set,
          this.name(a[1]!),
          this.vkey(a[2]!, SIG_COSIGNATURE_V1),
          a[3] === undefined ? undefined : this.url(a[3]),
        );
        return;
      }
      case "hub-witness-party": {
        this.arity(a, 3);
        const h = this.hub(a[0]!);
        const w = h.set.witnesses.get(a[1]!) ?? this.undefinedName(a[1]!);
        const key = `${h.name}\u0000${w.name}`;
        if (this.hubWitnessParty.has(key)) fail("policy-count", { line: this.line, keyword: kw });
        this.hubWitnessParty.add(key);
        w.party = this.name(a[2]!);
        w.partyGiven = true;
        return;
      }
      case "hub-group": {
        if (a.length < 1) throw new LineError("arguments");
        const h = this.hub(a[0]!);
        this.addGroup(h.set, a.slice(1));
        return;
      }
      case "hub-quorum": {
        this.arity(a, 2);
        const h = this.hub(a[0]!);
        this.once(`${kw}\u0000${h.name}`);
        this.setQuorum(h.set, a[1]!);
        return;
      }
      case "anchor":
        this.arity(a, 2);
        this.once(kw);
        p.anchorPeriod = this.num(a[0]!, 1);
        p.anchorMaxGap = this.num(a[1]!, 1);
        this.anchorGiven = true;
        return;
      case "anchor-hubs":
        this.arity(a, 2);
        this.once(kw);
        p.anchorHubs = { min: this.num(a[0]!), minIndependent: this.num(a[1]!) };
        return;
      case "bootstrap": {
        this.arity(a, 1);
        const h = this.hub(a[0]!);
        if (this.bootstrapSet.has(h.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.bootstrapSet.add(h.name);
        h.bootstrap = true;
        return;
      }

      // 2.6 Browser layer
      case "browser":
        this.arity(a, 1);
        this.once(kw);
        p.browserPeriod = this.num(a[0]!, 1);
        return;
      case "hub-domain": {
        this.arity(a, 2);
        const h = this.hub(a[0]!);
        if (this.hubDomainSet.has(h.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.hubDomainSet.add(h.name);
        if (!DOMAIN_RE.test(a[1]!)) throw new LineError("domain");
        h.domain = a[1]!;
        return;
      }
      case "waict": {
        if (a.length < 2) throw new LineError("arguments");
        const domain = a[0]!;
        if (!DOMAIN_RE.test(domain)) throw new LineError("domain");
        if (p.waict.has(domain)) this.duplicate(domain);
        const hubs = a.slice(1);
        for (const h of hubs) this.hub(h);
        if (new Set(hubs).size !== hubs.length) this.duplicate(hubs.join(" "));
        p.waict.set(domain, { domain, hubs, operator: "", witnesses: [], quorum: 0 });
        return;
      }
      case "waict-operator": {
        this.arity(a, 2);
        const s = this.service(a[0]!);
        this.once(`${kw}\u0000${s.domain}`);
        s.operator = this.name(a[1]!);
        return;
      }
      case "waict-witness": {
        this.arity(a, 3);
        const s = this.service(a[0]!);
        const name = this.name(a[1]!);
        if (s.witnesses.some((w) => w.name === name)) this.duplicate(name);
        let key: Uint8Array;
        try {
          key = b64decode(a[2]!, 32);
        } catch {
          throw new LineError("waict-key");
        }
        this.uniqueKey(key, name);
        const ed = Ed25519Key.parse(key);
        if (!ed) fail("bad-public-key");
        s.witnesses.push({ name, key, ed });
        return;
      }
      case "waict-quorum": {
        this.arity(a, 2);
        const s = this.service(a[0]!);
        this.once(`${kw}\u0000${s.domain}`);
        s.quorum = this.num(a[1]!, 1);
        return;
      }
      default:
        fail("policy-unknown-keyword", { line: this.line, keyword: kw.slice(0, 64) });
    }
  }

  // -- section 3 ------------------------------------------------------------

  private finish(): Policy {
    const p = this.p;
    this.line = 0;
    const missing = (keyword: string): never => fail("policy-count", { keyword });
    const rule = (n: number, detail?: string): never =>
      fail("policy-invalid", detail === undefined ? { rule: n } : { rule: n, detail });
    if (p.name === undefined) missing("name");
    if (p.visibility === undefined) missing("visibility");
    if (p.operator === undefined) missing("operator");
    if (p.authorities.size === 0) missing("authority");
    if (p.sign === undefined) missing("sign");
    if (p.mmd === undefined) missing("mmd");
    if (p.logs.size === 0) missing("log");
    if (p.witnesses.quorum === "") missing("quorum");
    const priv = p.visibility === "private";

    // Rule 1, deferred part: `release` may name a log defined later (as the
    // example in section 6 does).
    for (const r of this.releaseLines) {
      if (!p.logs.has(r.log)) fail("policy-undefined-name", { line: r.line, name: r.log });
    }

    // Rule 2
    for (const log of p.logs.values()) {
      if (log.profiles.length === 0) rule(2, `profile:${log.name}`);
    }
    for (const h of p.hubs.values()) {
      if (h.operator === "") rule(2, `hub-operator:${h.name}`);
      if (h.set.quorum === "") rule(2, `hub-quorum:${h.name}`);
      if (h.set.witnesses.size === 0) rule(2, `hub-witness:${h.name}`);
    }
    for (const s of p.waict.values()) {
      if (s.operator === "") rule(2, `waict-operator:${s.domain}`);
      if (s.quorum === 0) rule(2, `waict-quorum:${s.domain}`);
      if (s.witnesses.length === 0) rule(2, `waict-witness:${s.domain}`);
      if (s.quorum > s.witnesses.length) rule(2, `waict-quorum:${s.domain}`);
      for (const h of s.hubs) if (p.hubs.get(h)!.domain === undefined) rule(2, `hub-domain:${h}`);
    }

    // Rule 3
    const origins = new Set<string>();
    for (const o of [...[...p.logs.values()].map((l) => l.origin), ...[...p.hubs.values()].map((h) => h.origin)]) {
      if (o.startsWith("vitrine/")) rule(3, "reserved-origin");
      if (origins.has(o)) fail("policy-duplicate-name", { name: o });
      origins.add(o);
    }

    // Rule 5: quorum safety
    const appCost = p.witnesses.splitCost(new Set([p.operator!]));
    if (appCost < 1) fail("policy-unsafe-quorum", { quorum: p.witnesses.quorum, splitCost: appCost });
    const hubCosts = new Map<string, number>();
    for (const h of p.hubs.values()) {
      const c = h.set.splitCost(new Set([p.operator!, h.operator]));
      if (c < 1) fail("policy-unsafe-quorum", { hub: h.name, quorum: h.set.quorum, splitCost: c });
      hubCosts.set(h.name, c);
    }

    // Rule 6
    const app = [...p.hubs.values()].filter((h) => !h.bootstrap);
    if (p.anchorHubs) {
      const independent = app.filter((h) => h.operator !== p.operator).length;
      if (app.length < p.anchorHubs.min || independent < p.anchorHubs.minIndependent) rule(6, "anchor-hubs");
    }
    for (const b of p.hubs.values()) {
      if (!b.bootstrap) continue;
      if (b.operator === p.operator) rule(6, `bootstrap:${b.name}`);
      for (const h of app) if (h.operator === b.operator) rule(6, `bootstrap:${b.name}`);
    }

    // Rule 7
    if (priv) {
      if (!p.policySalt) rule(7, "policy-salt");
      if (p.auditors.size === 0) rule(7, "auditor");
      for (const log of p.logs.values()) {
        if (app.length > 0 && !log.blinded) rule(7, `blinded:${log.name}`);
        if (log.blinded && log.blinded.pseudoOrigin !== pseudoOrigin(log.origin, p.policySalt!)) {
          rule(7, `pseudo-origin:${log.name}`);
        }
      }
    } else {
      if (p.policySalt) rule(7, "policy-salt");
      if (this.hasBlinded) rule(7, "blinded");
    }

    // Defaults
    p.required ??= true;
    p.strictGiven ??= false;
    p.strict ??= priv;
    p.quiet ??= 0;
    p.cosignMax ??= 10;
    p.epoch ??= 600;
    p.words ??= "en";
    if (!this.anchorGiven) {
      p.anchorPeriod = 10;
      p.anchorMaxGap = 60;
    }
    if (p.browserPeriod === undefined && p.waict.size > 0) p.browserPeriod = 600;

    // Rule 8
    if (p.strictGiven && p.strict && (p.opens === undefined || p.closes === undefined)) rule(8, "strict");
    if (p.quiet > 0 && p.closes === undefined) rule(8, "quiet");
    if (this.seen.has("quiet") && p.closes === undefined) rule(8, "quiet");

    // Rule 9
    for (const log of p.logs.values()) {
      if (log.keysAuthority && !log.profiles.some((pr) => pr.tag === "vitrine/keys/v1")) rule(9, `keys-authority:${log.name}`);
    }
    if (this.monitorQuorumGiven !== undefined && this.monitorQuorumGiven > p.monitors.size) rule(9, "monitor-quorum");
    p.monitorQuorum = this.monitorQuorumGiven ?? Math.min(2, p.monitors.size);

    // Rule 10
    if (!priv) {
      for (const log of p.logs.values()) {
        if (log.profiles.some((pr) => pr.tag === "vitrine/election/v1") && log.mirrors.length === 0) {
          rule(10, `mirror:${log.name}`);
        }
      }
    }

    // Rule 11
    if (p.opens !== undefined && p.closes !== undefined && !(p.opens < p.closes)) rule(11, "opens-closes");
    if (p.effective !== undefined && p.opens !== undefined && !(p.effective > p.opens)) rule(11, "effective");
    if (p.opens !== undefined && p.closes !== undefined && p.quiet > p.closes - p.opens) rule(11, "quiet");

    const idHash = sha256(this.note.textBytes);
    const policy: Policy = {
      note: "",
      text: this.text,
      id: `sha256:${hexEncode(idHash)}`,
      idHash,
      name: p.name!,
      visibility: p.visibility!,
      required: p.required,
      strict: p.strict,
      strictGiven: p.strictGiven,
      quiet: p.quiet,
      operator: p.operator!,
      authorities: p.authorities,
      sign: p.sign!,
      auditors: p.auditors,
      mmd: p.mmd!,
      cosignMax: p.cosignMax,
      epoch: p.epoch,
      words: p.words,
      releases: p.releases,
      sites: p.sites,
      logs: p.logs,
      witnesses: p.witnesses,
      monitors: p.monitors,
      monitorQuorum: p.monitorQuorum,
      hubs: p.hubs,
      anchorPeriod: p.anchorPeriod!,
      anchorMaxGap: p.anchorMaxGap!,
      waict: p.waict,
      signedBy: [],
      splitCost: { app: appCost, hubs: hubCosts },
    };
    if (p.policySalt) policy.policySalt = p.policySalt;
    if (p.redaction) policy.redaction = p.redaction;
    if (p.opens !== undefined) policy.opens = p.opens;
    if (p.closes !== undefined) policy.closes = p.closes;
    if (p.supersedes !== undefined) policy.supersedes = p.supersedes;
    if (p.effective !== undefined) policy.effective = p.effective;
    if (p.anchorHubs) policy.anchorHubs = p.anchorHubs;
    if (p.browserPeriod !== undefined) policy.browserPeriod = p.browserPeriod;
    return policy;
  }
}
