// SPDX-License-Identifier: Apache-2.0
//
// Vitrine trust policies (specs/policy.md): parsing, drafts and sealing
// (section 1), the validation rules of section 3 with split costs and party
// split costs, authority signatures, the policy ID, the `platform`, `contact`
// and `checker` lines, and the successor rules of section 4.

import { b64decode, hexDecode, hexEncode } from "./base64.js";
import { equalBytes, fromUtf8, parseDecimal, utf8 } from "./bytes.js";
import { isDomain } from "./domain.js";
import { Ed25519Key } from "./ed25519.js";
import { fail, VerifyError } from "./errors.js";
import { isPlainText, isValidId, isValidTag } from "./entry.js";
import { sha256 } from "./hash.js";
import { parseNote, parseVkey, SIG_COSIGNATURE_V1, SIG_ED25519, verifyNote, type Note, type Vkey } from "./note.js";
import { partySplitCostOf, splitCostOf, WitnessSet, type Group, type QuorumShape, type Witness } from "./quorum.js";
import { ELECTION_TAG, EVENTS_TAG, KEYS_TAG, isEventsTag } from "./tags.js";

/** A policy is at most 64 KiB. */
export const MAX_POLICY_SIZE = 65536;
export const POLICY_HEADER = "vitrine/policy/v1";
/** `skew` default and maximum (specs/policy.md, section 2.1). */
export const DEFAULT_SKEW = 30;
export const MAX_SKEW = 300;
/** The seal's random bytes. */
export const SEAL_BYTES = 16;
/** A successor logged later than this before `opens` takes effect at least
 * this long after it was logged (section 4, rule 4). */
export const SUCCESSOR_DELAY = 86400;

export interface Authority {
  name: string;
  vkey: Vkey;
}

export interface Threshold {
  k: number;
  names: string[];
}

export interface ProfileLine {
  tag: string;
  meaningHash: string;
  from: bigint;
}

export interface PolicyMirror {
  url: string;
  /** Who runs it: the `mirror-party` line's party, else the operator. */
  party: string;
}

export interface SharedLogPin { name: string; policyId: string; url: string }

export interface PolicyLog {
  name: string;
  vkey: Vkey;
  /** The log's origin: its key name. */
  origin: string;
  /** The `log-time` key, a 0x04 cosigner key whose name is the origin. */
  logTime: Vkey;
  url?: string;
  mirrors: PolicyMirror[];
  profiles: ProfileLine[];
  params: Map<string, string[]>;
  entries: "public" | "restricted";
  blinded?: { pseudoOrigin: string; vkey: Vkey };
  keysAuthority?: Threshold;
}

export interface Monitor {
  name: string;
  vkey: Vkey;
  url: string;
  party: string;
  /** The `monitor-explorer` line: base URL of an explorer (informational). */
  explorer?: string;
}

export interface PolicyHub {
  name: string;
  vkey: Vkey;
  origin: string;
  url: string;
  operator: string;
  set: WitnessSet;
  bootstrap: boolean;
  /** The domain of its WAICT manifests. */
  domain?: string;
  /** The `hub-explorer` line: base URL of an explorer (informational). */
  explorer?: string;
}

export interface WaictWitness {
  name: string;
  key: Uint8Array;
  ed: Ed25519Key;
  /** Who runs it; its own name when the policy gives no party. */
  party: string;
}

export interface WaictService {
  domain: string;
  hubs: string[];
  operator: string;
  witnesses: WaictWitness[];
  quorum: number;
}

/** Split costs or party split costs of every quorum (section 3, rules 5 and
 * 12), with each quorum's faulty parties counted as faulty. */
export interface QuorumCosts {
  app: number;
  hubs: Map<string, number>;
  waict: Map<string, number>;
}

/** The `contact` lines (section 2.1): how voters reach the election
 * authority. Each kind has at most one line. */
export interface PolicyContact {
  /** The authority's name as people know it: 1 to 128 bytes of text. */
  name?: string;
  /** An ASCII email address. */
  email?: string;
  /** `+` and 7 to 15 digits. */
  phone?: string;
  /** An absolute `https` URL. */
  url?: string;
}

/** A `checker <purpose> <package> <sha256:hex>` line (section 2.1): the
 * checker that hub sites and explorers run in the browser. */
export interface PolicyChecker {
  /** What it checks: `results`, the only purpose defined. */
  purpose: "results";
  /** The package whose logged release holds the module. */
  package: string;
  /** `sha256:` and the lowercase hex SHA-256 of the checker's WASM module. */
  hash: string;
}

/** The kinds of `contact` line, in the order tools show them. */
export const CONTACT_KINDS = ["name", "email", "phone", "url"] as const;
/** The checker purposes. */
export const CHECKER_PURPOSES = ["results"] as const;
/** The longest `contact name` and `contact email`, in bytes. */
export const MAX_CONTACT_NAME = 128;
export const MAX_CONTACT_EMAIL = 254;

export interface Policy {
  /** The whole policy note (for a draft given without signatures, its text). */
  note: string;
  /** The note text, without signatures. */
  text: string;
  /** `sha256:<lowercase hex>` of the note text. A draft has no policy ID:
   * for one, this is `sha256:` and the hex of its draft hash, which only
   * labels it. */
  id: string;
  /** The SHA-256 in the ID. */
  idHash: Uint8Array;
  /** The draft hash (section 1): the SHA-256 of the lines other than empty,
   * comment and `seal` lines, each ending in a newline. A draft and the
   * policy sealed from it have the same draft hash. */
  draftHash: Uint8Array;
  /** True for an unsealed draft, which is never valid (section 1). */
  draft: boolean;
  /** The `seal` line: the sealing authority and its 16 bytes. */
  seal?: { authority: string; bytes: Uint8Array };
  name: string;
  visibility: "public" | "private";
  required: boolean;
  strict: boolean;
  /** True when a `strict` line is present. */
  strictGiven: boolean;
  quiet: number;
  policySalt?: Uint8Array;
  operator: string;
  /** The `platform` line (section 2.1): the party whose software runs the
   * deployment. Its witnesses count as faulty, like the operator's. */
  platform?: string;
  /** The `contact` lines. */
  contact: PolicyContact;
  /** The `checker` lines. */
  checkers: PolicyChecker[];
  minFaults: number;
  authorities: Map<string, Authority>;
  sign: Threshold;
  redaction?: Threshold;
  auditors: Map<string, Authority>;
  mmd: number;
  skew: number;
  cosignMax: number;
  epoch: number;
  opens?: number;
  closes?: number;
  supersedes?: string;
  effective?: number;
  retire: string[];
  releases: { log: string; package: string; version: string }[];
  sites: { origin: string; package: string }[];
  /** Discovery pins; structural parsing never implies list validation. */
  operatorList?: string;
  sharedLogs: Map<string, SharedLogPin>;
  /** The `explorer` lines: base URLs of the operator's own explorers
   * (informational; verifiers never trust them). */
  explorers: string[];
  logs: Map<string, PolicyLog>;
  witnesses: WitnessSet;
  monitors: Map<string, Monitor>;
  monitorQuorum: number;
  hubs: Map<string, PolicyHub>;
  anchorPeriod: number;
  anchorMaxGap: number;
  anchorHubs?: { min: number; minIndependent: number };
  /** `browser <period>`, default 600 (specs/policy.md, section 2.6). */
  browserPeriod: number;
  waict: Map<string, WaictService>;
  /** Authorities whose signatures on this policy verified. */
  signedBy: string[];
  /** True when the signatures make the policy valid: at least `sign`'s
   * threshold of the authorities it lists, the sealing authority among them. */
  signed: boolean;
  splitCost: QuorumCosts;
  partySplitCost: QuorumCosts;
}

export interface ParsePolicyOptions {
  /** Require the signatures that make a sealed policy valid (default true). */
  requireSignatures?: boolean;
  /** Accept an unsealed draft, with or without signatures (default false).
   * A draft is never valid: verifiers refuse it. */
  allowDraft?: boolean;
}

const NAME_RE = /^[A-Za-z0-9._-]{1,64}$/;
const HASH_ID_RE = /^sha256:[0-9a-f]{64}$/;
const DEV_HOSTS = new Set(["localhost", "127.0.0.1", "[::1]"]);
const RESERVED_ORIGIN_PREFIXES = ["vitrine/", "cosignature/"];

/** True for an origin no log or hub may have: one that starts with
 * `vitrine/` or `cosignature/` (specs/entry.md, section 1, domain
 * separation, rule 2). */
export function isReservedOrigin(origin: string): boolean {
  return RESERVED_ORIGIN_PREFIXES.some((x) => origin.startsWith(x));
}

/** The group name of a WAICT service's k-of-n quorum (not a valid name). */
const WAICT_GROUP = "\u0000waict";
/** A hub declaration has at most this many witnesses (rule 16). */
const MAX_HUB_WITNESSES = 31;
/** Steps of the anchor-hubs search (rule 6) before it gives up. */
const ANCHOR_HUBS_SEARCH_LIMIT = 1_000_000;

class LineError extends Error {}

function syntax(line: number, detail: string): never {
  throw new VerifyError("policy-syntax", { line, detail });
}

/** The policy's pseudo-origin for a private log (specs/hub.md, section 1). */
export function pseudoOrigin(origin: string, salt: Uint8Array): string {
  return hexEncode(sha256("vitrine/origin/v1", origin, salt));
}

function isUrl(s: string): boolean {
  let u: URL;
  try {
    u = new URL(s);
  } catch {
    return false;
  }
  if (u.username !== "" || u.password !== "") return false;
  if (u.protocol === "https:") return u.hostname !== "";
  if (u.protocol === "http:") return DEV_HOSTS.has(u.hostname);
  return false;
}

function isWebOrigin(s: string): boolean {
  if (!isUrl(s)) return false;
  const u = new URL(s);
  return u.origin === s;
}

const isIgnorable = (l: string): boolean => l === "" || l.startsWith("#");
const isSealLine = (l: string): boolean => l === "seal" || l.startsWith("seal ");

/** The text whose SHA-256 is the draft hash (section 1). */
function draftText(lines: readonly string[]): string {
  return lines
    .filter((l) => !isIgnorable(l) && !isSealLine(l))
    .map((l) => `${l}\n`)
    .join("");
}

/** The draft hash of a policy text or note (section 1), which witnesses'
 * proofs of possession name: the SHA-256 of its lines other than empty,
 * comment and `seal` lines, each ending in a newline. */
export function draftHashOf(input: string | Uint8Array): Uint8Array {
  const bytes = typeof input === "string" ? utf8(input) : input;
  let text: string;
  try {
    text = parseNote(bytes).text;
  } catch {
    text = fromUtf8(bytes);
  }
  const body = text.endsWith("\n") ? text.slice(0, -1) : text;
  return sha256(draftText(body.split("\n")));
}

/** Splits a policy input into its note (or, for a draft given without
 * signatures, a bare text). */
function noteOf(bytes: Uint8Array, allowDraft: boolean): Note {
  try {
    return parseNote(bytes);
  } catch (e) {
    if (!allowDraft) throw e;
    // A draft without signatures: the whole input is its text.
    const text = fromUtf8(bytes);
    if (!text.endsWith("\n") || !text.startsWith(`${POLICY_HEADER}\n`)) throw e;
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      if (c < 0x20 && c !== 0x0a) fail("bad-text", { detail: "control-character" });
    }
    return { text, textBytes: bytes, sigs: [] };
  }
}

/** Parses and validates a policy note. Throws VerifyError with a `policy-*`
 * code (or a note/key code) when it isn't valid; a draft throws
 * `policy-draft` unless `allowDraft` is set. */
export function parsePolicy(input: string | Uint8Array, opts: ParsePolicyOptions = {}): Policy {
  const bytes = typeof input === "string" ? utf8(input) : input;
  if (bytes.length > MAX_POLICY_SIZE) fail("too-large", { what: "policy", limit: MAX_POLICY_SIZE });
  const note = noteOf(bytes, opts.allowDraft ?? false);
  const lines = note.text.slice(0, -1).split("\n");
  const sealed = lines.some(isSealLine);
  if (!sealed && !opts.allowDraft) fail("policy-draft");
  const p = new PolicyParser(note.text, lines, sealed).run();
  p.note = typeof input === "string" ? input : fromUtf8(bytes);
  const signedBy = new Set<string>();
  const verified = verifyNote(
    note,
    [...p.authorities.values()].map((a) => a.vkey),
  );
  for (const v of verified) {
    for (const a of p.authorities.values()) if (a.vkey === v.vkey) signedBy.add(a.name);
  }
  p.signedBy = [...signedBy];
  const have = p.sign.names.filter((n) => signedBy.has(n)).length;
  p.signed = !p.draft && have >= p.sign.k && p.seal !== undefined && signedBy.has(p.seal.authority);
  if (!p.draft && (opts.requireSignatures ?? true) && !p.signed) {
    fail("policy-unsigned", { have, need: p.sign.k, ...(p.seal && !signedBy.has(p.seal.authority) ? { sealer: p.seal.authority } : {}) });
  }
  return p;
}

/** The profile line of `log` in force at `index`. */
export function profileAt(log: PolicyLog, index: bigint | undefined): ProfileLine {
  let cur = log.profiles[0]!;
  if (index === undefined) return log.profiles[log.profiles.length - 1]!;
  for (const pr of log.profiles) if (pr.from <= index) cur = pr;
  return cur;
}

/** The app hubs: the hubs not named by `bootstrap`. */
export function appHubs(p: Pick<Policy, "hubs">): PolicyHub[] {
  return [...p.hubs.values()].filter((h) => !h.bootstrap);
}

/** The quiet period `[start, end]`, if the policy has one (section 2.1). */
export function quietPeriod(p: Policy): { start: number; end: number } | undefined {
  if (p.closes === undefined) return undefined;
  if (p.strict && p.opens !== undefined) return { start: p.opens, end: p.closes };
  if (p.quiet > 0) return { start: p.closes - p.quiet, end: p.closes };
  return undefined;
}

/** True when `t` falls in the policy's quiet period. */
export function inQuietPeriod(p: Policy, t: number): boolean {
  const q = quietPeriod(p);
  return q !== undefined && t >= q.start && t <= q.end;
}

/** The policy's `events` logs: those with a `vitrine/events/v1` profile. */
export function eventsLogs(p: Policy): PolicyLog[] {
  return [...p.logs.values()].filter((l) => l.profiles.some((pr) => isEventsTag(pr.tag)));
}

/** The quorum shape of a WAICT service: one k-of-n group of its witnesses. */
export function waictShape(s: WaictService): QuorumShape {
  return {
    witnesses: new Map(s.witnesses.map((w) => [w.name, { party: w.party }])),
    groups: new Map<string, Group>([[WAICT_GROUP, { name: WAICT_GROUP, k: s.quorum, members: s.witnesses.map((w) => w.name) }]]),
    quorum: WAICT_GROUP,
  };
}

/** A hub's parties: its operator and its witnesses' parties (rule 6). */
function hubParties(h: PolicyHub): Set<string> {
  return new Set([h.operator, ...[...h.set.witnesses.values()].map((w) => w.party)]);
}

/** The parties whose witnesses are faulty in every quorum (section 3, rule
 * 5): the operator, and the platform when the policy has one. */
export function faultyParties(p: Pick<Policy, "operator" | "platform">): string[] {
  return p.platform === undefined ? [p.operator] : [p.operator, p.platform];
}

/** True when two hubs are independent of each other (section 3, rule 6). */
export function hubsIndependent(p: Pick<Policy, "operator" | "platform">, a: PolicyHub, b: PolicyHub): boolean {
  if (a.operator === b.operator) return false;
  const pa = hubParties(a);
  const shared = [...hubParties(b)].filter((x) => pa.has(x));
  for (const h of [a, b]) {
    const faulty = new Set([...faultyParties(p), h.operator, ...shared]);
    if (h.set.splitCost(faulty) < 1) return false;
  }
  return true;
}

/** True when the app hubs include `min` hubs that are pairwise independent
 * of each other, `minIndependent` of them independent (rule 6). Retired
 * hubs, when given, don't count. Throws when the search is too large. */
export function anchorHubsHold(
  p: Pick<Policy, "operator" | "platform" | "hubs">,
  min: number,
  minIndependent: number,
  retired: ReadonlySet<string> = new Set(),
): boolean {
  const hubs = appHubs(p).filter((h) => !retired.has(h.name));
  const m = Math.max(min, minIndependent);
  if (m <= 0) return true;
  if (hubs.length < m) return false;
  // A hub is independent when it is run by neither the operator nor the platform.
  const base = faultyParties(p);
  const indep = hubs.map((h) => !base.includes(h.operator));
  const pair = hubs.map((a) => hubs.map((b) => a !== b && hubsIndependent(p, a, b)));
  let steps = 0;
  const chosen: number[] = [];
  const search = (from: number, independents: number): boolean => {
    if (++steps > ANCHOR_HUBS_SEARCH_LIMIT) fail("policy-invalid", { rule: 6, detail: "anchor-hubs-search" });
    if (chosen.length === m) return independents >= minIndependent;
    // Not enough hubs left, or not enough independent ones can be added.
    if (hubs.length - from < m - chosen.length) return false;
    for (let i = from; i < hubs.length; i++) {
      if (!chosen.every((j) => pair[j]![i])) continue;
      chosen.push(i);
      const ok = search(i + 1, independents + (indep[i] ? 1 : 0));
      chosen.pop();
      if (ok) return true;
    }
    return false;
  };
  return search(0, 0);
}

/** A `contact email` (section 3, rule 19): ASCII `local@domain`, at most 254
 * bytes. */
function isContactEmail(s: string): boolean {
  if (s.length > MAX_CONTACT_EMAIL || !/^[\x00-\x7f]*$/.test(s)) return false;
  const at = s.indexOf("@");
  if (at < 0 || s.indexOf("@", at + 1) >= 0) return false;
  const local = s.slice(0, at);
  const labels = s.slice(at + 1).split(".");
  if (local.length < 1 || local.length > 64 || !/^[A-Za-z0-9._%+-]+$/.test(local)) return false;
  if (local.startsWith(".") || local.endsWith(".") || local.includes("..")) return false;
  return labels.length >= 2 && labels.every((l) => /^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/.test(l));
}

class PolicyParser {
  private line = 0;
  private readonly seen = new Map<string, number>();
  private readonly p: Partial<Policy> & {
    authorities: Map<string, Authority>;
    auditors: Map<string, Authority>;
    logs: Map<string, PolicyLog>;
    monitors: Map<string, Monitor>;
    hubs: Map<string, PolicyHub>;
    waict: Map<string, WaictService>;
    releases: { log: string; package: string; version: string }[];
    sites: { origin: string; package: string }[];
    witnesses: WitnessSet;
    retire: string[];
    sharedLogs: Map<string, SharedLogPin>;
    explorers: string[];
  };
  private readonly witnessParty = new Set<string>();
  private readonly monitorParty = new Set<string>();
  private readonly monitorExplorerSet = new Set<string>();
  private readonly hubExplorerSet = new Set<string>();
  private readonly hubWitnessParty = new Set<string>();
  private readonly waictWitnessParty = new Set<string>();
  private readonly memberUse = new Map<WitnessSet, Set<string>>();
  private readonly hubDomainSet = new Set<string>();
  private readonly allKeys = new Set<string>();
  private readonly bootstrapSet = new Set<string>();
  private readonly entriesSet = new Set<string>();
  private readonly logTimes = new Map<string, Vkey>();
  private readonly releaseLines: { log: string; line: number }[] = [];
  private readonly mirrorParties: { log: string; url: string; party: string; line: number }[] = [];
  private monitorQuorumGiven: number | undefined;
  private anchorGiven = false;
  private hasBlinded = false;

  constructor(
    private readonly text: string,
    private readonly lines: string[],
    private readonly sealed: boolean,
  ) {
    this.p = {
      authorities: new Map(),
      auditors: new Map(),
      logs: new Map(),
      monitors: new Map(),
      hubs: new Map(),
      waict: new Map(),
      releases: [],
      sites: [],
      contact: {},
      checkers: [],
      witnesses: new WitnessSet(),
      retire: [],
      sharedLogs: new Map(),
      explorers: [],
    };
  }

  run(): Policy {
    const lines = this.lines;
    if (lines[0] !== POLICY_HEADER) syntax(1, "header");
    for (let i = 1; i < lines.length; i++) {
      this.line = i + 1;
      const l = lines[i]!;
      if (isIgnorable(l)) {
        // Rule 13: a sealed policy has no empty or comment lines.
        if (this.sealed) fail("policy-invalid", { line: this.line, rule: 13, detail: "empty-or-comment" });
        continue;
      }
      const toks = l.split(" ");
      if (toks.some((t) => t === "")) syntax(this.line, "spacing");
      if (toks[0] === "seal" && i !== lines.length - 1) fail("policy-invalid", { line: this.line, rule: 13, detail: "seal-not-last" });
      try {
        this.handle(toks[0]!, toks.slice(1));
      } catch (e) {
        if (e instanceof LineError) syntax(this.line, e.message);
        if (e instanceof VerifyError && !e.code.startsWith("policy-")) {
          throw new VerifyError("policy-syntax", { line: this.line, detail: e.code });
        }
        throw e;
      }
    }
    return this.finish();
  }

  // -- helpers --------------------------------------------------------------

  private once(key: string): void {
    const n = (this.seen.get(key) ?? 0) + 1;
    this.seen.set(key, n);
    if (n > 1) fail("policy-count", { line: this.line, keyword: key.split("\u0000")[0]! });
  }

  private arity(args: string[], min: number, max: number = min): void {
    if (args.length < min || args.length > max) throw new LineError("arguments");
  }

  private name(s: string): string {
    if (!NAME_RE.test(s)) throw new LineError("name");
    if (s === "none") throw new LineError("reserved-name");
    return s;
  }

  private num(s: string, min = 0, max = Number.MAX_SAFE_INTEGER): number {
    let v: bigint;
    try {
      v = parseDecimal(s);
    } catch {
      throw new LineError("number");
    }
    if (v < BigInt(min) || v > BigInt(max)) throw new LineError("number-range");
    return Number(v);
  }

  /** A `contact <kind> <value>` line: a kind has at most one line, and its
   * value follows the kind (section 3, rule 19). */
  private contact(a: string[]): void {
    if (a.length < 2) throw new LineError("arguments");
    const kind = a[0]!;
    if (kind !== "name" && kind !== "email" && kind !== "phone" && kind !== "url") throw new LineError("contact-kind");
    // A name keeps its single spaces; the other kinds have none.
    const value = a.slice(1).join(" ");
    if (kind !== "name" && a.length !== 2) throw new LineError("arguments");
    const contact = this.p.contact!;
    if (contact[kind] !== undefined) fail("policy-count", { line: this.line, keyword: `contact ${kind}` });
    switch (kind) {
      case "name":
        if (utf8(value).length > MAX_CONTACT_NAME || !isPlainText(value)) throw new LineError("contact-name");
        break;
      case "email":
        if (!isContactEmail(value)) throw new LineError("contact-email");
        break;
      case "phone":
        if (!/^\+[1-9][0-9]{6,14}$/.test(value)) throw new LineError("contact-phone");
        break;
      case "url":
        // `https` only: not even localhost may use `http` here.
        if (!isUrl(value) || !value.startsWith("https:")) throw new LineError("contact-url");
        break;
    }
    contact[kind] = value;
  }

  private onOff(s: string): boolean {
    if (s === "on") return true;
    if (s === "off") return false;
    throw new LineError("on-off");
  }

  private url(s: string): string {
    if (!isUrl(s)) throw new LineError("url");
    return s;
  }

  /** Parses a vkey of `type`. No two key lines wrap the same public key,
   * whatever their role (rule 1a), so no key counts twice in a quorum. */
  private vkey(s: string, type: number): Vkey {
    const v = parseVkey(s, [type]);
    this.uniqueKey(v.key, v.name);
    return v;
  }

  private uniqueKey(key: Uint8Array, name: string): void {
    const k = hexEncode(key);
    if (this.allKeys.has(k)) throw new VerifyError("policy-duplicate-name", { line: this.line, name: name.slice(0, 64), rule: "1a" });
    this.allKeys.add(k);
  }

  private undefinedName(name: string): never {
    throw new VerifyError("policy-undefined-name", { line: this.line, name: name.slice(0, 64) });
  }

  private duplicate(name: string): never {
    throw new VerifyError("policy-duplicate-name", { line: this.line, name: name.slice(0, 64) });
  }

  private log(name: string): PolicyLog {
    return this.p.logs.get(name) ?? this.undefinedName(name);
  }

  private hub(name: string): PolicyHub {
    return this.p.hubs.get(name) ?? this.undefinedName(name);
  }

  private service(domain: string): WaictService {
    return this.p.waict.get(domain) ?? this.undefinedName(domain);
  }

  /** `<k> <name>...` over `pool` (rule 9: each listed once, 1 <= k <= n). */
  private threshold(args: string[], pool: Map<string, unknown>): Threshold {
    if (args.length < 2) throw new LineError("arguments");
    const names = args.slice(1);
    for (const n of names) if (!pool.has(n)) this.undefinedName(n);
    if (new Set(names).size !== names.length) this.duplicate(names.join(" "));
    const k = this.num(args[0]!, 1, names.length);
    return { k, names };
  }

  private addWitness(set: WitnessSet, name: string, vkey: Vkey, url: string | undefined): void {
    if (name === "none") throw new LineError("reserved-name");
    if (set.witnesses.has(name) || set.groups.has(name)) this.duplicate(name);
    const w: Witness = { name, vkey, party: name, partyGiven: false };
    if (url !== undefined) w.url = url;
    set.witnesses.set(name, w);
  }

  /** A group (rule 1b: each name is a member of at most one group, at most
   * once, so the groups form a tree). */
  private addGroup(set: WitnessSet, args: string[]): void {
    if (args.length < 3) throw new LineError("arguments");
    const name = this.name(args[0]!);
    if (name === "none") throw new LineError("reserved-name");
    if (set.witnesses.has(name) || set.groups.has(name)) this.duplicate(name);
    const members = args.slice(2);
    let used = this.memberUse.get(set);
    if (!used) {
      used = new Set();
      this.memberUse.set(set, used);
    }
    for (const m of members) {
      if (!set.witnesses.has(m) && !set.groups.has(m)) this.undefinedName(m);
      if (used.has(m)) throw new VerifyError("policy-invalid", { line: this.line, rule: "1b", name: m.slice(0, 64) });
      used.add(m);
    }
    const t = args[1]!;
    const k = t === "any" ? 1 : t === "all" ? members.length : this.num(t, 1, members.length);
    const g: Group = { name, k, members };
    set.groups.set(name, g);
  }

  private setQuorum(set: WitnessSet, name: string): void {
    if (name === "none") throw new VerifyError("policy-invalid", { line: this.line, rule: 4 });
    if (!set.witnesses.has(name) && !set.groups.has(name)) this.undefinedName(name);
    set.quorum = name;
  }

  // -- lines ----------------------------------------------------------------

  private handle(kw: string, a: string[]): void {
    const p = this.p;
    switch (kw) {
      // 2.1 Event
      case "name":
        this.arity(a, 1);
        this.once(kw);
        if (!isValidId(a[0]!)) throw new LineError("id");
        p.name = a[0]!;
        return;
      case "visibility":
        this.arity(a, 1);
        this.once(kw);
        if (a[0] !== "public" && a[0] !== "private") throw new LineError("visibility");
        p.visibility = a[0];
        return;
      case "required":
        this.arity(a, 1);
        this.once(kw);
        p.required = this.onOff(a[0]!);
        return;
      case "strict":
        this.arity(a, 1);
        this.once(kw);
        p.strict = this.onOff(a[0]!);
        p.strictGiven = true;
        return;
      case "quiet":
        this.arity(a, 1);
        this.once(kw);
        p.quiet = this.num(a[0]!);
        return;
      case "policy-salt":
        this.arity(a, 1);
        this.once(kw);
        try {
          p.policySalt = hexDecode(a[0]!, 32);
        } catch {
          throw new LineError("policy-salt");
        }
        return;
      case "operator":
        this.arity(a, 1);
        this.once(kw);
        p.operator = this.name(a[0]!);
        return;
      case "platform":
        this.arity(a, 1);
        this.once(kw);
        p.platform = this.name(a[0]!);
        return;
      case "contact":
        this.contact(a);
        return;
      case "checker": {
        this.arity(a, 3);
        if (a[0] !== "results") throw new LineError("checker-purpose");
        if (!isValidId(a[1]!)) throw new LineError("id");
        if (!HASH_ID_RE.test(a[2]!)) throw new LineError("checker-hash");
        if (p.checkers!.some((c) => c.purpose === a[0])) fail("policy-count", { line: this.line, keyword: kw });
        p.checkers!.push({ purpose: a[0], package: a[1]!, hash: a[2]! });
        return;
      }
      case "min-faults":
        this.arity(a, 1);
        this.once(kw);
        p.minFaults = this.num(a[0]!);
        return;
      case "authority": {
        this.arity(a, 2);
        const name = this.name(a[0]!);
        if (p.authorities.has(name)) this.duplicate(name);
        const vkey = this.vkey(a[1]!, SIG_ED25519);
        p.authorities.set(name, { name, vkey });
        return;
      }
      case "sign":
        this.once(kw);
        p.sign = this.threshold(a, p.authorities);
        return;
      case "redaction":
        this.once(kw);
        p.redaction = this.threshold(a, p.authorities);
        return;
      case "auditor": {
        this.arity(a, 2);
        const name = this.name(a[0]!);
        if (p.auditors.has(name)) this.duplicate(name);
        p.auditors.set(name, { name, vkey: this.vkey(a[1]!, SIG_ED25519) });
        return;
      }
      case "mmd":
        this.arity(a, 1);
        this.once(kw);
        p.mmd = this.num(a[0]!, 0, 3600);
        return;
      case "skew":
        this.arity(a, 1);
        this.once(kw);
        p.skew = this.num(a[0]!);
        return;
      case "cosign-max":
        this.arity(a, 1);
        this.once(kw);
        p.cosignMax = this.num(a[0]!, 1);
        return;
      case "epoch":
        this.arity(a, 1);
        this.once(kw);
        p.epoch = this.num(a[0]!, 1);
        return;
      case "opens":
        this.arity(a, 1);
        this.once(kw);
        p.opens = this.num(a[0]!);
        return;
      case "closes":
        this.arity(a, 1);
        this.once(kw);
        p.closes = this.num(a[0]!);
        return;
      case "supersedes":
        this.arity(a, 1);
        this.once(kw);
        if (!HASH_ID_RE.test(a[0]!)) throw new LineError("policy-id");
        p.supersedes = a[0]!;
        return;
      case "effective":
        this.arity(a, 1);
        this.once(kw);
        p.effective = this.num(a[0]!);
        return;
      case "retire": {
        this.arity(a, 1);
        const name = this.name(a[0]!);
        if (p.retire.includes(name)) throw new VerifyError("policy-invalid", { line: this.line, rule: 15, name });
        p.retire.push(name);
        return;
      }
      case "release":
        this.arity(a, 3);
        this.name(a[0]!);
        if (!isValidId(a[1]!) || !isValidId(a[2]!)) throw new LineError("id");
        p.releases.push({ log: a[0]!, package: a[1]!, version: a[2]! });
        this.releaseLines.push({ log: a[0]!, line: this.line });
        return;
      case "site":
        this.arity(a, 2);
        if (!isWebOrigin(a[0]!)) throw new LineError("origin");
        if (!isValidId(a[1]!)) throw new LineError("id");
        p.sites.push({ origin: a[0]!, package: a[1]! });
        return;
      case "seal": {
        this.arity(a, 2);
        this.once(kw);
        if (!p.authorities.has(a[0]!)) this.undefinedName(a[0]!);
        let bytes: Uint8Array;
        try {
          bytes = b64decode(a[1]!, SEAL_BYTES);
        } catch {
          throw new VerifyError("policy-invalid", { line: this.line, rule: 13, detail: "seal-bytes" });
        }
        p.seal = { authority: a[0]!, bytes };
        return;
      }

      // 2.2 Logs
      case "log": {
        this.arity(a, 2, 3);
        const name = this.name(a[0]!);
        if (p.logs.has(name)) this.duplicate(name);
        const vkey = this.vkey(a[1]!, SIG_ED25519);
        const log: PolicyLog = {
          name,
          vkey,
          origin: vkey.name,
          // Set by the log's `log-time` line; rule 2 checks that it has one.
          logTime: vkey,
          mirrors: [],
          profiles: [],
          params: new Map(),
          entries: "public",
        };
        if (a[2] !== undefined) log.url = this.url(a[2]);
        p.logs.set(name, log);
        return;
      }
      case "log-time": {
        this.arity(a, 2);
        const log = this.log(a[0]!);
        if (this.logTimes.has(log.name)) fail("policy-count", { line: this.line, keyword: kw });
        const vkey = this.vkey(a[1]!, SIG_COSIGNATURE_V1);
        this.logTimes.set(log.name, vkey);
        log.logTime = vkey;
        return;
      }
      case "mirror": {
        this.arity(a, 2);
        const log = this.log(a[0]!);
        const url = this.url(a[1]!);
        if (log.mirrors.some((m) => m.url === url)) this.duplicate(url);
        // The party is the operator's until a mirror-party line says otherwise.
        log.mirrors.push({ url, party: "" });
        return;
      }
      case "mirror-party":
        this.arity(a, 3);
        this.log(a[0]!);
        this.url(a[1]!);
        this.mirrorParties.push({ log: a[0]!, url: a[1]!, party: this.name(a[2]!), line: this.line });
        return;
      case "profile": {
        if (a.length !== 3 && a.length !== 5) throw new LineError("arguments");
        const log = this.log(a[0]!);
        if (!isValidTag(a[1]!)) throw new LineError("tag");
        if (!HASH_ID_RE.test(a[2]!)) throw new LineError("meaning-hash");
        let from = 0n;
        if (a.length === 5) {
          if (a[3] !== "from") throw new LineError("from");
          try {
            from = parseDecimal(a[4]!);
          } catch {
            throw new LineError("number");
          }
        }
        const prev = log.profiles[log.profiles.length - 1];
        if (!prev && from !== 0n) throw new VerifyError("policy-invalid", { line: this.line, rule: 2 });
        if (prev && from <= prev.from) throw new VerifyError("policy-invalid", { line: this.line, rule: 2 });
        log.profiles.push({ tag: a[1]!, meaningHash: a[2]!, from });
        return;
      }
      case "param": {
        if (a.length < 3) throw new LineError("arguments");
        const log = this.log(a[0]!);
        const pname = this.name(a[1]!);
        if (log.params.has(pname)) this.duplicate(pname);
        log.params.set(pname, a.slice(2));
        return;
      }
      case "entries": {
        this.arity(a, 2);
        const log = this.log(a[0]!);
        if (this.entriesSet.has(log.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.entriesSet.add(log.name);
        if (a[1] !== "public" && a[1] !== "restricted") throw new LineError("entries");
        log.entries = a[1];
        return;
      }
      case "blinded": {
        this.arity(a, 3);
        const log = this.log(a[0]!);
        if (log.blinded) fail("policy-count", { line: this.line, keyword: kw });
        if (!/^[0-9a-f]{64}$/.test(a[1]!)) throw new LineError("pseudo-origin");
        log.blinded = { pseudoOrigin: a[1]!, vkey: this.vkey(a[2]!, SIG_ED25519) };
        this.hasBlinded = true;
        return;
      }
      case "keys-authority": {
        if (a.length < 3) throw new LineError("arguments");
        const log = this.log(a[0]!);
        if (log.keysAuthority) fail("policy-count", { line: this.line, keyword: kw });
        log.keysAuthority = this.threshold(a.slice(1), p.authorities);
        return;
      }

      // 2.3 Witnesses
      case "witness":
        this.arity(a, 2, 3);
        this.addWitness(
          p.witnesses,
          this.name(a[0]!),
          this.vkey(a[1]!, SIG_COSIGNATURE_V1),
          a[2] === undefined ? undefined : this.url(a[2]),
        );
        return;
      case "witness-party": {
        this.arity(a, 2);
        const w = p.witnesses.witnesses.get(a[0]!) ?? this.undefinedName(a[0]!);
        if (this.witnessParty.has(w.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.witnessParty.add(w.name);
        w.party = this.name(a[1]!);
        w.partyGiven = true;
        return;
      }
      case "group":
        this.addGroup(p.witnesses, a);
        return;
      case "quorum":
        this.arity(a, 1);
        this.once(kw);
        this.setQuorum(p.witnesses, a[0]!);
        return;

      // 2.4 Monitors
      case "monitor": {
        this.arity(a, 3);
        const name = this.name(a[0]!);
        if (p.monitors.has(name)) this.duplicate(name);
        p.monitors.set(name, { name, vkey: this.vkey(a[1]!, SIG_ED25519), url: this.url(a[2]!), party: name });
        return;
      }
      case "monitor-quorum":
        this.arity(a, 1);
        this.once(kw);
        this.monitorQuorumGiven = this.num(a[0]!, 1);
        return;
      case "monitor-party": {
        this.arity(a, 2);
        const m = p.monitors.get(a[0]!) ?? this.undefinedName(a[0]!);
        if (this.monitorParty.has(m.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.monitorParty.add(m.name);
        m.party = this.name(a[1]!);
        return;
      }
      case "monitor-explorer": {
        this.arity(a, 2);
        const m = p.monitors.get(a[0]!) ?? this.undefinedName(a[0]!);
        const url = this.url(a[1]!);
        if (this.monitorExplorerSet.has(m.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.monitorExplorerSet.add(m.name);
        m.explorer = url;
        return;
      }

      // 2.5 Hubs
      case "hub": {
        this.arity(a, 3);
        const name = this.name(a[0]!);
        if (p.hubs.has(name)) this.duplicate(name);
        const vkey = this.vkey(a[1]!, SIG_ED25519);
        p.hubs.set(name, {
          name,
          vkey,
          origin: vkey.name,
          url: this.url(a[2]!),
          operator: "",
          set: new WitnessSet(),
          bootstrap: false,
        });
        return;
      }
      case "hub-operator": {
        this.arity(a, 2);
        const h = this.hub(a[0]!);
        this.once(`${kw}\u0000${h.name}`);
        h.operator = this.name(a[1]!);
        return;
      }
      case "hub-witness": {
        this.arity(a, 3, 4);
        const h = this.hub(a[0]!);
        this.addWitness(
          h.set,
          this.name(a[1]!),
          this.vkey(a[2]!, SIG_COSIGNATURE_V1),
          a[3] === undefined ? undefined : this.url(a[3]),
        );
        return;
      }
      case "hub-witness-party": {
        this.arity(a, 3);
        const h = this.hub(a[0]!);
        const w = h.set.witnesses.get(a[1]!) ?? this.undefinedName(a[1]!);
        const key = `${h.name}\u0000${w.name}`;
        if (this.hubWitnessParty.has(key)) fail("policy-count", { line: this.line, keyword: kw });
        this.hubWitnessParty.add(key);
        w.party = this.name(a[2]!);
        w.partyGiven = true;
        return;
      }
      case "hub-group": {
        if (a.length < 1) throw new LineError("arguments");
        const h = this.hub(a[0]!);
        this.addGroup(h.set, a.slice(1));
        return;
      }
      case "hub-quorum": {
        this.arity(a, 2);
        const h = this.hub(a[0]!);
        this.once(`${kw}\u0000${h.name}`);
        this.setQuorum(h.set, a[1]!);
        return;
      }
      case "anchor":
        this.arity(a, 2);
        this.once(kw);
        p.anchorPeriod = this.num(a[0]!, 1);
        p.anchorMaxGap = this.num(a[1]!, 1);
        this.anchorGiven = true;
        return;
      case "anchor-hubs":
        this.arity(a, 2);
        this.once(kw);
        p.anchorHubs = { min: this.num(a[0]!), minIndependent: this.num(a[1]!) };
        return;
      case "bootstrap": {
        this.arity(a, 1);
        const h = this.hub(a[0]!);
        if (this.bootstrapSet.has(h.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.bootstrapSet.add(h.name);
        h.bootstrap = true;
        return;
      }

      // 2.6 Browser layer
      case "browser":
        this.arity(a, 1);
        this.once(kw);
        p.browserPeriod = this.num(a[0]!, 1);
        return;
      case "hub-domain": {
        this.arity(a, 2);
        const h = this.hub(a[0]!);
        if (this.hubDomainSet.has(h.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.hubDomainSet.add(h.name);
        if (!isDomain(a[1]!)) throw new LineError("domain");
        h.domain = a[1]!;
        return;
      }
      case "hub-explorer": {
        this.arity(a, 2);
        const h = this.hub(a[0]!);
        const url = this.url(a[1]!);
        if (this.hubExplorerSet.has(h.name)) fail("policy-count", { line: this.line, keyword: kw });
        this.hubExplorerSet.add(h.name);
        h.explorer = url;
        return;
      }
      case "explorer": {
        this.arity(a, 1);
        const url = this.url(a[0]!);
        if (p.explorers.includes(url)) this.duplicate(url);
        p.explorers.push(url);
        return;
      }
      case "waict": {
        if (a.length < 2) throw new LineError("arguments");
        const domain = a[0]!;
        if (!isDomain(domain)) throw new LineError("domain");
        if (p.waict.has(domain)) this.duplicate(domain);
        const hubs = a.slice(1);
        for (const h of hubs) this.hub(h);
        if (new Set(hubs).size !== hubs.length) this.duplicate(hubs.join(" "));
        p.waict.set(domain, { domain, hubs, operator: "", witnesses: [], quorum: 0 });
        return;
      }
      case "waict-operator": {
        this.arity(a, 2);
        const s = this.service(a[0]!);
        this.once(`${kw}\u0000${s.domain}`);
        s.operator = this.name(a[1]!);
        return;
      }
      case "waict-witness": {
        this.arity(a, 3);
        const s = this.service(a[0]!);
        const name = this.name(a[1]!);
        if (s.witnesses.some((w) => w.name === name)) this.duplicate(name);
        let key: Uint8Array;
        try {
          key = b64decode(a[2]!, 32);
        } catch {
          throw new LineError("waict-key");
        }
        this.uniqueKey(key, name);
        const ed = Ed25519Key.parse(key);
        if (!ed) fail("bad-public-key");
        s.witnesses.push({ name, key, ed, party: name });
        return;
      }
      case "waict-witness-party": {
        this.arity(a, 3);
        const s = this.service(a[0]!);
        const w = s.witnesses.find((x) => x.name === a[1]!) ?? this.undefinedName(a[1]!);
        const key = `${s.domain}\u0000${w.name}`;
        if (this.waictWitnessParty.has(key)) fail("policy-count", { line: this.line, keyword: kw });
        this.waictWitnessParty.add(key);
        w.party = this.name(a[2]!);
        return;
      }
      case "waict-quorum": {
        this.arity(a, 2);
        const s = this.service(a[0]!);
        this.once(`${kw}\u0000${s.domain}`);
        s.quorum = this.num(a[1]!, 1);
        return;
      }
      case "operator-list": {
        this.arity(a, 1);
        this.once(kw);
        if (!HASH_ID_RE.test(a[0]!)) throw new LineError("operator-list-id");
        p.operatorList = a[0]!;
        return;
      }
      case "shared-log": {
        this.arity(a, 3);
        const name = this.name(a[0]!);
        if (!HASH_ID_RE.test(a[1]!)) throw new LineError("shared-policy-id");
        if (p.sharedLogs.has(name) || [...p.sharedLogs.values()].some((pin) => pin.policyId === a[1])) this.duplicate(name);
        p.sharedLogs.set(name, { name, policyId: a[1]!, url: this.url(a[2]!) });
        return;
      }
      default:
        fail("policy-unknown-keyword", { line: this.line, keyword: kw.slice(0, 64) });
    }
  }

  // -- section 3 ------------------------------------------------------------

  private finish(): Policy {
    const p = this.p;
    this.line = 0;
    const missing = (keyword: string): never => fail("policy-count", { keyword });
    const rule = (n: number | string, detail?: string): never =>
      fail("policy-invalid", detail === undefined ? { rule: n } : { rule: n, detail });
    if (p.name === undefined) missing("name");
    if (p.visibility === undefined) missing("visibility");
    if (p.operator === undefined) missing("operator");
    if (p.authorities.size === 0) missing("authority");
    if (p.sign === undefined) missing("sign");
    if (p.mmd === undefined) missing("mmd");
    if (p.logs.size === 0) missing("log");
    if (p.witnesses.quorum === "") missing("quorum");
    const priv = p.visibility === "private";
    const operator = p.operator!;

    // Rule 1, deferred part: `release` may name a log defined later (as the
    // example in section 6 does).
    for (const r of this.releaseLines) {
      if (!p.logs.has(r.log)) fail("policy-undefined-name", { line: r.line, name: r.log });
    }

    // Rule 2
    for (const log of p.logs.values()) {
      if (log.profiles.length === 0) rule(2, `profile:${log.name}`);
      if (!this.logTimes.has(log.name)) rule(2, `log-time:${log.name}`);
    }
    for (const h of p.hubs.values()) {
      if (h.operator === "") rule(2, `hub-operator:${h.name}`);
      if (h.set.quorum === "") rule(2, `hub-quorum:${h.name}`);
      if (h.set.witnesses.size === 0) rule(2, `hub-witness:${h.name}`);
    }
    for (const s of p.waict.values()) {
      if (s.operator === "") rule(2, `waict-operator:${s.domain}`);
      if (s.quorum === 0) rule(2, `waict-quorum:${s.domain}`);
      if (s.witnesses.length === 0) rule(2, `waict-witness:${s.domain}`);
      for (const h of s.hubs) if (p.hubs.get(h)!.domain === undefined) rule(2, `hub-domain:${h}`);
    }

    // Rule 3
    const origins = new Set<string>();
    for (const log of p.logs.values()) {
      if (log.logTime.name !== log.origin) rule(3, `log-time:${log.name}`);
    }
    for (const o of [...[...p.logs.values()].map((l) => l.origin), ...[...p.hubs.values()].map((h) => h.origin)]) {
      if (isReservedOrigin(o)) rule(3, "reserved-origin");
      if (origins.has(o)) fail("policy-duplicate-name", { name: o.slice(0, 64) });
      origins.add(o);
    }

    // Defaults
    p.required ??= true;
    p.strictGiven ??= false;
    p.strict ??= priv;
    p.quiet ??= 0;
    p.minFaults ??= 0;
    p.skew ??= DEFAULT_SKEW;
    p.cosignMax ??= 10;
    p.epoch ??= 600;
    if (!this.anchorGiven) {
      p.anchorPeriod = 10;
      p.anchorMaxGap = 60;
    }
    p.browserPeriod ??= 600;

    // Rules 5 and 12: quorum safety. Every quorum's split cost and party
    // split cost are at least 1 with its faulty parties counted as faulty,
    // and the party split cost at least min-faults + 1.
    // The operator's and the platform's witnesses are faulty in every quorum.
    const platform = p.platform;
    const faultyBase = faultyParties({ operator, ...(platform === undefined ? {} : { platform }) });
    const needParty = p.minFaults + 1;
    const unsafe = (where: Record<string, string>, quorum: string, split: number, party: number): never =>
      fail("policy-unsafe-quorum", { ...where, quorum, splitCost: split, partySplitCost: party, need: needParty });
    const partyCost = (q: QuorumShape, faulty: Set<string>): number => {
      const c = partySplitCostOf(q, faulty);
      // A search cut short gives only a lower bound: accept it only if it
      // already shows what the rules need.
      if (!c.exact && c.value < needParty) rule(5, "party-split-cost-search");
      return c.value;
    };
    const splitCost: QuorumCosts = { app: 0, hubs: new Map(), waict: new Map() };
    const partySplitCost: QuorumCosts = { app: 0, hubs: new Map(), waict: new Map() };
    {
      const faulty = new Set(faultyBase);
      const sc = p.witnesses.splitCost(faulty);
      const pc = sc < 1 ? 0 : partyCost(p.witnesses, faulty);
      if (sc < 1 || pc < needParty) unsafe({}, p.witnesses.quorum, sc, pc);
      splitCost.app = sc;
      partySplitCost.app = pc;
    }
    for (const h of p.hubs.values()) {
      const faulty = new Set([...faultyBase, h.operator]);
      const sc = h.set.splitCost(faulty);
      const pc = sc < 1 ? 0 : partyCost(h.set, faulty);
      if (sc < 1 || pc < needParty) unsafe({ hub: h.name }, h.set.quorum, sc, pc);
      splitCost.hubs.set(h.name, sc);
      partySplitCost.hubs.set(h.name, pc);
    }
    for (const s of p.waict.values()) {
      // Rule 12: one k-of-n group, 1 <= k <= n.
      if (s.quorum > s.witnesses.length) rule(12, `waict-quorum:${s.domain}`);
      const shape = waictShape(s);
      const faulty = new Set([...faultyBase, s.operator]);
      const sc = splitCostOf(shape, faulty);
      const pc = sc < 1 ? 0 : partyCost(shape, faulty);
      if (sc < 1 || pc < needParty) unsafe({ service: s.domain }, String(s.quorum), sc, pc);
      splitCost.waict.set(s.domain, sc);
      partySplitCost.waict.set(s.domain, pc);
    }

    // Rule 6
    const policyLike = { operator, ...(platform === undefined ? {} : { platform }) };
    const app = [...p.hubs.values()].filter((h) => !h.bootstrap);
    for (const b of p.hubs.values()) {
      if (!b.bootstrap) continue;
      if (faultyBase.includes(b.operator)) rule(6, `bootstrap:${b.name}`);
      for (const h of app) if (!hubsIndependent(policyLike, b, h)) rule(6, `bootstrap:${b.name}`);
    }
    if (p.anchorHubs) {
      if (!anchorHubsHold({ ...policyLike, hubs: p.hubs }, p.anchorHubs.min, p.anchorHubs.minIndependent)) rule(6, "anchor-hubs");
    }

    // Rule 7
    if (priv) {
      if (!p.policySalt) rule(7, "policy-salt");
      if (p.auditors.size === 0) rule(7, "auditor");
      for (const log of p.logs.values()) {
        if (app.length > 0 && !log.blinded) rule(7, `blinded:${log.name}`);
        if (log.blinded && log.blinded.pseudoOrigin !== pseudoOrigin(log.origin, p.policySalt!)) {
          rule(7, `pseudo-origin:${log.name}`);
        }
        // A subject's key name is the subject's name (hub.md, section 1).
        if (log.blinded && log.blinded.vkey.name !== log.blinded.pseudoOrigin) rule(7, `blinded-key:${log.name}`);
      }
    } else {
      if (p.policySalt) rule(7, "policy-salt");
      if (this.hasBlinded) rule(7, "blinded");
    }

    // Rule 8
    // Strict by default in a private event, and so needing the window too.
    if (p.strict && (p.opens === undefined || p.closes === undefined)) rule(8, "strict");
    if (this.seen.has("quiet") && p.closes === undefined) rule(8, "quiet");

    // Rule 9 (thresholds are checked as their lines are read)
    for (const log of p.logs.values()) {
      if (log.keysAuthority && !log.profiles.some((pr) => pr.tag === KEYS_TAG)) rule(9, `keys-authority:${log.name}`);
    }
    if (this.monitorQuorumGiven !== undefined && this.monitorQuorumGiven > p.monitors.size) rule(9, "monitor-quorum");
    p.monitorQuorum = this.monitorQuorumGiven ?? Math.min(2, p.monitors.size);

    // Rule 10
    const mirrorParty = new Set<string>();
    for (const mp of this.mirrorParties) {
      const m = p.logs.get(mp.log)!.mirrors.find((x) => x.url === mp.url);
      if (!m) fail("policy-invalid", { line: mp.line, rule: 10, detail: "mirror-party" });
      const key = `${mp.log}\u0000${mp.url}`;
      if (mirrorParty.has(key)) fail("policy-invalid", { line: mp.line, rule: 10, detail: "mirror-party" });
      mirrorParty.add(key);
      m.party = mp.party;
    }
    for (const log of p.logs.values()) for (const m of log.mirrors) if (m.party === "") m.party = operator;
    if (!priv) {
      for (const log of p.logs.values()) {
        if (log.profiles.some((pr) => pr.tag === ELECTION_TAG) && !log.mirrors.some((m) => m.party !== operator)) {
          rule(10, `mirror:${log.name}`);
        }
      }
    }

    // Rule 11
    if (p.opens !== undefined && p.closes !== undefined && !(p.opens < p.closes)) rule(11, "opens-closes");
    if (p.effective !== undefined && p.opens !== undefined && !(p.effective > p.opens)) rule(11, "effective");
    if (p.opens !== undefined && p.closes !== undefined && p.quiet > p.closes - p.opens) rule(11, "quiet");

    // Rule 13: the seal (its position and bytes are checked as lines are read)
    if (this.sealed) {
      if (!p.seal) rule(13, "seal");
      if (!p.sign!.names.includes(p.seal!.authority)) rule(13, "seal-authority");
    }

    // Rule 14
    if (p.skew > MAX_SKEW) rule(14, "skew");

    // Rule 15
    if (p.retire.length > 0 && p.supersedes === undefined) rule(15, "retire");

    // Rule 16: every hub refuses a declaration with more than 31 witnesses
    // or two witness keys with the same key name (specs/hub.md, section 2.1).
    if (app.length > 0) {
      const ws = [...p.witnesses.witnesses.values()];
      if (ws.length > MAX_HUB_WITNESSES) rule(16, "witnesses");
      if (new Set(ws.map((w) => w.vkey.name)).size !== ws.length) rule(16, "witness-key-names");
    }

    const draft = !this.sealed;
    const draftHash = sha256(draftText(this.lines));
    const idHash = draft ? draftHash : sha256(this.text);
    const policy: Policy = {
      note: "",
      text: this.text,
      id: `sha256:${hexEncode(idHash)}`,
      idHash,
      draftHash,
      draft,
      name: p.name!,
      visibility: p.visibility!,
      required: p.required,
      strict: p.strict,
      strictGiven: p.strictGiven,
      quiet: p.quiet,
      operator,
      ...(platform === undefined ? {} : { platform }),
      contact: p.contact!,
      checkers: p.checkers!,
      minFaults: p.minFaults,
      authorities: p.authorities,
      sign: p.sign!,
      auditors: p.auditors,
      mmd: p.mmd!,
      skew: p.skew,
      cosignMax: p.cosignMax,
      epoch: p.epoch,
      retire: p.retire,
      releases: p.releases,
      sites: p.sites,
      sharedLogs: p.sharedLogs,
      explorers: p.explorers,
      ...(p.operatorList === undefined ? {} : { operatorList: p.operatorList }),
      logs: p.logs,
      witnesses: p.witnesses,
      monitors: p.monitors,
      monitorQuorum: p.monitorQuorum,
      hubs: p.hubs,
      anchorPeriod: p.anchorPeriod!,
      anchorMaxGap: p.anchorMaxGap!,
      browserPeriod: p.browserPeriod,
      waict: p.waict,
      signedBy: [],
      signed: false,
      splitCost,
      partySplitCost,
    };
    if (p.seal) policy.seal = p.seal;
    if (p.policySalt) policy.policySalt = p.policySalt;
    if (p.redaction) policy.redaction = p.redaction;
    if (p.opens !== undefined) policy.opens = p.opens;
    if (p.closes !== undefined) policy.closes = p.closes;
    if (p.supersedes !== undefined) policy.supersedes = p.supersedes;
    if (p.effective !== undefined) policy.effective = p.effective;
    if (p.anchorHubs) policy.anchorHubs = p.anchorHubs;
    return policy;
  }
}

// ---------------------------------------------------------------------------
// Section 4: successors

/** The authorities of `x`'s `sign` line whose keys verify `note` (rule 2). */
export function successorSigners(x: Policy, note: string | Uint8Array): string[] {
  let n: Note;
  try {
    n = parseNote(note);
  } catch {
    return [];
  }
  const keys = x.sign.names.map((name) => x.authorities.get(name)!.vkey);
  const verified = new Set(verifyNote(n, keys).map((v) => v.vkey));
  return x.sign.names.filter((name) => verified.has(x.authorities.get(name)!.vkey));
}

/** True when `note` carries valid signatures from at least `x`'s `sign`
 * threshold of `x`'s authorities (section 4, rule 2). */
export function authorizedBy(x: Policy, note: string | Uint8Array): boolean {
  return successorSigners(x, note).length >= x.sign.k;
}

/** effective(Y) (rule 4): the latest of `T_c`, Y's `effective`, and, when X
 * has `opens` and `T_c >= opens(X) - 86400`, `T_c + 86400`. */
export function effectiveTime(x: Policy, y: Policy, tc: number): number {
  let e = tc;
  if (y.effective !== undefined && y.effective > e) e = y.effective;
  if (x.opens !== undefined && tc >= x.opens - SUCCESSOR_DELAY && tc + SUCCESSOR_DELAY > e) e = tc + SUCCESSOR_DELAY;
  return e;
}

function successorRule(rule: number, detail: string): never {
  throw new VerifyError("successor-rejected", { rule, detail });
}

/** X's figures with the witnesses, hub witnesses and hubs that Y retires
 * counted as faulty (rule 8). */
function retiredCosts(x: Policy, retired: ReadonlySet<string>): {
  app: { split: number; party: number };
  hubs: Map<string, { split: number; party: number }>;
} {
  const figures = (q: QuorumShape, faulty: Set<string>): { split: number; party: number } => {
    const split = splitCostOf(q, faulty, retired);
    // An inexact search gives a lower bound of X's figure, which only makes
    // the comparison easier for Y: use the split cost, an upper bound, then.
    const pc = partySplitCostOf(q, faulty, retired);
    return { split, party: pc.exact ? pc.value : split };
  };
  const hubs = new Map<string, { split: number; party: number }>();
  for (const h of x.hubs.values()) {
    if (retired.has(h.name)) continue;
    hubs.set(h.name, figures(h.set, new Set([...faultyParties(x), h.operator])));
  }
  return { app: figures(x.witnesses, new Set(faultyParties(x))), hubs };
}

/** Checks that `y` may succeed `x` (specs/policy.md, section 4, rules 1, 2,
 * 4, 5 and 8), given `tc`, the quorum time of the first `events` checkpoint
 * that contains Y's entry and meets X's quorum (rule 3). Returns
 * effective(Y); throws `successor-rejected` with the rule that fails. Rules 3
 * and 6 (logging and uniqueness) need the `events` log and are the caller's. */
export function acceptSuccessor(x: Policy, y: Policy, tc: number): { effective: number } {
  // Rule 1: Y is valid on its own.
  if (y.draft || !y.signed) successorRule(1, "not-valid");
  if (y.supersedes !== x.id) successorRule(1, "supersedes");
  // Rule 2
  if (!authorizedBy(x, y.note)) successorRule(2, "signatures");
  // Rule 5
  if (x.visibility === "public" && y.visibility === "private") successorRule(5, "visibility");
  const locked = x.opens !== undefined && tc >= x.opens;
  if (locked) {
    if (y.required !== x.required) successorRule(5, "required");
    if (y.strict !== x.strict) successorRule(5, "strict");
    if (y.quiet !== x.quiet) successorRule(5, "quiet");
    if (y.opens !== x.opens) successorRule(5, "opens");
    if (y.closes !== x.closes) successorRule(5, "closes");
    if (y.platform !== x.platform) successorRule(5, "platform");
    const xs = x.policySalt;
    const ys = y.policySalt;
    if ((xs === undefined) !== (ys === undefined) || (xs && ys && !equalBytes(xs, ys))) successorRule(5, "policy-salt");
  }
  // Rule 8: `retire` names something of X.
  const retired = new Set(y.retire);
  for (const name of y.retire) {
    const known = x.witnesses.witnesses.has(name) || x.hubs.has(name) || [...x.hubs.values()].some((h) => h.set.witnesses.has(name));
    if (!known) successorRule(8, `retire:${name}`);
  }
  if (locked) {
    // Rule 8: monotonic safety.
    for (const name of y.sign.names) {
      const xa = x.authorities.get(name);
      if (!x.sign.names.includes(name) || !xa || !equalBytes(xa.vkey.key, y.authorities.get(name)!.vkey.key)) successorRule(8, `sign:${name}`);
    }
    if (y.sign.k < x.sign.k) successorRule(8, "sign-threshold");
    const xc = retiredCosts(x, retired);
    if (y.splitCost.app < xc.app.split || y.partySplitCost.app < xc.app.party) successorRule(8, "app-quorum");
    for (const [name, c] of xc.hubs) {
      if (!y.hubs.has(name)) continue;
      if ((y.splitCost.hubs.get(name) ?? 0) < c.split || (y.partySplitCost.hubs.get(name) ?? 0) < c.party) successorRule(8, `hub-quorum:${name}`);
    }
    if (y.minFaults < x.minFaults) successorRule(8, "min-faults");
    const xa = x.anchorHubs ?? { min: 0, minIndependent: 0 };
    const ya = y.anchorHubs ?? { min: 0, minIndependent: 0 };
    const retiredApp = appHubs(x).filter((h) => retired.has(h.name));
    const xMin = Math.max(0, xa.min - retiredApp.length);
    const xBase = faultyParties(x);
    const xIndep = Math.max(0, xa.minIndependent - retiredApp.filter((h) => !xBase.includes(h.operator)).length);
    if (ya.min < xMin || ya.minIndependent < xIndep) successorRule(8, "anchor-hubs");
  }
  return { effective: effectiveTime(x, y, tc) };
}
