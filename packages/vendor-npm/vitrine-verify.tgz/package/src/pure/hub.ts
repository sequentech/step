// SPDX-License-Identifier: Apache-2.0
//
// Anchor hubs (specs/hub.md): subject keys, subject-map values, hub links
// (section 5), blinded-anchor openings (redaction.md, section 4.4),
// bootstrap links (section 6.4) and the log's tier-3 pairs (section 6.5).

import { b64decode, b64encode, hexEncode } from "./base64.js";
import { equalBytes, parseDecimal, u16be, u64be, u64ToNumber, utf8 } from "./bytes.js";
import { formatBlockDoc, parseBase64Body, parseBlockDoc, pickBlocks } from "./blocks.js";
import { mergeCosigs, verifyCheckpoint, type CheckedCheckpoint } from "./checkpoint.js";
import { checkLayout, fieldText, fieldU64, fieldValue, parseEntry, type Entry } from "./entry.js";
import { fail, VerifyError } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { verifyInclusion } from "./merkle.js";
import { verifyMptProof } from "./mpt.js";
import { parseNote, parseVkey, SIG_ED25519, verifyNote, type Vkey } from "./note.js";
import type { Policy, PolicyHub } from "./policy.js";
import { parseTlogProof, type TlogProof } from "./tlogproof.js";

export const HUB_LINK_HEADER = "vitrine/hub-link/v1";
export const OPENING_HEADER = "vitrine/blinded-opening/v1";
export const BLINDED_STATEMENT_HEADER = "vitrine/blinded-anchor/v1";

export const SUBJECT_ORIGIN = 0;
export const SUBJECT_BLINDED = 1;

/** A hub subject: an origin and its log key, or a pseudo-origin and its
 * anchoring key (section 1). */
export interface Subject {
  kind: typeof SUBJECT_ORIGIN | typeof SUBJECT_BLINDED;
  name: string;
  vkey: Vkey;
}

/** `H("vitrine/hub/v1/subject" || kind || opaque name<1..255> || opaque vkey<1..2^16-1>)` */
export function subjectKey(kind: number, name: string, vkeyText: string): Uint8Array {
  const n = utf8(name);
  const k = utf8(vkeyText);
  if (n.length < 1 || n.length > 255 || k.length < 1 || k.length > 0xffff) throw new RangeError("subject name or key length");
  return sha256("vitrine/hub/v1/subject", Uint8Array.of(kind), Uint8Array.of(n.length), n, u16be(k.length), k);
}

/** `H("vitrine/hub/v1/value" || uint64 entry_index || leaf_hash)` */
export function mapValue(entryIndex: bigint, leaf: Uint8Array): Uint8Array {
  return sha256("vitrine/hub/v1/value", u64be(entryIndex), leaf);
}

/** `H("vitrine/anchor/v1" || salt || checkpoint text)` */
export function anchorCommitment(salt: Uint8Array, checkpointText: string): Uint8Array {
  return sha256("vitrine/anchor/v1", salt, checkpointText);
}

export interface HubLink {
  hubOrigin: string;
  subjectName: string;
  subjectVkey: string;
  entry: TlogProof;
  index: TlogProof;
  map: Uint8Array;
}

function asCode<T>(code: "bad-hub-link" | "bad-opening", f: () => T): T {
  try {
    return f();
  } catch (e) {
    if (e instanceof VerifyError && (e.code === "bad-proof" || e.code === "bad-base64" || e.code === "bad-number" || e.code === "bad-text")) {
      throw new VerifyError(code, { detail: e.code });
    }
    throw e;
  }
}

export function parseHubLink(input: Uint8Array | string): HubLink {
  return asCode("bad-hub-link", () => {
    const doc = parseBlockDoc(input, { header: HUB_LINK_HEADER, keys: ["hub", "subject"], code: "bad-hub-link" });
    const [hub, subject] = doc.values as [string[], string[]];
    if (hub.length !== 1 || subject.length !== 2) fail("bad-hub-link", { detail: "lines" });
    const b = pickBlocks(doc.blocks, { entry: 0, index: 0, map: 0 }, "bad-hub-link");
    const entry = b.get("entry");
    const index = b.get("index");
    const map = b.get("map");
    if (!entry || !index || !map) fail("bad-hub-link", { detail: "blocks" });
    return {
      hubOrigin: hub[0]!,
      subjectName: subject[0]!,
      subjectVkey: subject[1]!,
      entry: parseTlogProof(entry.body),
      index: parseTlogProof(index.body),
      map: parseBase64Body(map.body),
    };
  });
}

export function formatHubLink(hubOrigin: string, subjectName: string, subjectVkey: string, entryProof: string, indexProof: string, mapProof: Uint8Array): Uint8Array {
  return formatBlockDoc(HUB_LINK_HEADER, [`hub ${hubOrigin}`, `subject ${subjectName} ${subjectVkey}`], [
    { type: "entry", args: [], body: utf8(entryProof) },
    { type: "index", args: [], body: utf8(indexProof) },
    { type: "map", args: [], body: utf8(b64encode(mapProof)) },
  ]);
}

export interface VerifiedHubLink {
  /** The subject the link is for: the one of `subjects` that it names. */
  subject: Subject;
  /** The hub checkpoint `H`, with the cosignatures of both proofs merged. */
  hub: CheckedCheckpoint;
  /** True when `H` meets the hub's quorum. */
  hubQuorum: boolean;
  /** Quorum time of `H`, when it meets the quorum. */
  hubQuorumTime?: number;
  entryIndex: bigint;
  entry: Entry;
  /** `wrong`: entry `j`, which the subject map gives as the subject's latest,
   * isn't one of the subject's anchors, or doesn't match the statement it
   * carries. Under a hub checkpoint that meets the hub's quorum, the hub's
   * witnesses co-signed a wrong index or a bad entry (specs/hub.md, section
   * 5.2, step 4). */
  kind: "anchor" | "blinded" | "rotate" | "wrong";
  /** For `wrong`: what is wrong. */
  wrong?: string;
  /** `received_at` of entry `j`, milliseconds. */
  receivedAt: bigint;
  /** For `anchor`: the app checkpoint note the entry carries. */
  anchored?: Uint8Array;
  /** For `blinded`: its sequence number and commitment. */
  blinded?: { seq: bigint; commitment: Uint8Array };
  /** For `rotate`: the new key, the successor policy its statement names,
   * and the old subject's latest anchored checkpoint, where it froze. */
  rotation?: Rotation;
}

/** A rotation statement (section 2.5), checked against its entry. */
export interface Rotation {
  newKey: string;
  policy: string;
  size: bigint;
  root: Uint8Array;
  time: number;
}

export const ROTATE_STATEMENT_HEADER = "vitrine/hub-rotate/v1";

/** Checks a blinded entry for `subject` in hub `hub`; returns its `seq` and
 * commitment, or what is wrong with it. */
export function blindedEntry(
  entry: Entry,
  hub: PolicyHub,
  subject: Subject,
): { seq: bigint; commitment: Uint8Array } | { wrong: string } {
  if (entry.tag !== "vitrine/hub/v1/blinded" || subject.kind !== SUBJECT_BLINDED) return { wrong: "entry-kind" };
  if (hexEncode(fieldValue(entry, "pseudo_origin")!) !== subject.name || fieldText(entry, "key") !== subject.vkey.text) {
    return { wrong: "entry-subject" };
  }
  const seq = fieldU64(entry, "seq")!;
  const commitment = fieldValue(entry, "commitment")!;
  let st;
  try {
    st = parseNote(fieldValue(entry, "statement")!);
  } catch {
    return { wrong: "statement" };
  }
  const want = `${BLINDED_STATEMENT_HEADER}\nhub ${hub.origin}\npseudo ${subject.name}\nseq ${seq}\ncommitment ${b64encode(commitment)}\n`;
  if (st.text !== want) return { wrong: "statement" };
  if (!verifyNote(st, [subject.vkey]).some((v) => v.vkey === subject.vkey)) return { wrong: "statement-signature" };
  return { seq, commitment };
}

const POLICY_ID_RE = /^sha256:[0-9a-f]{64}$/;

/** Reads a rotation entry's statement (section 2.5): its lines in order,
 * naming this hub, the subject's origin and both keys of the entry, and
 * valid signatures from the old and the new key. (The declared authorities'
 * signatures need the subject's enrolment, which only the hub's witnesses
 * hold.) Returns what is wrong, or the rotation. */
function rotationOf(entry: Entry, hub: PolicyHub, subject: Subject): Rotation | { wrong: string } {
  const newKey = fieldText(entry, "new")!;
  let note;
  try {
    note = parseNote(fieldValue(entry, "statement")!);
  } catch {
    return { wrong: "statement" };
  }
  const lines = note.text.slice(0, -1).split("\n");
  const keys = ["hub", "kind", "name", "policy", "old", "new", "size", "root", "time"];
  if (lines.length !== keys.length + 1 || lines[0] !== ROTATE_STATEMENT_HEADER) return { wrong: "statement" };
  const v = keys.map((k, i) => (lines[i + 1]!.startsWith(`${k} `) ? lines[i + 1]!.slice(k.length + 1) : undefined));
  const [h, kind, name, policy, old, nw, size, root, time] = v;
  if (h !== hub.origin || kind !== "origin" || name !== subject.name || old !== subject.vkey.text || nw !== newKey) return { wrong: "statement" };
  if (policy === undefined || !POLICY_ID_RE.test(policy)) return { wrong: "statement" };
  let out: Rotation;
  try {
    out = { newKey, policy, size: parseDecimal(size ?? ""), root: b64decode(root ?? "", 32), time: u64ToNumber(parseDecimal(time ?? "")) };
  } catch {
    return { wrong: "statement" };
  }
  let nk: Vkey;
  try {
    nk = parseVkey(newKey, [SIG_ED25519]);
  } catch {
    return { wrong: "statement" };
  }
  const signed = verifyNote(note, [subject.vkey, nk]);
  if (!signed.some((s) => s.vkey === subject.vkey) || !signed.some((s) => s.vkey === nk)) return { wrong: "statement-signature" };
  return out;
}

/** Verifies a hub link against `hub`'s key and witnesses, for the one of
 * `subjects` that it names (specs/hub.md, section 5.2, steps 1 to 4, and the
 * entry checks that need no app policy). Damaged or mismatched links throw; a
 * hub checkpoint short of the hub's quorum is reported in `hubQuorum`, and an
 * entry that isn't the subject's in `kind: "wrong"`. */
export function verifyHubLink(
  input: Uint8Array | string,
  hub: PolicyHub,
  subjects: Subject | readonly Subject[],
  deviceNow: number,
): VerifiedHubLink {
  const link = parseHubLink(input);
  if (link.hubOrigin !== hub.origin) fail("hub-link-mismatch", { detail: "hub" });
  const subject = (Array.isArray(subjects) ? subjects : [subjects as Subject]).find(
    (s) => s.name === link.subjectName && s.vkey.text === link.subjectVkey,
  );
  if (!subject) fail("hub-link-mismatch", { detail: "subject" });
  if (!link.entry.extra || !link.index.extra) fail("missing-extra");
  const e = verifyCheckpoint(link.entry.checkpoint, hub.vkey, hub.set, deviceNow);
  const ix = verifyCheckpoint(link.index.checkpoint, hub.vkey, hub.set, deviceNow);
  if (e.note.text !== ix.note.text) fail("hub-link-mismatch", { detail: "checkpoints" });
  const cosigs = mergeCosigs(e.cosigs, ix.cosigs);
  const hubCp: CheckedCheckpoint = {
    note: e.note,
    cp: e.cp,
    cosigs,
    future: [...new Set([...e.future, ...ix.future])],
    normalized: e.normalized,
  };
  const size = e.cp.size;
  if (link.index.index !== size - 1n) fail("hub-link-mismatch", { detail: "index-not-last" });
  if (link.entry.index >= link.index.index) fail("hub-link-mismatch", { detail: "entry-not-covered" });
  if (!verifyInclusion(link.index.index, size, leafHash(link.index.extra), link.index.proof, e.cp.root)) {
    fail("inclusion-failed", { what: "hub-index" });
  }
  if (!verifyInclusion(link.entry.index, size, leafHash(link.entry.extra), link.entry.proof, e.cp.root)) {
    fail("inclusion-failed", { what: "hub-entry" });
  }
  const ixEntry = parseEntry(link.index.extra);
  if (ixEntry.tag !== "vitrine/hub/v1/index") fail("hub-link-mismatch", { detail: "index-entry" });
  checkLayout(ixEntry);
  if (fieldU64(ixEntry, "covered") !== link.index.index) fail("hub-link-mismatch", { detail: "covered" });
  const key = subjectKey(subject.kind, subject.name, subject.vkey.text);
  const value = mapValue(link.entry.index, leafHash(link.entry.extra));
  if (!verifyMptProof(link.map, key, value, fieldValue(ixEntry, "root")!)) fail("map-proof-failed");

  const entry = parseEntry(link.entry.extra);
  const out: VerifiedHubLink = {
    subject,
    hub: hubCp,
    hubQuorum: hub.set.meets(cosigs),
    entryIndex: link.entry.index,
    entry,
    kind: "wrong",
    receivedAt: 0n,
  };
  const qt = hub.set.quorumTime(cosigs);
  if (qt !== undefined) out.hubQuorumTime = qt;
  const wrong = (detail: string): VerifiedHubLink => {
    out.kind = "wrong";
    out.wrong = detail;
    return out;
  };
  try {
    checkLayout(entry);
  } catch {
    return wrong("entry-layout");
  }
  out.receivedAt = fieldU64(entry, "received_at")!;
  if (entry.tag === "vitrine/hub/v1" && subject.kind === SUBJECT_ORIGIN) {
    if (fieldText(entry, "origin") !== subject.name || fieldText(entry, "key") !== subject.vkey.text) return wrong("entry-subject");
    out.kind = "anchor";
    out.anchored = fieldValue(entry, "checkpoint")!;
  } else if (entry.tag === "vitrine/hub/v1/blinded" && subject.kind === SUBJECT_BLINDED) {
    const b = blindedEntry(entry, hub, subject);
    if ("wrong" in b) return wrong(b.wrong);
    out.kind = "blinded";
    out.blinded = b;
  } else if (entry.tag === "vitrine/hub/v1/rotate" && subject.kind === SUBJECT_ORIGIN) {
    if (fieldText(entry, "origin") !== subject.name || fieldText(entry, "old") !== subject.vkey.text) return wrong("entry-subject");
    const rotation = rotationOf(entry, hub, subject);
    if ("wrong" in rotation) return wrong(rotation.wrong);
    out.kind = "rotate";
    out.rotation = rotation;
  } else {
    return wrong("entry-kind");
  }
  return out;
}

export interface Opening {
  /** The hub, by its origin. */
  hub: string;
  seq: bigint;
  salt: Uint8Array;
  /** The opened checkpoint note, with its cosignatures. */
  checkpoint: Uint8Array;
}

export function parseOpening(input: Uint8Array | string): Opening {
  return asCode("bad-opening", () => {
    const doc = parseBlockDoc(input, { header: OPENING_HEADER, keys: ["hub", "seq", "salt"], code: "bad-opening" });
    if (doc.values.some((v) => v.length !== 1)) fail("bad-opening", { detail: "lines" });
    const b = pickBlocks(doc.blocks, { checkpoint: 0 }, "bad-opening");
    const cp = b.get("checkpoint");
    if (!cp) fail("bad-opening", { detail: "checkpoint" });
    const [hub, seq, salt] = doc.values.map((v) => v[0]!) as [string, string, string];
    return { hub, seq: parseSeq(seq), salt: b64decode(salt, 32), checkpoint: cp.body };
  });
}

function parseSeq(s: string): bigint {
  if (!/^[1-9][0-9]{0,18}$/.test(s)) fail("bad-opening", { detail: "seq" });
  return BigInt(s);
}

export function formatOpening(hub: string, seq: bigint, salt: Uint8Array, checkpoint: Uint8Array): Uint8Array {
  return formatBlockDoc(OPENING_HEADER, [`hub ${hub}`, `seq ${seq}`, `salt ${b64encode(salt)}`], [
    { type: "checkpoint", args: [], body: checkpoint },
  ]);
}

/** Checks an opening against the blinded anchor it opens: it names the hub
 * by its origin, has the entry's `seq`, and opens its commitment
 * (specs/redaction.md, section 4.4). Returns the opened checkpoint note. */
export function checkOpening(o: Opening, hub: PolicyHub, blinded: { seq: bigint; commitment: Uint8Array }): Uint8Array {
  if (o.hub !== hub.origin) fail("bad-opening", { detail: "hub" });
  if (o.seq !== blinded.seq) fail("bad-opening", { detail: "seq" });
  const note = asCode("bad-opening", () => parseNote(o.checkpoint));
  const c = anchorCommitment(o.salt, note.text);
  if (!equalBytes(c, blinded.commitment)) fail("bad-opening", { detail: "commitment" });
  return o.checkpoint;
}

/** Checks a `previous-anchor` block (specs/receipt.md, section 3.3, step 3):
 * a tlog-proof against the hub checkpoint of the link, for the subject's
 * blinded entry with the link's `seq` minus one. Returns that entry's `seq`
 * and commitment; anything else is `bad-previous-anchor`. */
export function verifyPreviousAnchor(
  input: Uint8Array | string,
  link: VerifiedHubLink,
  hub: PolicyHub,
): { seq: bigint; commitment: Uint8Array } {
  const bad = (detail: string): never => fail("bad-previous-anchor", { detail });
  if (link.kind !== "blinded" || !link.blinded) return bad("not-blinded");
  let tp: TlogProof;
  try {
    tp = parseTlogProof(input);
  } catch {
    return bad("proof");
  }
  if (!tp.extra) return bad("extra");
  let text: string;
  try {
    text = parseNote(tp.checkpoint).text;
  } catch {
    return bad("checkpoint");
  }
  // The same hub checkpoint H as the link's, which the link verified.
  if (text !== link.hub.note.text) return bad("checkpoint");
  const size = link.hub.cp.size;
  if (tp.index >= size || !verifyInclusion(tp.index, size, leafHash(tp.extra), tp.proof, link.hub.cp.root)) return bad("inclusion");
  let entry: Entry;
  try {
    entry = parseEntry(tp.extra);
    checkLayout(entry);
  } catch {
    return bad("entry");
  }
  const b = blindedEntry(entry, hub, link.subject);
  if ("wrong" in b) return bad(b.wrong);
  if (b.seq + 1n !== link.blinded.seq) return bad("seq");
  return b;
}

/** The subject the policy's log is anchored as: its origin and log key, or,
 * in a private event, its pseudo-origin and blinded key. */
export function logSubject(policy: Policy, logName: string): Subject {
  const log = policy.logs.get(logName);
  if (!log) throw new VerifyError("unknown-log", { log: logName.slice(0, 64) });
  if (policy.visibility === "private" && log.blinded) {
    return { kind: SUBJECT_BLINDED, name: log.blinded.pseudoOrigin, vkey: log.blinded.vkey };
  }
  return { kind: SUBJECT_ORIGIN, name: log.origin, vkey: log.vkey };
}

/** The subject an app hub is anchored as in a bootstrap hub. */
export function hubSubject(hub: PolicyHub): Subject {
  return { kind: SUBJECT_ORIGIN, name: hub.origin, vkey: hub.vkey };
}

/** Finds the bootstrap hub a bootstrap link comes from. */
export function bootstrapHubOf(policy: Policy, input: Uint8Array | string): PolicyHub {
  const link = parseHubLink(input);
  for (const h of policy.hubs.values()) if (h.bootstrap && h.origin === link.hubOrigin) return h;
  return fail("bad-bootstrap-link", { detail: "hub" });
}

/** The log's pair for an app hub, at `GET <log>/anchors/<hub>/browser`
 * (specs/hub.md, section 6.5): the newest browser anchor or bootstrap link
 * for the hub, the newest of the log's own links from that hub whose hub
 * checkpoint is at or below the one it covers (`B`), and the consistency
 * proof in the hub's log between the two. Verifiers check it and copy its
 * blocks into the receipt chain as they are, so they fetch no proof from a
 * hub. */
export const BROWSER_PAIR_HEADER = "vitrine/browser-pair/v1";

export interface BrowserPair {
  /** The app hub, by its name in the policy. */
  hub: string;
  /** The log's hub link from the app hub (the `browser-link` block). */
  link: Uint8Array;
  /** The browser anchor (`browser`), or the bootstrap hub's link for the
   * app hub's subject (`bootstrap`): exactly one of the two. */
  browser?: Uint8Array;
  bootstrap?: Uint8Array;
  /** The `browser-consistency` block, from the link's hub checkpoint to `B`;
   * absent when the two have one size. */
  consistency?: { from: bigint; to: bigint; body: Uint8Array };
}

const PAIR_ARITY: Readonly<Record<string, number>> = { "browser-link": 1, browser: 1, bootstrap: 1, "browser-consistency": 3 };

/** Parses a `vitrine/browser-pair/v1` document: a `browser-link <hub>`
 * block, a `browser <hub>` or a `bootstrap <hub>` block and, unless the
 * sizes are equal, a `browser-consistency <hub> <from> <to>` block with
 * `from < to`, all for one hub. As in receipt chains, the order of the
 * blocks isn't checked and unknown blocks are ignored. */
export function parseBrowserPair(input: Uint8Array | string): BrowserPair {
  const bad = (detail: string): never => fail("bad-browser-pair", { detail });
  const doc = parseBlockDoc(input, { header: BROWSER_PAIR_HEADER, keys: [], code: "bad-browser-pair" });
  const picked = pickBlocks(doc.blocks, PAIR_ARITY, "bad-browser-pair");
  const link = picked.get("browser-link");
  if (!link) return bad("browser-link");
  const browser = picked.get("browser");
  const bootstrap = picked.get("bootstrap");
  if ((browser === undefined) === (bootstrap === undefined)) bad("browser-or-bootstrap");
  const covered = (browser ?? bootstrap)!;
  const cons = picked.get("browser-consistency");
  const hub = link.args[0]!;
  if (covered.args[0] !== hub || (cons && cons.args[0] !== hub)) bad("hub");
  const out: BrowserPair = { hub, link: link.body };
  if (browser) out.browser = browser.body;
  else out.bootstrap = covered.body;
  if (cons) {
    let from = 0n;
    let to = 0n;
    try {
      from = parseDecimal(cons.args[1]!);
      to = parseDecimal(cons.args[2]!);
    } catch {
      bad("consistency-sizes");
    }
    if (from >= to) bad("consistency-sizes");
    out.consistency = { from, to, body: cons.body };
  }
  return out;
}

/** Serialises a `vitrine/browser-pair/v1` document. */
export function formatBrowserPair(a: BrowserPair): Uint8Array {
  if ((a.browser === undefined) === (a.bootstrap === undefined)) throw new TypeError("a pair has a browser anchor or a bootstrap link");
  const blocks = [{ type: "browser-link", args: [a.hub], body: a.link }];
  if (a.browser) blocks.push({ type: "browser", args: [a.hub], body: a.browser });
  else blocks.push({ type: "bootstrap", args: [a.hub], body: a.bootstrap! });
  if (a.consistency) {
    blocks.push({ type: "browser-consistency", args: [a.hub, String(a.consistency.from), String(a.consistency.to)], body: a.consistency.body });
  }
  return formatBlockDoc(BROWSER_PAIR_HEADER, [], blocks);
}
