// SPDX-License-Identifier: Apache-2.0
//
// Anchor hubs (specs/hub.md): subject keys, subject-map values, hub links
// (section 5), blinded-anchor openings (redaction.md, section 4.4) and
// bootstrap links (section 6.4).

import { b64decode, b64encode, hexEncode } from "./base64.js";
import { u16be, u64be, utf8 } from "./bytes.js";
import { formatBlockDoc, parseBase64Body, parseBlockDoc, pickBlocks } from "./blocks.js";
import { mergeCosigs, verifyCheckpoint, type CheckedCheckpoint } from "./checkpoint.js";
import { checkLayout, fieldText, fieldU64, fieldValue, parseEntry, type Entry } from "./entry.js";
import { fail, VerifyError } from "./errors.js";
import { leafHash, sha256 } from "./hash.js";
import { verifyInclusion } from "./merkle.js";
import { verifyMptProof } from "./mpt.js";
import { parseNote, verifyNote, type Vkey } from "./note.js";
import type { Policy, PolicyHub } from "./policy.js";
import { parseTlogProof, type TlogProof } from "./tlogproof.js";

export const HUB_LINK_HEADER = "vitrine/hub-link/v1";
export const OPENING_HEADER = "vitrine/blinded-opening/v1";
export const BLINDED_STATEMENT_HEADER = "vitrine/blinded-anchor/v1";

export const SUBJECT_ORIGIN = 0;
export const SUBJECT_BLINDED = 1;

/** A hub subject: an origin and its log key, or a pseudo-origin and its
 * anchoring key (section 1). */
export interface Subject {
  kind: typeof SUBJECT_ORIGIN | typeof SUBJECT_BLINDED;
  name: string;
  vkey: Vkey;
}

/** `H("vitrine/hub/v1/subject" || kind || opaque name<1..255> || opaque vkey<1..2^16-1>)` */
export function subjectKey(kind: number, name: string, vkeyText: string): Uint8Array {
  const n = utf8(name);
  const k = utf8(vkeyText);
  if (n.length < 1 || n.length > 255 || k.length < 1 || k.length > 0xffff) throw new RangeError("subject name or key length");
  return sha256("vitrine/hub/v1/subject", Uint8Array.of(kind), Uint8Array.of(n.length), n, u16be(k.length), k);
}

/** `H("vitrine/hub/v1/value" || uint64 entry_index || leaf_hash)` */
export function mapValue(entryIndex: bigint, leaf: Uint8Array): Uint8Array {
  return sha256("vitrine/hub/v1/value", u64be(entryIndex), leaf);
}

/** `H("vitrine/anchor/v1" || salt || checkpoint text)` */
export function anchorCommitment(salt: Uint8Array, checkpointText: string): Uint8Array {
  return sha256("vitrine/anchor/v1", salt, checkpointText);
}

export interface HubLink {
  hubOrigin: string;
  subjectName: string;
  subjectVkey: string;
  entry: TlogProof;
  index: TlogProof;
  map: Uint8Array;
}

function asCode<T>(code: "bad-hub-link" | "bad-opening", f: () => T): T {
  try {
    return f();
  } catch (e) {
    if (e instanceof VerifyError && (e.code === "bad-proof" || e.code === "bad-base64" || e.code === "bad-number" || e.code === "bad-text")) {
      throw new VerifyError(code, { detail: e.code });
    }
    throw e;
  }
}

export function parseHubLink(input: Uint8Array | string): HubLink {
  return asCode("bad-hub-link", () => {
    const doc = parseBlockDoc(input, { header: HUB_LINK_HEADER, keys: ["hub", "subject"], code: "bad-hub-link" });
    const [hub, subject] = doc.values as [string[], string[]];
    if (hub.length !== 1 || subject.length !== 2) fail("bad-hub-link", { detail: "lines" });
    const b = pickBlocks(doc.blocks, { entry: 0, index: 0, map: 0 }, "bad-hub-link");
    const entry = b.get("entry");
    const index = b.get("index");
    const map = b.get("map");
    if (!entry || !index || !map) fail("bad-hub-link", { detail: "blocks" });
    return {
      hubOrigin: hub[0]!,
      subjectName: subject[0]!,
      subjectVkey: subject[1]!,
      entry: parseTlogProof(entry.body),
      index: parseTlogProof(index.body),
      map: parseBase64Body(map.body),
    };
  });
}

export function formatHubLink(hubOrigin: string, subjectName: string, subjectVkey: string, entryProof: string, indexProof: string, mapProof: Uint8Array): Uint8Array {
  return formatBlockDoc(HUB_LINK_HEADER, [`hub ${hubOrigin}`, `subject ${subjectName} ${subjectVkey}`], [
    { type: "entry", args: [], body: utf8(entryProof) },
    { type: "index", args: [], body: utf8(indexProof) },
    { type: "map", args: [], body: utf8(b64encode(mapProof)) },
  ]);
}

export interface VerifiedHubLink {
  /** The hub checkpoint `H`, with the cosignatures of both proofs merged. */
  hub: CheckedCheckpoint;
  /** True when `H` meets the hub's quorum. */
  hubQuorum: boolean;
  /** Quorum time of `H`, when it meets the quorum. */
  hubQuorumTime?: number;
  entryIndex: bigint;
  entry: Entry;
  kind: "anchor" | "blinded" | "rotate";
  /** `received_at` of entry `j`, milliseconds. */
  receivedAt: bigint;
  /** For `anchor`: the app checkpoint note the entry carries. */
  anchored?: Uint8Array;
  /** For `blinded`: its sequence number and commitment. */
  blinded?: { seq: bigint; commitment: Uint8Array };
}

/** Verifies a hub link for `subject` against `hub`'s key and witnesses
 * (specs/hub.md, section 5.2, steps 1 to 3, and the entry checks of steps 4
 * and 5 that need no app policy). Damaged or mismatched links throw; a hub
 * checkpoint short of the hub's quorum is reported in `hubQuorum`. */
export function verifyHubLink(input: Uint8Array | string, hub: PolicyHub, subject: Subject, deviceNow: number): VerifiedHubLink {
  const link = parseHubLink(input);
  if (link.hubOrigin !== hub.origin) fail("hub-link-mismatch", { detail: "hub" });
  if (link.subjectName !== subject.name || link.subjectVkey !== subject.vkey.text) fail("hub-link-mismatch", { detail: "subject" });
  if (!link.entry.extra || !link.index.extra) fail("missing-extra");
  const e = verifyCheckpoint(link.entry.checkpoint, hub.vkey, hub.set, deviceNow);
  const ix = verifyCheckpoint(link.index.checkpoint, hub.vkey, hub.set, deviceNow);
  if (e.note.text !== ix.note.text) fail("hub-link-mismatch", { detail: "checkpoints" });
  const cosigs = mergeCosigs(e.cosigs, ix.cosigs);
  const hubCp: CheckedCheckpoint = { note: e.note, cp: e.cp, cosigs, future: [...new Set([...e.future, ...ix.future])] };
  const size = e.cp.size;
  if (link.index.index !== size - 1n) fail("hub-link-mismatch", { detail: "index-not-last" });
  if (link.entry.index >= link.index.index) fail("hub-link-mismatch", { detail: "entry-not-covered" });
  if (!verifyInclusion(link.index.index, size, leafHash(link.index.extra), link.index.proof, e.cp.root)) {
    fail("inclusion-failed", { what: "hub-index" });
  }
  if (!verifyInclusion(link.entry.index, size, leafHash(link.entry.extra), link.entry.proof, e.cp.root)) {
    fail("inclusion-failed", { what: "hub-entry" });
  }
  const ixEntry = parseEntry(link.index.extra);
  if (ixEntry.tag !== "vitrine/hub/v1/index") fail("hub-link-mismatch", { detail: "index-entry" });
  checkLayout(ixEntry);
  if (fieldU64(ixEntry, "covered") !== link.index.index) fail("hub-link-mismatch", { detail: "covered" });
  const key = subjectKey(subject.kind, subject.name, subject.vkey.text);
  const value = mapValue(link.entry.index, leafHash(link.entry.extra));
  if (!verifyMptProof(link.map, key, value, fieldValue(ixEntry, "root")!)) fail("map-proof-failed");

  const entry = parseEntry(link.entry.extra);
  checkLayout(entry);
  const out: VerifiedHubLink = {
    hub: hubCp,
    hubQuorum: hub.set.meets(cosigs),
    entryIndex: link.entry.index,
    entry,
    kind: "anchor",
    receivedAt: fieldU64(entry, "received_at")!,
  };
  const qt = hub.set.quorumTime(cosigs);
  if (qt !== undefined) out.hubQuorumTime = qt;
  if (entry.tag === "vitrine/hub/v1" && subject.kind === SUBJECT_ORIGIN) {
    if (fieldText(entry, "origin") !== subject.name || fieldText(entry, "key") !== subject.vkey.text) {
      fail("hub-link-mismatch", { detail: "entry-subject" });
    }
    out.anchored = fieldValue(entry, "checkpoint")!;
  } else if (entry.tag === "vitrine/hub/v1/blinded" && subject.kind === SUBJECT_BLINDED) {
    if (hexEncode(fieldValue(entry, "pseudo_origin")!) !== subject.name || fieldText(entry, "key") !== subject.vkey.text) {
      fail("hub-link-mismatch", { detail: "entry-subject" });
    }
    const seq = fieldU64(entry, "seq")!;
    const commitment = fieldValue(entry, "commitment")!;
    const st = parseNote(fieldValue(entry, "statement")!);
    const want = `${BLINDED_STATEMENT_HEADER}\nhub ${hub.origin}\npseudo ${subject.name}\nseq ${seq}\ncommitment ${b64encode(commitment)}\n`;
    if (st.text !== want) fail("bad-blinded-anchor", { detail: "statement" });
    if (!verifyNote(st, [subject.vkey]).some((v) => v.vkey === subject.vkey)) fail("bad-blinded-anchor", { detail: "signature" });
    out.kind = "blinded";
    out.blinded = { seq, commitment };
  } else if (entry.tag === "vitrine/hub/v1/rotate" && subject.kind === SUBJECT_ORIGIN) {
    if (fieldText(entry, "origin") !== subject.name || fieldText(entry, "old") !== subject.vkey.text) {
      fail("hub-link-mismatch", { detail: "entry-subject" });
    }
    out.kind = "rotate";
  } else {
    fail("hub-link-mismatch", { detail: "entry-kind" });
  }
  return out;
}

export interface Opening {
  /** The hub, by policy name or origin. */
  hub: string;
  seq: bigint;
  salt: Uint8Array;
  /** The opened checkpoint note, with its cosignatures. */
  checkpoint: Uint8Array;
}

export function parseOpening(input: Uint8Array | string): Opening {
  return asCode("bad-opening", () => {
    const doc = parseBlockDoc(input, { header: OPENING_HEADER, keys: ["hub", "seq", "salt"], code: "bad-opening" });
    if (doc.values.some((v) => v.length !== 1)) fail("bad-opening", { detail: "lines" });
    const b = pickBlocks(doc.blocks, { checkpoint: 0 }, "bad-opening");
    const cp = b.get("checkpoint");
    if (!cp) fail("bad-opening", { detail: "checkpoint" });
    const [hub, seq, salt] = doc.values.map((v) => v[0]!) as [string, string, string];
    return { hub, seq: parseSeq(seq), salt: b64decode(salt, 32), checkpoint: cp.body };
  });
}

function parseSeq(s: string): bigint {
  if (!/^[1-9][0-9]{0,18}$/.test(s)) fail("bad-opening", { detail: "seq" });
  return BigInt(s);
}

export function formatOpening(hub: string, seq: bigint, salt: Uint8Array, checkpoint: Uint8Array): Uint8Array {
  return formatBlockDoc(OPENING_HEADER, [`hub ${hub}`, `seq ${seq}`, `salt ${b64encode(salt)}`], [
    { type: "checkpoint", args: [], body: checkpoint },
  ]);
}

/** Checks an opening against the blinded anchor it opens; returns the opened
 * checkpoint note. */
export function checkOpening(o: Opening, hub: PolicyHub, blinded: { seq: bigint; commitment: Uint8Array }): Uint8Array {
  if (o.hub !== hub.name && o.hub !== hub.origin) fail("bad-opening", { detail: "hub" });
  if (o.seq !== blinded.seq) fail("bad-opening", { detail: "seq" });
  const note = asCode("bad-opening", () => parseNote(o.checkpoint));
  const c = anchorCommitment(o.salt, note.text);
  if (b64encode(c) !== b64encode(blinded.commitment)) fail("bad-opening", { detail: "commitment" });
  return o.checkpoint;
}

/** The subject the policy's log is anchored as: its origin and log key, or,
 * in a private event, its pseudo-origin and blinded key. */
export function logSubject(policy: Policy, logName: string): Subject {
  const log = policy.logs.get(logName)!;
  if (policy.visibility === "private" && log.blinded) {
    return { kind: SUBJECT_BLINDED, name: log.blinded.pseudoOrigin, vkey: log.blinded.vkey };
  }
  return { kind: SUBJECT_ORIGIN, name: log.origin, vkey: log.vkey };
}

/** The subject an app hub is anchored as in a bootstrap hub. */
export function hubSubject(hub: PolicyHub): Subject {
  return { kind: SUBJECT_ORIGIN, name: hub.origin, vkey: hub.vkey };
}

/** Finds the bootstrap hub a bootstrap link comes from. */
export function bootstrapHubOf(policy: Policy, input: Uint8Array | string): PolicyHub {
  const link = parseHubLink(input);
  for (const h of policy.hubs.values()) if (h.bootstrap && h.origin === link.hubOrigin) return h;
  return fail("bad-bootstrap-link", { detail: "hub" });
}
