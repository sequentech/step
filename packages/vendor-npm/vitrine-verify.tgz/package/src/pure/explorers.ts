// SPDX-License-Identifier: Apache-2.0
//
// Explorers named by a policy (specs/policy.md, section 2.8): static Vitrine
// explorer sites that monitors, hubs and the operator run. They are
// informational. A verifier never trusts one; they only let a voter look the
// same record up somewhere else.

import { faultyParties, type Policy } from "./policy.js";

export interface PolicyExplorer {
  /** The explorer's base URL, as the policy gives it. */
  url: string;
  /** Whose line named it. */
  kind: "monitor" | "hub" | "operator";
  /** The monitor's or hub's name; for the operator's, the operator. */
  name: string;
  /** Who runs the monitor (`monitor-party`) or hub (`hub-operator`); the
   * operator for its own explorers. */
  party: string;
  /** True for a monitor or hub whose party differs from both the policy's
   * operator and its platform. Only the order of a list depends on it. A page
   * never calls anyone "independent": it says who runs the site. */
  independent: boolean;
}

/** The explorers a policy names. Those of parties other than the operator and
 * the platform come first (monitors, then hubs, each in policy order), then
 * the other monitors' and hubs', then the operator's own. */
export function explorersOf(policy: Policy): PolicyExplorer[] {
  const independent: PolicyExplorer[] = [];
  const rest: PolicyExplorer[] = [];
  const faulty = faultyParties(policy);
  const add = (kind: "monitor" | "hub", name: string, party: string, url: string | undefined): void => {
    if (url === undefined) return;
    const isIndependent = !faulty.includes(party);
    (isIndependent ? independent : rest).push({ url, kind, name, party, independent: isIndependent });
  };
  const monitors = [...policy.monitors.values()];
  const hubs = [...policy.hubs.values()];
  // Two passes keep monitors before hubs within each group.
  for (const m of monitors) add("monitor", m.name, m.party, m.explorer);
  for (const h of hubs) add("hub", h.name, h.operator, h.explorer);
  const own = policy.explorers.map((url): PolicyExplorer => ({ url, kind: "operator", name: policy.operator, party: policy.operator, independent: false }));
  return [...independent, ...rest, ...own];
}

export interface ExplorerLinkOptions {
  /** The policy ID, `sha256:<hex>`. */
  policyId: string;
  /** The log's name in the policy. */
  log: string;
  /** A Tracking ID (full, for an exact match) or a leaf hash to find. */
  find?: string;
  /** An entry index to open. */
  entry?: bigint | number;
  /** A checkpoint to open, by size. With `cosigner` or `anchor`. */
  checkpoint?: bigint | number;
  /** A witness whose cosignature on `checkpoint` the explorer checks. */
  cosigner?: string;
  /** A hub whose anchor of `checkpoint` the explorer checks. */
  anchor?: string;
}

function size(n: bigint | number, what: string): string {
  if (typeof n === "number" && !Number.isSafeInteger(n)) throw new RangeError(`${what} is a whole number`);
  const v = typeof n === "bigint" ? n : BigInt(n);
  if (v < 0n) throw new RangeError(`${what} is not negative`);
  return v.toString();
}

/** A link into an explorer: its base URL and a fragment of the keys that the
 * explorer reads (`policy`, `log`, then `find`, `entry`, or `checkpoint` with
 * `cosigner` or `anchor`: specs/policy.md, section 2.8). The base URL's own
 * fragment, if any, is dropped. */
export function explorerLink(url: string, o: ExplorerLinkOptions): string {
  const params = new URLSearchParams();
  params.set("policy", o.policyId);
  params.set("log", o.log);
  const pointsAtCheckpoint = o.checkpoint !== undefined || o.cosigner !== undefined || o.anchor !== undefined;
  const finds = (o.find !== undefined && o.find !== "") || o.entry !== undefined;
  if (pointsAtCheckpoint && finds) throw new TypeError("a link finds an entry or points at a checkpoint, not both");
  if (o.find !== undefined && o.find !== "") params.set("find", o.find);
  if (o.entry !== undefined) params.set("entry", size(o.entry, "an entry index"));
  if (pointsAtCheckpoint) {
    if (o.checkpoint === undefined) throw new TypeError("a signer needs the checkpoint's size");
    if ((o.cosigner === undefined) === (o.anchor === undefined)) throw new TypeError("a checkpoint link names one cosigner or one anchor");
    params.set("checkpoint", size(o.checkpoint, "a checkpoint size"));
    if (o.cosigner !== undefined) params.set("cosigner", o.cosigner);
    else params.set("anchor", o.anchor!);
  }
  const hash = url.indexOf("#");
  return `${hash < 0 ? url : url.slice(0, hash)}#${params.toString()}`;
}
