// SPDX-License-Identifier: Apache-2.0
//
// Explorers named by a policy (specs/policy.md, section 2.8): static Vitrine
// explorer sites that monitors, hubs and the operator run. They are
// informational. A verifier never trusts one; they only let a voter look the
// same record up somewhere else.

import type { Policy } from "./policy.js";

export interface PolicyExplorer {
  /** The explorer's base URL, as the policy gives it. */
  url: string;
  /** Whose line named it. */
  kind: "monitor" | "hub" | "operator";
  /** The monitor's or hub's name; for the operator's, the operator. */
  name: string;
  /** Who runs the monitor (`monitor-party`) or hub (`hub-operator`); the
   * operator for its own explorers. */
  party: string;
  /** True for a monitor or hub whose party differs from the policy's operator. */
  independent: boolean;
}

/** The explorers a policy names. Independent ones come first (monitors, then
 * hubs, each in policy order), then the other monitors' and hubs', then the
 * operator's own. */
export function explorersOf(policy: Policy): PolicyExplorer[] {
  const independent: PolicyExplorer[] = [];
  const rest: PolicyExplorer[] = [];
  const add = (kind: "monitor" | "hub", name: string, party: string, url: string | undefined): void => {
    if (url === undefined) return;
    const isIndependent = party !== policy.operator;
    (isIndependent ? independent : rest).push({ url, kind, name, party, independent: isIndependent });
  };
  const monitors = [...policy.monitors.values()];
  const hubs = [...policy.hubs.values()];
  // Two passes keep monitors before hubs within each group.
  for (const m of monitors) add("monitor", m.name, m.party, m.explorer);
  for (const h of hubs) add("hub", h.name, h.operator, h.explorer);
  const own = policy.explorers.map((url): PolicyExplorer => ({ url, kind: "operator", name: policy.operator, party: policy.operator, independent: false }));
  return [...independent, ...rest, ...own];
}

export interface ExplorerLinkOptions {
  /** The policy ID, `sha256:<hex>`. */
  policyId: string;
  /** The log's name in the policy. */
  log: string;
  /** A Tracking ID (full, for an exact match) or a leaf hash to find. */
  find?: string;
  /** An entry index to open. */
  entry?: bigint | number;
}

/** A link into an explorer: its base URL and a fragment of the keys that the
 * explorer reads (`policy`, `log`, `find` or `entry`). The base URL's own
 * fragment, if any, is dropped. */
export function explorerLink(url: string, o: ExplorerLinkOptions): string {
  const params = new URLSearchParams();
  params.set("policy", o.policyId);
  params.set("log", o.log);
  if (o.find !== undefined && o.find !== "") params.set("find", o.find);
  if (o.entry !== undefined) {
    const n = typeof o.entry === "bigint" ? o.entry : BigInt(o.entry);
    if (n < 0n) throw new RangeError("an entry index is not negative");
    params.set("entry", n.toString());
  }
  const hash = url.indexOf("#");
  return `${hash < 0 ? url : url.slice(0, hash)}#${params.toString()}`;
}
