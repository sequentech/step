// SPDX-License-Identifier: Apache-2.0
//
// The parts of WAICT (waict-proofs.md and waict-apis.md, at the commit in
// testdata/waict/COMMIT) that the browser layer uses: ChainHeadWithProof,
// waict-cosignature/v1 prefix roots (signature type 0x06, IT-23), and the
// data-only manifests of specs/hub.md, section 6.

import { b64decode, b64encode, b64urlEncode } from "./base64.js";
import { concat, equalBytes, fromUtf8, parseDecimal, readU64, Reader, u16be, u64be, utf8 } from "./bytes.js";
import { fail, VerifyError } from "./errors.js";
import { sha256 } from "./hash.js";
import { canonicalJson, parseCanonicalJson } from "./json.js";
import { keyId, parseNote } from "./note.js";
import { HUB_TAG } from "./tags.js";

export const SIG_WAICT_COSIGNATURE = 0x06;
export const PREFIX_ROOT_HEADER = "waict-cosignature/v1";
export const CHAIN_NODE_SIZE = 112;
/** The hub profile that a manifest names. */
export const HUB_PROFILE = HUB_TAG;

export interface ChainNode {
  position: bigint;
  timeCreated: bigint;
  resourceHash: Uint8Array;
  assetHostsHash: Uint8Array;
  chainHash: Uint8Array;
  /** The TLS serialisation, 112 bytes. */
  bytes: Uint8Array;
}

export interface ChainHeadWithProof {
  head: ChainNode;
  incProof: Uint8Array;
  signedPrefixRoot: Uint8Array;
}

/** `H("waict-rh" || resource)` */
export const resourceHash = (resource: Uint8Array): Uint8Array => sha256("waict-rh", resource);
/** The prefix-tree key of a domain: `H("waict-kh" || domain)`. */
export const domainKey = (domain: string): Uint8Array => sha256("waict-kh", domain);
/** The prefix-tree value of a chain head: `H("waict-ch" || head)`. */
export const chainValue = (head: Uint8Array): Uint8Array => sha256("waict-ch", head);

export function parseChainNode(b: Uint8Array): ChainNode {
  if (b.length !== CHAIN_NODE_SIZE) fail("bad-waict-proof", { detail: "chain-node" });
  return {
    position: readU64(b, 0),
    timeCreated: readU64(b, 8),
    resourceHash: b.slice(16, 48),
    assetHostsHash: b.slice(48, 80),
    chainHash: b.slice(80, 112),
    bytes: b.slice(),
  };
}

export function encodeChainNode(n: Omit<ChainNode, "bytes">): Uint8Array {
  return concat(u64be(n.position), u64be(n.timeCreated), n.resourceHash, n.assetHostsHash, n.chainHash);
}

/** Parses a ChainHeadWithProof: a ChainNode, `inc_proof<1..2^14-1>` and
 * `signed_prefix_root<1..2^24-1>`, with nothing after them. */
export function parseChainHeadWithProof(b: Uint8Array): ChainHeadWithProof {
  try {
    const r = new Reader(b);
    const head = parseChainNode(r.bytes(CHAIN_NODE_SIZE));
    const n = r.u16();
    if (n < 1 || n > 0x3fff) fail("bad-waict-proof", { detail: "inc-proof-length" });
    const incProof = r.bytes(n).slice();
    const m = r.u24();
    if (m < 1) fail("bad-waict-proof", { detail: "prefix-root-length" });
    const signedPrefixRoot = r.bytes(m).slice();
    r.end();
    return { head, incProof, signedPrefixRoot };
  } catch (e) {
    if (e instanceof VerifyError && e.code === "bad-waict-proof") throw e;
    return fail("bad-waict-proof", { detail: "framing" });
  }
}

export function encodeChainHeadWithProof(head: Uint8Array, incProof: Uint8Array, signedPrefixRoot: Uint8Array): Uint8Array {
  const m = signedPrefixRoot.length;
  return concat(head, u16be(incProof.length), incProof, Uint8Array.of(m >>> 16, (m >>> 8) & 0xff, m & 0xff), signedPrefixRoot);
}

export interface PrefixRoot {
  time: bigint;
  /** The transparency service's domain (before `/prefix-tree`). */
  service: string;
  size: bigint;
  root: Uint8Array;
}

export function parsePrefixRootText(text: string): PrefixRoot {
  if (!text.endsWith("\n")) fail("bad-waict-proof", { detail: "prefix-root" });
  const lines = text.slice(0, -1).split("\n");
  if (lines.length !== 5 || lines[0] !== PREFIX_ROOT_HEADER || !lines[1]!.startsWith("time ")) {
    fail("bad-waict-proof", { detail: "prefix-root" });
  }
  const origin = lines[2]!;
  if (!origin.endsWith("/prefix-tree")) fail("bad-waict-proof", { detail: "prefix-root-origin" });
  try {
    return {
      time: parseDecimal(lines[1]!.slice(5)),
      service: origin.slice(0, -"/prefix-tree".length),
      size: parseDecimal(lines[3]!),
      root: b64decode(lines[4]!, 32),
    };
  } catch {
    return fail("bad-waict-proof", { detail: "prefix-root" });
  }
}

/** A `waict-witness` line of the policy. */
export interface WaictKey {
  name: string;
  key: Uint8Array;
  ed: { verify(msg: Uint8Array, sig: Uint8Array): boolean };
}

/** Verifies a signed prefix root for `service`: at least `quorum` distinct
 * `keys` with a valid 0x06 signature whose timestamp is the note's `time`.
 * Other signature lines are ignored. */
export function verifyPrefixRoot(
  input: Uint8Array,
  service: string,
  keys: readonly WaictKey[],
  quorum: number,
): PrefixRoot & { signers: string[] } {
  let note;
  try {
    note = parseNote(input);
  } catch {
    return fail("bad-waict-proof", { detail: "prefix-root-note" });
  }
  const pr = parsePrefixRootText(note.text);
  if (pr.service !== service) fail("bad-waict-proof", { detail: "prefix-root-service" });
  const signers: string[] = [];
  for (const sg of note.sigs) {
    const k = keys.find((x) => x.name === sg.name && keyId(x.name, SIG_WAICT_COSIGNATURE, x.key) === sg.keyId);
    if (!k || signers.includes(k.name) || sg.sig.length !== 72) continue;
    if (readU64(sg.sig, 0) !== pr.time) continue;
    if (k.ed.verify(note.textBytes, sg.sig.subarray(8))) signers.push(k.name);
  }
  if (signers.length < quorum) fail("waict-quorum-not-met", { have: signers.length, need: quorum });
  return { ...pr, signers };
}

/** The prefix root's note text (for tools and tests). */
export function formatPrefixRootText(pr: PrefixRoot): string {
  return `${PREFIX_ROOT_HEADER}\ntime ${pr.time}\n${pr.service}/prefix-tree\n${pr.size}\n${b64encode(pr.root)}\n`;
}

/** The URL whose hash a hub manifest carries. */
export const checkpointUrl = (domain: string, size: bigint): string => `https://${domain}/checkpoints/${size}`;

/** Builds a hub's data-only manifest (specs/hub.md, section 6, step 2). */
export function buildManifest(hubOrigin: string, domain: string, size: bigint, time: string, checkpoint: Uint8Array): Uint8Array {
  if (size > BigInt(Number.MAX_SAFE_INTEGER)) throw new RangeError("size too large for a JSON number");
  return utf8(
    canonicalJson({
      url_hashes: { [checkpointUrl(domain, size)]: b64urlEncode(sha256(checkpoint)) },
      vitrine: { origin: hubOrigin, profile: HUB_PROFILE, size: Number(size), time },
    }),
  );
}

const MANIFEST_TIME_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;

/** True when `t` is a real UTC time written exactly as `YYYY-MM-DDTHH:MM:SSZ`. */
function isManifestTime(t: string): boolean {
  if (!MANIFEST_TIME_RE.test(t)) return false;
  const d = new Date(t);
  return !Number.isNaN(d.getTime()) && d.toISOString() === `${t.slice(0, -1)}.000Z`;
}

/** Checks a manifest (specs/hub.md, section 6.3, step 2): it must be exactly
 * the bytes that section 6 builds for `domain`, the hub origin, the size,
 * the checkpoint and the manifest's own `time`. The fields are compared
 * first, so the reason names the one that differs. Returns `time`, in POSIX
 * seconds. */
export function checkManifest(
  manifest: Uint8Array,
  hubOrigin: string,
  domain: string,
  size: bigint,
  checkpoint: Uint8Array,
): number {
  const bad = (detail: string): never => fail("bad-browser-anchor", { detail });
  let text = "";
  try {
    text = fromUtf8(manifest);
  } catch {
    bad("manifest-text");
  }
  const m = parseCanonicalJson(text);
  if (typeof m !== "object" || m === null || Array.isArray(m)) return bad("manifest-json");
  const o = m as Record<string, unknown>;
  const v = o["vitrine"];
  const u = o["url_hashes"];
  if (typeof v !== "object" || v === null || Array.isArray(v)) return bad("manifest-vitrine");
  if (typeof u !== "object" || u === null || Array.isArray(u)) return bad("manifest-url-hashes");
  const vit = v as Record<string, unknown>;
  if (vit["origin"] !== hubOrigin) bad("manifest-origin");
  if (vit["profile"] !== HUB_PROFILE) bad("manifest-profile");
  const s = vit["size"];
  if (typeof s !== "number" || !Number.isSafeInteger(s) || BigInt(s) !== size) bad("manifest-size");
  const time = vit["time"];
  if (typeof time !== "string" || !isManifestTime(time)) return bad("manifest-time");
  const url = checkpointUrl(domain, size);
  const hashes = u as Record<string, unknown>;
  if (!Object.hasOwn(hashes, url) || hashes[url] !== b64urlEncode(sha256(checkpoint))) bad("manifest-hash");
  if (!equalBytes(buildManifest(hubOrigin, domain, size, time, checkpoint), manifest)) bad("manifest-bytes");
  return Date.parse(time) / 1000;
}

/** True when two ChainNodes are byte-identical. */
export const sameChainNode = (a: ChainNode, b: ChainNode): boolean => equalBytes(a.bytes, b.bytes);
