// SPDX-License-Identifier: Apache-2.0
//
// Accepting a promise (specs/receipt.md, section 2, "Accepting a promise"):
// the client that gets a promise holds it only if the batch's `time` is at
// most 60 seconds from now. Now is the quorum-vouched time (section 3.1) of
// the log's latest checkpoint, which the client fetches when it gets the
// promise; in a quiet period, or when that checkpoint doesn't meet the
// quorum, now is the device clock. Any other promise is no promise to the
// client, which still escrows it with a monitor (section 2.1), so that
// monitors can report it.

import type { Expect, Reason } from "../types.js";
import { equalBytes, fromUtf8 } from "./bytes.js";
import { expectedEntry } from "./entry.js";
import { fail, reason, toReason } from "./errors.js";
import { leafHash } from "./hash.js";
import { logKeys, PolicyHistory, vouchedNow } from "./history.js";
import { parseNote } from "./note.js";
import { inQuietPeriod, profileAt, type Policy } from "./policy.js";
import { parsePromise, parsePromiseBatchText, PROMISE_ACCEPT_WINDOW, verifyPromise, type VerifiedPromise } from "./promise.js";
import { ELECTION_TAG } from "./tags.js";

export interface AcceptPromiseOptions {
  /** The device clock, POSIX seconds. */
  now: number;
  /** The log's latest checkpoint, as `GET <log>/checkpoint` served it when
   * the client got the promise. Without it, now is the device clock. */
  latest?: string | Uint8Array;
  /** The pinned policy with the successors the client applied; the batch
   * may name any of them. Default: the pinned policy alone. */
  history?: PolicyHistory;
  /** What the entry must be. When given, a promise for another entry isn't
   * accepted (`promise-leaf-mismatch`). */
  expect?: Expect;
}

export interface PromiseAcceptance {
  /** True when the promise verifies (and is for the expected entry, when
   * one is given) and its `time` is at most 60 seconds from `now`.
   * Otherwise the client treats it as no promise. */
  accepted: boolean;
  /** The promise, as text, whenever it verifies, accepted or not: the
   * client escrows it with one of the policy's monitors (section 2.1).
   * Undefined when it doesn't verify, since it then promises nothing. */
  escrow?: string;
  /** The verified promise: the batch with its `time`, the leaf and the
   * deadline. */
  promise?: VerifiedPromise;
  /** The now that `time` was compared with, POSIX seconds. */
  now: number;
  /** Where `now` comes from: the latest checkpoint's quorum-vouched time,
   * or the device clock. */
  clock: "vouched" | "device";
  /** Why the promise isn't accepted (`promise-time`, or what doesn't
   * verify), and why `now` is the device clock (`log-quiet`,
   * `no-signed-time`). */
  reasons: Reason[];
}

/** Judges a promise that log `log` just gave (specs/receipt.md, section 2):
 * it verifies under the pinned policy or an applied successor, as the batch
 * names, and its `time` is at most 60 seconds from now. Now is the
 * quorum-vouched time of `opts.latest`, capped at the device clock plus 300
 * seconds; while the log's election period is quiet (specs/policy.md,
 * section 2.1), or when that checkpoint is missing or doesn't meet the
 * quorum, it is the device clock. Never throws for bad input: the reasons
 * say what failed. */
export function acceptPromise(promise: string | Uint8Array, policy: Policy, log: string, opts: AcceptPromiseOptions): PromiseAcceptance {
  const h = opts.history ?? new PolicyHistory(policy);
  if (h.pinned.id !== policy.id) throw new TypeError("opts.history is for another pinned policy");
  const deviceNow = opts.now;
  const reasons: Reason[] = [];
  const inForce = h.at(deviceNow);
  const pl = inForce.logs.get(log) ?? policy.logs.get(log);
  let now = deviceNow;
  let clock: PromiseAcceptance["clock"] = "device";
  // A quiet log serves its pre-quiet checkpoint, whose time stays behind.
  if (pl && pl.profiles.some((p) => p.tag === ELECTION_TAG) && inQuietPeriod(inForce, deviceNow)) {
    reasons.push(reason("log-quiet"));
  } else {
    const vouched = opts.latest === undefined ? undefined : vouchedNow(h, [opts.latest], logKeys(log), deviceNow);
    if (vouched === undefined) {
      reasons.push(reason("no-signed-time"));
    } else {
      now = vouched;
      clock = "vouched";
    }
  }
  const out: PromiseAcceptance = { accepted: false, now, clock, reasons };
  try {
    out.promise = verifyUnder(promise, h, log);
    out.escrow = typeof promise === "string" ? promise : fromUtf8(promise);
  } catch (e) {
    delete out.promise;
    reasons.push(toReason(e, ["promise"]));
    return out;
  }
  const p = out.promise;
  if (opts.expect) {
    let want: Uint8Array | undefined;
    try {
      want = expectedEntry(opts.expect, pl ? profileAt(pl, undefined).tag : undefined);
    } catch (e) {
      reasons.push(toReason(e));
      return out;
    }
    if (!want) {
      reasons.push(reason("expectation-incomplete"));
      return out;
    }
    if (!equalBytes(leafHash(want), p.leaf)) {
      reasons.push(reason("promise-leaf-mismatch", undefined, ["promise"]));
      return out;
    }
  }
  if (Math.abs(p.batch.time - now) > PROMISE_ACCEPT_WINDOW) {
    reasons.push(reason("promise-time", { time: p.batch.time, now }, ["promise"]));
    return out;
  }
  out.accepted = true;
  return out;
}

/** Verifies a promise with the log key and terms of the policy its batch
 * names, which must be in `h`. */
function verifyUnder(promise: string | Uint8Array, h: PolicyHistory, log: string): VerifiedPromise {
  const batch = parsePromiseBatchText(parseNote(parsePromise(promise).batchNote).text);
  const bp = h.byId(batch.policy);
  if (!bp) fail("promise-policy-unknown", { policy: batch.policy });
  const bl = bp.logs.get(log);
  if (!bl) fail("unknown-log", { log: log.slice(0, 64) });
  const terms = { mmd: bp.mmd, skew: bp.skew };
  return verifyPromise(promise, bl.vkey, (id) => (id === bp.id ? terms : undefined));
}
