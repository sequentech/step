// SPDX-License-Identifier: Apache-2.0
//
// The hub state machine (specs/hub.md, section 7.1): the rules that every hub
// entry follows, which the hub's sequencer and every hub witness apply, and
// their effects on the hub state: the subjects, with their declarations
// (section 2.1), anchors, rotations and updates, the subject map (section 4)
// and the hub log's tree. Anyone who replays a hub's entries with it checks
// what the hub witnesses should have checked, which is how `hub-entry`
// evidence that needs a scan is judged (specs/evidence.md, section 2.6).
//
// An entry that breaks a rule throws `hub-entry-refused`, whose `rule` names
// the rule (HubRule) and whose `index` is the index the entry would have
// had, and leaves the state as it was.

import { b64decode, hexDecode, hexEncode } from "./base64.js";
import { equalBytes, parseDecimal, utf8 } from "./bytes.js";
import { EMPTY_TREE_ROOT, parseCheckpointText, type Checkpoint } from "./checkpoint.js";
import { checkLayout, fieldText, fieldU64, fieldValue, parseEntry, type Entry } from "./entry.js";
import { VerifyError, type Params } from "./errors.js";
import { leafHash, nodeHash, sha256 } from "./hash.js";
import {
  BLINDED_STATEMENT_HEADER,
  makeSubject,
  mapValue,
  ROTATE_STATEMENT_HEADER,
  SUBJECT_BLINDED,
  SUBJECT_ORIGIN,
  subjectKey,
  type Subject,
} from "./hub.js";
import { verifyConsistency } from "./merkle.js";
import { mptRoot, type MptLeaf } from "./mpt.js";
import { isValidKeyName, normalizeNote, parseNote, parseVkey, SIG_COSIGNATURE_V1, SIG_ED25519, verifyNote, type Note, type Vkey } from "./note.js";
import { isReservedOrigin, type Authority } from "./policy.js";
import { WitnessSet, type Group } from "./quorum.js";
import { HUB_TAGS } from "./tags.js";

export { HUB_TAGS } from "./tags.js";

/** A hub entry is at most 16 KiB (section 2). */
export const MAX_HUB_ENTRY_SIZE = 16384;
/** A declaration has 1 to 31 witnesses (section 2.1, rule 1). */
export const MAX_DECLARED_WITNESSES = 31;
export const ENROLL_STATEMENT_HEADER = "vitrine/hub-enroll/v1";
export const UPDATE_STATEMENT_HEADER = "vitrine/hub-update/v1";

const TAGS: ReadonlySet<string> = new Set(Object.values(HUB_TAGS));

/** The rules of section 7.1 that an entry can break: the `rule` of a
 * `hub-entry-refused` error. Where section 7.2 gives a rule's break an
 * evidence form, the rule's name says which in its comment. */
export type HubRule =
  /** Not a hub entry within the limits, or a statement or subject key in it
   * doesn't parse. */
  | "malformed"
  /** A statement's `hub` line names another hub. */
  | "wrong-hub"
  /** `received_at` (an index entry's `time`) is before the previous
   * entry's ("time going back"). */
  | "time-going-back"
  /** A statement's lines aren't the entry's fields ("field mismatch"). */
  | "field-mismatch"
  /** A statement or anchored checkpoint lacks the signature of a key the
   * rule needs: the subject's ("bad signature" for an anchor), or a
   * rotation's old or new key ("bad rotation"). */
  | "bad-signature"
  /** Fewer than `rotation` of the subject's authorities signed a rotation or
   * an update ("bad rotation"). */
  | "authorities"
  /** An enrolment or update doesn't give a valid declaration (section 2.1,
   * rules 1 to 6). */
  | "bad-declaration"
  /** The subject, or a rotation's new subject, is already enrolled. */
  | "enrolled"
  /** The subject isn't an enrolled subject of the entry's kind. */
  | "not-enrolled"
  /** A rotation froze the subject (for an anchor, a "fork"). */
  | "frozen"
  /** The anchored checkpoint has extension lines or another origin, or has
   * size 0 and another root than the empty tree's. */
  | "bad-checkpoint"
  /** The anchored checkpoint isn't in normal form under the declaration. */
  | "not-normal"
  /** The anchored checkpoint doesn't meet the declared quorum ("below
   * quorum"). */
  | "below-quorum"
  /** `old_size` isn't the latest anchor's size (0 without one), or the
   * checkpoint is smaller than the latest anchor. */
  | "old-size"
  /** The proof isn't empty where it must be, or doesn't show the checkpoint
   * extending the latest anchor. */
  | "proof"
  /** A same-size anchor with another root than the latest anchor's
   * ("fork"). */
  | "fork"
  /** A same-size anchor whose counting cosigners aren't a strict superset
   * of the latest anchor's that are still declared. */
  | "cosigners"
  /** A blinded anchor's `seq` isn't the subject's last plus one. */
  | "seq"
  /** A rotation's `size` and `root` aren't the old subject's latest anchor
   * ("bad rotation"). */
  | "rotation-anchor"
  /** A rotation's new key is its old key. */
  | "same-key"
  /** An update adds an authority, or changes one's name or key. */
  | "authority-added"
  /** An update lowers `rotation`. */
  | "rotation-lowered"
  /** The same update statement was applied to the subject before. */
  | "replayed"
  /** An index entry's `covered` or `root` disagrees with the entries before
   * it ("bad index"). */
  | "bad-index";

function refuse(rule: HubRule, detail?: string): never {
  const params: Params = { rule };
  if (detail !== undefined) params.detail = detail;
  throw new VerifyError("hub-entry-refused", params);
}

function malformed(detail: string): never {
  return refuse("malformed", detail);
}

// ---------------------------------------------------------------------------
// Statements (sections 2.1 to 2.6)

/** One kind of line in a statement grammar: the keywords that may fill it
 * (`witness` and `group` lines share one), and how many times. */
interface Slot {
  readonly keys: readonly string[];
  readonly min: number;
  readonly max: number;
}

const one = (key: string): Slot => ({ keys: [key], min: 1, max: 1 });
const opt = (key: string): Slot => ({ keys: [key], min: 0, max: 1 });
const many = (...keys: string[]): Slot => ({ keys, min: 0, max: Infinity });

/** A statement's lines after its header, as keyword and arguments, checked
 * against `slots`: lines in the slots' order, each slot's lines between its
 * bounds, arguments separated by single spaces. */
function statementLines(text: string, header: string, slots: readonly Slot[]): [string, string[]][] {
  if (!text.endsWith("\n")) malformed("no-final-newline");
  const lines = text.slice(0, -1).split("\n");
  if (lines[0] !== header) malformed("header");
  const out: [string, string[]][] = [];
  let s = 0;
  let n = 0;
  for (const line of lines.slice(1)) {
    const toks = line.split(" ");
    if (toks.some((t) => t.length === 0)) malformed("spacing");
    const kw = toks[0]!;
    while (s < slots.length && !slots[s]!.keys.includes(kw)) {
      if (n < slots[s]!.min) malformed(`missing-${slots[s]!.keys[0]!}`);
      s++;
      n = 0;
    }
    if (s === slots.length) malformed("line-order");
    if (++n > slots[s]!.max) malformed(`repeated-${kw}`);
    out.push([kw, toks.slice(1)]);
  }
  for (; s < slots.length; s++, n = 0) if (n < slots[s]!.min) malformed(`missing-${slots[s]!.keys[0]!}`);
  return out;
}

function arity(kw: string, args: readonly string[], min: number, max: number = min): void {
  if (args.length < min || args.length > max) malformed(`arguments-${kw}`);
}

function value(lines: readonly [string, string[]][], kw: string): string | undefined {
  const l = lines.find((x) => x[0] === kw);
  if (!l) return undefined;
  arity(kw, l[1], 1);
  return l[1][0]!;
}

function int(kw: string, s: string): bigint {
  try {
    return parseDecimal(s);
  } catch {
    return malformed(`number-${kw}`);
  }
}

function vkeyOf(kw: string, s: string): Vkey {
  try {
    return parseVkey(s);
  } catch {
    return malformed(`vkey-${kw}`);
  }
}

function hash32(kw: string, s: string): Uint8Array {
  try {
    return b64decode(s, 32);
  } catch {
    return malformed(`base64-${kw}`);
  }
}

const POLICY_ID_RE = /^sha256:[0-9a-f]{64}$/;
const PSEUDO_RE = /^[0-9a-f]{64}$/;
/** Names of witnesses, groups and authorities (section 2.1, rule 2). */
const NAME_RE = /^[A-Za-z0-9._-]{1,64}$/;

function policyId(s: string): string {
  if (!POLICY_ID_RE.test(s)) malformed("policy");
  return s;
}

function noteOf(input: Uint8Array | string): Note {
  try {
    return parseNote(input);
  } catch (e) {
    if (e instanceof VerifyError) malformed(`note-${e.code}`);
    throw e;
  }
}

/** A `witness` or `group` line of a declaration. */
export type CosignerLine = { kind: "witness"; name: string; vkey: Vkey } | { kind: "group"; name: string; k: number; members: string[] };

/** A subject's declaration (section 2.1): its cosigners and quorum, from the
 * `witness`, `group` and `quorum` lines, and its rotation authorities with
 * their threshold `rotation`. */
export interface Declaration {
  /** The `witness` and `group` lines, in their order. */
  cosigners: CosignerLine[];
  quorum: string;
  authorities: Authority[];
  rotation: number;
}

/** The declaration lines of an enrolment or update statement. `witness`
 * and `group` lines may interleave, as in a policy, so long as each group's
 * members come before it (rule 3); a witness's URL is ignored. */
function declarationLines(lines: readonly [string, string[]][]): {
  cosigners: CosignerLine[];
  quorum?: string;
  authorities?: Authority[];
  rotation?: number;
} {
  const cosigners: CosignerLine[] = [];
  const authorities: Authority[] = [];
  let quorum: string | undefined;
  let rotation: number | undefined;
  for (const [kw, a] of lines) {
    if (kw === "witness") {
      arity(kw, a, 2, 3);
      cosigners.push({ kind: "witness", name: a[0]!, vkey: vkeyOf(kw, a[1]!) });
    } else if (kw === "group") {
      if (a.length < 3) malformed("arguments-group");
      const members = a.slice(2);
      const t = a[1]!;
      // A k above 2^53 is still above the number of members, as rule 3 needs.
      const k = t === "any" ? 1 : t === "all" ? members.length : Number(int(kw, t));
      cosigners.push({ kind: "group", name: a[0]!, k, members });
    } else if (kw === "quorum") {
      arity(kw, a, 1);
      quorum = a[0]!;
    } else if (kw === "authority") {
      arity(kw, a, 2);
      authorities.push({ name: a[0]!, vkey: vkeyOf(kw, a[1]!) });
    } else if (kw === "rotation") {
      arity(kw, a, 1);
      rotation = Number(int(kw, a[0]!));
    }
  }
  const out: { cosigners: CosignerLine[]; quorum?: string; authorities?: Authority[]; rotation?: number } = { cosigners };
  if (quorum !== undefined) out.quorum = quorum;
  if (authorities.length > 0) out.authorities = authorities;
  if (rotation !== undefined) out.rotation = rotation;
  return out;
}

/** An enrolment statement (section 2.1). */
export interface EnrollStatement {
  note: Note;
  hub: string;
  kind: "origin" | "blinded";
  name: string;
  /** The subject's vkey, as written. */
  key: string;
  time: bigint;
  /** An origin subject's declaration; a blinded statement has none. */
  declaration?: Declaration;
}

const ENROLL_SLOTS = [
  one("hub"),
  one("kind"),
  one("name"),
  one("key"),
  one("time"),
  many("witness", "group"),
  opt("quorum"),
  many("authority"),
  opt("rotation"),
];

/** Parses an enrolment statement. An origin statement must declare a
 * quorum and a rotation threshold, and a blinded one must declare nothing;
 * whether the declaration is valid is checkDeclaration's call. */
export function parseEnrollStatement(input: Uint8Array | string): EnrollStatement {
  const note = noteOf(input);
  const lines = statementLines(note.text, ENROLL_STATEMENT_HEADER, ENROLL_SLOTS);
  const kind = value(lines, "kind")!;
  if (kind !== "origin" && kind !== "blinded") malformed("kind");
  const key = value(lines, "key")!;
  vkeyOf("key", key);
  const out: EnrollStatement = {
    note,
    hub: value(lines, "hub")!,
    kind,
    name: value(lines, "name")!,
    key,
    time: int("time", value(lines, "time")!),
  };
  const d = declarationLines(lines);
  if (kind === "blinded") {
    if (lines.length > 5) refuse("bad-declaration", "blinded");
    return out;
  }
  if (d.quorum === undefined) refuse("bad-declaration", "quorum");
  if (d.rotation === undefined) refuse("bad-declaration", "rotation");
  out.declaration = { cosigners: d.cosigners, quorum: d.quorum, authorities: d.authorities ?? [], rotation: d.rotation };
  return out;
}

/** A key rotation statement (section 2.5). */
export interface RotateStatement {
  note: Note;
  hub: string;
  kind: string;
  name: string;
  policy: string;
  /** The old and the new vkey, as written. */
  old: string;
  new: string;
  size: bigint;
  root: Uint8Array;
  time: bigint;
}

const ROTATE_SLOTS = ["hub", "kind", "name", "policy", "old", "new", "size", "root", "time"].map(one);

export function parseRotateStatement(input: Uint8Array | string): RotateStatement {
  const note = noteOf(input);
  const lines = statementLines(note.text, ROTATE_STATEMENT_HEADER, ROTATE_SLOTS);
  const v = (kw: string): string => value(lines, kw)!;
  vkeyOf("old", v("old"));
  vkeyOf("new", v("new"));
  return {
    note,
    hub: v("hub"),
    kind: v("kind"),
    name: v("name"),
    policy: policyId(v("policy")),
    old: v("old"),
    new: v("new"),
    size: int("size", v("size")),
    root: hash32("root", v("root")),
    time: int("time", v("time")),
  };
}

/** A declaration update statement (section 2.6). */
export interface UpdateStatement {
  note: Note;
  hub: string;
  name: string;
  policy: string;
  cosigners: CosignerLine[];
  quorum: string;
  /** The authorities that replace the subject's, if the statement has any. */
  authorities?: Authority[];
  /** The `rotation` that replaces the subject's, if the statement has one. */
  rotation?: number;
}

const UPDATE_SLOTS = [one("hub"), one("name"), one("policy"), many("witness", "group"), one("quorum"), many("authority"), opt("rotation")];

export function parseUpdateStatement(input: Uint8Array | string): UpdateStatement {
  const note = noteOf(input);
  const lines = statementLines(note.text, UPDATE_STATEMENT_HEADER, UPDATE_SLOTS);
  const d = declarationLines(lines);
  const out: UpdateStatement = {
    note,
    hub: value(lines, "hub")!,
    name: value(lines, "name")!,
    policy: policyId(value(lines, "policy")!),
    cosigners: d.cosigners,
    quorum: d.quorum!,
  };
  if (d.authorities) out.authorities = d.authorities;
  if (d.rotation !== undefined) out.rotation = d.rotation;
  return out;
}

/** A blinded anchor statement (section 2.3). */
export interface BlindedStatement {
  note: Note;
  hub: string;
  /** The pseudo-origin, 64 lowercase hex digits. */
  pseudo: string;
  seq: bigint;
  commitment: Uint8Array;
}

const BLINDED_SLOTS = ["hub", "pseudo", "seq", "commitment"].map(one);

export function parseBlindedStatement(input: Uint8Array | string): BlindedStatement {
  const note = noteOf(input);
  const lines = statementLines(note.text, BLINDED_STATEMENT_HEADER, BLINDED_SLOTS);
  const pseudo = value(lines, "pseudo")!;
  if (!PSEUDO_RE.test(pseudo)) malformed("pseudo");
  return {
    note,
    hub: value(lines, "hub")!,
    pseudo,
    seq: int("seq", value(lines, "seq")!),
    commitment: hash32("commitment", value(lines, "commitment")!),
  };
}

// ---------------------------------------------------------------------------
// Declarations and anchored checkpoints (sections 2 and 2.1)

/** Checks `d` against rules 1 to 6 of section 2.1 for the subject whose key
 * is `subject`, and returns its witnesses, groups and quorum as a witness
 * set. Throws `hub-entry-refused` with rule `bad-declaration`. */
export function checkDeclaration(d: Declaration, subject: Vkey): WitnessSet {
  const bad = (detail: string): never => refuse("bad-declaration", detail);
  const witnesses = d.cosigners.filter((c): c is Extract<CosignerLine, { kind: "witness" }> => c.kind === "witness");
  // Rule 1: 1 to 31 cosigner keys of type 0x04, with distinct key names.
  if (witnesses.length < 1 || witnesses.length > MAX_DECLARED_WITNESSES) bad("witness-count");
  const keyNames = new Set<string>();
  for (const w of witnesses) {
    if (w.vkey.type !== SIG_COSIGNATURE_V1) bad("witness-key-type");
    if (keyNames.has(w.vkey.name)) bad("witness-key-name");
    keyNames.add(w.vkey.name);
  }
  // Rules 2 and 3, in line order: names, and groups over earlier lines.
  const set = new WitnessSet();
  const members = new Set<string>();
  for (const c of d.cosigners) {
    if (!NAME_RE.test(c.name)) bad("name");
    if (set.witnesses.has(c.name) || set.groups.has(c.name)) bad("duplicate-name");
    if (c.kind === "witness") {
      set.witnesses.set(c.name, { name: c.name, vkey: c.vkey, party: c.name, partyGiven: false });
      continue;
    }
    for (const m of c.members) {
      if (!set.witnesses.has(m) && !set.groups.has(m)) bad("member-undefined");
      if (members.has(m)) bad("member-reused");
      members.add(m);
    }
    if (!(c.k >= 1 && c.k <= c.members.length)) bad("group-k");
    const g: Group = { name: c.name, k: c.k, members: [...c.members] };
    set.groups.set(c.name, g);
  }
  // Rule 4: the quorum is a group or a witness, never `none`.
  if (d.quorum === "none" || (!set.witnesses.has(d.quorum) && !set.groups.has(d.quorum))) bad("quorum");
  set.quorum = d.quorum;
  // Rule 5: Ed25519 authorities, with their own unique names (rule 2), and
  // 1 <= rotation <= their number.
  if (d.authorities.length < 1) bad("no-authority");
  const names = new Set<string>();
  for (const a of d.authorities) {
    if (!NAME_RE.test(a.name)) bad("name");
    if (names.has(a.name)) bad("duplicate-name");
    names.add(a.name);
    if (a.vkey.type !== SIG_ED25519) bad("authority-key-type");
  }
  if (!(d.rotation >= 1 && d.rotation <= d.authorities.length)) bad("rotation");
  // Rule 6: no public key twice among the subject's, the witnesses' and the
  // authorities'.
  const keys = new Set<string>([hexEncode(subject.key)]);
  for (const vk of [...witnesses.map((w) => w.vkey), ...d.authorities.map((a) => a.vkey)]) {
    const h = hexEncode(vk.key);
    if (keys.has(h)) bad("repeated-key");
    keys.add(h);
  }
  return set;
}

/** An anchored checkpoint, checked against its subject's declaration. */
export interface AnchoredCheckpoint {
  cp: Checkpoint;
  /** The declared witnesses whose cosignatures count: kept by normalization
   * and dated other than 0, by name. */
  counted: string[];
  /** Their public keys, hex: the cosigners a same-size anchor compares. */
  countedKeys: string[];
  /** True when they satisfy the declared quorum. */
  meetsQuorum: boolean;
}

/** Checks an anchored checkpoint (section 2, "Normal form"; section 7.1,
 * "Anchor"): no extension lines, `origin` as its origin, a signature from
 * the subject's key, and normal form under the declaration, which keeps a
 * declared witness's earliest valid line, dated 0 or not; a size-0
 * checkpoint has the empty tree's root. Whether it meets the quorum is in
 * the result. Throws `hub-entry-refused`. */
export function checkAnchoredCheckpoint(raw: Uint8Array, subject: Subject, set: WitnessSet): AnchoredCheckpoint {
  const note = noteOf(raw);
  let cp: Checkpoint;
  try {
    cp = parseCheckpointText(note.text);
  } catch (e) {
    if (e instanceof VerifyError) refuse("bad-checkpoint", String(e.params?.detail ?? e.code));
    throw e;
  }
  if (cp.origin !== subject.name) refuse("bad-checkpoint", "origin");
  const n = normalizeNote(note, subject.vkey, undefined, set.keys(), { zeroTimestamps: true });
  if (!n.signer) refuse("bad-signature", "checkpoint");
  if (!equalBytes(utf8(n.text), raw)) refuse("not-normal");
  if (cp.size === 0n && !equalBytes(cp.root, EMPTY_TREE_ROOT)) refuse("bad-checkpoint", "empty-tree");
  const counting = n.others.filter((v) => v.ts !== undefined && v.ts !== 0n);
  const counted = counting.map((v) => set.witnessFor(v.vkey)!.name);
  return {
    cp,
    counted,
    countedKeys: counting.map((v) => hexEncode(v.vkey.key)),
    meetsQuorum: set.satisfied(new Set(counted)),
  };
}

function signedBy(note: Note, key: Vkey): boolean {
  return verifyNote(note, [key]).some((v) => v.vkey === key);
}

/** The number of distinct authorities among `authorities` whose keys verify
 * `note`. */
export function authoritiesSigned(note: Note, authorities: readonly Authority[]): number {
  return verifyNote(
    note,
    authorities.map((a) => a.vkey),
  ).length;
}

function hashesOf(v: Uint8Array): Uint8Array[] {
  const out: Uint8Array[] = [];
  for (let i = 0; i < v.length; i += 32) out.push(v.subarray(i, i + 32));
  return out;
}

// ---------------------------------------------------------------------------
// The state (section 7.1)

/** The latest anchor of an origin subject. */
export interface LatestAnchor {
  size: bigint;
  root: Uint8Array;
  /** The public keys (hex) of the witnesses whose cosignatures counted on
   * it; none for the anchor a rotation starts a subject at. */
  cosigners: string[];
}

/** An enrolled origin subject. */
export interface OriginSubjectState {
  kind: typeof SUBJECT_ORIGIN;
  name: string;
  vkey: Vkey;
  declaration: Declaration;
  /** The declaration's witnesses, groups and quorum. */
  set: WitnessSet;
  latest?: LatestAnchor;
  frozen: boolean;
  /** SHA-256 (hex) of each update statement text applied to it. */
  updates: Set<string>;
}

/** An enrolled blinded subject. */
export interface BlindedSubjectState {
  kind: typeof SUBJECT_BLINDED;
  name: string;
  vkey: Vkey;
  /** Its last `seq`, 0 before its first anchor. */
  seq: bigint;
}

export type HubSubjectState = OriginSubjectState | BlindedSubjectState;

/** What applying an entry did. */
export interface AppliedHubEntry {
  /** The entry's index in the hub log. */
  index: number;
  tag: string;
  /** Its leaf hash. */
  leaf: Uint8Array;
}

/** The hub state of section 7.1, from an empty hub of origin `origin`. */
export class HubState {
  readonly origin: string;
  private subjects = new Map<string, HubSubjectState>();
  private map = new Map<string, MptLeaf>();
  private mapRootCache: Uint8Array | undefined;
  /** The hub log's compact range: its perfect subtrees, largest first. */
  private range: { size: number; hash: Uint8Array }[] = [];
  private count = 0;
  private lastTime = 0n;

  constructor(origin: string) {
    if (!isValidKeyName(origin) || isReservedOrigin(origin)) throw new TypeError("not a hub origin");
    this.origin = origin;
  }

  /** The number of entries in the hub log. */
  get size(): number {
    return this.count;
  }

  /** The previous entry's `received_at` (an index entry's `time`), in
   * milliseconds; 0 before the first entry. */
  get receivedAt(): bigint {
    return this.lastTime;
  }

  /** The root of the hub log's tree (RFC 9162). */
  root(): Uint8Array {
    if (this.range.length === 0) return sha256();
    let r = this.range[this.range.length - 1]!.hash;
    for (let i = this.range.length - 2; i >= 0; i--) r = nodeHash(this.range[i]!.hash, r);
    return r;
  }

  /** The root of the subject map (section 4). */
  mapRoot(): Uint8Array {
    this.mapRootCache ??= mptRoot([...this.map.values()]);
    return this.mapRootCache;
  }

  /** The subject map's entries: subject key, then value. */
  mapEntries(): MptLeaf[] {
    return [...this.map.values()].map((l) => ({ key: l.key, value: l.value }));
  }

  /** The map value of a subject key, if it has one. */
  mapValueOf(key: Uint8Array): Uint8Array | undefined {
    return this.map.get(hexEncode(key))?.value;
  }

  /** The state of an enrolled subject. Treat it as read-only. */
  subject(s: Subject): HubSubjectState | undefined {
    return this.subjects.get(hexEncode(subjectKey(s.kind, s.name, s.vkey)));
  }

  /** Applies one entry (its envelope bytes): checks every rule of section
   * 7.1 against the state, then applies its effects. An entry that breaks a
   * rule throws `hub-entry-refused` with its `index` and `rule` and changes
   * nothing. */
  apply(bytes: Uint8Array): AppliedHubEntry {
    const index = this.count;
    let checked: { tag: string; time: bigint; effect: () => void };
    try {
      checked = this.check(bytes, BigInt(index));
    } catch (e) {
      if (!(e instanceof VerifyError)) throw e;
      const p: Params = e.code === "hub-entry-refused" ? { ...e.params } : { rule: "malformed", detail: e.code };
      throw new VerifyError("hub-entry-refused", { index, ...p });
    }
    checked.effect();
    const leaf = leafHash(bytes);
    this.append(leaf);
    this.lastTime = checked.time;
    return { index, tag: checked.tag, leaf };
  }

  /** A copy that applies entries independently, so a batch can be applied
   * all or nothing (section 7, step 4). */
  clone(): HubState {
    const c = new HubState(this.origin);
    for (const [k, s] of this.subjects) {
      c.subjects.set(k, s.kind === SUBJECT_ORIGIN ? { ...s, updates: new Set(s.updates) } : { ...s });
    }
    c.map = new Map(this.map);
    c.mapRootCache = this.mapRootCache;
    c.range = [...this.range];
    c.count = this.count;
    c.lastTime = this.lastTime;
    return c;
  }

  /** A plain, deterministic description of the whole state, for tests and
   * debugging. */
  toJSON(): unknown {
    const subjects = [...this.subjects]
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([key, s]) => {
        if (s.kind === SUBJECT_BLINDED) return { key, kind: "blinded", name: s.name, vkey: s.vkey.text, seq: s.seq.toString() };
        return {
          key,
          kind: "origin",
          name: s.name,
          vkey: s.vkey.text,
          frozen: s.frozen,
          latest: s.latest ? { size: s.latest.size.toString(), root: hexEncode(s.latest.root), cosigners: [...s.latest.cosigners].sort() } : null,
          declaration: {
            cosigners: s.declaration.cosigners.map((c) => (c.kind === "witness" ? `witness ${c.name} ${c.vkey.text}` : `group ${c.name} ${c.k} ${c.members.join(" ")}`)),
            quorum: s.declaration.quorum,
            authorities: s.declaration.authorities.map((a) => `${a.name} ${a.vkey.text}`),
            rotation: s.declaration.rotation,
          },
          updates: [...s.updates].sort(),
        };
      });
    return {
      origin: this.origin,
      size: this.count,
      root: hexEncode(this.root()),
      receivedAt: this.lastTime.toString(),
      map: [...this.map.keys()].sort().map((k) => [k, hexEncode(this.map.get(k)!.value)]),
      subjects,
    };
  }

  // -- checks: each returns the entry's effect, and changes nothing itself --

  private check(bytes: Uint8Array, index: bigint): { tag: string; time: bigint; effect: () => void } {
    if (bytes.length > MAX_HUB_ENTRY_SIZE) malformed("too-large");
    const e = parseEntry(bytes);
    if (!TAGS.has(e.tag)) malformed("tag");
    checkLayout(e);
    const time = fieldU64(e, e.tag === HUB_TAGS.index ? "time" : "received_at")!;
    if (time < this.lastTime) refuse("time-going-back");
    const leaf = (): Uint8Array => leafHash(bytes);
    let effect: () => void;
    switch (e.tag) {
      case HUB_TAGS.enroll:
        effect = this.enroll(e);
        break;
      case HUB_TAGS.anchor:
        effect = this.anchor(e, index, leaf);
        break;
      case HUB_TAGS.blinded:
        effect = this.blinded(e, index, leaf);
        break;
      case HUB_TAGS.rotate:
        effect = this.rotate(e, index, leaf);
        break;
      case HUB_TAGS.update:
        effect = this.update(e);
        break;
      default:
        effect = this.index(e, index);
    }
    return { tag: e.tag, time, effect };
  }

  /** The subject an entry names; every subject key in an entry is an
   * Ed25519 vkey named after its subject (section 7.1, "Every entry"). */
  private subjectOf(kind: "origin" | "blinded", name: string, vkey: string): { subject: Subject; key: string } {
    let subject: Subject;
    try {
      subject = makeSubject(kind, name, vkey);
    } catch (e) {
      if (e instanceof VerifyError) malformed(`subject-${String(e.params?.detail ?? e.code)}`);
      throw e;
    }
    return { subject, key: hexEncode(subjectKey(subject.kind, subject.name, subject.vkey)) };
  }

  private setMap(key: string, value: Uint8Array): void {
    this.map.set(key, { key: hexDecode(key, 32), value });
    this.mapRootCache = undefined;
  }

  private enroll(e: Entry): () => void {
    const kind = fieldText(e, "kind") as "origin" | "blinded";
    const name = fieldText(e, "name")!;
    const vkey = fieldText(e, "key")!;
    const { subject, key } = this.subjectOf(kind, name, vkey);
    const st = parseEnrollStatement(fieldValue(e, "statement")!);
    if (st.hub !== this.origin) refuse("wrong-hub");
    if (st.kind !== kind || st.name !== name || st.key !== vkey) refuse("field-mismatch");
    if (!signedBy(st.note, subject.vkey)) refuse("bad-signature", "statement");
    let state: HubSubjectState;
    if (subject.kind === SUBJECT_ORIGIN) {
      const declaration = st.declaration!;
      const set = checkDeclaration(declaration, subject.vkey);
      state = { kind: SUBJECT_ORIGIN, name, vkey: subject.vkey, declaration, set, frozen: false, updates: new Set() };
    } else {
      state = { kind: SUBJECT_BLINDED, name, vkey: subject.vkey, seq: 0n };
    }
    if (this.subjects.has(key)) refuse("enrolled");
    return () => {
      this.subjects.set(key, state);
    };
  }

  private originSubject(key: string): OriginSubjectState {
    const s = this.subjects.get(key);
    if (!s || s.kind !== SUBJECT_ORIGIN) return refuse("not-enrolled");
    if (s.frozen) refuse("frozen");
    return s;
  }

  private anchor(e: Entry, index: bigint, leaf: () => Uint8Array): () => void {
    const { subject, key } = this.subjectOf("origin", fieldText(e, "origin")!, fieldText(e, "key")!);
    const s = this.originSubject(key);
    const a = checkAnchoredCheckpoint(fieldValue(e, "checkpoint")!, subject, s.set);
    if (!a.meetsQuorum) refuse("below-quorum");
    const oldSize = fieldU64(e, "old_size")!;
    const proof = hashesOf(fieldValue(e, "proof")!);
    const { size, root } = a.cp;
    const latest = s.latest;
    if (!latest) {
      if (oldSize !== 0n) refuse("old-size", "no-anchor");
      if (proof.length > 0) refuse("proof", "no-anchor");
    } else {
      if (oldSize !== latest.size) refuse("old-size");
      if (size < latest.size) refuse("old-size", "smaller");
      if (size > latest.size) {
        // Every tree extends the empty one, and consistency proofs start at
        // size 1 (RFC 9162), so from size 0 the proof is empty.
        if (latest.size === 0n) {
          if (proof.length > 0) refuse("proof", "from-empty");
        } else if (!verifyConsistency(latest.size, size, proof, latest.root, root)) {
          refuse("proof");
        }
      } else {
        if (proof.length > 0) refuse("proof", "same-size");
        if (!equalBytes(root, latest.root)) refuse("fork");
        const declared = new Set(s.set.keys().map((k) => hexEncode(k.key)));
        const before = latest.cosigners.filter((k) => declared.has(k));
        const now = new Set(a.countedKeys);
        if (!before.every((k) => now.has(k)) || now.size <= before.length) refuse("cosigners");
      }
    }
    return () => {
      s.latest = { size, root, cosigners: a.countedKeys };
      this.setMap(key, mapValue(index, leaf()));
    };
  }

  private blinded(e: Entry, index: bigint, leaf: () => Uint8Array): () => void {
    const pseudo = hexEncode(fieldValue(e, "pseudo_origin")!);
    const { subject, key } = this.subjectOf("blinded", pseudo, fieldText(e, "key")!);
    const st = parseBlindedStatement(fieldValue(e, "statement")!);
    if (st.hub !== this.origin) refuse("wrong-hub");
    const s = this.subjects.get(key);
    if (!s || s.kind !== SUBJECT_BLINDED) return refuse("not-enrolled");
    const seq = fieldU64(e, "seq")!;
    if (st.pseudo !== pseudo || st.seq !== seq || !equalBytes(st.commitment, fieldValue(e, "commitment")!)) refuse("field-mismatch");
    if (!signedBy(st.note, subject.vkey)) refuse("bad-signature", "statement");
    if (seq !== s.seq + 1n) refuse("seq", `${seq}-after-${s.seq}`);
    return () => {
      s.seq = seq;
      this.setMap(key, mapValue(index, leaf()));
    };
  }

  private rotate(e: Entry, index: bigint, leaf: () => Uint8Array): () => void {
    const origin = fieldText(e, "origin")!;
    const oldText = fieldText(e, "old")!;
    const newText = fieldText(e, "new")!;
    const old = this.subjectOf("origin", origin, oldText);
    const nw = this.subjectOf("origin", origin, newText);
    const st = parseRotateStatement(fieldValue(e, "statement")!);
    if (st.hub !== this.origin) refuse("wrong-hub");
    if (st.kind !== "origin" || st.name !== origin || st.old !== oldText || st.new !== newText) refuse("field-mismatch");
    const s = this.originSubject(old.key);
    const latest = s.latest;
    if (!latest || latest.size !== st.size || !equalBytes(latest.root, st.root)) refuse("rotation-anchor");
    if (equalBytes(old.subject.vkey.key, nw.subject.vkey.key)) refuse("same-key");
    if (this.subjects.has(nw.key)) refuse("enrolled", "new");
    if (!signedBy(st.note, old.subject.vkey)) refuse("bad-signature", "old-key");
    if (!signedBy(st.note, nw.subject.vkey)) refuse("bad-signature", "new-key");
    const n = authoritiesSigned(st.note, s.declaration.authorities);
    if (n < s.declaration.rotation) refuse("authorities", `${n}-of-${s.declaration.rotation}`);
    const next: OriginSubjectState = {
      kind: SUBJECT_ORIGIN,
      name: origin,
      vkey: nw.subject.vkey,
      declaration: s.declaration,
      set: s.set,
      latest: { size: st.size, root: st.root, cosigners: [] },
      frozen: false,
      updates: new Set(),
    };
    return () => {
      s.frozen = true;
      this.setMap(old.key, mapValue(index, leaf()));
      this.subjects.set(nw.key, next);
    };
  }

  private update(e: Entry): () => void {
    const origin = fieldText(e, "origin")!;
    const { subject, key } = this.subjectOf("origin", origin, fieldText(e, "key")!);
    const st = parseUpdateStatement(fieldValue(e, "statement")!);
    if (st.hub !== this.origin) refuse("wrong-hub");
    const s = this.originSubject(key);
    if (st.name !== origin) refuse("field-mismatch");
    if (!signedBy(st.note, subject.vkey)) refuse("bad-signature", "statement");
    const cur = s.declaration;
    const n = authoritiesSigned(st.note, cur.authorities);
    if (n < cur.rotation) refuse("authorities", `${n}-of-${cur.rotation}`);
    for (const a of st.authorities ?? []) {
      if (!cur.authorities.some((c) => c.name === a.name && c.vkey.text === a.vkey.text)) refuse("authority-added", a.name.slice(0, 64));
    }
    if (st.rotation !== undefined && st.rotation < cur.rotation) refuse("rotation-lowered");
    const declaration: Declaration = {
      cosigners: st.cosigners,
      quorum: st.quorum,
      authorities: st.authorities ?? cur.authorities,
      rotation: st.rotation ?? cur.rotation,
    };
    const set = checkDeclaration(declaration, subject.vkey);
    const text = hexEncode(sha256(st.note.text));
    if (s.updates.has(text)) refuse("replayed");
    return () => {
      s.declaration = declaration;
      s.set = set;
      s.updates.add(text);
    };
  }

  private index(e: Entry, index: bigint): () => void {
    if (fieldU64(e, "covered") !== index) refuse("bad-index", "covered");
    if (!equalBytes(fieldValue(e, "root")!, this.mapRoot())) refuse("bad-index", "root");
    return () => {};
  }

  private append(leaf: Uint8Array): void {
    let node = { size: 1, hash: leaf };
    while (this.range.length > 0 && this.range[this.range.length - 1]!.size === node.size) {
      const left = this.range.pop()!;
      node = { size: left.size * 2, hash: nodeHash(left.hash, node.hash) };
    }
    this.range.push(node);
    this.count++;
  }
}
