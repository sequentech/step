// SPDX-License-Identifier: Apache-2.0
//
// Keys logs (specs/entry.md, sections 4.4 and 5.6; specs/profile.md, section
// 5.2): which keys are valid when, from a `keys/v1` log's `vitrine/key/v1`
// statements and their entries' sequencing times, and the `signed-by` check
// of a statement at an entry's sequencing time. A key's validity starts when
// its `add` entry is sequenced, never earlier whatever its `not-before` says,
// and a `revoke` takes effect when it is sequenced and for good.

import { equalBytes, parseSmall } from "./bytes.js";
import { checkLayout, fieldText, fieldU64, fieldValue, isValidId, parseEntry, type Entry } from "./entry.js";
import { fail, reason } from "./errors.js";
import { parseNote, parseVkey, SIG_ED25519, verifyNote, type Note, type Vkey } from "./note.js";
import type { Policy } from "./policy.js";
import { asCode, statementValues } from "./statements.js";
import type { Reason } from "../types.js";

export const KEY_STATEMENT_HEADER = "vitrine/key/v1";
export const KEYS_TAG = "vitrine/keys/v1";

/** A `vitrine/key/v1` statement. */
export interface KeyStatement {
  /** The keys log's origin. */
  log: string;
  action: "add" | "revoke";
  /** The key's vkey. Keys compare whole: the same key bytes under another
   * name are another key. */
  key: string;
  holder: string;
  notBefore: number;
  /** 0 for none. */
  notAfter: number;
}

/** Parses a `vitrine/key/v1` statement's text. Throws `bad-key-statement`. */
export function parseKeyStatement(text: string): KeyStatement {
  return asCode("bad-key-statement", () => {
    const v = statementValues(text, KEY_STATEMENT_HEADER, ["log", "action", "key", "holder", "not-before", "not-after"], "bad-key-statement");
    const [log, action, key, holder, notBefore, notAfter] = v as [string, string, string, string, string, string];
    if (log.length === 0) fail("bad-key-statement", { detail: "log" });
    if (action !== "add" && action !== "revoke") return fail("bad-key-statement", { detail: "action" });
    parseVkey(key);
    if (!isValidId(holder)) fail("bad-key-statement", { detail: "holder" });
    return { log, action, key, holder, notBefore: parseSmall(notBefore), notAfter: parseSmall(notAfter) };
  });
}

/** The statement of a `keys/v1` entry of log `logName`, when the entry counts
 * (profile.md, section 5.2): its fields are those of its `vitrine/key/v1`
 * statement, the statement names the log, and at least `k` of the log's
 * `keys-authority` sign it. `policy` is the policy in force at the entry's
 * sequencing time. Throws `bad-key-statement`. */
export function keyEntryStatement(entry: Uint8Array | Entry, policy: Policy, logName: string): KeyStatement {
  return asCode("bad-key-statement", () => {
    const bad = (detail: string): never => fail("bad-key-statement", { detail });
    const log = policy.logs.get(logName);
    if (!log || !log.profiles.some((p) => p.tag === KEYS_TAG)) bad("log");
    const e = entry instanceof Uint8Array ? parseEntry(entry) : entry;
    if (e.tag !== KEYS_TAG) bad("tag");
    checkLayout(e);
    const note = parseNote(fieldValue(e, "statement")!);
    const s = parseKeyStatement(note.text);
    if (s.log !== log!.origin) bad("log");
    if (
      fieldText(e, "action") !== s.action ||
      fieldText(e, "key") !== s.key ||
      fieldText(e, "holder") !== s.holder ||
      fieldU64(e, "not_before") !== BigInt(s.notBefore) ||
      fieldU64(e, "not_after") !== BigInt(s.notAfter)
    ) {
      bad("fields");
    }
    const t = log!.keysAuthority;
    if (!t) return bad("keys-authority");
    const keys = t.names.map((n) => policy.authorities.get(n)!.vkey);
    if (verifyNote(note, keys).length < t.k) bad("signature");
    return s;
  });
}

/** The outcome of a `signed-by` check. */
export type SignedBy =
  | {
      status: "ok";
      /** The other valid keys that signed, in log order. */
      cosignedBy: string[];
    }
  /** The tool doesn't hold the keys log complete through the time yet. */
  | { status: "waiting" }
  /** `signed-by-failed`, with a `detail`: `not-ed25519`, `not-signed`,
   * `revoked` (and `revokedAt`), `not-valid` or `cosigners` (and `have`,
   * `need`). */
  | { status: "failed"; reason: Reason };

interface KeyEvent {
  statement: KeyStatement;
  sequenced: number;
}

/** A `keys/v1` log's statements, in log order, with their entries'
 * sequencing times. */
export class KeyLog {
  private readonly events: KeyEvent[] = [];
  /** The time through which the tool holds every entry of the log:
   * `signed-by` waits for a later time (profile.md, section 5.2). Default:
   * the log is held complete. */
  completeThrough: number;

  constructor(
    /** The keys log's origin, which its statements name. */
    readonly origin: string,
    o: { completeThrough?: number } = {},
  ) {
    this.completeThrough = o.completeThrough ?? Number.POSITIVE_INFINITY;
  }

  /** Adds the log's next statement, with its entry's sequencing time. Throws
   * `bad-key-statement` for a statement that names another log. */
  push(statement: KeyStatement, sequenced: number): void {
    if (statement.log !== this.origin) fail("bad-key-statement", { detail: "log" });
    this.events.push({ statement, sequenced });
  }

  /** The sequencing time of the first `revoke` of `key` sequenced at or
   * before `t`, if any. */
  revokedAt(key: string, t: number): number | undefined {
    let at: number | undefined;
    for (const { statement: s, sequenced } of this.events) {
      if (s.action === "revoke" && s.key === key && sequenced <= t && (at === undefined || sequenced < at)) at = sequenced;
    }
    return at;
  }

  /** Whether `key` is valid at `t`: an `add` sequenced at or before `t`
   * whose `not-before` is at or before `t` and whose `not-after` is 0 or at
   * or after `t`, and no `revoke` sequenced at or before `t`. */
  isValid(key: string, t: number): boolean {
    if (this.revokedAt(key, t) !== undefined) return false;
    return this.events.some(
      ({ statement: s, sequenced }) => s.action === "add" && s.key === key && sequenced <= t && s.notBefore <= t && (s.notAfter === 0 || s.notAfter >= t),
    );
  }

  /** The keys the log adds, once each, in the order of their first `add`. */
  keys(): string[] {
    const out: string[] = [];
    for (const { statement: s } of this.events) if (s.action === "add" && !out.includes(s.key)) out.push(s.key);
    return out;
  }

  /** The `signed-by` check (profile.md, section 5.2) of a statement note with
   * the Ed25519 key `signer`, for an entry sequenced at `at`: the note
   * verifies with the key; the key has no `revoke` sequenced at or before
   * `at` (which fails at once, even before the log is held complete); and,
   * once the log is held complete through `at`, the key is valid then and
   * at least `cosigners` other distinct Ed25519 keys valid then also signed.
   * The signer's key bytes never count, under any name. */
  signedBy(note: string | Uint8Array | Note, signer: string, at: number, cosigners = 0): SignedBy {
    const failed = (detail: string, p: Record<string, string | number> = {}): SignedBy => ({ status: "failed", reason: reason("signed-by-failed", { detail, ...p }) });
    let n: Note;
    let sv: Vkey;
    try {
      n = typeof note === "string" || note instanceof Uint8Array ? parseNote(note) : note;
      sv = parseVkey(signer, [SIG_ED25519]);
    } catch {
      return failed("not-ed25519");
    }
    if (verifyNote(n, [sv]).length === 0) return failed("not-signed");
    const revoked = this.revokedAt(signer, at);
    if (revoked !== undefined) return failed("revoked", { revokedAt: revoked });
    if (this.completeThrough < at) return { status: "waiting" };
    if (!this.isValid(signer, at)) return failed("not-valid");
    const counted: Uint8Array[] = [sv.key];
    const cosignedBy: string[] = [];
    for (const k of this.keys()) {
      if (!this.isValid(k, at)) continue;
      let v: Vkey;
      try {
        v = parseVkey(k, [SIG_ED25519]);
      } catch {
        continue;
      }
      if (counted.some((b) => equalBytes(b, v.key))) continue;
      if (verifyNote(n, [v]).length === 0) continue;
      counted.push(v.key);
      cosignedBy.push(k);
    }
    if (cosignedBy.length < cosigners) return failed("cosigners", { have: cosignedBy.length, need: cosigners });
    return { status: "ok", cosignedBy };
  }
}
