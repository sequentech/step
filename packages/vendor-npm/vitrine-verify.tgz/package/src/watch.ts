// SPDX-License-Identifier: Apache-2.0
//
// Asking a hub for email watches and feeds (specs/watch.md; docs/api.md,
// section 4). The calls follow the request rules of the other online calls:
// no credentials, no referrer, no redirects. The JSON goes as `text/plain`,
// which a browser sends to a hub on another origin without a preflight; the
// hub reads the body whatever its content type.

import { parseTrackingPrefix } from "./pure/tracking.js";

export interface WatchOptions {
  /** The fetch to use; default the global one. */
  fetch?: typeof fetch;
  signal?: AbortSignal;
}

/** What to watch, as `POST <hub>/watch` takes it (specs/watch.md, section 3.1). */
export type WatchRequest = {
  /** `sha256:<hex>`. */
  policy: string;
  email: string;
  /** A language tag; the hub records it and sends English. */
  lang?: string;
} & (
  | { what: "election" }
  // A receipt (a tlog-proof, or a receipt chain, unchanged), or the full
  // Tracking ID of a ballot (52 characters) when the voter holds no receipt.
  | { what: "ballot"; receipt: string; trackingId?: never }
  | { what: "ballot"; trackingId: string; receipt?: never }
  // A voter pseudonym: 8 to 52 characters, with `:` or `-` between groups.
  | { what: "pseudonym"; pseudonym: string }
);

/** A hub that wouldn't take the call. */
export class WatchError extends Error {
  override name = "WatchError";
  constructor(
    message: string,
    /** The HTTP status, or 0 when there was no answer. */
    readonly status: number,
    /** For a 429, the seconds the hub asked to wait. */
    readonly retryAfter?: number,
  ) {
    super(message);
  }
}

/** The answer to a request: the hub sent a confirmation email, if the address
 * can be mailed. It says nothing about the address. */
export interface WatchPending {
  status: "pending";
  /** The seconds the confirmation link works. */
  expiresIn: number;
}

/** The answer to a confirmation. */
export interface WatchConfirmed {
  status: "watching";
  what: "ballot" | "pseudonym" | "election";
  /** `sha256:<hex>`. */
  policy: string;
}

const MAX_ANSWER = 64 * 1024;

function route(hub: string, path: string): string {
  return `${hub.replace(/\/+$/, "")}/${path}`;
}

function policyHex(policy: string): string {
  const m = /^sha256:([0-9a-f]{64})$/.exec(policy);
  if (!m) throw new TypeError("a policy ID is sha256: and 64 lowercase hex digits");
  return m[1]!;
}

/** Groups of four characters joined by `-`, as a full Tracking ID is shown. */
function fullTrackingId(typed: string): string {
  const { chars } = parseTrackingPrefix(typed);
  if (chars.length !== 52) throw new TypeError("a ballot is named by its full Tracking ID, 52 characters");
  return chars.match(/.{4}/g)!.join("-");
}

/** The feed of a policy's events (`GET <hub>/feeds/<policy hex>.atom`), or
 * with `trackingId`, of one ballot's too. Needs no address. */
export function feedUrl(hub: string, policy: string, trackingId?: string): string {
  const hex = policyHex(policy);
  return trackingId === undefined ? route(hub, `feeds/${hex}.atom`) : route(hub, `feeds/${hex}/ballot/${fullTrackingId(trackingId)}.atom`);
}

async function call(f: typeof fetch, url: string, body: string, opts: WatchOptions): Promise<{ status: number; headers: Headers; text: string }> {
  let res: Response;
  try {
    res = await f(url, {
      method: "POST",
      headers: { "content-type": "text/plain;charset=UTF-8" },
      body,
      credentials: "omit",
      referrerPolicy: "no-referrer",
      redirect: "error",
      ...(opts.signal ? { signal: opts.signal } : {}),
    });
  } catch (e) {
    if (opts.signal?.aborted) throw e;
    throw new WatchError("no answer", 0);
  }
  const text = (await res.text()).slice(0, MAX_ANSWER);
  return { status: res.status, headers: res.headers, text };
}

function fail(r: { status: number; headers: Headers; text: string }): never {
  let message = `status ${r.status}`;
  try {
    const j: unknown = JSON.parse(r.text);
    if (j && typeof j === "object" && "error" in j && typeof j.error === "string") message = j.error;
  } catch {
    // Not the hub's JSON: the status says enough.
  }
  const ra = r.headers.get("Retry-After");
  const wait = ra !== null && /^[0-9]{1,6}$/.test(ra.trim()) ? Number(ra.trim()) : undefined;
  throw new WatchError(message, r.status, wait);
}

function json(text: string): Record<string, unknown> {
  const j: unknown = JSON.parse(text);
  if (!j || typeof j !== "object" || Array.isArray(j)) throw new TypeError("the hub's answer is not JSON of the expected form");
  return j as Record<string, unknown>;
}

/** Asks a hub to watch, `POST <hub>/watch`. Resolves with `pending` for a
 * request the hub took (202), whether or not it knows the address; throws a
 * WatchError for the hub's refusal: 400 for a request or receipt that is not
 * good under the policy, 422 for a policy the hub doesn't follow, 429 for too
 * many requests, 503 for a hub that sends no mail. A TypeError, before any
 * request, for a policy or Tracking ID that is not one. */
export async function requestWatch(hub: string, req: WatchRequest, opts: WatchOptions = {}): Promise<WatchPending> {
  policyHex(req.policy);
  const body: Record<string, string> = { policy: req.policy, email: req.email, what: req.what };
  if (req.lang !== undefined) body.lang = req.lang;
  if (req.what === "ballot") {
    if (req.receipt !== undefined) body.receipt = req.receipt;
    else if (req.trackingId !== undefined) body.tracking_id = fullTrackingId(req.trackingId);
    else throw new TypeError("a ballot watch has a receipt or a tracking ID");
  } else if (req.what === "pseudonym") {
    body.pseudonym = req.pseudonym;
  }
  const f = opts.fetch ?? globalThis.fetch.bind(globalThis);
  const r = await call(f, route(hub, "watch"), JSON.stringify(body), opts);
  if (r.status !== 202) fail(r);
  const j = json(r.text);
  return { status: "pending", expiresIn: typeof j.expires_in === "number" ? j.expires_in : 86_400 };
}

/** Uses the token of a confirmation link (`#confirm=<token>`), `POST
 * <hub>/watch/confirm`. Throws a WatchError with status 404 for an unknown
 * token and 410 for one more than 24 hours old. */
export async function confirmWatch(hub: string, token: string, opts: WatchOptions = {}): Promise<WatchConfirmed> {
  const f = opts.fetch ?? globalThis.fetch.bind(globalThis);
  const r = await call(f, route(hub, "watch/confirm"), JSON.stringify({ token }), opts);
  if (r.status !== 200) fail(r);
  const j = json(r.text);
  const what = j.what;
  if (j.status !== "watching" || (what !== "ballot" && what !== "pseudonym" && what !== "election") || typeof j.policy !== "string") {
    throw new TypeError("the hub's answer is not a confirmation");
  }
  return { status: "watching", what, policy: j.policy };
}

/** Ends a watch at once, `POST <hub>/watch/unsubscribe?t=<token>`, with the
 * token of an email's footer (`#unsubscribe=<token>`). The hub answers alike
 * for a token it doesn't know. */
export async function unsubscribeWatch(hub: string, token: string, opts: WatchOptions = {}): Promise<void> {
  const f = opts.fetch ?? globalThis.fetch.bind(globalThis);
  const r = await call(f, `${route(hub, "watch/unsubscribe")}?t=${encodeURIComponent(token)}`, "List-Unsubscribe=One-Click", opts);
  if (r.status !== 200) fail(r);
}
