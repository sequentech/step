// SPDX-License-Identifier: Apache-2.0
//
// Every reason code and step code that @vitrine/verify emits, with a one-line
// English description each. The UI kit maps reason codes to the Fluent
// messages `reason-<code>` and step codes to `step-<code>`; the descriptions
// here are for developers and for the UI kit's English source, not for users.
// TypeScript checks that the verifier only emits codes listed here.

export const REASON_CODES = [
  // Encodings and limits
  { code: "bad-base64", description: "A base64 value is invalid or not canonical." },
  { code: "bad-hex", description: "A hex value is invalid (only lowercase hex digits are accepted)." },
  { code: "bad-text", description: "Text is not valid UTF-8 or contains a forbidden character." },
  { code: "bad-number", description: "A decimal number is malformed, has leading zeros, or is out of range." },
  { code: "trailing-data", description: "A structure is followed by unexpected bytes." },
  { code: "truncated", description: "A structure ends before all of its parts." },
  { code: "too-large", description: "An object exceeds a size or count limit of the specs." },

  // Signed notes and keys
  { code: "bad-note", description: "A signed note is malformed." },
  { code: "bad-key-name", description: "A key name is empty or contains a space, a plus sign or a control character." },
  { code: "bad-vkey", description: "A verifier key is malformed, has the wrong key ID, or the wrong signature type." },
  { code: "bad-public-key", description: "An Ed25519 public key is not canonical or is of small order." },
  { code: "duplicate-signature", description: "A note has two signature lines with the same key name and key ID." },
  { code: "bad-signature", description: "A signature from a key the policy knows does not verify." },
  { code: "missing-signature", description: "A note lacks the signature it must carry (for example the log's)." },

  // Checkpoints and cosignatures
  { code: "bad-checkpoint", description: "A checkpoint's text is malformed." },
  { code: "wrong-origin", description: "A checkpoint or note names another log or hub than expected." },
  { code: "cosignature-in-future", description: "A cosignature is dated more than 300 seconds after the device clock and was ignored." },
  { code: "quorum-not-met", description: "The valid cosignatures do not satisfy the policy's quorum yet." },

  // Proofs
  { code: "bad-proof", description: "A tlog-proof or proof document is malformed." },
  { code: "missing-extra", description: "A receipt has no extra line holding the entry." },
  { code: "index-out-of-range", description: "A leaf index is not below the tree size." },
  { code: "inclusion-failed", description: "An inclusion proof does not verify against the signed root." },
  { code: "consistency-failed", description: "A consistency proof does not verify between two signed checkpoints." },
  { code: "split-view", description: "Two signed checkpoints of one log have the same size but different roots." },

  // Entries and expectations
  { code: "bad-entry", description: "An entry does not parse as a Vitrine entry." },
  { code: "wrong-profile", description: "The entry's tag differs from the log's profile at that index." },
  { code: "bad-entry-layout", description: "The entry does not match its profile's fields and types." },
  { code: "entry-mismatch", description: "The entry differs from the one the user expects." },
  { code: "expectation-incomplete", description: "The expectations do not determine the whole entry yet." },
  { code: "expectation-unknown-field", description: "The expectations name a field the profile does not have." },
  { code: "expectation-unsupported", description: "Field expectations were given for a profile this verifier does not know." },
  { code: "receipts-disagree", description: "The issued and record receipts are for different entries or positions." },

  // Promises
  { code: "bad-promise", description: "A promise or promise batch is malformed." },
  { code: "promise-mmd-too-large", description: "A promise batch states a longer merge delay than the policy allows." },
  { code: "promise-leaf-mismatch", description: "The promise is for another entry than the expected one." },
  { code: "promise-pending", description: "Only a promise exists; the receipt is not due yet." },
  { code: "promise-deadline-passed", description: "The promise's deadline passed, by signed time, without a receipt." },
  { code: "promise-kept-unproven", description: "No receipt in the chain shows the promise was kept by its deadline." },

  // Receipt chains
  { code: "malformed-chain", description: "The receipt chain is not a well-formed receipt chain document." },
  { code: "duplicate-block", description: "A receipt chain has two blocks of one type (for one hub)." },
  { code: "no-receipt", description: "A receipt chain has no promise, issued or record block." },
  { code: "policy-mismatch", description: "The receipt chain names another policy than the pinned one." },
  { code: "unknown-log", description: "The receipt chain names a log the policy does not have." },
  { code: "unknown-hub", description: "A block names a hub the policy does not have; it was ignored." },
  { code: "consistency-missing", description: "A consistency proof the chain needs is absent." },
  { code: "consistency-mismatch", description: "A consistency block's sizes do not match the checkpoints it links." },
  { code: "waiting-for-cosignatures", description: "The record is not witnessed yet." },
  { code: "waiting-for-record", description: "This tier waits for a witnessed record." },
  { code: "no-signed-time", description: "No signed time is available yet, so deadlines cannot be judged." },
  { code: "deadline-passed", description: "The tier's deadline passed, by signed time." },
  { code: "record-invalid", description: "This tier could not be checked because the record tier is invalid." },
  { code: "bad-reference", description: "A receipt reference URL is malformed." },

  // Hubs
  { code: "waiting-for-anchor", description: "No verified anchor from this hub is in the chain yet." },
  { code: "hub-quorum-not-met", description: "The hub checkpoint does not satisfy the hub's quorum yet." },
  { code: "bad-hub-link", description: "A hub link is malformed or does not verify." },
  { code: "hub-link-mismatch", description: "A hub link is for another hub or subject, or its entries are not what they must be." },
  { code: "map-proof-failed", description: "The hub's subject-map proof does not verify." },
  { code: "subject-rotated", description: "The log's key was rotated at this hub; the successor policy is needed." },
  { code: "anchor-behind-record", description: "The hub's anchored checkpoint is older than the record checkpoint." },
  { code: "anchor-quorum-not-met", description: "The anchored checkpoint does not meet the app log's quorum." },
  { code: "bad-blinded-anchor", description: "A blinded anchor entry or its statement does not verify." },
  { code: "opening-missing", description: "Private event: the opening of the blinded anchor is not in the chain." },
  { code: "bad-opening", description: "An opening is malformed or does not match its blinded anchor." },

  // Browser layer
  { code: "browser-test-only", description: "The policy uses the browser layer only as a test (no independent service and no bootstrap hub)." },
  { code: "waiting-for-browser-anchor", description: "No browser anchor or bootstrap link for this hub is in the chain yet." },
  { code: "browser-behind-anchor", description: "The browser layer or bootstrap hub holds an older hub checkpoint than the hub's anchor; a newer one is due." },
  { code: "bad-browser-anchor", description: "A browser anchor is malformed or its manifest, hub, domain or size do not match." },
  { code: "bad-waict-proof", description: "The WAICT chain head or prefix-tree proof does not verify." },
  { code: "waict-quorum-not-met", description: "The WAICT prefix root lacks enough valid signatures from the policy's waict witnesses." },
  { code: "unknown-waict-service", description: "The browser anchor comes from a service the policy does not list for this hub." },
  { code: "waict-service-not-independent", description: "The WAICT service is run by the operator, so it does not count for the browser tier." },
  { code: "bad-bootstrap-link", description: "A bootstrap link is malformed or does not verify." },

  // Policies
  { code: "policy-syntax", description: "A policy line is malformed." },
  { code: "policy-unknown-keyword", description: "A policy line starts with an unknown keyword." },
  { code: "policy-count", description: "A policy line appears more or fewer times than allowed." },
  { code: "policy-undefined-name", description: "A policy line references a name that is not defined before it." },
  { code: "policy-duplicate-name", description: "A policy defines a name, key or origin twice." },
  { code: "policy-invalid", description: "A policy breaks a validation rule of specs/policy.md, section 3." },
  { code: "policy-unsafe-quorum", description: "A quorum's split cost is below 1, so it does not tolerate the operator's witnesses." },
  { code: "policy-unsigned", description: "A policy lacks valid signatures from enough of its authorities." },
] as const;

export const STEP_CODES = [
  // tier "policy"
  { code: "chain-format", description: "The receipt chain is well formed." },
  { code: "policy-pinned", description: "The receipt chain is for the pinned policy." },
  { code: "log-known", description: "The receipt chain's log is in the policy." },
  // tier "entry"
  { code: "entry-parse", description: "The entry parses as a Vitrine entry." },
  { code: "entry-profile", description: "The entry has the log's profile at its index, with the profile's fields." },
  { code: "entry-expectation", description: "The entry is the one the user expects." },
  // tier "record"
  { code: "promise-signature", description: "The promise batch is signed by the log, for this log, within the policy's merge delay." },
  { code: "promise-inclusion", description: "The promised leaf is in the signed promise batch." },
  { code: "promise-leaf", description: "The promise is for the expected entry." },
  { code: "promise-kept", description: "A witnessed receipt shows the promise was kept by its deadline." },
  { code: "issued-signature", description: "The issued receipt's checkpoint is signed by the log." },
  { code: "issued-inclusion", description: "The entry is in the issued receipt's tree." },
  { code: "record-signature", description: "The record receipt's checkpoint is signed by the log." },
  { code: "record-inclusion", description: "The entry is in the record receipt's tree." },
  { code: "receipts-match", description: "The issued and record receipts are for the same entry at the same index." },
  { code: "record-consistency", description: "The record checkpoint extends the issued checkpoint." },
  // tier "witnesses"
  { code: "record-quorum", description: "The witnesses' cosignatures on the record meet the policy's quorum." },
  // tier "hubs" (params.hub)
  { code: "hub-link", description: "The hub's link verifies: hub signature, hub quorum, index entry and subject map." },
  { code: "hub-opening", description: "Private event: the opening matches the hub's blinded anchor." },
  { code: "hub-anchored-checkpoint", description: "The checkpoint the hub anchored is signed by the log and meets the quorum." },
  { code: "hub-anchor-consistency", description: "The anchored checkpoint extends the record checkpoint." },
  // tier "browser" (params.hub)
  { code: "browser-anchor", description: "The browser anchor verifies: hub checkpoint, manifest, WAICT proof and prefix-root signatures." },
  { code: "browser-consistency", description: "The hub checkpoint in the browser layer extends the hub's anchor checkpoint." },
  { code: "bootstrap-link", description: "The bootstrap hub's link for this hub verifies." },
  { code: "bootstrap-consistency", description: "The hub checkpoint the bootstrap hub anchored extends the hub's anchor checkpoint." },
] as const;

export type ReasonCode = (typeof REASON_CODES)[number]["code"];
export type StepCode = (typeof STEP_CODES)[number]["code"];
