// SPDX-License-Identifier: Apache-2.0
//
// Every reason code and step code that @vitrine/verify emits, with a one-line
// English description each. The UI kit maps reason codes to the Fluent
// messages `reason-<code>` and step codes to `step-<code>`; the descriptions
// here are for developers and for the UI kit's English source, not for users.
// TypeScript checks that the verifier only emits codes listed here.

export const REASON_CODES = [
  // Encodings and limits
  { code: "bad-base64", description: "A base64 value is invalid or not canonical." },
  { code: "bad-hex", description: "A hex value is invalid (only lowercase hex digits are accepted)." },
  { code: "bad-text", description: "Text is not valid UTF-8 or contains a forbidden character." },
  { code: "bad-number", description: "A decimal number is malformed, has leading zeros, or is out of range." },
  { code: "trailing-data", description: "A structure is followed by unexpected bytes." },
  { code: "truncated", description: "A structure ends before all of its parts." },
  { code: "too-large", description: "An object exceeds a size or count limit of the specs." },

  // Signed notes and keys
  { code: "bad-note", description: "A signed note is malformed." },
  { code: "bad-key-name", description: "A key name is empty or contains a space, a plus sign or a control character." },
  { code: "bad-vkey", description: "A verifier key is malformed, has the wrong key ID, or the wrong signature type." },
  { code: "bad-public-key", description: "An Ed25519 public key is not canonical or is of small order." },
  { code: "missing-signature", description: "A note lacks a valid signature it must carry (for example the log's)." },

  // Checkpoints and cosignatures
  { code: "bad-checkpoint", description: "A checkpoint's text is malformed or has extension lines." },
  { code: "bad-empty-tree", description: "A signed checkpoint of size 0 has a root other than the empty tree's (bad-checkpoint evidence)." },
  { code: "wrong-origin", description: "A checkpoint or note names another log or hub than expected." },
  { code: "log-time-missing", description: "A receipt's checkpoint lacks a valid log-time cosignature dated other than 0." },
  { code: "cosignature-in-future", description: "A cosignature is dated more than 300 seconds after the device clock and was ignored." },
  { code: "quorum-not-met", description: "The valid cosignatures do not satisfy the policy's quorum yet." },

  // Proofs
  { code: "bad-proof", description: "A tlog-proof or proof document is malformed." },
  { code: "missing-extra", description: "A receipt has no extra line holding the entry." },
  { code: "index-out-of-range", description: "A leaf index is not below the tree size." },
  { code: "inclusion-failed", description: "An inclusion proof does not verify against the signed root." },
  { code: "consistency-failed", description: "A consistency proof does not verify between two signed checkpoints." },
  { code: "split-view", description: "Two signed checkpoints of one log have the same size but different roots (split-view evidence)." },

  // Entries and expectations
  { code: "bad-entry", description: "An entry does not parse as a Vitrine entry." },
  { code: "wrong-profile", description: "The entry's tag differs from the log's profile at that index." },
  { code: "bad-entry-layout", description: "The entry does not match its profile's fields and types." },
  { code: "entry-mismatch", description: "The entry differs from the one the user expects." },
  { code: "expectation-incomplete", description: "The expectations do not determine the whole entry yet." },
  { code: "expectation-unknown-field", description: "The expectations name a field the profile does not have." },
  { code: "expectation-unsupported", description: "Field expectations were given for a profile this verifier does not know." },
  { code: "receipts-disagree", description: "The issued and record receipts are for different entries or positions." },

  // Promises
  { code: "bad-promise", description: "A promise or promise batch is malformed." },
  { code: "promise-policy-unknown", description: "The promise batch names a policy that is neither the pinned one nor an accepted successor." },
  { code: "promise-mmd-too-large", description: "A promise batch states a longer merge delay than its policy allows." },
  { code: "promise-leaf-mismatch", description: "The promise is for another entry than the expected one." },
  { code: "promise-time", description: "A promise's time is more than 60 seconds from now, so the client treats it as no promise and only escrows it." },
  { code: "promise-pending", description: "Only a promise exists; the receipt is not due yet." },
  { code: "promise-deadline-passed", description: "The promise's deadline passed, by signed time, without a receipt." },
  { code: "promise-kept-unproven", description: "No receipt in the chain shows the promise was kept by its deadline." },
  { code: "broken-promise", description: "A log-signed checkpoint dated after the promise's deadline lacks the promised index (broken-promise evidence)." },
  { code: "bad-promise-list", description: "A promise listing is malformed, or a batch in it isn't of the listing's hour or its leaves don't give the batch's size and root." },

  // Receipt chains
  { code: "malformed-chain", description: "The receipt chain is not a well-formed receipt chain document." },
  { code: "duplicate-block", description: "A receipt chain has two blocks of one type (for one hub)." },
  { code: "no-receipt", description: "A receipt chain has no promise, issued or record block." },
  { code: "policy-mismatch", description: "The receipt chain names another policy than the pinned one or its accepted successors." },
  { code: "policy-draft", description: "The policy is an unsealed draft, which is never valid." },
  { code: "profile-meaning-unknown", description: "A pinned profile meaning or its infrastructure minimums cannot be established, so overall facts remain pending." },
  { code: "bad-policy-ack", description: "The policy-ack block is malformed, or is not the log's acknowledgement of the chain's policy." },
  { code: "unknown-log", description: "The receipt chain names a log the policy does not have." },
  { code: "unknown-hub", description: "A block names a hub the policy does not have; it was ignored." },
  { code: "consistency-missing", description: "A consistency proof the chain needs is absent." },
  { code: "consistency-mismatch", description: "A consistency block's sizes do not match the checkpoints it links." },
  { code: "waiting-for-cosignatures", description: "The record is not witnessed yet." },
  { code: "waiting-for-record", description: "This tier waits for a witnessed record." },
  { code: "no-signed-time", description: "No checkpoint that meets the quorum gives a signed time, so the device clock was used and no tier turns late." },
  { code: "deadline-passed", description: "The tier's deadline passed, by signed time." },
  { code: "record-invalid", description: "This tier could not be checked because the record tier is invalid." },
  { code: "bad-reference", description: "A receipt reference URL is malformed." },
  { code: "reference-unpinned", description: "No pinned policy matches the receipt reference's policy locator." },
  { code: "reference-ambiguous", description: "The receipt reference's policy locator matches more than one pinned policy, so it is refused." },

  // The booth's configuration check
  { code: "bad-config", description: "The election's config statement, the voting-opened milestone, or an entry or receipt for one of them is malformed, unsigned or not witnessed, so the booth must not encrypt." },
  { code: "config-mismatch", description: "The election's config statement verifies but doesn't match the booth (event, election, key, ballot styles, policy or release), so the booth must not encrypt." },

  // Keys logs
  { code: "bad-key-statement", description: "A keys log statement is malformed, names another log, doesn't match its entry, or lacks the log's keys-authority signatures, so it doesn't count." },
  { code: "signed-by-failed", description: "A statement isn't signed by its key, the key was revoked or isn't valid in the keys log at the entry's sequencing time, or too few other valid keys cosigned it." },

  // Upgrades
  { code: "log-quiet", description: "The log is in a quiet period and serves nothing newer until it ends, so what depends on it stays pending until then." },
  { code: "log-private", description: "The log is private: its routes need an auditor's credential, so the application's voter routes supply its proofs." },
  { code: "monitor-evidence", description: "A monitor answered the gossiped checkpoint with evidence it published about the log; fetch and verify it." },

  // Successor policies
  { code: "successors-unchecked", description: "The events log has not been read for successor policies up to a recent checkpoint, so no tier is verified yet." },
  { code: "bad-policy-proofs", description: "The successor-policy proofs are malformed or do not verify." },
  { code: "successor-rejected", description: "A successor policy breaks a rule of the successor rules, so the policy before it stays in force." },
  { code: "policy-equivocation", description: "Two different successors of one policy are in the events log: the policy's signers equivocated." },

  // Hubs
  { code: "bad-subject", description: "A hub subject is malformed: its key isn't an Ed25519 key named after it, its origin is reserved or too long, or its pseudo-origin isn't 64 lowercase hex digits." },
  { code: "waiting-for-anchor", description: "No verified anchor from this hub is in the chain yet." },
  { code: "hub-quorum-not-met", description: "A hub checkpoint (with detail b, the browser layer's B) does not meet its hub's quorum, so it does not count yet." },
  { code: "bad-hub-link", description: "A hub link is malformed or does not verify." },
  { code: "hub-link-mismatch", description: "A hub link is for another hub or subject, or its proofs do not fit together." },
  { code: "hub-index-wrong", description: "The hub's index maps the subject to an entry that is not its anchor: the hub's witnesses co-signed a wrong index." },
  { code: "map-proof-failed", description: "The hub's subject-map proof does not verify." },
  { code: "subject-rotated", description: "The log's key was rotated at this hub under an applied successor; a link for the new key is needed." },
  { code: "rotation-unauthorized", description: "The log's key was rotated at this hub by an entry that no applied successor policy authorizes." },
  { code: "anchor-behind-record", description: "The hub's anchored checkpoint is older than the record checkpoint." },
  { code: "anchor-quorum-not-met", description: "The anchored or opened checkpoint does not meet the app log's quorum, so it does not count." },
  { code: "hub-link-stale", description: "The hub checkpoint of the log's link is more than two anchor periods older than the hub's latest checkpoint." },
  { code: "bad-blinded-anchor", description: "A blinded anchor entry or its statement does not verify." },
  { code: "opening-missing", description: "Private event: the opening of the blinded anchor is not in the chain." },
  { code: "bad-opening", description: "An opening is malformed or does not match its blinded anchor." },
  { code: "previous-anchor-missing", description: "Private event: the previous blinded anchor, its opening or their consistency proof is not in the chain." },
  { code: "bad-previous-anchor", description: "Private event: the previous blinded anchor is not the subject's entry with the previous seq in the same hub checkpoint." },
  { code: "attestation-missing", description: "Private event: no audit attestation that covers the opening is in the chain yet." },
  { code: "attestation-not-covering", description: "Private event: the audit attestation does not cover this opening yet." },
  { code: "bad-attestation", description: "An audit attestation is malformed, does not verify with a policy auditor key, or contradicts the opening." },
  { code: "hub-entry-refused", description: "A hub entry breaks a rule of the hub state machine, which params.rule names; its effects were not applied." },

  // Browser layer
  { code: "browser-test-only", description: "The policy uses the browser layer only as a test (no independent service and no bootstrap hub)." },
  { code: "waiting-for-browser-anchor", description: "The log's pair for this hub (its own hub link, with a browser anchor or a bootstrap link) is not complete in the chain yet." },
  { code: "pair-not-covering", description: "The log's pair for this hub rests on a hub link from before the entry; the next pair covers it." },
  { code: "browser-below-link", description: "The browser anchor or bootstrap link shows an older hub checkpoint than the pair's hub link, so the pair does not fit together." },
  { code: "waiting-for-hub-tier", description: "Private event: the browser tier for this hub is verified only once the hub tier is." },
  { code: "bad-browser-pair", description: "The log's vitrine/browser-pair/v1 document is malformed." },
  { code: "bad-browser-anchor", description: "A browser anchor is malformed or its manifest, hub, domain or size do not match." },
  { code: "bad-waict-proof", description: "The WAICT chain head or prefix-tree proof does not verify." },
  { code: "waict-quorum-not-met", description: "The WAICT prefix root lacks enough valid signatures from the policy's waict witnesses." },
  { code: "unknown-waict-service", description: "The browser anchor comes from a service the policy does not list for this hub." },
  { code: "waict-service-not-independent", description: "The WAICT service is run by the operator, so it does not count for the browser tier." },
  { code: "bad-bootstrap-link", description: "A bootstrap link is malformed or does not verify." },

  // Policies
  { code: "policy-syntax", description: "A policy line is malformed." },
  { code: "policy-unknown-keyword", description: "A policy line starts with an unknown keyword." },
  { code: "policy-count", description: "A policy line appears more or fewer times than allowed." },
  { code: "policy-undefined-name", description: "A policy line references a name that is not defined before it." },
  { code: "policy-duplicate-name", description: "A policy defines a name, key or origin twice." },
  { code: "policy-invalid", description: "A policy breaks a validation rule of specs/policy.md, section 3." },
  { code: "policy-unsafe-quorum", description: "A quorum's split cost or party split cost is too low once its faulty parties are counted as faulty." },
  { code: "policy-unsigned", description: "A policy lacks valid signatures from enough of its sign authorities, the sealing authority among them." },

  // Payloads and redaction
  { code: "payload-mismatch", description: "A payload and its salt don't open the commitment in the entry: the server serves other bytes (payload-mismatch report)." },
  { code: "payload-missing", description: "A commitment field has no payload in the bundle, or is withheld without a notice bundle that verifies (payload-missing report)." },
  { code: "bad-payload-bundle", description: "A payload bundle is malformed, is for another log or range, or has a block for a field that isn't a commitment." },
  { code: "bad-notice", description: "A redaction notice is malformed." },
  { code: "notice-unsigned", description: "A redaction notice lacks valid signatures from enough of the policy's redaction approvers, or the policy allows no redaction." },
  { code: "notice-mismatch", description: "A redaction notice or its events entry doesn't name the withheld entry, field and commitment, names an entry that can't be redacted, or doesn't withhold the payload as the server says." },
  { code: "notice-not-applied", description: "A redaction notice has no effect: its previous line doesn't name the latest notice that applied to the entry, it repeats one, or it isn't dated after that notice was sequenced." },
  { code: "bad-notice-bundle", description: "A notice bundle is malformed, or its receipt doesn't verify in the events log or doesn't meet the quorum." },

  // Evidence
  { code: "bad-operator-list", description: "An operator list is malformed or exceeds its format limits." },
  { code: "operator-list-refused", description: "An operator list fails its pinned authority, freshness, selection or rollback checks." },
  { code: "bad-shared-submission", description: "A shared-log enrolment, authorization or submission is malformed." },
  { code: "shared-submission-refused", description: "A shared-log submission fails its signature, namespace, policy or document checks." },
  { code: "bad-evidence", description: "The evidence file is malformed, or lacks a block its kind needs." },
  { code: "evidence-unknown-kind", description: "The evidence file is of a kind this verifier does not know." },
  { code: "evidence-unpinned", description: "The evidence file's policy is neither pinned nor an accepted successor of a pinned policy." },
  { code: "evidence-wrong-subject", description: "The evidence file's subject is not a log or hub of its policy, or not one its kind applies to." },
  { code: "evidence-policy-mismatch", description: "An object in the evidence file is for another policy than the file's." },
  { code: "not-proven", description: "The evidence's objects verify but do not show the misbehaviour it claims." },
  { code: "needs-scan", description: "The claim can only be checked by reading the log's entries, which this verifier did not do." },
  { code: "rule-unsupported", description: "The evidence names a profile rule that only the WASM verifier runs; this verifier runs vitrine/parse only." },
  { code: "faulty-witness", description: "This witness co-signed both of two inconsistent checkpoints, or a hub checkpoint with a bad entry, so it is proven faulty." },
  { code: "trust-assumption-failed", description: "The checkpoints that show the misbehaviour meet the quorum: more witnesses are faulty than the policy assumes." },
  { code: "misbehaviour-proven", description: "The evidence proves the misbehaviour it claims, under the file's policy." },
] as const;

export const STEP_CODES = [
  // tier "policy"
  { code: "chain-format", description: "The receipt chain is well formed." },
  { code: "policy-pinned", description: "The receipt chain is for the pinned policy or an accepted successor." },
  { code: "policy-successors", description: "The events log was read for successor policies up to a recent checkpoint." },
  { code: "policy-ack", description: "The log's acknowledgement of the chain's policy verifies." },
  { code: "log-known", description: "The receipt chain's log is in the policy." },
  // tier "entry"
  { code: "entry-parse", description: "The entry parses as a Vitrine entry." },
  { code: "entry-profile", description: "The entry has the log's profile at its index, with the profile's fields." },
  { code: "entry-expectation", description: "The entry is the one the user expects." },
  // tier "record"
  { code: "promise-signature", description: "The promise batch is signed by the log, for this log, under a known policy and within its merge delay." },
  { code: "promise-inclusion", description: "The promised leaf is in the signed promise batch." },
  { code: "promise-leaf", description: "The promise is for the expected entry." },
  { code: "promise-kept", description: "A receipt shows the promise was kept by its deadline, and no held checkpoint shows it broken." },
  { code: "issued-signature", description: "The issued receipt's checkpoint is signed by the log and carries its log-time." },
  { code: "issued-inclusion", description: "The entry is in the issued receipt's tree." },
  { code: "record-signature", description: "The record receipt's checkpoint is signed by the log and carries its log-time." },
  { code: "record-inclusion", description: "The entry is in the record receipt's tree." },
  { code: "receipts-match", description: "The issued and record receipts are for the same entry at the same index." },
  { code: "record-consistency", description: "The record checkpoint extends the issued checkpoint." },
  // tier "witnesses"
  { code: "record-quorum", description: "The witnesses' cosignatures on the record meet the policy's quorum." },
  { code: "log-consistent", description: "The checkpoints of the log that the verifier holds show no split view." },
  // tier "hubs" (params.hub)
  { code: "hub-link", description: "The hub's link verifies: hub signature, hub quorum, index entry and subject map." },
  { code: "hub-opening", description: "Private event: the opening matches the hub's blinded anchor." },
  { code: "hub-anchored-checkpoint", description: "The checkpoint the hub anchored (or the opened one) is signed by the log and meets the quorum." },
  { code: "hub-previous-anchor", description: "Private event: the previous blinded anchor is in the same hub checkpoint and its opening matches it." },
  { code: "hub-opening-consistency", description: "Private event: the two opened checkpoints are consistent." },
  { code: "hub-attestation", description: "Private event: an auditor's attestation covers the opening." },
  { code: "hub-anchor-consistency", description: "The anchored checkpoint and the record checkpoint are consistent." },
  // tier "browser" (params.hub)
  { code: "browser-link", description: "The hub link of the log's pair verifies, with the hub's quorum, and its anchored checkpoint contains the entry." },
  { code: "browser-link-consistency", description: "The checkpoint that the pair's hub link anchors and the record checkpoint are consistent." },
  { code: "browser-anchor", description: "The browser anchor verifies: hub checkpoint, manifest, WAICT proof and prefix-root signatures." },
  { code: "bootstrap-link", description: "The bootstrap hub's link for this hub verifies." },
  { code: "browser-consistency", description: "The hub checkpoint that the browser anchor or bootstrap link shows extends the hub checkpoint of the pair's link." },
] as const;

export type ReasonCode = (typeof REASON_CODES)[number]["code"];
export type StepCode = (typeof STEP_CODES)[number]["code"];
