// SPDX-License-Identifier: Apache-2.0
//
// Upgrading receipt chains (specs/receipt.md, sections 1.2 and 2.2): resolve a
// promise, replace an issued receipt with one against a cosigned epoch
// checkpoint, fetch the latest hub anchors and browser-layer proofs, and check
// the log against a mirror.
//
// Privacy (P9, TL-T10): requests whose path depends on the entry's index or
// on the size of its first checkpoint go only to the log. Requests to third
// parties (mirrors, hubs) come after a random delay of 1 to 30 minutes. No
// request carries credentials or a referrer, and redirects are refused, so
// nothing reaches a server the caller didn't name in the policy.

import { hexEncode } from "./pure/base64.js";
import { equalBytes, fromUtf8, utf8 } from "./pure/bytes.js";
import { parseHashLines } from "./pure/blocks.js";
import { BROWSER_ANCHOR_HEADER, verifyBrowserAnchor } from "./pure/browser.js";
import { consistencyBlock, formatChain, parseChain, type ConsistencyBlock, type HubBlocks, type ReceiptChain } from "./pure/chain.js";
import { verifyCheckpoint, type CheckedCheckpoint, type Checkpoint } from "./pure/checkpoint.js";
import { leafHash } from "./pure/hash.js";
import { bootstrapHubOf, HUB_LINK_HEADER, hubSubject, logSubject, verifyHubLink, type Subject, type VerifiedHubLink } from "./pure/hub.js";
import { MAX_CONSISTENCY_HASHES, MAX_INCLUSION_HASHES, verifyConsistency, verifyInclusion } from "./pure/merkle.js";
import { appHubs, type Policy, type PolicyHub, type PolicyLog } from "./pure/policy.js";
import { parsePromise } from "./pure/promise.js";
import { referenceMatches, type ReceiptReference } from "./pure/reference.js";
import { formatTlogProof, parseTlogProof, type TlogProof } from "./pure/tlogproof.js";

/** Responses are at most 4 MiB, the size of a whole chain. */
const MAX_RESPONSE = 4 << 20;
const MINUTE_MS = 60_000;

export interface UpgradeOptions {
  /** The fetch to use; default the global one. */
  fetch?: typeof fetch;
  /** The device clock, POSIX seconds. */
  now?: () => number;
  /** For a chain whose best receipt is an unwitnessed issued receipt: when
   * the client got it, POSIX seconds. The first upgrade then uses the first
   * epoch that starts after it; without it, the latest epoch that exists. */
  issuedAt?: number;
  /** Check the log against one of its mirrors (the "later checks"), once the
   * record is witnessed. Default true. */
  checkMirror?: boolean;
  /** The delay before third-party requests, in milliseconds. Default: uniform
   * between 1 and 30 minutes. */
  thirdPartyDelay?: () => number;
  /** How to wait; default setTimeout. */
  sleep?: (ms: number, signal?: AbortSignal) => Promise<void>;
  /** Random numbers in [0, 1), for the delay and the choice of mirror. */
  random?: () => number;
  signal?: AbortSignal;
}

export type UpgradeErrorCode = "policy-mismatch" | "unknown-log" | "split-view" | "consistency-failed" | "not-found" | "entry-mismatch";

/** A failure the caller must keep: for `split-view` and `consistency-failed`,
 * `checkpoints` holds both checkpoint notes, the start of split-view evidence
 * (specs/evidence.md, section 2.1). */
export class UpgradeError extends Error {
  readonly code: UpgradeErrorCode;
  readonly checkpoints: string[];

  constructor(code: UpgradeErrorCode, message: string, checkpoints: string[] = []) {
    super(message);
    this.name = "UpgradeError";
    this.code = code;
    this.checkpoints = checkpoints;
  }
}

function join(base: string, path: string): string {
  return base.endsWith("/") ? `${base}${path}` : `${base}/${path}`;
}

function defaultSleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(signal.reason);
      return;
    }
    const t = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    const onAbort = (): void => {
      clearTimeout(t);
      reject(signal?.reason);
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

interface Got {
  status: number;
  body?: Uint8Array;
}

/** Fetch with the request rules: GET only, no credentials, no referrer, no
 * redirects, bounded bodies. Network errors read as status 0. */
class Http {
  constructor(
    private readonly f: typeof fetch,
    private readonly signal: AbortSignal | undefined,
  ) {}

  async get(url: string): Promise<Got> {
    let res: Response;
    try {
      res = await this.f(url, {
        method: "GET",
        credentials: "omit",
        referrerPolicy: "no-referrer",
        redirect: "error",
        ...(this.signal ? { signal: this.signal } : {}),
      });
    } catch (e) {
      if (this.signal?.aborted) throw e;
      return { status: 0 };
    }
    if (res.status !== 200) {
      await res.body?.cancel().catch(() => undefined);
      return { status: res.status };
    }
    const body = await readLimited(res);
    return body ? { status: 200, body } : { status: 413 };
  }
}

async function readLimited(res: Response): Promise<Uint8Array | undefined> {
  if (!res.body) {
    const b = new Uint8Array(await res.arrayBuffer());
    return b.length > MAX_RESPONSE ? undefined : b;
  }
  const reader = res.body.getReader();
  const parts: Uint8Array[] = [];
  let n = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    n += value.length;
    if (n > MAX_RESPONSE) {
      await reader.cancel().catch(() => undefined);
      return undefined;
    }
    parts.push(value);
  }
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

interface VerifiedReceipt {
  proof: TlogProof;
  extra: Uint8Array;
  cp: CheckedCheckpoint;
}

/** Upgrades a receipt chain as far as the servers allow, and returns the new
 * chain. Blocks are replaced only by ones that verify; on anything else the
 * chain keeps what it had. Throws UpgradeError for a chain of another policy
 * or log, and when the log contradicts itself or a mirror. */
export async function upgradeChain(chain: string | Uint8Array, policy: Policy, opts: UpgradeOptions = {}): Promise<string> {
  return new Upgrader(policy, opts).run(parseChain(chain));
}

/** Rebuilds a chain from a receipt reference (specs/receipt.md, section 4):
 * fetches the receipt for the reference's entry from the log only. Pass the
 * result to upgradeChain for the anchors. */
export async function chainFromReference(ref: ReceiptReference, policy: Policy, opts: UpgradeOptions = {}): Promise<string> {
  if (!referenceMatches(ref, policy)) throw new UpgradeError("policy-mismatch", "the reference is for another policy");
  const log = policy.logs.get(ref.log);
  if (!log) throw new UpgradeError("unknown-log", `the policy has no log ${ref.log}`);
  const u = new Upgrader(policy, opts);
  const got = log.url ? await u.http.get(join(log.url, `receipt/${hexEncode(leafHash(ref.entry))}`)) : { status: 0 };
  if (got.status !== 200 || !got.body) throw new UpgradeError("not-found", `the log has no receipt for this entry (HTTP ${got.status})`);
  const r = u.receiptOf(got.body, log);
  if (!r || !equalBytes(r.extra, ref.entry) || r.proof.index !== ref.index) {
    throw new UpgradeError("entry-mismatch", "the log's receipt is not for the referenced entry");
  }
  return fromUtf8(formatChain({ policyId: policy.id, log: log.name, record: got.body, hubs: new Map(), unknown: [] }));
}

class Upgrader {
  readonly http: Http;
  private readonly now: () => number;
  private readonly random: () => number;
  private delayed = false;

  constructor(
    private readonly policy: Policy,
    private readonly opts: UpgradeOptions,
  ) {
    const f = opts.fetch ?? globalThis.fetch.bind(globalThis);
    this.http = new Http(f, opts.signal);
    this.now = opts.now ?? ((): number => Math.floor(Date.now() / 1000));
    this.random = opts.random ?? Math.random;
  }

  async run(c: ReceiptChain): Promise<string> {
    if (c.policyId !== this.policy.id) throw new UpgradeError("policy-mismatch", "the chain is for another policy");
    const log = this.policy.logs.get(c.log);
    if (!log) throw new UpgradeError("unknown-log", `the policy has no log ${c.log}`);
    if (log.url) {
      if (!c.issued && !c.record && c.promise) await this.resolvePromise(c, log, log.url);
      if (!this.witnessed(c, log)) await this.firstUpgrade(c, log, log.url);
      await this.anchors(c, log, log.url);
      const rec = this.witnessed(c, log);
      if (rec && (this.opts.checkMirror ?? true)) await this.checkMirror(rec, log, log.url);
    }
    return fromUtf8(formatChain(c));
  }

  /** A verified receipt (signature and inclusion), or undefined. */
  receiptOf(body: Uint8Array, log: PolicyLog): VerifiedReceipt | undefined {
    try {
      const proof = parseTlogProof(body);
      const extra = proof.extra;
      if (!extra) return undefined;
      const cp = verifyCheckpoint(proof.checkpoint, log.vkey, this.policy.witnesses, this.now());
      if (proof.index >= cp.cp.size) return undefined;
      if (!verifyInclusion(proof.index, cp.cp.size, leafHash(extra), proof.proof, cp.cp.root)) return undefined;
      return { proof, extra, cp };
    } catch {
      return undefined;
    }
  }

  private checkpointOf(body: Uint8Array | undefined, log: PolicyLog): CheckedCheckpoint | undefined {
    if (!body) return undefined;
    try {
      return verifyCheckpoint(body, log.vkey, this.policy.witnesses, this.now());
    } catch {
      return undefined;
    }
  }

  private proofOf(body: Uint8Array | undefined, max: number): Uint8Array[] | undefined {
    if (!body) return undefined;
    try {
      return parseHashLines(body, max);
    } catch {
      return undefined;
    }
  }

  /** The best receipt when it meets the quorum. */
  private witnessed(c: ReceiptChain, log: PolicyLog): VerifiedReceipt | undefined {
    const body = c.record ?? c.issued;
    const r = body ? this.receiptOf(body, log) : undefined;
    return r && this.policy.witnesses.meets(r.cp.cosigs) ? r : undefined;
  }

  private async thirdParty(): Promise<void> {
    if (this.delayed) return;
    this.delayed = true;
    const ms = this.opts.thirdPartyDelay ? this.opts.thirdPartyDelay() : MINUTE_MS + this.random() * 29 * MINUTE_MS;
    if (ms > 0) await (this.opts.sleep ?? defaultSleep)(ms, this.opts.signal);
  }

  /** specs/receipt.md, section 2.2: the receipt against the earliest cosigned
   * checkpoint with the promised leaf, from the log only. */
  private async resolvePromise(c: ReceiptChain, log: PolicyLog, url: string): Promise<void> {
    let leaf: Uint8Array;
    try {
      leaf = parsePromise(c.promise!).leaf;
    } catch {
      return;
    }
    const got = await this.http.get(join(url, `receipt/${hexEncode(leaf)}`));
    if (got.status !== 200 || !got.body) return;
    const r = this.receiptOf(got.body, log);
    if (r && equalBytes(leafHash(r.extra), leaf)) c.record = got.body;
  }

  /** specs/receipt.md, section 1.2, the first upgrade: epoch checkpoint,
   * inclusion proof at its size and consistency proof from the issued size,
   * all from the log. */
  private async firstUpgrade(c: ReceiptChain, log: PolicyLog, url: string): Promise<void> {
    const body = c.record ?? c.issued;
    const r = body ? this.receiptOf(body, log) : undefined;
    if (!r) return;
    const epoch = this.policy.epoch;
    const now = this.now();
    const candidates: number[] = [];
    if (this.opts.issuedAt !== undefined) {
      const n = Math.floor(this.opts.issuedAt / epoch) + 1;
      if (n * epoch <= now) candidates.push(n);
    } else {
      const n = Math.floor(now / epoch);
      candidates.push(n, n - 1);
    }
    for (const n of candidates) {
      if (n < 0) continue;
      const got = await this.http.get(join(url, `epoch/${n}`));
      const ep = this.checkpointOf(got.body, log);
      if (!got.body || !ep || !this.policy.witnesses.meets(ep.cosigs)) continue;
      const size = ep.cp.size;
      if (size <= r.proof.index) continue;
      const inc = await this.http.get(join(url, `proof/inclusion/${r.proof.index}/${size}`));
      const incProof = this.proofOf(inc.body, MAX_INCLUSION_HASHES);
      if (!incProof || !verifyInclusion(r.proof.index, size, leafHash(r.extra), incProof, ep.cp.root)) return;
      const issued = c.issued ? this.receiptOf(c.issued, log) : undefined;
      let cons;
      if (issued) {
        const from = issued.cp.cp.size;
        if (from > size) continue;
        if (from === size) {
          if (!equalBytes(issued.cp.cp.root, ep.cp.root)) {
            throw new UpgradeError("split-view", "the epoch checkpoint and the issued receipt disagree", [issued.proof.checkpoint, fromUtf8(got.body)]);
          }
        } else {
          const cr = await this.http.get(join(url, `proof/consistency/${from}/${size}`));
          const proof = this.proofOf(cr.body, MAX_CONSISTENCY_HASHES);
          if (!proof) return;
          if (!verifyConsistency(from, size, proof, issued.cp.cp.root, ep.cp.root)) {
            throw new UpgradeError("consistency-failed", "the log's consistency proof doesn't link the issued receipt to the epoch checkpoint", [
              issued.proof.checkpoint,
              fromUtf8(got.body),
            ]);
          }
          cons = consistencyBlock(from, size, proof);
        }
      }
      c.record = utf8(formatTlogProof({ extra: r.extra, index: r.proof.index, proof: incProof, checkpoint: fromUtf8(got.body) }));
      if (cons) c.consistency = cons;
      else delete c.consistency;
      // Anchor consistency proofs started at the old record size.
      for (const h of c.hubs.values()) delete h.anchorConsistency;
      return;
    }
  }

  /** The latest anchors and browser-layer proofs, from the log
   * (`anchors/<hub>`, `anchors/<hub>/browser`). */
  private async anchors(c: ReceiptChain, log: PolicyLog, url: string): Promise<void> {
    const body = c.record ?? c.issued;
    const rec = body ? this.receiptOf(body, log) : undefined;
    if (!rec) return;
    for (const h of appHubs(this.policy)) {
      const blocks: HubBlocks = c.hubs.get(h.name) ?? {};
      await this.anchor(blocks, h, log, url, rec.cp.cp);
      const base = this.hubCheckpointOf(blocks, h, log);
      if (base) await this.browserLayer(blocks, h, url, base);
      if (Object.keys(blocks).length > 0) c.hubs.set(h.name, blocks);
    }
  }

  private async anchor(blocks: HubBlocks, h: PolicyHub, log: PolicyLog, url: string, record: Checkpoint): Promise<void> {
    const got = await this.http.get(join(url, `anchors/${h.name}`));
    if (got.status !== 200 || !got.body) return;
    try {
      const subject = logSubject(this.policy, log.name);
      const link = verifyHubLink(got.body, h, subject, this.now());
      if (!link.hubQuorum) return;
      // Never go back to an older hub checkpoint than the chain holds.
      const old = this.hubLinkOf(blocks.anchor, h, subject);
      if (old && old.hub.cp.size > link.hub.cp.size) return;
      if (link.kind === "blinded") {
        // A private event's opening comes from the application (POST
        // voter/opening), so a blinded anchor only fills an empty slot.
        if (!blocks.anchor) blocks.anchor = got.body;
        return;
      }
      if (link.kind !== "anchor" || (blocks.anchor && blocks.opening)) return;
      const anchored = verifyCheckpoint(link.anchored!, log.vkey, this.policy.witnesses, this.now());
      const from = record.size;
      const to = anchored.cp.size;
      if (to < from) return;
      let cons: ConsistencyBlock | undefined;
      if (to === from) {
        if (!equalBytes(record.root, anchored.cp.root)) return;
      } else {
        const cr = await this.http.get(join(url, `proof/consistency/${from}/${to}`));
        const proof = this.proofOf(cr.body, MAX_CONSISTENCY_HASHES);
        if (!proof || !verifyConsistency(from, to, proof, record.root, anchored.cp.root)) return;
        cons = consistencyBlock(from, to, proof);
      }
      blocks.anchor = got.body;
      if (cons) blocks.anchorConsistency = cons;
      else delete blocks.anchorConsistency;
      // A bootstrap proof started at the old anchor's hub checkpoint.
      delete blocks.bootstrapConsistency;
    } catch {
      // Keep what the chain has.
    }
  }

  private hubLinkOf(body: Uint8Array | undefined, h: PolicyHub, subject: Subject): VerifiedHubLink | undefined {
    if (!body) return undefined;
    try {
      return verifyHubLink(body, h, subject, this.now());
    } catch {
      return undefined;
    }
  }

  private hubCheckpointOf(blocks: HubBlocks, h: PolicyHub, log: PolicyLog): Checkpoint | undefined {
    const link = this.hubLinkOf(blocks.anchor, h, logSubject(this.policy, log.name));
    return link?.hubQuorum ? link.hub.cp : undefined;
  }

  /** The hub size a chain's browser-layer block reaches, if it verifies. */
  private browserSize(blocks: HubBlocks, h: PolicyHub, base: Checkpoint): bigint {
    let best = -1n;
    if (blocks.browser) {
      try {
        const v = verifyBrowserAnchor(blocks.browser, this.policy, h, base, this.now());
        if (v.hubQuorum && v.position === "extends") best = v.hub.cp.size;
      } catch {
        // Not a usable block.
      }
    }
    if (blocks.bootstrap) {
      try {
        const b = bootstrapHubOf(this.policy, blocks.bootstrap);
        const link = verifyHubLink(blocks.bootstrap, b, hubSubject(h), this.now());
        if (link.hubQuorum && link.kind === "anchor") {
          const s = verifyCheckpoint(link.anchored!, h.vkey, h.set, this.now()).cp.size;
          if (s > best) best = s;
        }
      } catch {
        // Not a usable block.
      }
    }
    return best;
  }

  private async browserLayer(blocks: HubBlocks, h: PolicyHub, url: string, base: Checkpoint): Promise<void> {
    const got = await this.http.get(join(url, `anchors/${h.name}/browser`));
    if (got.status !== 200 || !got.body) return;
    const nl = got.body.indexOf(0x0a);
    const header = nl < 0 ? "" : fromUtf8(got.body.subarray(0, nl));
    const have = this.browserSize(blocks, h, base);
    try {
      if (header === BROWSER_ANCHOR_HEADER) {
        const v = verifyBrowserAnchor(got.body, this.policy, h, base, this.now());
        if (v.hubQuorum && v.position === "extends" && v.hub.cp.size >= have) blocks.browser = got.body;
      } else if (header === HUB_LINK_HEADER) {
        const b = bootstrapHubOf(this.policy, got.body);
        const link = verifyHubLink(got.body, b, hubSubject(h), this.now());
        if (!link.hubQuorum || link.kind !== "anchor") return;
        const anchored = verifyCheckpoint(link.anchored!, h.vkey, h.set, this.now()).cp;
        if (anchored.size < base.size || anchored.size < have) return;
        if (anchored.size === base.size) {
          if (!equalBytes(anchored.root, base.root)) return;
          blocks.bootstrap = got.body;
          delete blocks.bootstrapConsistency;
          return;
        }
        // The hub-log proof comes from the app hub, a third party. Both sizes
        // are those of the latest anchors, the same for every voter.
        await this.thirdParty();
        const cr = await this.http.get(join(h.url, `proof/consistency/${base.size}/${anchored.size}`));
        const proof = this.proofOf(cr.body, MAX_CONSISTENCY_HASHES);
        if (!proof || !verifyConsistency(base.size, anchored.size, proof, base.root, anchored.root)) return;
        blocks.bootstrap = got.body;
        blocks.bootstrapConsistency = consistencyBlock(base.size, anchored.size, proof);
      }
    } catch {
      // Keep what the chain has.
    }
  }

  /** specs/receipt.md, section 1.2, later checks: the latest checkpoint from
   * a mirror and from the log must agree, and the log's must extend the
   * record. Mirrors serve only tlog-tiles paths, so both checkpoints come
   * from `checkpoint`; the consistency proofs come from the log. */
  private async checkMirror(rec: VerifiedReceipt, log: PolicyLog, url: string): Promise<void> {
    if (log.mirrors.length === 0) return;
    await this.thirdParty();
    const mirror = log.mirrors[Math.min(log.mirrors.length - 1, Math.floor(this.random() * log.mirrors.length))]!;
    const fromMirror = await this.http.get(join(mirror, "checkpoint"));
    const fromLog = await this.http.get(join(url, "checkpoint"));
    const lc = this.checkpointOf(fromLog.body, log);
    if (!lc || !fromLog.body) return;
    const logText = fromUtf8(fromLog.body);
    await this.agree(rec.cp.cp, rec.proof.checkpoint, lc.cp, logText, url);
    const mc = this.checkpointOf(fromMirror.body, log);
    if (mc && fromMirror.body) await this.agree(mc.cp, fromUtf8(fromMirror.body), lc.cp, logText, url);
  }

  /** Two checkpoints of the log agree when one extends the other; the log
   * proves it. A contradiction throws with both checkpoints. */
  private async agree(a: Checkpoint, aText: string, b: Checkpoint, bText: string, url: string): Promise<void> {
    const both = [aText, bText];
    if (a.size === b.size) {
      if (!equalBytes(a.root, b.root)) throw new UpgradeError("split-view", "two checkpoints of one size have different roots", both);
      return;
    }
    const [lo, hi] = a.size < b.size ? [a, b] : [b, a];
    const got = await this.http.get(join(url, `proof/consistency/${lo.size}/${hi.size}`));
    const proof = this.proofOf(got.body, MAX_CONSISTENCY_HASHES);
    if (!proof) return;
    if (!verifyConsistency(lo.size, hi.size, proof, lo.root, hi.root)) {
      throw new UpgradeError("consistency-failed", "the log's consistency proof doesn't link two of its checkpoints", both);
    }
  }
}
