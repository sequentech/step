// SPDX-License-Identifier: Apache-2.0
//
// Upgrading and checking receipt chains online (specs/receipt.md, sections
// 1.2, 2.2 and 3.1).
//
// - upgradeAtCast: the booth's upgrade while its confirmation screen is open.
//   It polls the log's latest checkpoint every 500 ms until one meets the
//   quorum and covers the issued receipt, then computes the inclusion proof
//   and the consistency proof from the log's tiles. It contacts only the log.
// - upgradeChain and upgradeChainReport: a later check. Successor discovery
//   from the events log, promise resolution, the first epoch upgrade, the
//   latest anchors and browser-layer proofs (all from the log), the log's
//   latest and epoch checkpoints; then, after one random delay, a mirror's
//   checkpoint, every app hub's latest checkpoint, and gossip.
// - checkChain: an upgrade, then verifyChain with what the run fetched.
// - acceptPromiseOnline: the log's latest checkpoint, fetched from the log
//   when a promise arrives, to judge the promise's time (section 2).
//
// Privacy (P9, TL-T10): requests whose path depends on the entry, its index or
// its receipts' sizes go only to the log. Third parties (mirrors,
// hubs, monitors) only get requests that name no entry, after a random delay
// of 1 to 30 minutes, or at once when a hub or browser tier is late or an
// anchor is older than the record. No request carries credentials or a
// referrer, and redirects are refused, so nothing reaches a server the policy
// doesn't name.
//
// Quiet periods (docs/api.md, section 2.1): a 425 from the log means "not
// before the period ends". The chain keeps what it has, the report says until
// when, and it is never an error.

import type { ChainResult, Expect, Reason, Where } from "./types.js";
import { acceptPromise, type PromiseAcceptance } from "./pure/accept.js";
import { hexEncode } from "./pure/base64.js";
import { equalBytes, fromUtf8, utf8 } from "./pure/bytes.js";
import { formatHashLines, parseHashLines } from "./pure/blocks.js";
import { verifyBrowserAnchor } from "./pure/browser.js";
import { consistencyBlock, formatChain, parseChain, verifyChain, type ConsistencyBlock, type HubBlocks, type ReceiptChain } from "./pure/chain.js";
import { parseCheckpointText, type CheckedCheckpoint, type Checkpoint } from "./pure/checkpoint.js";
import { fieldText, parseEntry } from "./pure/entry.js";
import { fail, reason, toReason } from "./pure/errors.js";
import { leafHash, sha256 } from "./pure/hash.js";
import {
  applyPolicyProofs,
  MAX_DISCOVERY_PREFIX_BYTES,
  eventsLogName,
  formatPolicyProofs,
  hubKeys,
  judgeCheckpoint,
  judgeWith,
  logKeys,
  needsDiscovery,
  PolicyHistory,
  type Judged,
  type KeysOf,
  type PolicyProofEntry,
} from "./pure/history.js";
import { bootstrapHubOf, hubSubject, logSubject, parseBrowserPair, verifyHubLink, type BrowserPair, type Subject, type VerifiedHubLink } from "./pure/hub.js";
import { MAX_CONSISTENCY_HASHES, MAX_INCLUSION_HASHES, treeRoot, verifyConsistency, verifyInclusion } from "./pure/merkle.js";
import { parseNote } from "./pure/note.js";
import { appHubs, quietPeriod, type Policy, type PolicyHub, type PolicyLog } from "./pure/policy.js";
import { parsePromise, parsePromiseBatchText } from "./pure/promise.js";
import { referenceMatches, type ReceiptReference } from "./pure/reference.js";
import { policyAckPath, verifyPolicyAck } from "./pure/statements.js";
import { entryBundlePath, HASH_SIZE, parseEntryBundle, tilePath, TileTree, TILE_WIDTH } from "./pure/tiles.js";
import { EVENT_KINDS, EVENTS_TAG, isEventsTag } from "./pure/tags.js";
import { formatTlogProof, parseTlogProof, type TlogProof } from "./pure/tlogproof.js";

/** Responses are at most 4 MiB, the size of a whole chain. */
const MAX_RESPONSE = 4 << 20;
const MINUTE_MS = 60_000;
/** The booth polls the log's checkpoint this often at cast, milliseconds. */
export const AT_CAST_POLL_MS = 500;
/** How long the booth polls at cast by default, milliseconds. */
export const AT_CAST_TIMEOUT_MS = 30_000;
/** Epochs tried after the first one whose checkpoint is smaller than the
 * issued checkpoint. */
const MAX_EPOCH_STEPS = 4;
/** Successor discovery reads the whole events log, up to this many entries. */
const MAX_EVENTS_ENTRIES = 1 << 16;
/** Cosignatures may be dated this far past the device clock. */
const CLOCK_SKEW = 300;

export interface UpgradeOptions {
  /** The fetch to use; default the global one. */
  fetch?: typeof fetch;
  /** The device clock, POSIX seconds. */
  now?: () => number;
  /** The pinned policy with the successors applied so far. Discovery adds to
   * it, so keep it across checks. Default: the pinned policy alone. */
  history?: PolicyHistory;
  /** Read the events log for successor policies first (public events only;
   * a private event's voter route supplies them). Default true. */
  discover?: boolean;
  /** Check the log against one of its mirrors. Default true. */
  checkMirror?: boolean;
  /** Fetch every app hub's latest checkpoint (`GET <hub>/checkpoint`), for
   * the staleness check of section 3.1. Default true. */
  hubCheckpoints?: boolean;
  /** Send the latest epoch checkpoint to the policy's monitors
   * (specs/evidence.md, section 4). Default true. */
  gossip?: boolean;
  /** Make the third-party requests at once, without the random delay: a hub
   * or browser tier is late, or an anchor is older than the record
   * (section 3.1). checkChain sets it from the chain's state. */
  urgent?: boolean;
  /** The delay before third-party requests, in milliseconds. Default:
   * uniform between 1 and 30 minutes. */
  thirdPartyDelay?: () => number;
  /** How to wait; default setTimeout. */
  sleep?: (ms: number, signal?: AbortSignal) => Promise<void>;
  /** Random numbers in [0, 1), for the delay and the choice of mirror. */
  random?: () => number;
  signal?: AbortSignal;
}

export type UpgradeErrorCode =
  | "policy-mismatch"
  | "unknown-log"
  | "split-view"
  | "consistency-failed"
  | "not-found"
  | "entry-mismatch"
  | "quiet-period";

/** A failure the caller must keep: for `split-view` and `consistency-failed`,
 * `checkpoints` holds both checkpoint notes, the start of split-view evidence
 * (specs/evidence.md, section 2.1), and `chain` the chain as far as the run
 * upgraded it. `quiet-period` (chainFromReference only) says when to retry. */
export class UpgradeError extends Error {
  readonly code: UpgradeErrorCode;
  readonly checkpoints: string[];
  readonly chain?: string;
  readonly quietUntil?: number;

  constructor(code: UpgradeErrorCode, message: string, checkpoints: string[] = [], extra: { chain?: string; quietUntil?: number } = {}) {
    super(message);
    this.name = "UpgradeError";
    this.code = code;
    this.checkpoints = checkpoints;
    if (extra.chain !== undefined) this.chain = extra.chain;
    if (extra.quietUntil !== undefined) this.quietUntil = extra.quietUntil;
  }
}

/** Two of the log's signed checkpoints that no append-only log could have
 * produced, or whose consistency proof from the log didn't verify. */
export interface Contradiction {
  code: "split-view" | "consistency-failed";
  /** Both checkpoint notes. */
  checkpoints: [string, string];
}

export interface UpgradeReport {
  /** The upgraded chain. */
  chain: string;
  /** The log's checkpoints that the run fetched (its latest, its latest
   * epoch checkpoint, a mirror's), for verifyChain's `checkpoints`. */
  checkpoints: string[];
  /** Every app hub's latest checkpoint, by hub name, for verifyChain's
   * `hubCheckpoints`. */
  hubCheckpoints: Record<string, string>;
  /** The history, with the successors that discovery applied. */
  history: PolicyHistory;
  /** When the log answered 425 (a quiet period): when the period ends by
   * its `Retry-After`, POSIX seconds. Until then the chain stays pending. */
  quietUntil?: number;
  /** What the run couldn't do or found, as reasons. */
  reasons: Reason[];
  contradictions: Contradiction[];
  /** True when the third-party requests ran. */
  thirdParty: boolean;
}

function join(base: string, path: string): string {
  return base.endsWith("/") ? `${base}${path}` : `${base}/${path}`;
}

function defaultSleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(signal.reason);
      return;
    }
    const t = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    const onAbort = (): void => {
      clearTimeout(t);
      reject(signal?.reason);
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

interface Got {
  status: number;
  body?: Uint8Array;
  /** For 425: the `Retry-After` seconds. */
  retryAfter?: number;
}

/** `Retry-After`: seconds, or an HTTP date. */
function retryAfterOf(v: string | null, nowMs: number): number | undefined {
  if (v === null) return undefined;
  const t = v.trim();
  if (/^[0-9]{1,10}$/.test(t)) return Number(t);
  const d = Date.parse(t);
  return Number.isNaN(d) ? undefined : Math.max(0, Math.ceil((d - nowMs) / 1000));
}

/** Fetch with the request rules: no credentials, no referrer, no redirects,
 * bounded bodies. Network errors read as status 0. */
class Http {
  constructor(
    private readonly f: typeof fetch,
    private readonly signal: AbortSignal | undefined,
  ) {}

  get(url: string): Promise<Got> {
    return this.send(url, { method: "GET" });
  }

  /** A text/plain POST, which needs no CORS preflight (gossip). */
  post(url: string, body: string): Promise<Got> {
    return this.send(url, { method: "POST", body, headers: { "Content-Type": "text/plain" } });
  }

  private async send(url: string, init: RequestInit): Promise<Got> {
    let res: Response;
    try {
      res = await this.f(url, {
        ...init,
        credentials: "omit",
        referrerPolicy: "no-referrer",
        redirect: "error",
        ...(this.signal ? { signal: this.signal } : {}),
      });
    } catch (e) {
      if (this.signal?.aborted) throw e;
      return { status: 0 };
    }
    if (res.status !== 200 && res.status !== 409) {
      await res.body?.cancel().catch(() => undefined);
      const g: Got = { status: res.status };
      if (res.status === 425) {
        const ra = retryAfterOf(res.headers.get("Retry-After"), Date.now());
        if (ra !== undefined) g.retryAfter = ra;
      }
      return g;
    }
    const body = await readLimited(res);
    return body ? { status: res.status, body } : { status: 413 };
  }
}

async function readLimited(res: Response): Promise<Uint8Array | undefined> {
  if (!res.body) {
    const b = new Uint8Array(await res.arrayBuffer());
    return b.length > MAX_RESPONSE ? undefined : b;
  }
  const reader = res.body.getReader();
  const parts: Uint8Array[] = [];
  let n = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    n += value.length;
    if (n > MAX_RESPONSE) {
      await reader.cancel().catch(() => undefined);
      return undefined;
    }
    parts.push(value);
  }
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

/** Thrown inside a run when the log answers 425. */
class QuietPeriod extends Error {}

/** A receipt that verifies: signature, log-time and inclusion. */
interface Rcpt {
  body: Uint8Array;
  proof: TlogProof;
  extra: Uint8Array;
  judged: Judged<CheckedCheckpoint>;
  cp: Checkpoint;
  leaf: Uint8Array;
}

interface HeldCheckpoint {
  judged: Judged<CheckedCheckpoint>;
  text: string;
}

/** A pair that verifies as far as it goes without the record. */
interface PairState {
  /** The app checkpoint that the pair's link anchors, as signed. */
  note: Uint8Array;
  anchored: Checkpoint;
  /** `B`, the hub checkpoint that the browser anchor or bootstrap link shows. */
  b: Checkpoint;
}

/** The chain's pair for a hub, if it holds one. */
function chainPair(blocks: HubBlocks, hub: string): BrowserPair | undefined {
  if (!blocks.browserLink || (!blocks.browser && !blocks.bootstrap)) return undefined;
  const pair: BrowserPair = { hub, link: blocks.browserLink };
  if (blocks.browser) pair.browser = blocks.browser;
  else pair.bootstrap = blocks.bootstrap!;
  if (blocks.browserConsistency) pair.consistency = blocks.browserConsistency;
  return pair;
}

/** True when the policy has a browser layer for tier 3 (a WAICT service or a
 * bootstrap hub), so the log serves pairs. */
function browserTier(p: Policy): boolean {
  return p.waict.size > 0 || [...p.hubs.values()].some((h) => h.bootstrap);
}

/** Upgrades a receipt chain as far as the servers allow (section 1.2) and
 * returns the new chain. Blocks are replaced only by ones that verify; on
 * anything else the chain keeps what it had. Throws UpgradeError for a chain
 * of another policy or log, and when the log contradicts itself or a mirror. */
export async function upgradeChain(chain: string | Uint8Array, policy: Policy, opts: UpgradeOptions = {}): Promise<string> {
  const report = await upgradeChainReport(chain, policy, opts);
  const c = report.contradictions[0];
  if (c) {
    const what = c.code === "split-view" ? "two checkpoints of one size have different roots" : "the log's consistency proof doesn't link two of its checkpoints";
    throw new UpgradeError(c.code, what, [...c.checkpoints], { chain: report.chain });
  }
  return report.chain;
}

/** Like upgradeChain, but returns what the run fetched and found instead of
 * throwing on contradictions. */
export async function upgradeChainReport(chain: string | Uint8Array, policy: Policy, opts: UpgradeOptions = {}): Promise<UpgradeReport> {
  const c = parseChain(chain);
  return new Upgrader(policy, opts).run(c);
}

export interface AtCastOptions {
  fetch?: typeof fetch;
  signal?: AbortSignal;
  /** How long to poll for a checkpoint that meets the quorum, milliseconds.
   * Default 30 000. */
  timeoutMs?: number;
  /** The poll interval, milliseconds. Default 500. */
  pollMs?: number;
  /** The device clock, POSIX seconds. */
  now?: () => number;
  /** A milliseconds clock for the timeout. Default Date.now. */
  clock?: () => number;
  sleep?: (ms: number, signal?: AbortSignal) => Promise<void>;
  history?: PolicyHistory;
}

export interface AtCastResult {
  /** The chain, with the new `record` and `consistency` when `upgraded`. */
  chain: string;
  upgraded: boolean;
  /** When the log answered 425: when the quiet period ends. */
  quietUntil?: number;
  reasons: Reason[];
}

/** The booth's upgrade at cast (specs/receipt.md, section 1.2): polls
 * `GET <log>/checkpoint` until the answer meets the quorum and is at least as
 * large as the `issued` checkpoint, then computes from the log's tiles the
 * inclusion proof at that size and the consistency proof from the `issued`
 * size, verifies both, and stores them as `record` and `consistency`. It
 * contacts only the log. Throws UpgradeError when the log contradicts itself. */
export async function upgradeAtCast(chain: string | Uint8Array, policy: Policy, opts: AtCastOptions = {}): Promise<AtCastResult> {
  const c = parseChain(chain);
  const u = new Upgrader(policy, {
    ...(opts.fetch ? { fetch: opts.fetch } : {}),
    ...(opts.signal ? { signal: opts.signal } : {}),
    ...(opts.now ? { now: opts.now } : {}),
    ...(opts.sleep ? { sleep: opts.sleep } : {}),
    ...(opts.history ? { history: opts.history } : {}),
    discover: false,
  });
  return u.atCast(c, opts);
}

export interface AcceptPromiseOnlineOptions {
  fetch?: typeof fetch;
  signal?: AbortSignal;
  /** The device clock, POSIX seconds. */
  now?: () => number;
  /** The pinned policy with the successors applied so far. Default: the
   * pinned policy alone. */
  history?: PolicyHistory;
  /** What the entry must be (see AcceptPromiseOptions). */
  expect?: Expect;
}

/** Judges a promise that log `log` just gave (specs/receipt.md, section 2):
 * fetches the log's latest checkpoint, from the log only
 * (`GET <log>/checkpoint`), and calls acceptPromise with it. A private
 * log's routes need an auditor's credential, so its promise is judged by the
 * device clock (`log-private`); so is one whose log doesn't answer. */
export async function acceptPromiseOnline(
  promise: string | Uint8Array,
  policy: Policy,
  log: string,
  opts: AcceptPromiseOnlineOptions = {},
): Promise<PromiseAcceptance> {
  const history = opts.history ?? new PolicyHistory(policy);
  const now = (opts.now ?? ((): number => Math.floor(Date.now() / 1000)))();
  const http = new Http(opts.fetch ?? globalThis.fetch.bind(globalThis), opts.signal);
  const inForce = history.at(now);
  const pl = inForce.logs.get(log) ?? policy.logs.get(log);
  const first: Reason[] = [];
  let latest: Uint8Array | undefined;
  if (inForce.visibility === "private") first.push(reason("log-private"));
  else if (pl?.url) {
    const got = await http.get(join(pl.url, "checkpoint"));
    if (got.status === 200 && got.body) latest = got.body;
  }
  const a = acceptPromise(promise, policy, log, { now, history, ...(latest ? { latest } : {}), ...(opts.expect ? { expect: opts.expect } : {}) });
  a.reasons.unshift(...first);
  return a;
}

/** Rebuilds a chain from a receipt reference (specs/receipt.md, section 4):
 * fetches from the log only, with `GET <log>/receipt/<leaf hash>?index=<i>`,
 * the receipt against the checkpoint with the earliest quorum time among
 * those that contain the entry and meet the quorum (section 2.2), and stores
 * it as `issued`. The index lets a `queue` log, which keeps no index of its
 * leaf hashes, find the leaf. Pass the result to upgradeChain or checkChain
 * for the rest. */
export async function chainFromReference(ref: ReceiptReference, policy: Policy, opts: UpgradeOptions = {}): Promise<string> {
  if (!referenceMatches(ref, policy)) throw new UpgradeError("policy-mismatch", "the reference is for another policy");
  const u = new Upgrader(policy, opts);
  const log = u.h.at(u.now()).logs.get(ref.log) ?? policy.logs.get(ref.log);
  if (!log) throw new UpgradeError("unknown-log", `the policy has no log ${ref.log}`);
  u.useLog(log);
  const path = `receipt/${hexEncode(leafHash(ref.entry))}?index=${ref.index}`;
  const got = log.url ? await u.http.get(join(log.url, path)) : { status: 0 };
  if (got.status === 425) {
    const until = got.retryAfter === undefined ? undefined : u.now() + got.retryAfter;
    throw new UpgradeError("quiet-period", "the log is in a quiet period", [], until === undefined ? {} : { quietUntil: until });
  }
  if (got.status !== 200 || !got.body) throw new UpgradeError("not-found", `the log has no receipt for this entry (HTTP ${got.status})`);
  const r = u.receiptOf(got.body);
  if (!r || !equalBytes(r.extra, ref.entry) || r.proof.index !== ref.index) {
    throw new UpgradeError("entry-mismatch", "the log's receipt is not for the referenced entry");
  }
  return fromUtf8(formatChain({ policyId: policy.id, log: log.name, issued: got.body, hubs: new Map(), unknown: [] }));
}

export interface CheckChainOptions extends UpgradeOptions {
  /** What the entry must be (specs/receipt.md, section 1.1). */
  expect: Expect;
  where?: Where;
  /** A private event's `vitrine/policy-proofs/v1` document, from the voter
   * route (specs/redaction.md, section 4.3). */
  policyProofs?: string | Uint8Array;
}

export interface CheckChainResult {
  /** The upgraded chain; store it. */
  chain: string;
  result: ChainResult;
  /** Undefined when the chain couldn't be upgraded at all (it doesn't parse,
   * or is for another policy): `result` says why. */
  report?: UpgradeReport;
}

/** Section 3.1: a hub or browser tier (or one of its hubs) turned late, or
 * an `anchor` block's anchor is older than the record. */
function urgent(r: ChainResult): boolean {
  return r.tiers.some(
    (t) =>
      ((t.tier === "hubs" || t.tier === "browser") && (t.status === "late" || (t.hubs ?? []).some((d) => d.status === "late"))) ||
      (t.tier === "hubs" && (t.hubs ?? []).some((d) => d.reasons.some((x) => x.code === "anchor-behind-record"))),
  );
}

/** An online check (specs/receipt.md, sections 1.2 and 3.1): upgrades the
 * chain, at once without the random delay when a hub or browser tier is late
 * or an anchor is older than the record, then verifies it with the log
 * checkpoints, hub checkpoints and successors the run fetched. */
export async function checkChain(chain: string | Uint8Array, policy: Policy, opts: CheckChainOptions): Promise<CheckChainResult> {
  if (!opts || !opts.expect) throw new TypeError("checkChain needs expectations (opts.expect)");
  const history = opts.history ?? new PolicyHistory(policy);
  const now = opts.now ?? ((): number => Math.floor(Date.now() / 1000));
  const proofReasons: Reason[] = [];
  if (opts.policyProofs !== undefined) {
    try {
      proofReasons.push(...applyPolicyProofs(history, opts.policyProofs, now()).reasons);
    } catch (e) {
      delete history.readThrough;
      proofReasons.push(toReason(e));
    }
  }
  const base = { expect: opts.expect, history, ...(opts.where ? { where: opts.where } : {}) };
  const before = verifyChain(chain, policy, { ...base, now: now() });
  let report: UpgradeReport;
  try {
    report = await upgradeChainReport(chain, policy, { ...opts, history, urgent: opts.urgent ?? urgent(before) });
  } catch (e) {
    if (opts.signal?.aborted) throw e;
    before.reasons.push(...proofReasons);
    return { chain: typeof chain === "string" ? chain : fromUtf8(chain), result: before };
  }
  const result = verifyChain(report.chain, policy, {
    ...base,
    now: now(),
    checkpoints: report.checkpoints,
    hubCheckpoints: report.hubCheckpoints,
    inconsistencies: report.contradictions.filter((x) => x.code === "consistency-failed").map((x) => x.checkpoints),
  });
  result.reasons.push(...proofReasons, ...report.reasons);
  return { chain: report.chain, result, report };
}

// ---------------------------------------------------------------------------

class Upgrader {
  readonly http: Http;
  readonly h: PolicyHistory;
  private readonly deviceNow: () => number;
  private readonly random: () => number;
  private delayed = false;
  private keysOf: KeysOf = logKeys("");
  private logName = "";
  private readonly checkpoints: string[] = [];
  private readonly hubCheckpoints: Record<string, string> = {};
  private readonly reasons: Reason[] = [];
  private readonly contradictions: Contradiction[] = [];
  private quietUntil: number | undefined;
  private quiet = false;
  private thirdPartyRan = false;
  private latestLog: HeldCheckpoint | undefined;
  private latestEpoch: HeldCheckpoint | undefined;

  constructor(
    private readonly pinned: Policy,
    private readonly opts: UpgradeOptions,
  ) {
    const f = opts.fetch ?? globalThis.fetch.bind(globalThis);
    this.http = new Http(f, opts.signal);
    this.deviceNow = opts.now ?? ((): number => Math.floor(Date.now() / 1000));
    this.random = opts.random ?? Math.random;
    this.h = opts.history ?? new PolicyHistory(pinned);
    if (this.h.pinned.id !== pinned.id) throw new TypeError("opts.history is for another pinned policy");
  }

  now(): number {
    return this.deviceNow();
  }

  useLog(log: PolicyLog): void {
    this.logName = log.name;
    this.keysOf = logKeys(log.name);
  }

  // -- Requests ------------------------------------------------------------

  /** A GET to the chain's log (or the events log); a 425 is noted. */
  private async logGet(url: string, path: string): Promise<Got> {
    const g = await this.http.get(join(url, path));
    if (g.status === 425) this.noteQuiet(g.retryAfter);
    return g;
  }

  private noteQuiet(retryAfter: number | undefined): void {
    this.quiet = true;
    if (retryAfter === undefined) return;
    const until = this.now() + retryAfter;
    if (this.quietUntil === undefined || until > this.quietUntil) this.quietUntil = until;
  }

  /** The one random delay before third-party requests, unless urgent. */
  private async delay(): Promise<void> {
    if (this.delayed) return;
    this.delayed = true;
    if (this.opts.urgent) return;
    const ms = this.opts.thirdPartyDelay ? this.opts.thirdPartyDelay() : MINUTE_MS + this.random() * 29 * MINUTE_MS;
    if (ms > 0) await (this.opts.sleep ?? defaultSleep)(ms, this.opts.signal);
  }

  // -- Verification helpers ------------------------------------------------

  receiptOf(body: Uint8Array | undefined): Rcpt | undefined {
    if (!body) return undefined;
    try {
      const proof = parseTlogProof(body);
      const extra = proof.extra;
      if (!extra) return undefined;
      const judged = judgeCheckpoint(this.h, proof.checkpoint, this.keysOf, this.now(), { requireLogTime: true });
      const cp = judged.value.cp;
      const leaf = leafHash(extra);
      if (proof.index >= cp.size || !verifyInclusion(proof.index, cp.size, leaf, proof.proof, cp.root)) return undefined;
      return { body, proof, extra, judged, cp, leaf };
    } catch {
      return undefined;
    }
  }

  private checkpointOf(body: Uint8Array | undefined, requireLogTime = false, keysOf: KeysOf = this.keysOf): Judged<CheckedCheckpoint> | undefined {
    if (!body) return undefined;
    try {
      return judgeCheckpoint(this.h, body, keysOf, this.now(), requireLogTime ? { requireLogTime: true } : {});
    } catch {
      return undefined;
    }
  }

  private proofOf(body: Uint8Array | undefined, max: number): Uint8Array[] | undefined {
    if (!body) return undefined;
    try {
      return parseHashLines(body, max);
    } catch {
      return undefined;
    }
  }

  /** The record receipt, or the issued one. */
  private best(c: ReceiptChain): Rcpt | undefined {
    return this.receiptOf(c.record) ?? this.receiptOf(c.issued);
  }

  private contradiction(code: Contradiction["code"], a: string, b: string, params: Record<string, string | number>): void {
    if (this.contradictions.some((x) => x.checkpoints[0] === a && x.checkpoints[1] === b)) return;
    this.contradictions.push({ code, checkpoints: [a, b] });
    this.reasons.push(reason(code, params, ["checkpoints"]));
  }

  /** The log's subjects in a hub under every policy of the history. */
  private logSubjects(): Subject[] {
    const out: Subject[] = [];
    for (const e of this.h.epochs) {
      if (!e.policy.logs.has(this.logName)) continue;
      const s = logSubject(e.policy, this.logName);
      if (!out.some((x) => x.kind === s.kind && x.name === s.name && x.vkey.text === s.vkey.text)) out.push(s);
    }
    return out;
  }

  private hubSubjects(name: string): Subject[] {
    const out: Subject[] = [];
    for (const e of this.h.epochs) {
      const hd = e.policy.hubs.get(name);
      if (!hd) continue;
      const s = hubSubject(hd);
      if (!out.some((x) => x.name === s.name && x.vkey.text === s.vkey.text)) out.push(s);
    }
    return out;
  }

  /** A hub link judged under rule 9, or undefined when it doesn't verify. */
  private linkOf(hubName: string, body: Uint8Array | undefined, subjects: readonly Subject[]): Judged<VerifiedHubLink> | undefined {
    if (!body) return undefined;
    try {
      return judgeWith(
        this.h,
        hubKeys(hubName),
        (_k, p) => verifyHubLink(body, p.hubs.get(hubName)!, subjects, this.now()),
        (v) => ({ cosigs: v.hub.cosigs }),
      );
    } catch {
      return undefined;
    }
  }

  /** The policy the chain names and its log; throws UpgradeError. */
  private chainLog(c: ReceiptChain): PolicyLog {
    const chainPolicy = this.h.byId(c.policyId);
    if (!chainPolicy) throw new UpgradeError("policy-mismatch", "the chain is for another policy");
    const log = this.h.at(this.now()).logs.get(c.log) ?? chainPolicy.logs.get(c.log);
    if (!log) throw new UpgradeError("unknown-log", `the policy has no log ${c.log}`);
    this.useLog(log);
    return log;
  }

  private finish(c: ReceiptChain): UpgradeReport {
    if (this.quiet) this.reasons.push(reason("log-quiet", this.quietUntil === undefined ? {} : { until: this.quietUntil }));
    const r: UpgradeReport = {
      chain: fromUtf8(formatChain(c)),
      checkpoints: this.checkpoints,
      hubCheckpoints: this.hubCheckpoints,
      history: this.h,
      reasons: this.reasons,
      contradictions: this.contradictions,
      thirdParty: this.thirdPartyRan,
    };
    if (this.quietUntil !== undefined) r.quietUntil = this.quietUntil;
    return r;
  }

  // -- The later check -----------------------------------------------------

  async run(c: ReceiptChain): Promise<UpgradeReport> {
    if (this.opts.discover !== false) await this.discover();
    const log = this.chainLog(c);
    const p = this.h.at(this.now());
    if (p.visibility === "private") {
      // Every route of a private log needs an auditor's credential.
      this.reasons.push(reason("log-private"));
    } else if (log.url) {
      const url = log.url;
      if (!c.policyAck) await this.policyAck(c, url);
      if (!c.issued && !c.record && c.promise) await this.resolvePromise(c, url);
      await this.firstUpgrade(c, url);
      await this.anchors(c, url, p);
      await this.latest(c, url, p);
    }
    await this.thirdParty(log, p);
    return this.finish(c);
  }

  /** The log's acknowledgement of the chain's policy (entry.md, 5.7). */
  private async policyAck(c: ReceiptChain, url: string): Promise<void> {
    if (!c.policyId.startsWith("sha256:")) return;
    const log = this.h.byId(c.policyId)?.logs.get(c.log);
    if (!log) return;
    const got = await this.logGet(url, policyAckPath(c.policyId));
    if (got.status !== 200 || !got.body) return;
    try {
      verifyPolicyAck(got.body, log, c.policyId);
      c.policyAck = got.body;
    } catch {
      // Not the log's acknowledgement: leave the chain without one.
    }
  }

  /** Section 2.2: `GET <log>/receipt/<leaf hash>?near=<promise time>`, from
   * the log only. The log answers against the smallest checkpoint that
   * contains the leaf and shows the promise kept, when one exists, and
   * otherwise against the one with the earliest quorum time; a `queue` log
   * needs `near` to find the leaf. The receipt is stored as `issued` and
   * never replaced. */
  private async resolvePromise(c: ReceiptChain, url: string): Promise<void> {
    let leaf: Uint8Array;
    let time: number;
    try {
      const p = parsePromise(c.promise!);
      leaf = p.leaf;
      time = parsePromiseBatchText(parseNote(p.batchNote).text).time;
    } catch {
      return;
    }
    const got = await this.logGet(url, `receipt/${hexEncode(leaf)}?near=${time}`);
    if (got.status !== 200 || !got.body) return;
    const r = this.receiptOf(got.body);
    if (r && equalBytes(r.leaf, leaf)) c.issued = got.body;
  }

  /** A changed record invalidates proofs that started at its size. */
  private recordChanged(c: ReceiptChain): void {
    for (const h of c.hubs.values()) {
      delete h.anchorConsistency;
      delete h.browserLinkConsistency;
    }
  }

  private storeRecord(c: ReceiptChain, base: Rcpt, proof: Uint8Array[], note: string, cons: ConsistencyBlock | undefined): void {
    c.record = utf8(formatTlogProof({ extra: base.extra, index: base.proof.index, proof, checkpoint: note }));
    if (cons) c.consistency = cons;
    else delete c.consistency;
    this.recordChanged(c);
  }

  /** Section 1.2, the first upgrade: the first epoch that starts after the
   * log-time of the `issued` checkpoint (a later one if that epoch's
   * checkpoint is smaller), its checkpoint, and from the log the inclusion
   * proof at its size and the consistency proof from the `issued` size. It
   * replaces the record from the cast; once the record is that epoch
   * checkpoint, there is nothing to do. A chain without `issued` upgrades an
   * unwitnessed record the same way, without a consistency block. */
  private async firstUpgrade(c: ReceiptChain, url: string): Promise<void> {
    const issued = this.receiptOf(c.issued);
    const record = this.receiptOf(c.record);
    let base: Rcpt;
    if (issued) base = issued;
    else if (record && !record.judged.meets) base = record;
    else return;
    const lt = base.judged.value.logTime;
    if (lt === undefined) return;
    const epoch = base.judged.policy.epoch;
    const n0 = Math.floor(lt / epoch) + 1;
    for (let k = n0; k < n0 + MAX_EPOCH_STEPS; k++) {
      if (k * epoch > this.now() + CLOCK_SKEW) return;
      const got = await this.logGet(url, `epoch/${k}`);
      if (got.status !== 200 || !got.body) return;
      const ep = this.checkpointOf(got.body, true);
      if (!ep || !ep.meets) return;
      const to = ep.value.cp;
      if (to.size < base.cp.size) continue;
      const text = fromUtf8(got.body);
      if (record && record !== base) {
        if (record.cp.size === to.size) {
          if (equalBytes(record.cp.root, to.root)) return;
          this.contradiction("split-view", record.proof.checkpoint, text, { size: Number(to.size) });
          return;
        }
        // The record from the cast and the epoch checkpoint must agree too.
        if (!(await this.agree(record.cp, record.proof.checkpoint, to, text, url))) return;
      }
      if (to.size === base.cp.size) {
        if (!equalBytes(base.cp.root, to.root)) {
          this.contradiction("split-view", base.proof.checkpoint, text, { size: Number(to.size) });
          return;
        }
        this.storeRecord(c, base, base.proof.proof, text, undefined);
        return;
      }
      const inc = await this.logGet(url, `proof/inclusion/${base.proof.index}/${to.size}`);
      const incProof = this.proofOf(inc.body, MAX_INCLUSION_HASHES);
      if (!incProof || !verifyInclusion(base.proof.index, to.size, base.leaf, incProof, to.root)) return;
      let cons: ConsistencyBlock | undefined;
      if (base === issued) {
        const cr = await this.logGet(url, `proof/consistency/${base.cp.size}/${to.size}`);
        const proof = this.proofOf(cr.body, MAX_CONSISTENCY_HASHES);
        if (!proof) return;
        if (!verifyConsistency(base.cp.size, to.size, proof, base.cp.root, to.root)) {
          this.contradiction("consistency-failed", base.proof.checkpoint, text, { from: Number(base.cp.size), to: Number(to.size) });
          return;
        }
        cons = consistencyBlock(base.cp.size, to.size, proof);
      }
      this.storeRecord(c, base, incProof, text, cons);
      return;
    }
  }

  /** Checks that two of the log's checkpoints agree: equal roots at equal
   * sizes, else the log's consistency proof between them. A contradiction
   * is recorded. Returns false when they don't agree or the proof is
   * unavailable. */
  private async agree(a: Checkpoint, aText: string, b: Checkpoint, bText: string, url: string): Promise<boolean> {
    if (a.size === b.size) {
      if (equalBytes(a.root, b.root)) return true;
      this.contradiction("split-view", aText, bText, { size: Number(a.size) });
      return false;
    }
    const [lo, hi, loText, hiText] = a.size < b.size ? [a, b, aText, bText] : [b, a, bText, aText];
    const got = await this.logGet(url, `proof/consistency/${lo.size}/${hi.size}`);
    const proof = this.proofOf(got.body, MAX_CONSISTENCY_HASHES);
    if (!proof) return false;
    // The low-level proof API requires a positive prefix size. Online
    // comparisons also encounter authenticated, canonical empty epochs.
    const emptyPrefix = lo.size === 0n && proof.length === 0 && equalBytes(lo.root, sha256());
    if (!emptyPrefix && !verifyConsistency(lo.size, hi.size, proof, lo.root, hi.root)) {
      this.contradiction("consistency-failed", loText, hiText, { from: Number(lo.size), to: Number(hi.size) });
      return false;
    }
    return true;
  }

  /** The latest hub links and the pairs of tier 3, from the log
   * (`anchors/<hub>`, `anchors/<hub>/browser`), for every app hub. */
  private async anchors(c: ReceiptChain, url: string, p: Policy): Promise<void> {
    const best = this.best(c);
    if (!best) return;
    const subjects = this.logSubjects();
    for (const h of appHubs(p)) {
      const blocks: HubBlocks = c.hubs.get(h.name) ?? {};
      const path = `anchors/${encodeURIComponent(h.name)}`;
      const got = await this.logGet(url, path);
      const fresh = got.status === 200 ? this.linkOf(h.name, got.body, subjects) : undefined;
      const old = this.linkOf(h.name, blocks.anchor, subjects);
      const usable = (l: Judged<VerifiedHubLink> | undefined): l is Judged<VerifiedHubLink> =>
        l !== undefined && l.meets && (l.value.kind === "anchor" || l.value.kind === "rotate");
      let link = usable(old) ? old : undefined;
      if (usable(fresh) && got.body) {
        const newer = !link || fresh.value.hub.cp.size > link.value.hub.cp.size;
        // A rotation link only fills an empty slot: an older anchor of the
        // old subject still shows what the hub holds.
        const take = newer && (fresh.value.kind === "anchor" || !link);
        if (take) {
          const cons = fresh.value.kind === "anchor" ? await this.anchorConsistency(url, best, fresh) : null;
          if (cons !== false) {
            blocks.anchor = got.body;
            if (cons) blocks.anchorConsistency = cons;
            else delete blocks.anchorConsistency;
            link = fresh;
          }
        }
      }
      if (link && link === old && link.value.kind === "anchor" && !blocks.anchorConsistency) {
        // The record changed: prove the kept anchor against it again.
        const cons = await this.anchorConsistency(url, best, link);
        if (cons) blocks.anchorConsistency = cons;
      }
      if (browserTier(p)) await this.pair(blocks, h, url, p, best);
      if (Object.keys(blocks).length > 0) c.hubs.set(h.name, blocks);
    }
  }

  /** The `anchor-consistency` block between the record and a link's anchored
   * checkpoint: `null` when none is needed (equal sizes), false when the
   * link can't be used. Equal sizes with different roots are kept, as the
   * split-view evidence they are. */
  private anchorConsistency(url: string, best: Rcpt, link: Judged<VerifiedHubLink>): Promise<ConsistencyBlock | null | false> {
    return this.withRecord(url, best, link.value.anchored!);
  }

  /** The app-log consistency proof between the record and an anchored
   * checkpoint (`note`), from the log, from the smaller to the larger:
   * `null` when the sizes are equal, false when it can't be had or doesn't
   * verify (which is kept as a contradiction). */
  private async withRecord(url: string, best: Rcpt, note: Uint8Array): Promise<ConsistencyBlock | null | false> {
    const anchored = this.checkpointOf(note);
    if (!anchored || !anchored.meets) return false;
    const a = best.cp;
    const b = anchored.value.cp;
    const text = fromUtf8(note);
    if (a.size === b.size) {
      if (!equalBytes(a.root, b.root)) this.contradiction("split-view", best.proof.checkpoint, text, { size: Number(a.size) });
      return null;
    }
    const [lo, hi] = a.size < b.size ? [a, b] : [b, a];
    const got = await this.logGet(url, `proof/consistency/${lo.size}/${hi.size}`);
    const proof = this.proofOf(got.body, MAX_CONSISTENCY_HASHES);
    if (!proof) return false;
    if (!verifyConsistency(lo.size, hi.size, proof, lo.root, hi.root)) {
      const [x, y] = a.size < b.size ? [best.proof.checkpoint, text] : [text, best.proof.checkpoint];
      this.contradiction("consistency-failed", x, y, { from: Number(lo.size), to: Number(hi.size) });
      return false;
    }
    return consistencyBlock(lo.size, hi.size, proof);
  }

  /** Tier 3 for one hub (specs/hub.md, section 6.5; receipt.md, section 3.1,
   * step 4): the log's pair at `anchors/<hub>/browser`, checked and copied
   * into the chain as it is, with `browser-link-consistency` between the
   * record and the size that the pair's link anchors, from the log. A pair
   * that covers the entry is kept, and replaced only by a newer one that
   * also does. No proof is fetched from a hub. */
  private async pair(blocks: HubBlocks, h: PolicyHub, url: string, p: Policy, best: Rcpt): Promise<void> {
    const cur = chainPair(blocks, h.name);
    const curState = cur ? this.pairState(cur, h, p) : undefined;
    const covers = (s: PairState): boolean => s.anchored.size > best.proof.index;
    const got = await this.logGet(url, `anchors/${encodeURIComponent(h.name)}/browser`);
    let fresh: { pair: BrowserPair; state: PairState } | undefined;
    if (got.status === 200 && got.body) {
      try {
        const pair = parseBrowserPair(got.body);
        const state = pair.hub === h.name ? this.pairState(pair, h, p) : undefined;
        if (state) fresh = { pair, state };
      } catch {
        // Not a pair: keep what the chain has.
      }
    }
    let take = false;
    if (fresh) {
      if (!curState) take = true;
      else if (covers(curState)) take = covers(fresh.state) && fresh.state.b.size > curState.b.size;
      else take = covers(fresh.state) || fresh.state.b.size > curState.b.size;
    }
    if (take && fresh) {
      const cons = await this.withRecord(url, best, fresh.state.note);
      if (cons !== false) {
        blocks.browserLink = fresh.pair.link;
        if (fresh.pair.browser) {
          blocks.browser = fresh.pair.browser;
          delete blocks.bootstrap;
        } else {
          blocks.bootstrap = fresh.pair.bootstrap!;
          delete blocks.browser;
        }
        if (fresh.pair.consistency) blocks.browserConsistency = { ...fresh.pair.consistency };
        else delete blocks.browserConsistency;
        if (cons) blocks.browserLinkConsistency = cons;
        else delete blocks.browserLinkConsistency;
        return;
      }
    }
    // Keep the chain's pair; prove it against the record again if the
    // record changed.
    if (curState && !blocks.browserLinkConsistency) {
      const cons = await this.withRecord(url, best, curState.note);
      if (cons) blocks.browserLinkConsistency = cons;
    }
  }

  /** Checks a pair as far as it goes without the record: the link verifies
   * with the hub's quorum and anchors a checkpoint that meets the app
   * quorum; `B` verifies (a browser anchor or a bootstrap link) with the
   * hub's quorum; `B` is at least as large as the link's hub checkpoint,
   * with equal roots and no `browser-consistency` block at equal sizes, or a
   * verifying one. Undefined when it doesn't. */
  private pairState(pair: BrowserPair, h: PolicyHub, p: Policy): PairState | undefined {
    try {
      const link = this.linkOf(h.name, pair.link, this.logSubjects());
      if (!link || !link.meets || link.value.kind !== "anchor") return undefined;
      const note = link.value.anchored!;
      const anchored = this.checkpointOf(note);
      if (!anchored || !anchored.meets) return undefined;
      let b: Checkpoint | undefined;
      if (pair.browser) {
        const v = verifyBrowserAnchor(pair.browser, p, h, this.now());
        // A B short of the hub's quorum doesn't count (impl-20).
        if (v.belowQuorum.length === 0) b = v.hub.cp;
      } else if (pair.bootstrap) {
        b = this.bootstrapAnchored(pair.bootstrap, h, p)?.cp;
      }
      const H = link.value.hub.cp;
      if (!b || b.size < H.size) return undefined;
      if (b.size === H.size) {
        if (pair.consistency || !equalBytes(b.root, H.root)) return undefined;
      } else {
        const cons = pair.consistency;
        if (!cons || cons.from !== H.size || cons.to !== b.size) return undefined;
        const proof = this.proofOf(cons.body, MAX_CONSISTENCY_HASHES);
        if (!proof || !verifyConsistency(H.size, b.size, proof, H.root, b.root)) return undefined;
      }
      return { note, anchored: anchored.value.cp, b };
    } catch {
      return undefined;
    }
  }

  /** The app hub checkpoint a bootstrap link anchors, when the link meets
   * the bootstrap hub's quorum and the checkpoint the app hub's. */
  private bootstrapAnchored(body: Uint8Array, h: PolicyHub, p: Policy): CheckedCheckpoint | undefined {
    try {
      const b = bootstrapHubOf(p, body);
      const link = this.linkOf(b.name, body, this.hubSubjects(h.name));
      if (!link || !link.meets || link.value.kind !== "anchor") return undefined;
      const anchored = this.checkpointOf(link.value.anchored, false, hubKeys(h.name));
      return anchored && anchored.meets ? anchored.value : undefined;
    } catch {
      return undefined;
    }
  }

  /** The log's latest checkpoint and latest epoch checkpoint, for signed
   * time and the later checks, and the consistency from the record to the
   * latest epoch checkpoint (section 1.2). */
  private async latest(c: ReceiptChain, url: string, p: Policy): Promise<void> {
    const got = await this.logGet(url, "checkpoint");
    const j = got.status === 200 ? this.checkpointOf(got.body) : undefined;
    if (j && got.body) {
      this.latestLog = { judged: j, text: fromUtf8(got.body) };
      this.checkpoints.push(this.latestLog.text);
    }
    const epoch = p.epoch;
    const now = this.now();
    const tries = [Math.floor(now / epoch), Math.floor(now / epoch) - 1];
    const q = quietPeriod(p);
    // In a quiet period, the newest epoch the log serves is from before it.
    if (q && now >= q.start && now <= q.end) tries.push(Math.ceil(q.start / epoch) - 1);
    for (const k of tries) {
      if (k < 0) continue;
      const g = await this.logGet(url, `epoch/${k}`);
      if (g.status === 404 || g.status === 425) continue;
      const e = g.status === 200 ? this.checkpointOf(g.body) : undefined;
      if (e && g.body) {
        this.latestEpoch = { judged: e, text: fromUtf8(g.body) };
        this.checkpoints.push(this.latestEpoch.text);
      }
      break;
    }
    const best = this.best(c);
    if (best && this.latestEpoch) await this.agree(best.cp, best.proof.checkpoint, this.latestEpoch.judged.value.cp, this.latestEpoch.text, url);
  }

  /** After the delay: a mirror's checkpoint, every app hub's latest
   * checkpoint, and gossip. None of these requests names the entry. */
  private async thirdParty(log: PolicyLog, p: Policy): Promise<void> {
    const ref = this.latestEpoch ?? this.latestLog;
    const mirrors = log.mirrors;
    const wantMirror = (this.opts.checkMirror ?? true) && mirrors.length > 0 && ref !== undefined && log.url !== undefined;
    const hubs = (this.opts.hubCheckpoints ?? true) ? appHubs(p) : [];
    const gossip = (this.opts.gossip ?? true) && ref !== undefined ? [...p.monitors.values()] : [];
    if (!wantMirror && hubs.length === 0 && gossip.length === 0) return;
    await this.delay();
    this.thirdPartyRan = true;
    if (wantMirror) {
      const m = mirrors[Math.min(mirrors.length - 1, Math.floor(this.random() * mirrors.length))]!;
      const got = await this.http.get(join(m.url, "checkpoint"));
      const mc = got.status === 200 ? this.checkpointOf(got.body) : undefined;
      if (mc && got.body) {
        const text = fromUtf8(got.body);
        this.checkpoints.push(text);
        await this.agree(ref!.judged.value.cp, ref!.text, mc.value.cp, text, log.url!);
      }
    }
    for (const h of hubs) {
      const got = await this.http.get(join(h.url, "checkpoint"));
      if (got.status === 200 && this.checkpointOf(got.body, false, hubKeys(h.name)) && got.body) {
        this.hubCheckpoints[h.name] = fromUtf8(got.body);
      }
    }
    for (const m of gossip) {
      const got = await this.http.post(join(m.url, "gossip"), ref!.text);
      if (got.status !== 409 || !got.body) continue;
      let text = "";
      try {
        text = fromUtf8(got.body).trim();
      } catch {
        continue;
      }
      const ev = /^evidence (sha256:[0-9a-f]{64})$/.exec(text);
      if (ev) this.reasons.push(reason("monitor-evidence", { monitor: m.name, evidence: ev[1]! }));
    }
  }

  // -- Successor discovery (rule 7) -----------------------------------------

  /** Reads the events log of a public event for successor policies, builds
   * the `vitrine/policy-proofs/v1` document from its public routes, and
   * applies it. These reads don't depend on the entry. */
  private async discover(): Promise<void> {
    const latest = this.h.latest.policy;
    if (!needsDiscovery(latest) || latest.visibility === "private") return;
    const ev = latest.logs.get(eventsLogName(latest)!)!;
    if (!ev.url) return;
    try {
      const doc = await this.policyProofs(ev, ev.url);
      if (!doc) return;
      this.reasons.push(...applyPolicyProofs(this.h, doc.document, this.now(), {eventsPrefix:doc.prefix}).reasons);
    } catch (e) {
      if (this.opts.signal?.aborted) throw e;
      delete this.h.readThrough;
      this.reasons.push(toReason(e));
    }
  }

  private async bundle(url: string, n: bigint, width: number): Promise<Uint8Array[] | undefined> {
    const got = await this.http.get(join(url, entryBundlePath(n, width)));
    if (got.status === 200 && got.body) return parseEntryBundle(got.body, width);
    if (got.status === 404 && width < TILE_WIDTH) {
      // Partial bundles may be gone once the full one exists.
      const full = await this.http.get(join(url, entryBundlePath(n)));
      if (full.status === 200 && full.body) return parseEntryBundle(full.body, TILE_WIDTH).slice(0, width);
    }
    return undefined;
  }

  private async policyProofs(ev: PolicyLog, url: string): Promise<{document:Uint8Array; prefix:Uint8Array[]} | undefined> {
    const keys = logKeys(ev.name);
    const got = await this.http.get(join(url, "checkpoint"));
    if (got.status !== 200 || !got.body) return undefined;
    const served = judgeCheckpoint(this.h, got.body, keys, this.now()).value.cp;
    if (served.size > BigInt(MAX_EVENTS_ENTRIES)) return fail("too-large", { what: "events-log", limit: MAX_EVENTS_ENTRIES });
    const leaves: Uint8Array[] = [];
    const prefix: Uint8Array[] = [];
    let prefixBytes = 0;
    const found: { index: bigint; entry: Uint8Array }[] = [];
    for (let n = 0n; n * BigInt(TILE_WIDTH) < served.size; n++) {
      const left = served.size - n * BigInt(TILE_WIDTH);
      const width = left >= BigInt(TILE_WIDTH) ? TILE_WIDTH : Number(left);
      const entries = await this.bundle(url, n, width);
      if (!entries) return undefined;
      entries.forEach((e, k) => {
        prefixBytes += e.length;
        if (prefixBytes > MAX_DISCOVERY_PREFIX_BYTES) fail("too-large", {what:"events-prefix",limit:MAX_DISCOVERY_PREFIX_BYTES});
        leaves.push(leafHash(e));
        prefix.push(e);
        try {
          const parsed = parseEntry(e);
          if (isEventsTag(parsed.tag) && fieldText(parsed, "kind") === EVENT_KINDS.policy) found.push({ index: n * BigInt(TILE_WIDTH) + BigInt(k), entry: e });
        } catch {
          // Not a policy entry.
        }
      });
    }
    // The bundles must be the checkpoint's entries, so none was left out.
    if (!equalBytes(treeRoot(leaves), served.root)) fail("bad-policy-proofs", { detail: "entries" });
    const entries: PolicyProofEntry[] = [];
    for (const f of found) {
      // The receipt that dates the entry (rule 3): against the checkpoint with
      // the earliest quorum time, by index so a `queue` log finds the leaf.
      const r = await this.http.get(join(url, `receipt/${hexEncode(leafHash(f.entry))}?index=${f.index}`));
      if (r.status !== 200 || !r.body) return undefined;
      const from = parseCheckpointText(parseNote(parseTlogProof(r.body).checkpoint).text).size;
      let proof: Uint8Array[] = [];
      if (from < served.size) {
        const cr = await this.http.get(join(url, `proof/consistency/${from}/${served.size}`));
        const p = this.proofOf(cr.body, MAX_CONSISTENCY_HASHES);
        if (!p) return undefined;
        proof = p;
      }
      entries.push({ proof: r.body, from, to: served.size, consistency: formatHashLines(proof) });
    }
    return {document:formatPolicyProofs({ log: ev.name, checkpoint: got.body, entries }),prefix};
  }

  // -- At cast ---------------------------------------------------------------

  /** A hash tile from the log, falling back to the full tile when a partial
   * one is gone (tlog-tiles). */
  private async tile(url: string, level: number, n: bigint, width: number): Promise<Uint8Array> {
    const got = await this.logGet(url, tilePath(level, n, width));
    if (got.status === 200 && got.body) return got.body;
    if (got.status === 425) throw new QuietPeriod();
    if (got.status === 404 && width < TILE_WIDTH) {
      const full = await this.logGet(url, tilePath(level, n));
      if (full.status === 200 && full.body && full.body.length === TILE_WIDTH * HASH_SIZE) return full.body.subarray(0, width * HASH_SIZE);
      if (full.status === 425) throw new QuietPeriod();
    }
    throw new Error(`no tile ${level}/${n} (HTTP ${got.status})`);
  }

  async atCast(c: ReceiptChain, opts: AtCastOptions): Promise<AtCastResult> {
    const log = this.chainLog(c);
    const result = (upgraded: boolean): AtCastResult => {
      const r = this.finish(c);
      const out: AtCastResult = { chain: r.chain, upgraded, reasons: r.reasons };
      if (r.quietUntil !== undefined) out.quietUntil = r.quietUntil;
      return out;
    };
    if (this.h.at(this.now()).visibility === "private") {
      this.reasons.push(reason("log-private"));
      return result(false);
    }
    const url = log.url;
    const base = this.receiptOf(c.issued);
    if (!url || !base) return result(false);
    const record = this.receiptOf(c.record);
    if ((record ?? base).judged.meets) return result(false);
    const pollMs = opts.pollMs ?? AT_CAST_POLL_MS;
    const clock = opts.clock ?? Date.now;
    const sleep = opts.sleep ?? defaultSleep;
    const end = clock() + (opts.timeoutMs ?? AT_CAST_TIMEOUT_MS);
    let found: HeldCheckpoint | undefined;
    for (;;) {
      const got = await this.logGet(url, "checkpoint");
      if (got.status === 425) return result(false);
      const j = got.status === 200 ? this.checkpointOf(got.body, true) : undefined;
      if (j && got.body && j.meets && j.value.cp.size >= base.cp.size) {
        found = { judged: j, text: fromUtf8(got.body) };
        break;
      }
      if (clock() + pollMs > end) {
        this.reasons.push(reason("waiting-for-cosignatures"));
        return result(false);
      }
      await sleep(pollMs, opts.signal);
    }
    const from = base.cp;
    const to = found.judged.value.cp;
    const both = [base.proof.checkpoint, found.text];
    if (to.size === from.size) {
      if (!equalBytes(from.root, to.root)) throw new UpgradeError("split-view", "the log's latest checkpoint and the issued receipt disagree", both);
      this.storeRecord(c, base, base.proof.proof, found.text, undefined);
      return result(true);
    }
    const tree = new TileTree(to.size, (level, n, width) => this.tile(url, level, n, width));
    let inc: Uint8Array[];
    let cons: Uint8Array[];
    try {
      inc = await tree.inclusionProof(base.proof.index);
      cons = await tree.consistencyProof(from.size);
    } catch (e) {
      if (opts.signal?.aborted) throw e;
      return result(false);
    }
    if (!verifyConsistency(from.size, to.size, cons, from.root, to.root)) {
      throw new UpgradeError("consistency-failed", "the log's tiles don't link the issued receipt to its latest checkpoint", both);
    }
    if (!verifyInclusion(base.proof.index, to.size, base.leaf, inc, to.root)) {
      this.reasons.push(reason("inclusion-failed", { what: "tiles" }));
      return result(false);
    }
    this.storeRecord(c, base, inc, found.text, consistencyBlock(from.size, to.size, cons));
    return result(true);
  }
}
