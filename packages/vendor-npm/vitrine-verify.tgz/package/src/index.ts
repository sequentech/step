// SPDX-License-Identifier: Apache-2.0
//
// @vitrine/verify: the verifier SDK (docs/api.md, section 8). Verification
// runs on a backend: today the pure TypeScript verifier, later the WASM build
// of vitrine-tlog, behind the same calls. `init()` picks the backend.
//
// Browser rules: no request the caller didn't ask for, no credentials or
// cookies, no telemetry, and no WebCrypto for Ed25519 (@noble/curves checks
// signatures, with the strict rules of specs/entry.md).

import type { ChainResult, EvidenceResult, Expect, ReceiptResult } from "./types.js";
import { verifyChain as pureVerifyChain, verifyReceipt as pureVerifyReceipt, type VerifyChainOptions } from "./pure/chain.js";
import { buildElectionEntry as pureBuildElectionEntry, type ElectionFields } from "./pure/entry.js";
import { receiptWordsFor } from "./pure/identicon.js";
import { buildEvidence as pureBuildEvidence, verifyEvidence as pureVerifyEvidence } from "./pure/evidence.js";
import { parsePolicy as pureParsePolicy, policyWords as purePolicyWords, type ParsePolicyOptions, type Policy } from "./pure/policy.js";

export type * from "./types.js";
export { REASON_CODES, STEP_CODES, type ReasonCode, type StepCode } from "./codes.js";
export { VerifyError } from "./pure/errors.js";
export type { Policy, PolicyHub, PolicyLog, ParsePolicyOptions, SharedLogPin } from "./pure/policy.js";
export { isFormatChar, type ElectionFields } from "./pure/entry.js";
export { formatBrowserPair, parseBrowserPair, type BrowserPair } from "./pure/hub.js";
export { CHAIN_FILE_EXTENSION, CHAIN_MEDIA_TYPE, policySummary, type VerifyChainOptions } from "./pure/chain.js";
export { identicon } from "./pure/identicon.js";
export {
  formatReceiptReference,
  parseReceiptReference,
  policyPrefix,
  referenceLeafHex,
  referenceMatches,
  resolveReference,
  type ReceiptReference,
} from "./pure/reference.js";
export {
  checkBoothConfig,
  checkStyles,
  parseConfigStatement,
  parseMilestoneStatement,
  styleDigest,
  stylesHash,
  type BoothCheckInput,
  type BoothConfig,
  type ConfigStatement,
  type MilestoneStatement,
  type Release,
} from "./pure/config.js";
export { PolicyHistory, type DiscoveryResult, type PolicyEpoch, type SerializedPolicyHistory } from "./pure/history.js";
export { checkLoggedRelease, checkReleaseFiles, parseReleaseManifest, parseReleaseStatement, type CheckLoggedReleaseOptions, type LoggedRelease, type ReleaseManifest, type ReleaseStatement } from "./pure/release.js";
export { keyEntryStatement, KeyLog, parseKeyStatement, type KeyStatement, type SignedBy } from "./pure/keylog.js";
export { acceptPromise, type AcceptPromiseOptions, type PromiseAcceptance } from "./pure/accept.js";
// Payloads and redaction (specs/redaction.md): pure TypeScript in every
// backend, since they need only SHA-256 and Ed25519.
export {
  checkNoticeApprovals,
  checkPayload,
  checkPayloadBundle,
  formatNoticeBundle,
  formatNoticeText,
  formatPayloadBundle,
  MAX_BASIS_BYTES,
  NOTICE_ACTIONS,
  NOTICE_BUNDLE_HEADER,
  NOTICE_HEADER,
  NOTICE_REASONS,
  NoticeChain,
  noticeSigners,
  openPayload,
  parseNotice,
  parseNoticeBundle,
  parsePayloadBundle,
  PAYLOAD_BUNDLE_ENTRIES,
  PAYLOAD_BUNDLE_HEADER,
  PAYLOAD_BUNDLE_MEDIA_TYPE,
  PAYLOAD_LABEL,
  PAYLOAD_MEDIA_TYPE,
  payloadCommitment,
  SALT_BYTES,
  verifyNotice,
  verifyNoticeBundle,
  verifyWithheld,
  type AppliedNotice,
  type Notice,
  type NoticeAction,
  type NoticeBundle,
  type NoticeField,
  type NoticeOutcome,
  type NoticeReason,
  type NoticeTarget,
  type PayloadBlock,
  type PayloadBundle,
  type PayloadCheck,
  type PayloadState,
  type VerifiedNotice,
  type VerifiedNoticeBundle,
  type VerifyNoticeBundleOptions,
  type WithheldBlock,
} from "./pure/redaction.js";
export {
  acceptPromiseOnline,
  chainFromReference,
  checkChain,
  upgradeAtCast,
  upgradeChain,
  upgradeChainReport,
  UpgradeError,
  type AcceptPromiseOnlineOptions,
  type AtCastOptions,
  type AtCastResult,
  type CheckChainOptions,
  type CheckChainResult,
  type Contradiction,
  type UpgradeErrorCode,
  type UpgradeOptions,
  type UpgradeReport,
} from "./upgrade.js";
export { chainFileName, electionOf, ReceiptStore, STORE_DB_NAME, type PutOptions, type ReceiptStoreOptions, type StoredReceipt } from "./store.js";

// Building blocks for apps: successor discovery (policy.md, section 4), keys
// logs (profile.md, section 5.2), the logs' signed statements (entry.md,
// sections 5.7 and 5.8) and tiles.
export * as history from "./pure/history.js";
export * as keylogs from "./pure/keylog.js";
export * as redaction from "./pure/redaction.js";
export * as operators from "./pure/operators.js";
export * as profiles from "./pure/profiles.js";
export { CORE_PROFILE_METADATA, authenticateProfileMinimums, enforceBuiltinProfileMinimums, validateProfileMinimums, pinPolicy, type PinPolicyOptions, type ProfileMinimums, type ProfileMeaningPackage, type AuthenticatedProfileMinimums } from "./pure/profiles.js";
export * as shared from "./pure/shared.js";
export { parseOperatorList, verifyOperatorList, updateOperatorList, checkOperatorSelection, type OperatorList, type OperatorEntry, type OperatorListPin, type OperatorListTrust } from "./pure/operators.js";
export { parseSharedEnrolment, verifySharedEnrolment, parseSharedAuthorization, verifySharedAuthorization, parseSharedSubmission, checkSharedBindings, checkSharedNamespace, type SharedEnrolment, type SharedAuthorization, type SharedSubmission } from "./pure/shared.js";
export * as releases from "./pure/release.js";
export * as statements from "./pure/statements.js";
export * as tiles from "./pure/tiles.js";

/** The signed objects an evidence file is built from (specs/evidence.md). */
export type EvidenceObjects = Record<string, string | Uint8Array | readonly (string | Uint8Array)[]>;

/** Options of verifyReceipt: those of verifyChain without the expectations. */
export type VerifyReceiptOptions = Omit<VerifyChainOptions, "expect">;

/** What a verification backend provides. Backends without the evidence
 * functions leave them out; the SDK then throws a clear error. */
export interface Backend {
  readonly name: string;
  parsePolicy(text: string | Uint8Array, opts?: ParsePolicyOptions): Policy;
  policyWords(policy: Policy): string[];
  verifyReceipt(receipt: string | Uint8Array, policy: Policy, log: string, expect: Expect, opts?: VerifyReceiptOptions): ReceiptResult;
  verifyChain(chain: string | Uint8Array, policy: Policy, opts: VerifyChainOptions): ChainResult;
  receiptWords(leafHash: Uint8Array, policy: Policy): string[];
  buildElectionEntry(f: ElectionFields): Uint8Array;
  verifyEvidence?(file: string | Uint8Array, pinned: readonly Policy[]): EvidenceResult;
  buildEvidence?(kind: string, objects: EvidenceObjects, policy: Policy): string;
}

/** The independent pure TypeScript backend. */
export const pureBackend: Backend = {
  name: "pure",
  parsePolicy: (text, opts) => pureParsePolicy(text, opts),
  policyWords: (policy) => purePolicyWords(policy),
  verifyReceipt: (receipt, policy, log, expect, opts) => pureVerifyReceipt(receipt, policy, log, expect, opts),
  verifyChain: (chain, policy, opts) => pureVerifyChain(chain, policy, opts),
  receiptWords: (leafHash, policy) => receiptWordsFor(leafHash, policy.words),
  buildElectionEntry: (f) => pureBuildElectionEntry(f),
  verifyEvidence: (file, pinned) => pureVerifyEvidence(file, pinned),
  buildEvidence: (kind, objects, policy) => pureBuildEvidence(kind, objects, policy),
};

let backend: Backend = pureBackend;

export interface InitOptions {
  /** The backend to use. Default: the pure TypeScript verifier, until the
   * WASM core is published. */
  backend?: Backend;
}

/** Loads the verification core. Safe to call more than once. */
export async function init(opts: InitOptions = {}): Promise<void> {
  backend = opts.backend ?? pureBackend;
}

/** The name of the backend in use ("pure" for now). */
export function backendName(): string {
  return backend.name;
}

/** Parses a policy and checks signatures and structure. Use pinPolicy for new-pin admission. Throws VerifyError. */
export function parsePolicy(text: string | Uint8Array, opts?: ParsePolicyOptions): Policy {
  return backend.parsePolicy(text, opts);
}

/** The policy words, in the policy's language. */
export function policyWords(policy: Policy): string[] {
  return backend.policyWords(policy);
}

/** Verifies one receipt (specs/receipt.md, section 1.1). */
export function verifyReceipt(receipt: string | Uint8Array, policy: Policy, log: string, expect: Expect, opts?: VerifyReceiptOptions): ReceiptResult {
  return backend.verifyReceipt(receipt, policy, log, expect, opts);
}

/** Verifies a receipt chain (specs/receipt.md, section 3.1). */
export function verifyChain(chain: string | Uint8Array, policy: Policy, opts: VerifyChainOptions): ChainResult {
  return backend.verifyChain(chain, policy, opts);
}

/** The four receipt words of a leaf hash (specs/receipt.md, section 5). */
export function receiptWords(leafHash: Uint8Array, policy: Policy): string[] {
  return backend.receiptWords(leafHash, policy);
}

/** Builds a `vitrine/election/ballots/v1` entry (specs/entry.md, section 4.1). */
export function buildElectionEntry(f: ElectionFields): Uint8Array {
  return backend.buildElectionEntry(f);
}

const NEEDS_WASM = "needs the WASM backend (vitrine-tlog), which this build of @vitrine/verify doesn't include yet";

/** Verifies an evidence file under the pinned policies (specs/evidence.md). */
export function verifyEvidence(file: string | Uint8Array, pinned: Policy | readonly Policy[]): EvidenceResult {
  if (!backend.verifyEvidence) throw new Error(`verifyEvidence ${NEEDS_WASM}`);
  return backend.verifyEvidence(file, Array.isArray(pinned) ? pinned : [pinned as Policy]);
}

/** Builds an evidence file (specs/evidence.md). */
export function buildEvidence(kind: string, objects: EvidenceObjects, policy: Policy): string {
  if (!backend.buildEvidence) throw new Error(`buildEvidence ${NEEDS_WASM}`);
  return backend.buildEvidence(kind, objects, policy);
}
