// SPDX-License-Identifier: Apache-2.0
//
// Looking a Tracking ID up in a log server's or monitor's bucket
// (specs/entry.md, section 4.1; docs/api.md, sections 2.1 and 5). The request
// names the 3-character bucket and nothing more of the ID, and the filtering
// happens here, so the server never learns which ballot was asked for. The
// request rules of the other online calls apply: no credentials, no
// referrer, no redirects, a bounded answer.

import { findInBucket, MAX_BUCKET_ANSWER, parseBucketAnswer, type BucketAnswer, type BucketMatches } from "./pure/bucket.js";
import { parseBucket, parseTrackingPrefix, type Bucket } from "./pure/tracking.js";

export interface BucketLookupOptions {
  /** The fetch to use; default the global one. */
  fetch?: typeof fetch;
  signal?: AbortSignal;
}

/** A server that wouldn't list a bucket. */
export class BucketLookupError extends Error {
  override name = "BucketLookupError";
  constructor(
    message: string,
    /** The HTTP status, or 0 when there was no answer. */
    readonly status: number,
    /** For a 503, the seconds the server asked to wait. */
    readonly retryAfter?: number,
  ) {
    super(message);
  }
}

/** The URL of a bucket: `<server>/lookup/<log>/tracking-bucket/<bucket>`,
 * where `server` is the origin of a log server's public listener or a monitor
 * and `log` the log's name. */
export function bucketUrl(server: string, log: string, bucket: Bucket | string): string {
  const b = typeof bucket === "string" ? parseBucket(bucket) : bucket;
  const base = server.replace(/\/+$/, "");
  const name = log
    .split("/")
    .map((s) => encodeURIComponent(s))
    .join("/");
  return `${base}/lookup/${name}/tracking-bucket/${b.chars}`;
}

async function readText(res: Response): Promise<string | undefined> {
  if (!res.body) {
    const b = new Uint8Array(await res.arrayBuffer());
    return b.length > MAX_BUCKET_ANSWER ? undefined : new TextDecoder().decode(b);
  }
  const reader = res.body.getReader();
  const parts: Uint8Array[] = [];
  let n = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    n += value.length;
    if (n > MAX_BUCKET_ANSWER) {
      await reader.cancel().catch(() => undefined);
      return undefined;
    }
    parts.push(value);
  }
  const all = new Uint8Array(n);
  let o = 0;
  for (const p of parts) {
    all.set(p, o);
    o += p.length;
  }
  return new TextDecoder().decode(all);
}

/** Fetches a bucket's entries. Throws a BucketLookupError for no answer, a
 * status other than 200 or an answer over the limit, and a TypeError for one
 * that isn't a bucket answer. */
export async function fetchBucket(server: string, log: string, bucket: Bucket | string, opts: BucketLookupOptions = {}): Promise<BucketAnswer> {
  const b = typeof bucket === "string" ? parseBucket(bucket) : bucket;
  const f = opts.fetch ?? globalThis.fetch.bind(globalThis);
  let res: Response;
  try {
    res = await f(bucketUrl(server, log, b), {
      method: "GET",
      credentials: "omit",
      referrerPolicy: "no-referrer",
      redirect: "error",
      ...(opts.signal ? { signal: opts.signal } : {}),
    });
  } catch (e) {
    if (opts.signal?.aborted) throw e;
    throw new BucketLookupError("no answer", 0);
  }
  if (res.status !== 200) {
    await res.body?.cancel().catch(() => undefined);
    const ra = res.headers.get("Retry-After");
    const wait = ra !== null && /^[0-9]{1,6}$/.test(ra.trim()) ? Number(ra.trim()) : undefined;
    throw new BucketLookupError(`status ${res.status}`, res.status, wait);
  }
  const text = await readText(res);
  if (text === undefined) throw new BucketLookupError("answer too large", 413);
  return parseBucketAnswer(text, b);
}

/** Looks a typed short or full Tracking ID up: fetches its bucket from the
 * server and filters it here. Returns at most 5 ballots that share the short
 * ID's two groups with it, with the number of groups each shares, and how many
 * more there are. Throws a TypeError for a Tracking ID that isn't one (fewer
 * than 8 characters, or characters outside the alphabet) before asking. */
export async function lookupTrackingId(server: string, log: string, typed: string, opts: BucketLookupOptions = {}): Promise<BucketMatches> {
  const prefix = parseTrackingPrefix(typed);
  const answer = await fetchBucket(server, log, prefix.chars.slice(0, 3), opts);
  return findInBucket(answer, typed);
}
