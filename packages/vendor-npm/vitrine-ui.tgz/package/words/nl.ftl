# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Dutch (nl).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Opgenomen
fact-unchanged = Ongewijzigd
fact-same-for-everyone = Voor iedereen hetzelfde

fact-state-done = In orde
fact-state-promised = Toegezegd
fact-state-pending = In afwachting
fact-state-late = Vertraagd
fact-state-invalid = Kon niet worden gecontroleerd
fact-state-failed = Niet geslaagd
fact-state-checking = Wordt gecontroleerd

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Uw vermelding staat in het register.
fact-included-promised = Het register heeft een ondertekende toezegging gedaan om uw vermelding op te nemen.
fact-included-pending = Sommige bewijzen dat uw vermelding in het register staat, zijn nog onderweg.
fact-included-late = Het register had uw vermelding inmiddels moeten opnemen.
fact-included-invalid = Het bewijs dat uw vermelding in het register staat, kon niet worden gecontroleerd: de gegevens lijken beschadigd.
fact-included-failed = De eigen handtekeningen van het register spreken elkaar tegen over uw vermelding.
fact-unchanged-done = Onafhankelijke getuigen hebben het register ondertekend, zodat er niets ongemerkt in kan veranderen.
fact-unchanged-pending = Wachten tot de onafhankelijke getuigen het register ondertekenen.
fact-unchanged-late = De getuigen hadden het register inmiddels moeten ondertekenen.
fact-unchanged-invalid = De bewijzen over de geschiedenis van het register konden niet worden gecontroleerd: de gegevens lijken beschadigd.
fact-unchanged-failed = Ondertekende bewijzen over de geschiedenis van het register spreken elkaar tegen.
fact-same-for-everyone-done = Iedereen die controleert, krijgt ditzelfde register te zien.
fact-same-for-everyone-pending = Wachten tot het register is verankerd waar iedereen het kan controleren.
fact-same-for-everyone-late = Het register had inmiddels verankerd moeten zijn waar iedereen het kan controleren.
fact-same-for-everyone-invalid = De ankers konden niet worden gecontroleerd: de gegevens lijken beschadigd.
fact-same-for-everyone-failed = Ondertekende bewijzen tonen aan dat niet iedereen hetzelfde register te zien krijgt.
# Instead of the pending text: `fact-pending-successors` (any fact) when every
# tier the fact rests on waits only for the check for a newer trust policy
# (specs/policy.md, section 4, rule 7), and
# `fact-same-for-everyone-pending-attestation` when a private event's anchor
# hubs wait for an auditor to confirm the sealed anchors (specs/receipt.md,
# section 3.3).
fact-pending-successors = De bewijzen kloppen. Dit wordt als in orde getoond zodra is gecontroleerd of het vertrouwensbeleid door een nieuwer beleid is vervangen.
fact-same-for-everyone-pending-attestation = Verankerd. Een auditor moet de verzegelde ankers nog bevestigen, en dat kan even duren.

## Tiers

tier-record = Register
tier-witnesses = Getuigen
tier-hubs = Ankerhubs
tier-browser = Browserlaag
tier-policy = Beleid
tier-entry = Vermelding

tier-status-verified = Geverifieerd
tier-status-pending = In afwachting
tier-status-late = Vertraagd
tier-status-invalid = Kon niet worden gecontroleerd
tier-status-failed = Niet geslaagd
tier-status-unused = Niet gebruikt
tier-status-checking = Wordt gecontroleerd
tier-status-promised = Toegezegd

tier-record-verified = Uw vermelding staat in het ondertekende register.
tier-record-promised = Het register heeft een ondertekende toezegging gedaan om uw vermelding op te nemen.
tier-record-pending = Sommige bewijzen van het register zijn nog onderweg.
tier-record-late = Het register had uw vermelding inmiddels moeten opnemen.
tier-record-invalid = De bewijzen van het register lijken beschadigd en konden daarom niet worden gecontroleerd.
tier-record-failed = Het register heeft bewijzen ondertekend die elkaar tegenspreken.
tier-record-checking = De bewijzen van het register worden gecontroleerd.
tier-witnesses-verified = Voldoende onafhankelijke getuigen hebben het register ondertekend.
tier-witnesses-pending = Wachten tot de getuigen ondertekenen. Dit duurt enkele seconden.
tier-witnesses-late = De getuigen hadden inmiddels moeten ondertekenen.
tier-witnesses-invalid = De handtekeningen van de getuigen lijken beschadigd en konden daarom niet worden gecontroleerd.
tier-witnesses-failed = Getuigen hebben een register ondertekend dat het uwe tegenspreekt.
tier-witnesses-checking = De handtekeningen van de getuigen worden gecontroleerd.
tier-hubs-verified = Elke ankerhub bevat het register.
tier-hubs-pending = Onderweg naar de ankerhubs. Dit duurt enkele seconden.
tier-hubs-late = De ankerhubs hadden het register inmiddels moeten bevatten.
tier-hubs-invalid = Het antwoord van een ankerhub lijkt beschadigd en kon daarom niet worden gecontroleerd.
tier-hubs-failed = Een ankerhub bevat een ondertekend register dat het uwe tegenspreekt.
tier-hubs-unused = Dit beleid gebruikt geen ankerhubs.
tier-hubs-checking = De ankerhubs worden gecontroleerd.
tier-browser-verified = Verankerd waar browsers controleren.
tier-browser-pending = Verwacht binnen enkele minuten. U hoeft niet te wachten.
tier-browser-late = Het had inmiddels verankerd moeten zijn waar browsers controleren.
tier-browser-invalid = Het antwoord van de browserlaag lijkt beschadigd en kon daarom niet worden gecontroleerd.
tier-browser-failed = Een ondertekend anker waar browsers controleren, spreekt het register tegen.
tier-browser-unused = Dit beleid gebruikt geen onafhankelijke browserlaag.
tier-browser-checking = De browserlaag wordt gecontroleerd.
# Instead of the pending text: `tier-pending-successors` (any tier) when every
# check of the tier passed but the check for a newer trust policy hasn't run
# yet; in a private event, `tier-hubs-pending-attestation` when the anchor hubs
# wait for an auditor, and `tier-browser-pending-hubs` when the browser layer
# waits for the anchor hubs.
tier-pending-successors = De bewijzen kloppen. Dit wordt als geverifieerd getoond zodra is gecontroleerd of het vertrouwensbeleid door een nieuwer beleid is vervangen.
tier-hubs-pending-attestation = Verankerd. Een auditor moet de verzegelde ankers nog bevestigen. Dat kan even duren, en het wordt nooit als vertraagd aangemerkt.
tier-browser-pending-hubs = Wacht op de ankerhubs: bij een privégebeurtenis telt de browserlaag pas mee zodra die zijn geverifieerd.
tier-test = Alleen een test: in handen van de beheerder, dus telt het niet mee.
tier-deadline = Verwacht uiterlijk om { TIME($deadline) }
hub-test = test

## The one-line status

status-verified = Geverifieerd
status-checking = Wordt gecontroleerd…
status-pending = In afwachting
status-late = Vertraagd
status-invalid = Kon niet worden gecontroleerd
status-failed = Niet geslaagd
status-summary-verified = Opgenomen, ongewijzigd en voor iedereen hetzelfde.
status-summary-checking = De bewijzen in het ontvangstbewijs worden in deze browser gecontroleerd.
status-summary-pending = Sommige bewijzen zijn nog onderweg. U hoeft niet te wachten.
status-summary-pending-successors = De bewijzen kloppen. Het ontvangstbewijs wordt als geverifieerd getoond zodra is gecontroleerd of het vertrouwensbeleid door een nieuwer beleid is vervangen.
status-summary-pending-attestation = Verankerd. Een auditor moet de verzegelde ankers nog bevestigen. U hoeft niet te wachten.
status-summary-late = Sommige bewijzen hadden inmiddels binnen moeten zijn.
status-summary-invalid = Sommige gegevens konden niet worden gecontroleerd: het bestand of het antwoord van de server lijkt beschadigd. Dit toont niet aan dat iemand heeft gefraudeerd.
status-summary-failed = Ondertekende bewijzen spreken elkaar tegen. Bewaar het bewijsmateriaal.

## <vitrine-receipt>

receipt-label = Ontvangstbewijs
receipt-words-label = Woorden van het ontvangstbewijs
receipt-entry = Vermelding { $index } in { $log }
receipt-entry-promised = Toegezegde vermelding in { $log }
receipt-provenance-page = Gecontroleerd door deze website
receipt-provenance-page-hint = Deze website heeft het eigen register gecontroleerd. Controleer het onafhankelijk om zeker te zijn.
receipt-provenance-independent = Onafhankelijk van de website gecontroleerd
receipt-facts-heading = Wat de bewijzen laten zien
receipt-chain-heading = Hoe ver het is gekomen
receipt-compare-heading = Vergelijk met de officiële bekendmaking
receipt-compare-hint = Deze woorden en getuigen moeten overeenkomen met wat de verantwoordelijke instantie heeft gepubliceerd, bijvoorbeeld in de bekendmaking van de verkiezing.
receipt-policy-words = Beleidswoorden
receipt-policy-in-force = Beleid dat nu van kracht is
receipt-policy-in-force-hint = Het heeft het eerdere beleid vervangen, zoals de regels van dat beleid toestaan. De woorden ervan moeten overeenkomen met een nieuwere bekendmaking van de verantwoordelijke instantie.
receipt-policy-id = Beleids-ID
receipt-event = Gebeurtenis
receipt-witnesses = Getuigen
receipt-witness-party = in handen van { $party }
receipt-hubs = Ankerhubs
receipt-clock-warning = De klok van dit apparaat wijkt meer dan een minuut af. Termijnen worden beoordeeld volgens de ondertekende tijd, niet volgens deze klok.
receipt-action-check = Onafhankelijk controleren
receipt-action-download = Ontvangstbewijs downloaden
receipt-action-retry = Opnieuw controleren
receipt-invalid = Sommige gegevens konden niet worden gecontroleerd: het bestand of het antwoord van de server lijkt beschadigd. Dit toont niet aan dat iemand heeft gefraudeerd. U kunt opnieuw controleren, of onafhankelijk controleren.
receipt-no-expect = Deze pagina heeft niet aangegeven welke vermelding te verwachten is, dus dit ontvangstbewijs kan niet als het uwe worden getoond.
receipt-error = Dit ontvangstbewijs kon niet worden gecontroleerd.
receipt-empty = Nog geen ontvangstbewijs.
receipt-announce = { $tier }: { $status }.

## <vitrine-receipt>, the receipt card (the voter board). Its five steps are
## sealed on this device, then the four tiers. `$noun` is the profile's name for
## one entry ("ballot" in the election profile), or `receipt-noun`.

receipt-noun = vermelding
receipt-fingerprint-label = Vingerafdruk van { $noun }

receipt-seal-checking = Wordt gecontroleerd
receipt-seal-sealed = Verzegeld
receipt-seal-record-public = Opgenomen in het openbare register
receipt-seal-record-private = Opgenomen in het privéregister
receipt-seal-witnesses = Bevestigd door onafhankelijke getuigen
receipt-seal-hubs = { $hubs }. Browseranker binnenkort verwacht
receipt-seal-browser = Verankerd waar browsers controleren

receipt-step-sealed = Verzegeld op dit apparaat
receipt-step-sealed-done = Verzegeld voordat het uw browser verliet.
receipt-step-sealed-wait = Wordt verzegeld in uw browser…
receipt-step-record-public = Toegevoegd aan het openbare register
receipt-step-record-private = Toegevoegd aan het privéregister
receipt-step-record-done = Vermelding #{ $index }. Uw browser heeft deze gecontroleerd.
receipt-step-record-wait = Wachten tot het register de vermelding opneemt…
receipt-step-record-promised = Het register heeft een ondertekende toezegging gedaan om de vermelding op te nemen.
receipt-step-witnesses = Bevestigd door getuigen
receipt-step-witnesses-done = Ondertekend door { $signed } van de { $total } onafhankelijke getuigen.
receipt-step-witnesses-done-any = Ondertekend door onafhankelijke getuigen.
receipt-step-witnesses-wait = Wachten op de handtekeningen van de getuigen…
receipt-step-hubs-public =
    { $count ->
        [one] Verankerd in { $count } openbare hub
       *[other] Verankerd in { $count } openbare hubs
    }
receipt-step-hubs-private =
    { $count ->
        [one] Verankerd in { $count } hub, verzegeld
       *[other] Verankerd in { $count } hubs, verzegeld
    }
receipt-step-hubs-none = Ankerhubs
receipt-step-hubs-done-public = Ook gedeelde registers bevatten dit register.
receipt-step-hubs-done-private = Er wordt niets onthuld over wat het bevat.
receipt-step-hubs-wait = Binnen enkele seconden…
receipt-step-hubs-partial = Tot nu toe staat het register in { $agree } van de { $total } hubs…
receipt-step-browser = Verankerd waar browsers controleren
receipt-step-browser-done = In hetzelfde register als de code van deze website.
receipt-step-browser-wait = Binnen enkele minuten. U hoeft niet te wachten.
receipt-step-browser-wait-minutes =
    { $minutes ->
        [one] Binnen een minuut. U hoeft niet te wachten.
       *[other] Binnen { $minutes } minuten. U hoeft niet te wachten.
    }
receipt-step-late = Duurt langer dan het zou moeten.
receipt-step-invalid = Kon niet worden gecontroleerd: de gegevens lijken beschadigd.
receipt-step-failed = Spreekt het ondertekende register tegen.
receipt-step-unused = Niet gebruikt door het beleid van deze gebeurtenis.
receipt-step-state-done = In orde
receipt-step-state-active = Bezig
receipt-step-state-scheduled = Gepland
receipt-step-state-waiting = Wachten

receipt-caption-checking-public = Uw browser controleert het openbare register…
receipt-caption-checking-private = Uw browser controleert het privéregister…
receipt-caption-public = Geverifieerd door uw browser, met code die iedereen kan inspecteren.
receipt-caption-private = Privéregister. Geaccrediteerde auditors kunnen het volledig controleren.
receipt-caption-late = Sommige stappen duren langer dan het zou moeten.
receipt-caption-invalid = Sommige gegevens konden niet worden gecontroleerd. Ze lijken beschadigd.
receipt-caption-failed = Uw browser heeft een probleem met het register gevonden.

receipt-check-elsewhere = Op een ander apparaat controleren
receipt-action-save = Ontvangstbewijs opslaan

## <vitrine-receipt variant="summary">, the re-check on a later visit (the
## revisit board).

receipt-summary-label = Controle van het ontvangstbewijs
receipt-summary-title-public = Uw vermelding staat nog steeds in het openbare register
receipt-summary-title-private = Uw vermelding staat nog steeds in het privéregister
receipt-summary-title-checking = Uw vermelding in het register wordt gecontroleerd…
receipt-summary-title-late = Sommige bewijzen voor uw vermelding zijn te laat
receipt-summary-title-invalid = Uw vermelding kon niet worden gecontroleerd
receipt-summary-title-failed = We konden uw vermelding in het register niet bevestigen
receipt-summary-checked-now = Zojuist door uw browser gecontroleerd.
receipt-summary-checked-at = Door uw browser gecontroleerd om { TIME($time) }.
receipt-summary-unchanged = Niets van wat eerder is vastgelegd, is gewijzigd.
receipt-summary-witnesses = Getuigen
receipt-summary-hubs-public = Openbare hubs
receipt-summary-hubs-private = Hubs
receipt-summary-browser = Waar browsers controleren
receipt-summary-agree = { $agree } van { $total } zijn het eens
receipt-summary-agree-any = Zijn het eens
receipt-summary-anchored = Verankerd op { DATE($time) }
receipt-summary-anchored-plain = Verankerd
receipt-summary-waiting = Wachten
receipt-summary-due = Binnenkort verwacht
receipt-summary-unused = Niet gebruikt
receipt-view = Ontvangstbewijs bekijken

## <vitrine-how-we-check>

how-label = Hoe de controle werkt
how-heading = Hoe wij controleren
how-receipt = Uw browser bewaart een ondertekend ontvangstbewijs. Het bevat een vingerafdruk van wat u hebt ingediend, nooit de inhoud.
how-grew = Bij elk bezoek vraagt uw browser het register om een kort bewijs dat het alleen is gegroeid.
how-witnesses = Onafhankelijke getuigen ondertekenen het, en openbare hubs verankeren het waar browsers controleren, zodat iedereen hetzelfde register ziet.

## <vitrine-proof-steps>

steps-heading = Alle controles
steps-summary =
    { $total ->
        [one] { $passed } van { $total } controle geslaagd
       *[other] { $passed } van { $total } controles geslaagd
    }
steps-result-passed = Geslaagd
steps-result-failed = Niet geslaagd
steps-result-not-run = Nog niet uitgevoerd
steps-show-details = Details tonen
steps-hide-details = Details verbergen
steps-objects = Betrokken ondertekende objecten: { $objects }
steps-evidence = Bewijsmateriaal opslaan
steps-empty = Nog geen controles.

## <vitrine-chain>

chain-label = Keten van het ontvangstbewijs

## <vitrine-alert>

alert-label = Aangetoond probleem
alert-kind-split-view-title = Het register is aan verschillende mensen anders getoond
alert-kind-split-view-body = Twee versies van het register, beide ondertekend door de beheerder, kunnen niet allebei waar zijn. Het kan om een fout of een aanval gaan. Uw vermelding kan nog steeds meetellen, maar een onafhankelijke partij zou dit moeten bekijken.
alert-kind-broken-promise-title = Het register is een ondertekende toezegging niet nagekomen
alert-kind-broken-promise-body = Het register had toegezegd een vermelding binnen een vastgestelde termijn op te nemen, en zijn eigen handtekeningen laten zien dat dat niet is gebeurd. Een onafhankelijke partij zou dit moeten bekijken.
alert-kind-bad-entry-title = Het register bevat een vermelding die niet aan de regels voldoet
alert-kind-bad-entry-body = Een ondertekende vermelding in het register voldoet niet aan een regel van zijn profiel. Een onafhankelijke partij zou dit moeten bekijken.
alert-kind-hub-entry-title = Een ankerhub heeft een vermelding geaccepteerd die hij had moeten weigeren
alert-kind-hub-entry-body = De getuigen van een ankerhub hebben het register van die hub ondertekend terwijl het een vermelding bevat die niet aan de regels van de hub voldoet. Minstens één van hen heeft dus ondertekend zonder te controleren.
alert-kind-time-regression-title = Het register heeft een valse tijd ondertekend
alert-kind-time-regression-body = Het register heeft twee versies van zichzelf ondertekend, en de grootste heeft de vroegste tijd. De ondertekende tijd van een register gaat nooit terug, dus een van de twee is vals. Een onafhankelijke partij zou dit moeten bekijken.
alert-kind-policy-equivocation-title = De verantwoordelijke instanties van het vertrouwensbeleid hebben twee verschillende vervangingen ondertekend
alert-kind-policy-equivocation-body = Voldoende verantwoordelijke instanties van het vertrouwensbeleid hebben twee verschillende vervangingen ervan ondertekend, en beide zijn vastgelegd. De eerst vastgelegde telt, maar de tweede kan verschillende mensen een verschillend beleid tonen. Een onafhankelijke partij zou dit moeten bekijken.
alert-kind-bad-checkpoint-title = Een register heeft een onmogelijke versie van zichzelf ondertekend
alert-kind-bad-checkpoint-body = Het heeft een versie ondertekend die geen vermeldingen heeft, maar toch niet leeg is. Geen eerlijk register en geen eerlijke ankerhub kan een dergelijke versie maken. Een onafhankelijke partij zou dit moeten bekijken.
alert-kind-unknown-title = Er is een probleem gevonden
alert-kind-unknown-body = Het bewijsmateriaal toont een soort probleem aan dat deze pagina niet kent: { $kind }.
alert-not-proven-title = Dit bestand toont geen probleem aan
alert-not-proven-body = Het bestand is gecontroleerd en toont geen probleem aan. Het is geen bewijsmateriaal.
alert-unpinned-title = Dit bestand hoort bij een beleid dat niet op dit apparaat is vastgezet
alert-unpinned-body = Het kan op dit apparaat niet als bewijs worden getoond. Vergelijk de beleidswoorden van het bestand met de officiële bekendmaking, en zet dat beleid vast voordat u het bestand opnieuw controleert.
alert-invalid-title = Dit bestand kon niet worden gecontroleerd
alert-invalid-body = Het bestand lijkt beschadigd. Dit toont niet aan dat iemand heeft gefraudeerd.
alert-proven-under = Aangetoond op basis van het beleid met deze woorden:
alert-file-policy-words = De beleidswoorden van het bestand:
alert-parties = Verantwoordelijk, volgens hun eigen handtekeningen: { $parties }
alert-evidence-heading = Bewijsmateriaal bewaard op dit apparaat
alert-evidence-hint = Waarnemers controleren dit bewijsmateriaal op hun eigen computer. Het bewijst wat het register heeft ondertekend en bevat niets over wat u hebt ingediend.
alert-download = Bewijsmateriaal downloaden
alert-send = Bewijsmateriaal naar de waarnemers versturen
alert-monitors-heading = Waarnemers genoemd in het beleid
alert-confirm-heading = Het bewijsmateriaal versturen?
alert-confirm-body =
    { $count ->
        [one] Hiermee verstuurt u het bestand met bewijsmateriaal naar deze waarnemer. Die ziet het bestand en ook dat het van dit apparaat komt.
       *[other] Hiermee verstuurt u het bestand met bewijsmateriaal naar deze { $count } waarnemers. Die zien het bestand en ook dat het van dit apparaat komt.
    }
alert-confirm-send = Ja, versturen
alert-confirm-cancel = Annuleren
alert-sending = Het bewijsmateriaal wordt naar de waarnemers verstuurd.
alert-no-monitors = Het beleid noemt geen monitoringdiensten. Bewaar het bestand en geef het aan een waarnemer.
alert-delivery-waiting = Wachten op bevestiging
alert-delivery-sending = Wordt verstuurd
alert-delivery-confirmed = Bevestigd
alert-delivery-failed = Niet bevestigd

## <vitrine-alert>, the alert board: the evidence kept on this device, as the
## signed items the file holds.

alert-yours-title = We konden uw vermelding in het register niet bevestigen
alert-yours-split-view-body = Het register dat aan uw browser is getoond, komt niet overeen met het register dat de onafhankelijke getuigen hebben ondertekend. Het kan om een fout of een aanval gaan. Uw vermelding kan nog steeds meetellen, maar een onafhankelijke partij zou dit moeten bekijken.
alert-evidence-count =
    { $count ->
        [one] { $count } ondertekend item
       *[other] { $count } ondertekende items
    }
alert-item-receipt = Uw ontvangstbewijs voor vermelding #{ $index }
alert-item-receipt-detail = Ondertekend door het register toen het werd toegevoegd
alert-item-receipt-other = Ontvangstbewijs voor vermelding #{ $index }
alert-item-checkpoint = Ondertekend register, omvang { $size }
alert-item-checkpoint-shown = Register dat aan u is getoond, omvang { $size }
alert-item-checkpoint-shown-detail = Bevat uw vermelding
alert-item-checkpoint-witnessed = Register ondertekend door getuigen, omvang { $size }
alert-item-witnessed-detail =
    { $count ->
        [one] Ondertekend door { $count } getuige
       *[other] Ondertekend door { $count } getuigen
    }
alert-item-hubs-detail =
    { $hubs ->
        [one] Verankerd in { $hubs } openbare hub
       *[other] Verankerd in { $hubs } openbare hubs
    }
alert-item-promise = Ondertekende toezegging om een vermelding op te nemen
alert-item-policy = Ondertekend vertrouwensbeleid
alert-item-policy-ack = Ondertekende erkenning van het vertrouwensbeleid
alert-item-why-split-view = Kan niet zijn gegroeid uit het register van omvang { $size }
alert-item-why-time-regression = De ondertekende tijd ervan ligt vóór die van het kleinere register
alert-item-why-bad-checkpoint = Heeft geen vermeldingen, maar is toch niet leeg
alert-what-next = Wat gebeurt er daarna?
alert-what-next-body = Onafhankelijke waarnemers lezen het bewijsmateriaal op hun eigen computer. Er wordt niets verstuurd, tenzij u ervoor kiest het te versturen. U kunt het bestand ook bewaren en aan iemand geven die u vertrouwt: het bewijst wat het register heeft ondertekend, waar het ook wordt gecontroleerd.

## <vitrine-badge>

badge-check = Onafhankelijk controleren
badge-opens = opent een onafhankelijke verificatietool

## Monitor reports (specs/evidence.md, section 3). `report-kind-<kind>` says
## what a report is about, with `$subject`, the record or hub it names. A
## report is its monitor's own statement, not proof: show `report-established`
## only when monitors of enough different parties report the same thing.

report-kind-cosign-late = { $subject } heeft al te lang geen recente versie die door voldoende van zijn getuigen is ondertekend.
report-kind-anchor-late = { $subject } is niet op tijd verankerd: het register of de ankerhub is te laat, en het rapport kan niet zeggen welke van de twee.
report-kind-unreachable = Een server van { $subject } reageert niet meer.
report-kind-mirror-behind = De kopie van { $subject } bij een spiegelserver loopt achter.
report-kind-payload-missing = Sommige gegevens die in { $subject } zijn vastgelegd, zijn niet beschikbaar, en geen enkele melding zegt dat ze zijn achtergehouden.
report-kind-payload-mismatch = Sommige gegevens die { $subject } aanbiedt, passen niet bij wat het heeft vastgelegd.
report-kind-rule-failing = Een vermelding in { $subject } voldoet niet aan een regel van zijn profiel. De monitoringdienst heeft bewijsmateriaal gepubliceerd dat iedereen kan controleren.
report-kind-promise-pending = { $subject } heeft een ondertekende toezegging gedaan om een vermelding op te nemen, en heeft dat nog niet gedaan.
report-kind-promise-unlisted = { $subject } laat een reeks van zijn ondertekende toezeggingen weg uit zijn lijst.
report-kind-promise-late = { $subject } is een ondertekende toezegging niet op tijd nagekomen: het register of zijn getuigen waren te laat, of hun klokken lopen niet gelijk.
report-kind-promise-misdated = { $subject } heeft een reeks van zijn ondertekende toezeggingen verkeerd gedateerd: de tijd ervan past niet bij het uur waarin de reeks is vermeld, of bij het moment waarop de monitoringdienst haar voor het eerst zag.
report-kind-opening-missing = { $subject } heeft een verzegeld anker niet op tijd voor de auditor geopend.
report-kind-ack-missing = { $subject } biedt zijn ondertekende verklaring dat het het geldende vertrouwensbeleid volgt niet aan.
report-kind-config-mismatch = Een stemhokje kreeg verkiezingsinstellingen te zien die { $subject } niet heeft vastgelegd, of die afwijken van de vastgelegde.
report-kind-code-mismatch = Een website bood een script aan dat in geen enkele in { $subject } vastgelegde release zit.
report-kind-unknown = Rapport van monitoringdienst ‘{ $kind }’ over { $subject }
report-established = Vastgesteld: monitoringdiensten van voldoende verschillende partijen melden het.
report-statement = Gemeld door { $monitor }. Een rapport is een verklaring van de monitoringdienst zelf, geen bewijs over iemand anders.

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = Het ontvangstbewijsbestand heeft de juiste vorm
step-policy-pinned = Het ontvangstbewijs hoort bij het vastgezette vertrouwensbeleid
step-policy-successors = Er is gecontroleerd of een nieuwer vertrouwensbeleid het vastgezette heeft vervangen
step-policy-ack = Het register heeft ondertekend dat het het vertrouwensbeleid volgt
step-log-known = Het register van het ontvangstbewijs staat in het beleid
step-entry-parse = De vermelding heeft de juiste vorm
step-entry-profile = De vermelding heeft het type van het register en de bijbehorende velden
step-entry-expectation = De vermelding is degene die u verwachtte
step-promise-signature = Het register heeft een ondertekende toezegging gedaan om de vermelding op te nemen
step-promise-inclusion = De ondertekende toezegging omvat de vermelding
step-promise-leaf = De toezegging geldt voor de vermelding die u verwachtte
step-promise-kept = Het register is zijn toezegging binnen de termijn nagekomen
step-issued-signature = Het ontvangstbewijs bij indiening is door het register ondertekend
step-issued-inclusion = De vermelding staat in het ontvangstbewijs bij indiening
step-record-signature = Het ontvangstbewijs van het register is door het register ondertekend
step-record-inclusion = De vermelding staat in het register
step-receipts-match = De ontvangstbewijzen horen bij dezelfde vermelding op dezelfde positie
step-record-consistency = Het register is sinds het ontvangstbewijs bij indiening alleen gegroeid
step-record-quorum = Voldoende onafhankelijke getuigen hebben het register ondertekend
step-log-consistent = De versies van het register die hier zijn gezien, spreken elkaar niet tegen
step-hub-link = Het bewijs van hub { $hub } klopt
step-hub-opening = Na opening toont het verzegelde anker in hub { $hub } het register
step-hub-anchored-checkpoint = Het register dat in hub { $hub } is verankerd, is ondertekend door het register en zijn getuigen
step-hub-previous-anchor = Hub { $hub } bevat het vorige verzegelde anker, en na opening toont dat anker het register
step-hub-opening-consistency = Het register is tussen zijn laatste twee verzegelde ankers in hub { $hub } alleen gegroeid
step-hub-attestation = Een auditor heeft het verzegelde anker in hub { $hub } bevestigd
step-hub-anchor-consistency = Het register is tot aan zijn anker in hub { $hub } alleen gegroeid
step-browser-link = Het bewijs van hub { $hub } voor de browserlaag klopt en omvat de vermelding
step-browser-link-consistency = Het register is tussen uw ontvangstbewijs en het bewijs van hub { $hub } voor de browserlaag alleen gegroeid
step-browser-anchor = De browserlaag bevat het register van hub { $hub }
step-browser-consistency = Hub { $hub } is alleen gegroeid tot aan zijn versie die is verankerd waar browsers controleren
step-bootstrap-link = Een bootstraphub verankert hub { $hub }
step-unknown = Controle ‘{ $code }’

## Reasons, why a check failed or is still waiting (`reason-<code>`). Their
## variables are the verifier's `params`. A message uses only those that the
## verifier always passes for its code: the tier, hub or step it belongs to is
## shown next to it anyway.

# Encodings and limits
reason-bad-base64 = Een base64-waarde heeft een onjuiste vorm.
reason-bad-hex = Een hexadecimale waarde heeft een onjuiste vorm.
reason-bad-text = Een stuk tekst is niet geldig of bevat een niet-toegestaan teken.
reason-bad-number = Een getal heeft een onjuiste vorm of valt buiten het toegestane bereik.
reason-trailing-data = Na een deel van het bestand volgen onverwachte gegevens.
reason-truncated = Een deel van het bestand eindigt te vroeg.
reason-too-large = Iets is groter dan de limieten toestaan.

# Signed notes and keys
reason-bad-note = Een ondertekende notitie heeft een onjuiste vorm.
reason-bad-key-name = Een sleutelnaam heeft een onjuiste vorm.
reason-bad-vkey = Een openbare sleutel heeft een onjuiste vorm of is van het verkeerde type.
reason-bad-public-key = Een openbare sleutel is niet geldig.
reason-missing-signature = Een handtekening die er moet zijn, ontbreekt.

# Checkpoints and witness signatures
reason-bad-checkpoint = Een controlepunt heeft een onjuiste vorm.
reason-bad-empty-tree = Een ondertekende versie van het register is onmogelijk: ze heeft geen vermeldingen, maar haar inhoud is niet leeg.
reason-wrong-origin = Een ondertekende notitie noemt een ander register of een andere hub dan verwacht.
reason-log-time-missing = Een ontvangstbewijs mist de ondertekende tijd van het register en kon daarom niet worden gecontroleerd.
reason-cosignature-in-future = Een handtekening van een getuige is in de toekomst gedateerd en is daarom genegeerd.
reason-quorum-not-met = Er hebben nog niet voldoende onafhankelijke getuigen ondertekend.

# Proofs
reason-bad-proof = Een bewijs heeft een onjuiste vorm.
reason-missing-extra = Een ontvangstbewijs bevat de vermelding niet.
reason-index-out-of-range = De positie van de vermelding ligt voorbij het einde van het register.
reason-inclusion-failed = Het bewijs dat de vermelding in het register staat, klopt niet.
reason-consistency-failed = Het bewijs dat het register alleen is gegroeid, klopt niet.
reason-split-view = Twee ondertekende versies van het register hebben dezelfde omvang maar een verschillende inhoud.

# Entries and expectations
reason-bad-entry = De vermelding heeft een onjuiste vorm.
reason-wrong-profile = Het type van de vermelding verschilt van het type van het register op die positie.
reason-bad-entry-layout = De velden van de vermelding passen niet bij het type ervan.
reason-entry-mismatch = De vermelding is niet degene die u verwachtte.
reason-expectation-incomplete = De pagina gaf niet voldoende informatie over de vermelding om die te controleren.
reason-expectation-unknown-field = De pagina noemde een veld dat dit soort vermelding niet heeft.
reason-expectation-unsupported = Deze verificatietool kan de velden van dit soort vermelding niet controleren.
reason-receipts-disagree = De ontvangstbewijzen in het bestand horen bij verschillende vermeldingen of posities.

# Promises
reason-bad-promise = De toezegging heeft een onjuiste vorm.
reason-promise-policy-unknown = De toezegging noemt een vertrouwensbeleid dat niet het vastgezette is en ook geen beleid dat het heeft vervangen.
reason-promise-mmd-too-large = De toezegging laat meer vertraging toe dan het beleid toestaat.
reason-promise-leaf-mismatch = De toezegging geldt voor een andere vermelding.
reason-promise-time = De tijd die het register op zijn toezegging zette, ligt meer dan een minuut af van het moment waarop ze aankwam, dus ze telt niet als toezegging.
reason-promise-pending = Het register heeft toegezegd de vermelding op te nemen. Het ontvangstbewijs hoeft er nog niet te zijn.
reason-promise-deadline-passed = De termijn van de toezegging is verstreken en er is nog geen ontvangstbewijs.
reason-promise-kept-unproven = Niets in het bestand laat zien dat de toezegging op tijd is nagekomen.
reason-broken-promise = Het register heeft toegezegd de vermelding vóór de termijn ({ TIME($deadline) }) op te nemen, maar zijn eigen ondertekende tijd ({ TIME($logTime) }) laat zien dat het dat toen nog steeds niet had gedaan.
reason-bad-promise-list = De lijst met de toezeggingen die het register in een uur heeft gedaan, heeft een onjuiste vorm of past niet bij die toezeggingen, en kon daarom niet worden gecontroleerd.

# Receipt chains
reason-malformed-chain = Het ontvangstbewijsbestand heeft een onjuiste vorm.
reason-duplicate-block = Het ontvangstbewijsbestand bevat hetzelfde deel twee keer.
reason-no-receipt = Het bestand bevat geen toezegging en geen ontvangstbewijs.
reason-policy-mismatch = Het ontvangstbewijs noemt een ander vertrouwensbeleid dan het vastgezette.
reason-policy-draft = Het vertrouwensbeleid is nog een concept, en een concept is nooit geldig.
reason-bad-policy-ack = De ondertekende verklaring van het register dat het dit vertrouwensbeleid volgt, heeft een onjuiste vorm of past er niet bij.
reason-unknown-log = Het ontvangstbewijs noemt een register dat niet in het beleid staat.
reason-unknown-hub = Een deel noemt een ankerhub die niet in het beleid staat; dat deel is daarom genegeerd.
reason-consistency-missing = Een bewijs dat het register alleen is gegroeid, ontbreekt.
reason-consistency-mismatch = Een bewijs dat het register alleen is gegroeid, past niet bij de versies die het verbindt.
reason-waiting-for-cosignatures = Wachten tot de getuigen het register ondertekenen.
reason-waiting-for-record = Wachten op het door getuigen ondertekende register.
reason-no-signed-time = Er is nog geen ondertekende tijd, dus termijnen kunnen nog niet worden beoordeeld.
reason-deadline-passed = De termijn is verstreken, volgens de ondertekende tijd.
reason-record-invalid = Dit kon niet worden gecontroleerd, omdat de bewijzen van het register niet konden worden gecontroleerd.
reason-bad-reference = Een link naar een ontvangstbewijs heeft een onjuiste vorm.
reason-reference-unpinned = Geen enkel vertrouwensbeleid dat op dit apparaat is vastgezet, past bij deze link naar een ontvangstbewijs.
reason-reference-ambiguous = Deze link naar een ontvangstbewijs past bij meer dan één vertrouwensbeleid dat op dit apparaat is vastgezet, en is daarom niet gebruikt.

# The booth's configuration check
reason-bad-config = De instellingen van de verkiezing, of de melding dat de stemming is geopend, hebben een onjuiste vorm, zijn niet ondertekend of zijn niet door voldoende getuigen ondertekend, dus het stemhokje versleutelt er geen stembiljet mee.
reason-config-mismatch = De vastgelegde instellingen van de verkiezing passen niet bij de gebeurtenis, de verkiezing, de verkiezingssleutel, de stembiljetontwerpen, het vertrouwensbeleid of de software van het stemhokje, of zijn niet de instellingen die golden toen de stemming openging, dus het stemhokje versleutelt geen stembiljet.

# Keys logs
reason-bad-key-statement = Een verklaring in een sleutelregister heeft een onjuiste vorm, noemt een ander register, past niet bij haar vermelding of mist de handtekeningen die ze nodig heeft, dus ze telt niet mee.
reason-signed-by-failed = Een verklaring is niet ondertekend met haar sleutel, de sleutel was ingetrokken of niet geldig toen de vermelding werd vastgelegd, of te weinig andere geldige sleutels hebben haar ook ondertekend.
    .not-ed25519 = De verklaring, of de sleutel die haar had moeten ondertekenen, heeft een onjuiste vorm of is van het verkeerde type.
    .not-signed = De verklaring is niet ondertekend met haar sleutel.
    .revoked = De sleutel die de verklaring ondertekende, was al ingetrokken toen de vermelding werd vastgelegd.
    .not-valid = De sleutel die de verklaring ondertekende, was niet geldig toen de vermelding werd vastgelegd.
    .cosigners = Te weinig andere geldige sleutels hebben de verklaring ook ondertekend: { $have } van de { $need } die nodig zijn.

# Upgrades
reason-log-quiet = Het register zit in een stille periode en toont tot het einde daarvan niets nieuws, dus sommige bewijzen wachten tot dan.
reason-log-private = Het register is privé: alleen auditors kunnen het lezen, dus de bewijzen ervan komen via de website van de gebeurtenis.
reason-monitor-evidence = Monitoringdienst { $monitor } heeft bewijsmateriaal gepubliceerd dat deze versie van het register in tegenspraak is met de versie die de dienst zelf heeft. Dat bewijsmateriaal is hier nog niet gecontroleerd.

# Successor policies
reason-successors-unchecked = Er is nog niet gecontroleerd of een nieuwer vertrouwensbeleid dit beleid heeft vervangen, dus niets wordt als geverifieerd getoond.
reason-bad-policy-proofs = De bewijzen over een nieuwer vertrouwensbeleid hebben een onjuiste vorm of kloppen niet.
reason-successor-rejected = Er is een nieuwer vertrouwensbeleid gepubliceerd, maar het houdt zich niet aan de regels voor het vervangen van een beleid, dus het eerdere beleid blijft van kracht.
reason-policy-equivocation = De verantwoordelijke instanties van het vertrouwensbeleid hebben twee verschillende vervangingen ervan ondertekend, wat bewijst dat ze zichzelf hebben tegengesproken. De eerst gepubliceerde telt.

# Anchor hubs
reason-bad-subject = De naam of sleutel waaronder een ankerhub de ankers van een register bewaart, heeft een onjuiste vorm, dus die telt niet mee.
reason-waiting-for-anchor = Wachten tot de ankerhub het register verankert.
reason-hub-quorum-not-met = Er hebben nog niet voldoende getuigen van de ankerhub ondertekend.
reason-bad-hub-link = Het bewijs van de ankerhub heeft een onjuiste vorm of klopt niet.
reason-hub-link-mismatch = Het bewijs van de ankerhub gaat over iets anders.
reason-hub-index-wrong = De getuigen van hub { $hub } hebben een index ondertekend die voor dit register naar de verkeerde vermelding wijst, dus ze hebben ondertekend zonder te controleren.
reason-map-proof-failed = Het bewijs uit de tabel van de ankerhub klopt niet.
reason-subject-rotated = De sleutel van het register is bij deze ankerhub gewijzigd. Het nieuwere vertrouwensbeleid is nodig.
reason-rotation-unauthorized = Bij hub { $hub } is de sleutel van het register gewijzigd door een vermelding die geen enkel bekend vertrouwensbeleid toestaat.
reason-anchor-behind-record = De ankerhub bevat een oudere versie van het register dan uw ontvangstbewijs.
reason-anchor-quorum-not-met = Het verankerde register heeft niet voldoende handtekeningen van getuigen.
reason-hub-link-stale = Het bewijs van hub { $hub } dat het register heeft, is veel ouder dan de nieuwste versie van de hub: het register zou inmiddels een nieuwer bewijs moeten hebben.
reason-bad-blinded-anchor = Een verzegeld anker klopt niet.
reason-opening-missing = Het bestand bevat nog niet wat het verzegelde anker opent.
reason-bad-opening = Wat het verzegelde anker zou moeten openen, past er niet bij.
reason-previous-anchor-missing = Het vorige verzegelde anker in hub { $hub }, of wat het opent, staat nog niet in het bestand.
reason-bad-previous-anchor = Het vorige verzegelde anker is niet het anker van het register direct vóór dit anker, en kon daarom niet worden gecontroleerd.
reason-attestation-missing = Nog geen enkele auditor heeft het verzegelde anker in hub { $hub } bevestigd. Het blijft in afwachting tot een auditor dat doet, en wordt nooit als vertraagd aangemerkt.
reason-attestation-not-covering = De bevestiging van de auditor voor hub { $hub } omvat de verzegelde ankers { $from } tot en met { $to }, nog niet nummer { $seq }.
reason-bad-attestation = De bevestiging van een auditor kon niet worden gecontroleerd: ze heeft een onjuiste vorm, is niet ondertekend door een auditor van het vertrouwensbeleid of past niet bij het verzegelde anker.
reason-hub-entry-refused = Een ankerhub heeft een vermelding vastgelegd die de regels van de hub overtreedt, dus die vermelding telt niet mee.

# Browser layer
reason-browser-test-only = De browserlaag is hier alleen een test: die is in handen van de beheerder.
reason-waiting-for-browser-anchor = Wachten op de browserlaag. Die wordt binnen enkele minuten verwacht.
reason-pair-not-covering = Het nieuwste bewijs van het register voor de browserlaag, van hub { $hub }, is van vóór de vermelding. Het volgende bewijs omvat de vermelding wel.
reason-browser-below-link = De browserlaag toont een oudere versie van hub { $hub } dan het bewijs waarmee ze is gekoppeld, dus die twee passen niet bij elkaar.
reason-waiting-for-hub-tier = Wacht op hub { $hub }: bij een privégebeurtenis telt de browserlaag pas mee zodra de hub is geverifieerd.
reason-bad-browser-pair = De bewijzen van het register voor de browserlaag hebben een onjuiste vorm.
reason-bad-browser-anchor = Een browseranker heeft een onjuiste vorm of komt niet overeen.
reason-bad-waict-proof = Het bewijs van de browserlaag klopt niet.
reason-waict-quorum-not-met = Er hebben niet voldoende getuigen van de browserlaag ondertekend.
reason-unknown-waict-service = Het browseranker komt van een dienst die niet in het beleid staat.
reason-waict-service-not-independent = De browserlaag is in handen van de beheerder en telt daarom niet mee.
reason-bad-bootstrap-link = Het bewijs van een bootstraphub heeft een onjuiste vorm of klopt niet.

# Trust policies
reason-policy-syntax = Een tekstregel van het vertrouwensbeleid heeft een onjuiste vorm.
reason-policy-unknown-keyword = Een tekstregel van het vertrouwensbeleid begint met een onbekend woord.
reason-policy-count = Een tekstregel van het vertrouwensbeleid komt te vaak of helemaal niet voor.
reason-policy-undefined-name = Het vertrouwensbeleid gebruikt een naam voordat die is gedefinieerd.
reason-policy-duplicate-name = Het vertrouwensbeleid definieert een naam twee keer.
reason-policy-invalid = Het vertrouwensbeleid voldoet niet aan een van de regels die ervoor gelden.
reason-policy-unsafe-quorum = Het quorum van getuigen in het vertrouwensbeleid is niet veilig.
reason-policy-unsigned = Het vertrouwensbeleid heeft niet voldoende handtekeningen van de verantwoordelijke instanties.

# Payloads and redaction
reason-payload-mismatch = De gegevens die een server voor een vermelding heeft gestuurd, passen niet bij wat het register ervan bewaart, dus het zijn niet de vastgelegde gegevens. Een spiegelserver van het register heeft misschien de juiste gegevens.
reason-payload-missing = Gegevens die voor een vermelding zijn vastgelegd, zijn niet beschikbaar, en geen enkele geldige melding zegt dat ze zijn achtergehouden. Een spiegelserver van het register heeft ze misschien nog.
reason-bad-payload-bundle = De gegevens die een server voor een reeks vermeldingen heeft gestuurd, hebben een onjuiste vorm of horen niet bij die vermeldingen, en konden daarom niet worden gecontroleerd. Een spiegelserver van het register heeft ze misschien.
reason-bad-notice = Een melding over het achterhouden van gegevens heeft een onjuiste vorm, dus die telt niet mee.
reason-notice-unsigned = Een melding over het achterhouden van gegevens heeft niet voldoende handtekeningen van de instanties die het vertrouwensbeleid daarvoor aanwijst, dus die telt niet mee.
    .no-redaction = Het vertrouwensbeleid staat niet toe dat gegevens worden achtergehouden, dus een melding daarover telt niet mee.
reason-notice-mismatch = Een melding over het achterhouden van gegevens past niet bij de gegevens die ermee worden achtergehouden of bij de vastgelegde kopie ervan, of noemt gegevens die niet kunnen worden achtergehouden, dus die telt niet mee.
    .profile = Een melding over het achterhouden van gegevens noemt een vermelding waarvan de gegevens niet kunnen worden achtergehouden, zoals een stembiljet, dus die telt niet mee.
reason-notice-not-applied = Een melding over het achterhouden van gegevens heeft geen effect: ze verwijst niet naar de laatste melding die op dezelfde vermelding werd toegepast, herhaalt een eerdere melding, of is gedateerd vóór het moment waarop die melding werd vastgelegd.
reason-bad-notice-bundle = Het bewijs dat een melding over het achterhouden van gegevens is vastgelegd, heeft een onjuiste vorm, klopt niet of heeft niet voldoende handtekeningen van getuigen, dus de melding telt niet mee.

# Evidence files
reason-bad-evidence = Het bestand met bewijsmateriaal heeft een onjuiste vorm, of er ontbreekt een deel dat dit soort bestand nodig heeft.
reason-evidence-unknown-kind = Het bestand met bewijsmateriaal is van een soort die deze verificatietool niet kent.
reason-evidence-unpinned = Het bestand met bewijsmateriaal hoort bij een vertrouwensbeleid dat dit apparaat niet heeft vastgezet.
reason-evidence-wrong-subject = Het bestand met bewijsmateriaal gaat over een register of hub waarop dit soort bestand volgens zijn vertrouwensbeleid niet van toepassing is.
reason-evidence-policy-mismatch = Een deel van het bestand met bewijsmateriaal hoort bij een ander vertrouwensbeleid dan dat van het bestand.
reason-not-proven = De handtekeningen van het bewijsmateriaal kloppen, maar ze tonen het beweerde probleem niet aan.
reason-needs-scan = Dit kan alleen worden beslist door de vermeldingen van het register te lezen, en dat heeft deze controle niet gedaan.
reason-rule-unsupported = Het bewijsmateriaal noemt een regel die deze verificatietool niet kan uitvoeren. Een volledige verificatietool kan die wel controleren.
reason-faulty-witness = Deze getuige heeft twee versies ondertekend die elkaar tegenspreken, of een versie van een hub met een ongeldige vermelding, wat bewijst dat de getuige onbetrouwbaar is.
reason-trust-assumption-failed = Genoeg getuigen hebben de tegenstrijdige versies ondertekend om het quorum te halen: meer getuigen zijn onbetrouwbaar dan het vertrouwensbeleid aanneemt.
reason-misbehaviour-proven = Het bewijsmateriaal toont het beweerde probleem aan, volgens het vertrouwensbeleid van het bestand.

reason-unknown = Reden ‘{ $code }’

# Shared infrastructure. Draft translations need native-speaker review.
reason-bad-operator-list = The infrastructure list is damaged or uses an unsupported format.
reason-operator-list-refused = The infrastructure list could not be accepted under the pinned authorities, validity window or update history.
reason-bad-shared-submission = The shared-log request or enrolment is damaged or does not follow the format.
reason-shared-submission-refused = The shared log could not accept this request under its pinned policy, submitter key or namespace.

# New metadata reason: native translation review needed outside English.
reason-profile-meaning-unknown = The profile meaning is not available for validation.

## extension

# The names of the anchor hubs and the browser layer in the extension's compact receipt chain.
tier-hubs-short = Hubs
tier-browser-short = Browser
