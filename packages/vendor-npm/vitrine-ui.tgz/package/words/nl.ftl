# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Dutch (nl).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Opgenomen
fact-unchanged = Ongewijzigd
fact-same-for-everyone = Voor iedereen hetzelfde

fact-state-done = In orde
fact-state-promised = Toegezegd
fact-state-pending = In afwachting
fact-state-late = Vertraagd
fact-state-invalid = Kon niet worden gecontroleerd
fact-state-failed = Niet geslaagd
fact-state-checking = Wordt gecontroleerd

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Uw vermelding staat in het register.
fact-included-promised = Het register heeft een ondertekende toezegging gedaan om uw vermelding op te nemen.
fact-included-pending = Wachten tot het register uw vermelding opneemt.
fact-included-late = Het register had uw vermelding inmiddels moeten opnemen.
fact-included-invalid = Het bewijs dat uw vermelding in het register staat, kon niet worden gecontroleerd: de gegevens lijken beschadigd.
fact-included-failed = De eigen handtekeningen van het register spreken elkaar tegen over uw vermelding.
fact-unchanged-done = Onafhankelijke getuigen hebben het register ondertekend, zodat er niets ongemerkt in kan veranderen.
fact-unchanged-pending = Wachten tot de onafhankelijke getuigen het register ondertekenen.
fact-unchanged-late = De getuigen hadden het register inmiddels moeten ondertekenen.
fact-unchanged-invalid = De bewijzen over de geschiedenis van het register konden niet worden gecontroleerd: de gegevens lijken beschadigd.
fact-unchanged-failed = Ondertekende bewijzen over de geschiedenis van het register spreken elkaar tegen.
fact-same-for-everyone-done = Iedereen die controleert, krijgt ditzelfde register te zien.
fact-same-for-everyone-pending = Wachten tot het register is verankerd waar iedereen het kan controleren.
fact-same-for-everyone-late = Het register had inmiddels verankerd moeten zijn waar iedereen het kan controleren.
fact-same-for-everyone-invalid = De ankers konden niet worden gecontroleerd: de gegevens lijken beschadigd.
fact-same-for-everyone-failed = Ondertekende bewijzen tonen aan dat niet iedereen hetzelfde register te zien krijgt.

## Tiers

tier-record = Register
tier-witnesses = Getuigen
tier-hubs = Ankerhubs
tier-browser = Browserlaag
tier-policy = Beleid
tier-entry = Vermelding

tier-status-verified = Geverifieerd
tier-status-pending = In afwachting
tier-status-late = Vertraagd
tier-status-invalid = Kon niet worden gecontroleerd
tier-status-failed = Niet geslaagd
tier-status-unused = Niet gebruikt
tier-status-checking = Wordt gecontroleerd
tier-status-promised = Toegezegd

tier-record-verified = Uw vermelding staat in het ondertekende register.
tier-record-promised = Het register heeft een ondertekende toezegging gedaan om uw vermelding op te nemen.
tier-record-pending = Het register heeft uw vermelding nog niet opgenomen.
tier-record-late = Het register had uw vermelding inmiddels moeten opnemen.
tier-record-invalid = De bewijzen van het register lijken beschadigd en konden daarom niet worden gecontroleerd.
tier-record-failed = Het register heeft bewijzen ondertekend die elkaar tegenspreken.
tier-record-checking = De bewijzen van het register worden gecontroleerd.
tier-witnesses-verified = Voldoende onafhankelijke getuigen hebben het register ondertekend.
tier-witnesses-pending = Wachten tot de getuigen ondertekenen. Dit duurt enkele seconden.
tier-witnesses-late = De getuigen hadden inmiddels moeten ondertekenen.
tier-witnesses-invalid = De handtekeningen van de getuigen lijken beschadigd en konden daarom niet worden gecontroleerd.
tier-witnesses-failed = Getuigen hebben een register ondertekend dat het uwe tegenspreekt.
tier-witnesses-checking = De handtekeningen van de getuigen worden gecontroleerd.
tier-hubs-verified = Elke ankerhub bevat het register.
tier-hubs-pending = Onderweg naar de ankerhubs. Dit duurt enkele seconden.
tier-hubs-late = De ankerhubs hadden het register inmiddels moeten bevatten.
tier-hubs-invalid = Het antwoord van een ankerhub lijkt beschadigd en kon daarom niet worden gecontroleerd.
tier-hubs-failed = Een ankerhub bevat een ondertekend register dat het uwe tegenspreekt.
tier-hubs-unused = Dit beleid gebruikt geen ankerhubs.
tier-hubs-checking = De ankerhubs worden gecontroleerd.
tier-browser-verified = Verankerd waar browsers controleren.
tier-browser-pending = Verwacht binnen enkele minuten. U hoeft niet te wachten.
tier-browser-late = Het had inmiddels verankerd moeten zijn waar browsers controleren.
tier-browser-invalid = Het antwoord van de browserlaag lijkt beschadigd en kon daarom niet worden gecontroleerd.
tier-browser-failed = Een ondertekend anker waar browsers controleren, spreekt het register tegen.
tier-browser-unused = Dit beleid gebruikt geen onafhankelijke browserlaag.
tier-browser-checking = De browserlaag wordt gecontroleerd.
tier-test = Alleen een test: in handen van de beheerder, dus telt het niet mee.
tier-deadline = Verwacht uiterlijk om { TIME($deadline) }
hub-test = test

## The one-line status

status-verified = Geverifieerd
status-checking = Wordt gecontroleerd…
status-pending = In afwachting
status-late = Vertraagd
status-invalid = Kon niet worden gecontroleerd
status-failed = Niet geslaagd
status-summary-verified = Opgenomen, ongewijzigd en voor iedereen hetzelfde.
status-summary-checking = De bewijzen in het ontvangstbewijs worden in deze browser gecontroleerd.
status-summary-pending = Sommige bewijzen zijn nog onderweg. U hoeft niet te wachten.
status-summary-late = Sommige bewijzen hadden inmiddels binnen moeten zijn.
status-summary-invalid = Sommige gegevens konden niet worden gecontroleerd: het bestand of het antwoord van de server lijkt beschadigd. Dit toont niet aan dat iemand heeft gefraudeerd.
status-summary-failed = Ondertekende bewijzen spreken elkaar tegen. Bewaar het bewijsmateriaal.

## <vitrine-receipt>

receipt-label = Ontvangstbewijs
receipt-words-label = Woorden van het ontvangstbewijs
receipt-entry = Vermelding { $index } in { $log }
receipt-entry-promised = Toegezegde vermelding in { $log }
receipt-provenance-page = Gecontroleerd door deze website
receipt-provenance-page-hint = Deze website heeft het eigen register gecontroleerd. Controleer het onafhankelijk om zeker te zijn.
receipt-provenance-independent = Onafhankelijk van de website gecontroleerd
receipt-facts-heading = Wat de bewijzen laten zien
receipt-chain-heading = Hoe ver het is gekomen
receipt-compare-heading = Vergelijk met de officiële bekendmaking
receipt-compare-hint = Deze woorden en getuigen moeten overeenkomen met wat de verantwoordelijke instantie heeft gepubliceerd, bijvoorbeeld in de bekendmaking van de verkiezing.
receipt-policy-words = Beleidswoorden
receipt-policy-id = Beleids-ID
receipt-event = Gebeurtenis
receipt-witnesses = Getuigen
receipt-witness-party = in handen van { $party }
receipt-hubs = Ankerhubs
receipt-clock-warning = De klok van dit apparaat wijkt meer dan een minuut af. Termijnen worden beoordeeld volgens de ondertekende tijd, niet volgens deze klok.
receipt-action-check = Onafhankelijk controleren
receipt-action-download = Ontvangstbewijs downloaden
receipt-action-retry = Opnieuw controleren
receipt-invalid = Sommige gegevens konden niet worden gecontroleerd: het bestand of het antwoord van de server lijkt beschadigd. Dit toont niet aan dat iemand heeft gefraudeerd. U kunt opnieuw controleren, of onafhankelijk controleren.
receipt-no-expect = Deze pagina heeft niet aangegeven welke vermelding te verwachten is, dus dit ontvangstbewijs kan niet als het uwe worden getoond.
receipt-error = Dit ontvangstbewijs kon niet worden gecontroleerd.
receipt-empty = Nog geen ontvangstbewijs.
receipt-announce = { $tier }: { $status }.

## <vitrine-proof-steps>

steps-heading = Alle controles
steps-summary =
    { $total ->
        [one] { $passed } van { $total } controle geslaagd
       *[other] { $passed } van { $total } controles geslaagd
    }
steps-result-passed = Geslaagd
steps-result-failed = Niet geslaagd
steps-result-not-run = Nog niet uitgevoerd
steps-show-details = Details tonen
steps-hide-details = Details verbergen
steps-objects = Betrokken ondertekende objecten: { $objects }
steps-evidence = Bewijsmateriaal opslaan
steps-empty = Nog geen controles.

## <vitrine-chain>

chain-label = Keten van het ontvangstbewijs

## <vitrine-alert>

alert-label = Aangetoond probleem
alert-kind-split-view-title = Het register is aan verschillende mensen anders getoond
alert-kind-split-view-body = Twee versies van het register, beide ondertekend door de beheerder, kunnen niet allebei waar zijn. Het kan om een fout of een aanval gaan. Uw vermelding kan nog steeds meetellen, maar een onafhankelijke partij zou dit moeten bekijken.
alert-kind-broken-promise-title = Het register is een ondertekende toezegging niet nagekomen
alert-kind-broken-promise-body = Het register had toegezegd een vermelding binnen een vastgestelde termijn op te nemen, en zijn eigen handtekeningen laten zien dat dat niet is gebeurd. Een onafhankelijke partij zou dit moeten bekijken.
alert-kind-bad-entry-title = Het register bevat een vermelding die niet aan de regels voldoet
alert-kind-bad-entry-body = Een ondertekende vermelding in het register voldoet niet aan een regel van zijn profiel. Een onafhankelijke partij zou dit moeten bekijken.
alert-kind-stale-anchor-title = Het register is niet op tijd verankerd
alert-kind-stale-anchor-body = Het register of een ankerhub had meer tijd nodig om het register te verankeren dan het beleid toestaat. Het gaat om een toegezegd serviceniveau dat niet is gehaald, niet om het register zelf.
alert-kind-hub-entry-title = Een ankerhub heeft een vermelding geaccepteerd die hij had moeten weigeren
alert-kind-hub-entry-body = De getuigen van een ankerhub hebben het register van die hub ondertekend terwijl het een vermelding bevat die niet aan de regels van de hub voldoet. Minstens één van hen heeft dus ondertekend zonder te controleren.
alert-kind-unknown-title = Er is een probleem gevonden
alert-kind-unknown-body = Het bewijsmateriaal toont een soort probleem aan dat deze pagina niet kent: { $kind }.
alert-not-proven-title = Dit bestand toont geen probleem aan
alert-not-proven-body = Het bestand is gecontroleerd en toont geen probleem aan. Het is geen bewijsmateriaal.
alert-unpinned-title = Dit bestand hoort bij een beleid dat niet op dit apparaat is vastgezet
alert-unpinned-body = Het kan op dit apparaat niet als bewijs worden getoond. Vergelijk de beleidswoorden van het bestand met de officiële bekendmaking, en zet dat beleid vast voordat u het bestand opnieuw controleert.
alert-invalid-title = Dit bestand kon niet worden gecontroleerd
alert-invalid-body = Het bestand lijkt beschadigd. Dit toont niet aan dat iemand heeft gefraudeerd.
alert-proven-under = Aangetoond op basis van het beleid met deze woorden:
alert-file-policy-words = De beleidswoorden van het bestand:
alert-parties = Verantwoordelijk, volgens hun eigen handtekeningen: { $parties }
alert-evidence-heading = Bewijsmateriaal bewaard op dit apparaat
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } KB
alert-evidence-hint = Iedereen kan dit bestand op de eigen computer controleren. Het bevat alleen ondertekende objecten uit het register.
alert-download = Bewijsmateriaal downloaden
alert-send = Naar de monitoringdiensten versturen
alert-monitors-heading = Monitoringdiensten genoemd in het beleid
alert-confirm-heading = Het bewijsmateriaal versturen?
alert-confirm-body =
    { $count ->
        [one] Hiermee verstuurt u het bestand met bewijsmateriaal naar deze monitoringdienst. Die ziet het bestand en ook dat het van dit apparaat komt.
       *[other] Hiermee verstuurt u het bestand met bewijsmateriaal naar deze { $count } monitoringdiensten. Die zien het bestand en ook dat het van dit apparaat komt.
    }
alert-confirm-send = Ja, versturen
alert-confirm-cancel = Annuleren
alert-sending = Het bewijsmateriaal wordt naar de monitoringdiensten verstuurd.
alert-no-monitors = Het beleid noemt geen monitoringdiensten. Bewaar het bestand en geef het aan een waarnemer.
alert-delivery-waiting = Wachten op bevestiging
alert-delivery-sending = Wordt verstuurd
alert-delivery-confirmed = Bevestigd
alert-delivery-failed = Niet bevestigd

## <vitrine-badge>

badge-check = Onafhankelijk controleren
badge-opens = opent een onafhankelijke verificatietool

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = Het ontvangstbewijsbestand heeft de juiste vorm
step-policy-pinned = Het ontvangstbewijs hoort bij het vastgezette vertrouwensbeleid
step-log-known = Het register van het ontvangstbewijs staat in het beleid
step-entry-parse = De vermelding heeft de juiste vorm
step-entry-profile = De vermelding heeft het type van het register en de bijbehorende velden
step-entry-expectation = De vermelding is degene die u verwachtte
step-promise-signature = Het register heeft een ondertekende toezegging gedaan om de vermelding op te nemen
step-promise-inclusion = De ondertekende toezegging omvat de vermelding
step-promise-leaf = De toezegging geldt voor de vermelding die u verwachtte
step-promise-kept = Het register is zijn toezegging binnen de termijn nagekomen
step-issued-signature = Het ontvangstbewijs bij indiening is door het register ondertekend
step-issued-inclusion = De vermelding staat in het ontvangstbewijs bij indiening
step-record-signature = Het ontvangstbewijs van het register is door het register ondertekend
step-record-inclusion = De vermelding staat in het register
step-receipts-match = De ontvangstbewijzen horen bij dezelfde vermelding op dezelfde positie
step-record-consistency = Het register is sinds het ontvangstbewijs bij indiening alleen gegroeid
step-record-quorum = Voldoende onafhankelijke getuigen hebben het register ondertekend
step-hub-link = Het bewijs van hub { $hub } klopt
step-hub-opening = Na opening toont het verzegelde anker in hub { $hub } het register
step-hub-anchored-checkpoint = Het register dat in hub { $hub } is verankerd, is ondertekend door het register en zijn getuigen
step-hub-anchor-consistency = Het register is tot aan zijn anker in hub { $hub } alleen gegroeid
step-browser-anchor = De browserlaag bevat het register van hub { $hub }
step-browser-consistency = Hub { $hub } is tot aan zijn browseranker alleen gegroeid
step-bootstrap-link = Een bootstraphub verankert hub { $hub }
step-bootstrap-consistency = Hub { $hub } is tot aan zijn bootstrapanker alleen gegroeid
step-unknown = Controle ‘{ $code }’

## Reasons, why a check failed or is still waiting (`reason-<code>`). They
## take no variables: the tier, hub or step they belong to is shown next to them.

# Encodings and limits
reason-bad-base64 = Een base64-waarde heeft een onjuiste vorm.
reason-bad-hex = Een hexadecimale waarde heeft een onjuiste vorm.
reason-bad-text = Een stuk tekst is niet geldig of bevat een niet-toegestaan teken.
reason-bad-number = Een getal heeft een onjuiste vorm of valt buiten het toegestane bereik.
reason-trailing-data = Na een deel van het bestand volgen onverwachte gegevens.
reason-truncated = Een deel van het bestand eindigt te vroeg.
reason-too-large = Iets is groter dan de limieten toestaan.

# Signed notes and keys
reason-bad-note = Een ondertekende notitie heeft een onjuiste vorm.
reason-bad-key-name = Een sleutelnaam heeft een onjuiste vorm.
reason-bad-vkey = Een openbare sleutel heeft een onjuiste vorm of is van het verkeerde type.
reason-bad-public-key = Een openbare sleutel is niet geldig.
reason-duplicate-signature = Een notitie bevat dezelfde handtekening twee keer.
reason-bad-signature = Een handtekening klopt niet.
reason-missing-signature = Een handtekening die er moet zijn, ontbreekt.

# Checkpoints and witness signatures
reason-bad-checkpoint = Een controlepunt heeft een onjuiste vorm.
reason-wrong-origin = Een ondertekende notitie noemt een ander register of een andere hub dan verwacht.
reason-cosignature-in-future = Een handtekening van een getuige is in de toekomst gedateerd en is daarom genegeerd.
reason-quorum-not-met = Er hebben nog niet voldoende onafhankelijke getuigen ondertekend.

# Proofs
reason-bad-proof = Een bewijs heeft een onjuiste vorm.
reason-missing-extra = Een ontvangstbewijs bevat de vermelding niet.
reason-index-out-of-range = De positie van de vermelding ligt voorbij het einde van het register.
reason-inclusion-failed = Het bewijs dat de vermelding in het register staat, klopt niet.
reason-consistency-failed = Het bewijs dat het register alleen is gegroeid, klopt niet.
reason-split-view = Twee ondertekende versies van het register hebben dezelfde omvang maar een verschillende inhoud.

# Entries and expectations
reason-bad-entry = De vermelding heeft een onjuiste vorm.
reason-wrong-profile = Het type van de vermelding verschilt van het type van het register op die positie.
reason-bad-entry-layout = De velden van de vermelding passen niet bij het type ervan.
reason-entry-mismatch = De vermelding is niet degene die u verwachtte.
reason-expectation-incomplete = De pagina gaf niet voldoende informatie over de vermelding om die te controleren.
reason-expectation-unknown-field = De pagina noemde een veld dat dit soort vermelding niet heeft.
reason-expectation-unsupported = Deze verificatietool kan de velden van dit soort vermelding niet controleren.
reason-receipts-disagree = De ontvangstbewijzen in het bestand horen bij verschillende vermeldingen of posities.

# Promises
reason-bad-promise = De toezegging heeft een onjuiste vorm.
reason-promise-mmd-too-large = De toezegging laat meer vertraging toe dan het beleid toestaat.
reason-promise-leaf-mismatch = De toezegging geldt voor een andere vermelding.
reason-promise-pending = Het register heeft toegezegd de vermelding op te nemen. Het ontvangstbewijs hoeft er nog niet te zijn.
reason-promise-deadline-passed = De termijn van de toezegging is verstreken en er is nog geen ontvangstbewijs.
reason-promise-kept-unproven = Niets in het bestand laat zien dat de toezegging op tijd is nagekomen.

# Receipt chains
reason-malformed-chain = Het ontvangstbewijsbestand heeft een onjuiste vorm.
reason-duplicate-block = Het ontvangstbewijsbestand bevat hetzelfde deel twee keer.
reason-no-receipt = Het bestand bevat geen toezegging en geen ontvangstbewijs.
reason-policy-mismatch = Het ontvangstbewijs noemt een ander vertrouwensbeleid dan het vastgezette.
reason-unknown-log = Het ontvangstbewijs noemt een register dat niet in het beleid staat.
reason-unknown-hub = Een deel noemt een ankerhub die niet in het beleid staat; dat deel is daarom genegeerd.
reason-consistency-missing = Een bewijs dat het register alleen is gegroeid, ontbreekt.
reason-consistency-mismatch = Een bewijs dat het register alleen is gegroeid, past niet bij de versies die het verbindt.
reason-waiting-for-cosignatures = Wachten tot de getuigen het register ondertekenen.
reason-waiting-for-record = Wachten op het door getuigen ondertekende register.
reason-no-signed-time = Er is nog geen ondertekende tijd, dus termijnen kunnen nog niet worden beoordeeld.
reason-deadline-passed = De termijn is verstreken, volgens de ondertekende tijd.
reason-record-invalid = Dit kon niet worden gecontroleerd, omdat de bewijzen van het register niet konden worden gecontroleerd.
reason-bad-reference = Een link naar een ontvangstbewijs heeft een onjuiste vorm.

# Anchor hubs
reason-waiting-for-anchor = Wachten tot de ankerhub het register verankert.
reason-hub-quorum-not-met = Er hebben nog niet voldoende getuigen van de ankerhub ondertekend.
reason-bad-hub-link = Het bewijs van de ankerhub heeft een onjuiste vorm of klopt niet.
reason-hub-link-mismatch = Het bewijs van de ankerhub gaat over iets anders.
reason-map-proof-failed = Het bewijs uit de tabel van de ankerhub klopt niet.
reason-subject-rotated = De sleutel van het register is bij deze ankerhub gewijzigd. Het nieuwere vertrouwensbeleid is nodig.
reason-anchor-behind-record = De ankerhub bevat een oudere versie van het register dan uw ontvangstbewijs.
reason-anchor-quorum-not-met = Het verankerde register heeft niet voldoende handtekeningen van getuigen.
reason-bad-blinded-anchor = Een verzegeld anker klopt niet.
reason-opening-missing = Het bestand bevat nog niet wat het verzegelde anker opent.
reason-bad-opening = Wat het verzegelde anker zou moeten openen, past er niet bij.

# Browser layer
reason-browser-test-only = De browserlaag is hier alleen een test: die is in handen van de beheerder.
reason-waiting-for-browser-anchor = Wachten op de browserlaag. Die wordt binnen enkele minuten verwacht.
reason-browser-behind-anchor = De browserlaag bevat een oudere versie dan de ankerhub. Een nieuwere wordt verwacht.
reason-bad-browser-anchor = Een browseranker heeft een onjuiste vorm of komt niet overeen.
reason-bad-waict-proof = Het bewijs van de browserlaag klopt niet.
reason-waict-quorum-not-met = Er hebben niet voldoende getuigen van de browserlaag ondertekend.
reason-unknown-waict-service = Het browseranker komt van een dienst die niet in het beleid staat.
reason-waict-service-not-independent = De browserlaag is in handen van de beheerder en telt daarom niet mee.
reason-bad-bootstrap-link = Het bewijs van een bootstraphub heeft een onjuiste vorm of klopt niet.

# Trust policies
reason-policy-syntax = Een tekstregel van het vertrouwensbeleid heeft een onjuiste vorm.
reason-policy-unknown-keyword = Een tekstregel van het vertrouwensbeleid begint met een onbekend woord.
reason-policy-count = Een tekstregel van het vertrouwensbeleid komt te vaak of helemaal niet voor.
reason-policy-undefined-name = Het vertrouwensbeleid gebruikt een naam voordat die is gedefinieerd.
reason-policy-duplicate-name = Het vertrouwensbeleid definieert een naam twee keer.
reason-policy-invalid = Het vertrouwensbeleid voldoet niet aan een van de regels die ervoor gelden.
reason-policy-unsafe-quorum = Het quorum van getuigen in het vertrouwensbeleid is niet veilig.
reason-policy-unsigned = Het vertrouwensbeleid heeft niet voldoende handtekeningen van de verantwoordelijke instanties.

reason-unknown = Reden ‘{ $code }’
