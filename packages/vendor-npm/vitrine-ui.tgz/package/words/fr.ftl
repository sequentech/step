# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in French (fr).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Inclus
fact-unchanged = Inchangé
fact-same-for-everyone = Identique pour tous

fact-state-done = Fait
fact-state-promised = Promis
fact-state-pending = En attente
fact-state-late = En retard
fact-state-invalid = Vérification impossible
fact-state-failed = Échec
fact-state-checking = Vérification en cours

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Votre entrée figure dans le registre.
fact-included-promised = Le registre a signé la promesse d’inclure votre entrée.
fact-included-pending = En attente de l’inclusion de votre entrée dans le registre.
fact-included-late = Le registre aurait déjà dû inclure votre entrée.
fact-included-invalid = La preuve que votre entrée figure dans le registre n’a pas pu être vérifiée : les données semblent endommagées.
fact-included-failed = Les signatures du registre lui-même se contredisent au sujet de votre entrée.
fact-unchanged-done = Des témoins indépendants ont signé le registre, donc rien ne peut y changer sans que cela se voie.
fact-unchanged-pending = En attente de la signature du registre par les témoins indépendants.
fact-unchanged-late = Les témoins auraient déjà dû signer le registre.
fact-unchanged-invalid = Les preuves concernant l’historique du registre n’ont pas pu être vérifiées : les données semblent endommagées.
fact-unchanged-failed = Des preuves signées concernant l’historique du registre se contredisent.
fact-same-for-everyone-done = Toute personne qui vérifie voit ce même registre.
fact-same-for-everyone-pending = En attente de l’ancrage du registre là où chacun peut le vérifier.
fact-same-for-everyone-late = Le registre devrait déjà être ancré là où chacun peut le vérifier.
fact-same-for-everyone-invalid = Les ancrages n’ont pas pu être vérifiés : les données semblent endommagées.
fact-same-for-everyone-failed = Des preuves signées montrent que le registre présenté n’est pas le même pour tout le monde.

## Tiers

tier-record = Registre
tier-witnesses = Témoins
tier-hubs = Pôles d’ancrage
tier-browser = Couche navigateur
tier-policy = Politique de confiance
tier-entry = Entrée

tier-status-verified = Vérifié
tier-status-pending = En attente
tier-status-late = En retard
tier-status-invalid = Vérification impossible
tier-status-failed = Échec
tier-status-unused = Non utilisé
tier-status-checking = Vérification en cours
tier-status-promised = Promis

tier-record-verified = Votre entrée figure dans le registre signé.
tier-record-promised = Le registre a signé la promesse d’inclure votre entrée.
tier-record-pending = Le registre n’a pas encore inclus votre entrée.
tier-record-late = Le registre aurait déjà dû inclure votre entrée.
tier-record-invalid = Les preuves du registre semblent endommagées, elles n’ont donc pas pu être vérifiées.
tier-record-failed = Le registre a signé des preuves qui se contredisent.
tier-record-checking = Vérification des preuves du registre en cours.
tier-witnesses-verified = Suffisamment de témoins indépendants ont signé le registre.
tier-witnesses-pending = En attente de la signature des témoins. Cela prend quelques secondes.
tier-witnesses-late = Les témoins auraient déjà dû signer.
tier-witnesses-invalid = Les signatures des témoins semblent endommagées, elles n’ont donc pas pu être vérifiées.
tier-witnesses-failed = Des témoins ont signé un registre qui contredit le vôtre.
tier-witnesses-checking = Vérification des signatures des témoins en cours.
tier-hubs-verified = Chaque pôle d’ancrage détient le registre.
tier-hubs-pending = En route vers les pôles d’ancrage. Cela prend quelques secondes.
tier-hubs-late = Les pôles d’ancrage devraient déjà détenir le registre.
tier-hubs-invalid = La réponse d’un pôle d’ancrage semble endommagée, elle n’a donc pas pu être vérifiée.
tier-hubs-failed = Un pôle d’ancrage détient un registre signé qui contredit le vôtre.
tier-hubs-unused = Cette politique n’utilise aucun pôle d’ancrage.
tier-hubs-checking = Vérification des pôles d’ancrage en cours.
tier-browser-verified = Ancré là où les navigateurs vérifient.
tier-browser-pending = Prévu d’ici quelques minutes. Vous n’avez pas besoin d’attendre.
tier-browser-late = Le registre devrait déjà être ancré là où les navigateurs vérifient.
tier-browser-invalid = La réponse de la couche navigateur semble endommagée, elle n’a donc pas pu être vérifiée.
tier-browser-failed = Un ancrage signé, là où les navigateurs vérifient, contredit le registre.
tier-browser-unused = Cette politique n’utilise aucune couche navigateur indépendante.
tier-browser-checking = Vérification de la couche navigateur en cours.
tier-test = Test uniquement : géré par l’opérateur, il ne compte donc pas.
tier-deadline = Attendu au plus tard à { TIME($deadline) }
hub-test = test

## The one-line status

status-verified = Vérifié
status-checking = Vérification en cours…
status-pending = En attente
status-late = En retard
status-invalid = Vérification impossible
status-failed = Échec
status-summary-verified = Inclus, inchangé et identique pour tous.
status-summary-checking = Vérification des preuves du reçu en cours dans ce navigateur.
status-summary-pending = Certaines preuves sont encore en route. Vous n’avez pas besoin d’attendre.
status-summary-late = Certaines preuves auraient déjà dû arriver.
status-summary-invalid = Certaines données n’ont pas pu être vérifiées : elles semblent endommagées, dans le fichier ou dans la réponse du serveur. Cela ne montre pas que quelqu’un ait triché.
status-summary-failed = Des preuves signées se contredisent. Conservez les éléments de preuve.

## <vitrine-receipt>

receipt-label = Reçu
receipt-words-label = Mots du reçu
receipt-entry = Entrée { $index } du registre { $log }
receipt-entry-promised = Entrée promise dans le registre { $log }
receipt-provenance-page = Vérifié par ce site
receipt-provenance-page-hint = Ce site a vérifié son propre registre. Pour en avoir la certitude, vérifiez-le indépendamment.
receipt-provenance-independent = Vérifié indépendamment du site
receipt-facts-heading = Ce que montrent les preuves
receipt-chain-heading = Jusqu’où il est parvenu
receipt-compare-heading = Comparer avec l’avis officiel
receipt-compare-hint = Ces mots et ces témoins doivent correspondre à ceux que l’autorité a publiés, par exemple dans l’avis d’élection.
receipt-policy-words = Mots de la politique
receipt-policy-id = Identifiant de la politique
receipt-event = Événement
receipt-witnesses = Témoins
receipt-witness-party = géré par { $party }
receipt-hubs = Pôles d’ancrage
receipt-clock-warning = L’horloge de cet appareil est décalée de plus d’une minute. Les échéances sont évaluées selon l’heure signée, et non selon cette horloge.
receipt-action-check = Vérifier indépendamment
receipt-action-download = Télécharger le reçu
receipt-action-retry = Vérifier à nouveau
receipt-invalid = Certaines données n’ont pas pu être vérifiées : elles semblent endommagées, dans le fichier ou dans la réponse du serveur. Cela ne montre pas que quelqu’un ait triché. Vous pouvez vérifier à nouveau, ou vérifier indépendamment.
receipt-no-expect = Cette page n’a pas indiqué quelle entrée attendre, ce reçu ne peut donc pas être présenté comme le vôtre.
receipt-error = Ce reçu n’a pas pu être vérifié.
receipt-empty = Aucun reçu pour l’instant.
receipt-announce = { $tier } : { $status }.

## <vitrine-proof-steps>

steps-heading = Toutes les vérifications
steps-summary =
    { $total ->
        [one] Vérification réussie : { $passed } sur { $total }
       *[other] Vérifications réussies : { $passed } sur { $total }
    }
steps-result-passed = Réussie
steps-result-failed = Échec
steps-result-not-run = Pas encore effectuée
steps-show-details = Afficher les détails
steps-hide-details = Masquer les détails
steps-objects = Objets signés concernés : { $objects }
steps-evidence = Enregistrer les éléments de preuve
steps-empty = Aucune vérification pour l’instant.

## <vitrine-chain>

chain-label = Chaîne du reçu

## <vitrine-alert>

alert-label = Problème avéré
alert-kind-split-view-title = Le registre a été présenté différemment selon les personnes
alert-kind-split-view-body = Deux versions du registre, toutes deux signées par son opérateur, ne peuvent pas être vraies à la fois. Il peut s’agir d’une défaillance ou d’une attaque. Votre entrée peut tout de même être prise en compte, mais un tiers indépendant devrait examiner la situation.
alert-kind-broken-promise-title = Le registre n’a pas tenu une promesse signée
alert-kind-broken-promise-body = Le registre avait promis d’inclure une entrée avant une échéance, et ses propres signatures montrent qu’il ne l’a pas fait. Un tiers indépendant devrait examiner la situation.
alert-kind-bad-entry-title = Le registre contient une entrée qui enfreint ses règles
alert-kind-bad-entry-body = Une entrée signée dans le registre enfreint une règle de son profil. Un tiers indépendant devrait examiner la situation.
alert-kind-stale-anchor-title = Le registre n’a pas été ancré à temps
alert-kind-stale-anchor-body = Le registre ou un pôle d’ancrage a mis plus de temps que la politique ne le permet pour ancrer le registre. C’est un manquement à un niveau de service promis ; le registre lui-même n’est pas en cause.
alert-kind-hub-entry-title = Un pôle d’ancrage a accepté une entrée qu’il aurait dû refuser
alert-kind-hub-entry-body = Les témoins d’un pôle d’ancrage ont signé un registre du pôle contenant une entrée qui enfreint les règles de ce pôle : au moins l’un d’eux a donc signé sans vérifier.
alert-kind-unknown-title = Un problème a été détecté
alert-kind-unknown-body = Les éléments de preuve montrent un problème d’un type que cette page ne connaît pas : { $kind }.
alert-not-proven-title = Ce fichier ne prouve aucun problème
alert-not-proven-body = Le fichier a été vérifié et ne prouve aucun problème. Ce n’est pas un élément de preuve.
alert-unpinned-title = Ce fichier concerne une politique que cet appareil n’a pas épinglée
alert-unpinned-body = Il ne peut pas être présenté comme preuve sur cet appareil. Comparez les mots de la politique du fichier avec l’avis officiel, puis épinglez cette politique avant de vérifier à nouveau le fichier.
alert-invalid-title = Ce fichier n’a pas pu être vérifié
alert-invalid-body = Le fichier semble endommagé. Cela ne montre pas que quelqu’un ait triché.
alert-proven-under = Avéré selon la politique identifiée par ces mots :
alert-file-policy-words = Mots de la politique du fichier :
alert-parties = Responsables, d’après leurs propres signatures : { $parties }
alert-evidence-heading = Éléments de preuve conservés sur cet appareil
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } Ko
alert-evidence-hint = Toute personne peut vérifier ce fichier sur son propre ordinateur. Il ne contient que des objets signés issus du registre.
alert-download = Télécharger les éléments de preuve
alert-send = Envoyer aux services de veille
alert-monitors-heading = Services de veille désignés par la politique
alert-confirm-heading = Envoyer les éléments de preuve ?
alert-confirm-body =
    { $count ->
        [one] Le fichier des éléments de preuve sera envoyé à ce service de veille. Il verra ce fichier et saura qu’il provient de cet appareil.
       *[other] Le fichier des éléments de preuve sera envoyé à ces { $count } services de veille. Ils verront ce fichier et sauront qu’il provient de cet appareil.
    }
alert-confirm-send = Oui, envoyer
alert-confirm-cancel = Annuler
alert-sending = Les éléments de preuve sont en cours d’envoi aux services de veille.
alert-no-monitors = La politique ne désigne aucun service de veille. Conservez le fichier et remettez-le à un observateur.
alert-delivery-waiting = En attente de confirmation
alert-delivery-sending = Envoi en cours
alert-delivery-confirmed = Confirmé
alert-delivery-failed = Non confirmé

## <vitrine-badge>

badge-check = Vérifier indépendamment
badge-opens = ouvre un vérificateur indépendant

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = Le fichier du reçu est bien formé
step-policy-pinned = Le reçu correspond à la politique de confiance épinglée
step-log-known = Le registre du reçu figure dans la politique
step-entry-parse = L’entrée est bien formée
step-entry-profile = L’entrée a le type du registre et les champs de ce type
step-entry-expectation = L’entrée est celle que vous attendiez
step-promise-signature = Le registre a signé la promesse d’inclure l’entrée
step-promise-inclusion = La promesse signée couvre l’entrée
step-promise-leaf = La promesse concerne l’entrée que vous attendiez
step-promise-kept = Le registre a tenu sa promesse avant l’échéance
step-issued-signature = Le reçu remis lors du dépôt est signé par le registre
step-issued-inclusion = L’entrée figure dans le reçu remis lors du dépôt
step-record-signature = Le reçu du registre est signé par le registre
step-record-inclusion = L’entrée figure dans le registre
step-receipts-match = Les reçus concernent la même entrée, à la même position
step-record-consistency = Le registre n’a fait que croître depuis le reçu remis lors du dépôt
step-record-quorum = Suffisamment de témoins indépendants ont signé le registre
step-hub-link = La preuve du pôle { $hub } est valide
step-hub-opening = Une fois ouvert, l’ancrage scellé du pôle { $hub } correspond au registre
step-hub-anchored-checkpoint = Le registre ancré dans le pôle { $hub } est signé par le registre et ses témoins
step-hub-anchor-consistency = Le registre n’a fait que croître jusqu’à son ancrage dans le pôle { $hub }
step-browser-anchor = La couche navigateur détient le registre du pôle { $hub }
step-browser-consistency = Le pôle { $hub } n’a fait que croître jusqu’à son ancrage dans la couche navigateur
step-bootstrap-link = Un pôle d’amorçage ancre le pôle { $hub }
step-bootstrap-consistency = Le pôle { $hub } n’a fait que croître jusqu’à son ancrage d’amorçage
step-unknown = Vérification « { $code } »

## Reasons, why a check failed or is still waiting (`reason-<code>`). They
## take no variables: the tier, hub or step they belong to is shown next to them.

# Encodings and limits
reason-bad-base64 = Une valeur base64 est mal formée.
reason-bad-hex = Une valeur hexadécimale est mal formée.
reason-bad-text = Un texte n’est pas valide ou contient un caractère interdit.
reason-bad-number = Un nombre est mal formé ou hors limites.
reason-trailing-data = Des données inattendues suivent une partie du fichier.
reason-truncated = Une partie du fichier se termine trop tôt.
reason-too-large = Un élément dépasse les limites autorisées.

# Signed notes and keys
reason-bad-note = Une note signée est mal formée.
reason-bad-key-name = Un nom de clé est mal formé.
reason-bad-vkey = Une clé publique est mal formée ou n’est pas du bon type.
reason-bad-public-key = Une clé publique n’est pas valide.
reason-duplicate-signature = Une note porte deux fois la même signature.
reason-bad-signature = Une signature n’est pas valide.
reason-missing-signature = Il manque une signature obligatoire.

# Checkpoints and witness signatures
reason-bad-checkpoint = Un point de contrôle est mal formé.
reason-wrong-origin = Une note signée nomme un registre ou un pôle autre que celui attendu.
reason-cosignature-in-future = Une signature de témoin porte une date future, elle a donc été ignorée.
reason-quorum-not-met = Trop peu de témoins indépendants ont signé pour l’instant.

# Proofs
reason-bad-proof = Une preuve est mal formée.
reason-missing-extra = Un reçu ne contient pas l’entrée.
reason-index-out-of-range = La position de l’entrée se situe au-delà de la fin du registre.
reason-inclusion-failed = La preuve que l’entrée figure dans le registre n’est pas valide.
reason-consistency-failed = La preuve que le registre n’a fait que croître n’est pas valide.
reason-split-view = Deux versions signées du registre ont la même taille mais des contenus différents.

# Entries and expectations
reason-bad-entry = L’entrée est mal formée.
reason-wrong-profile = Le type de l’entrée diffère de celui du registre à cette position.
reason-bad-entry-layout = Les champs de l’entrée ne correspondent pas à son type.
reason-entry-mismatch = L’entrée n’est pas celle que vous attendiez.
reason-expectation-incomplete = La page n’a pas donné assez d’informations sur l’entrée pour la vérifier.
reason-expectation-unknown-field = La page a indiqué un champ que ce type d’entrée ne possède pas.
reason-expectation-unsupported = Ce vérificateur ne prend pas en charge les champs de ce type d’entrée.
reason-receipts-disagree = Les reçus du fichier concernent des entrées ou des positions différentes.

# Promises
reason-bad-promise = La promesse est mal formée.
reason-promise-mmd-too-large = La promesse accorde un délai plus long que la politique ne le permet.
reason-promise-leaf-mismatch = La promesse concerne une autre entrée.
reason-promise-pending = Le registre a promis d’inclure l’entrée. L’échéance de son reçu n’est pas encore arrivée.
reason-promise-deadline-passed = L’échéance de la promesse est passée et il n’y a pas encore de reçu.
reason-promise-kept-unproven = Rien dans le fichier ne montre que la promesse ait été tenue dans les délais.

# Receipt chains
reason-malformed-chain = Le fichier du reçu est mal formé.
reason-duplicate-block = Le fichier du reçu contient deux fois la même partie.
reason-no-receipt = Le fichier ne contient ni promesse ni reçu.
reason-policy-mismatch = Le reçu désigne une autre politique de confiance que celle épinglée.
reason-unknown-log = Le reçu désigne un registre qui ne figure pas dans la politique.
reason-unknown-hub = Une partie désigne un pôle d’ancrage qui ne figure pas dans la politique, elle a donc été ignorée.
reason-consistency-missing = Il manque une preuve que le registre n’a fait que croître.
reason-consistency-mismatch = Une preuve que le registre n’a fait que croître ne correspond pas aux versions qu’elle relie.
reason-waiting-for-cosignatures = En attente de la signature du registre par les témoins.
reason-waiting-for-record = En attente du registre signé par les témoins.
reason-no-signed-time = Il n’y a pas encore d’heure signée, les échéances ne peuvent donc pas être évaluées.
reason-deadline-passed = L’échéance est passée, selon l’heure signée.
reason-record-invalid = Vérification impossible, car les preuves du registre n’ont pas pu être vérifiées.
reason-bad-reference = Un lien vers un reçu est mal formé.

# Anchor hubs
reason-waiting-for-anchor = En attente de l’ancrage du registre par le pôle d’ancrage.
reason-hub-quorum-not-met = Trop peu de témoins du pôle d’ancrage ont signé pour l’instant.
reason-bad-hub-link = La preuve du pôle d’ancrage est mal formée ou n’est pas valide.
reason-hub-link-mismatch = La preuve du pôle d’ancrage porte sur autre chose.
reason-map-proof-failed = La preuve d’inclusion dans la table du pôle d’ancrage n’est pas valide.
reason-subject-rotated = La clé du registre a changé auprès de ce pôle d’ancrage. La nouvelle politique de confiance est nécessaire.
reason-anchor-behind-record = Le pôle d’ancrage détient une version du registre plus ancienne que votre reçu.
reason-anchor-quorum-not-met = Le registre ancré ne porte pas assez de signatures de témoins.
reason-bad-blinded-anchor = Un ancrage scellé n’est pas valide.
reason-opening-missing = Le fichier ne contient pas encore ce qui ouvre l’ancrage scellé.
reason-bad-opening = Ce qui devrait ouvrir l’ancrage scellé ne lui correspond pas.

# Browser layer
reason-browser-test-only = La couche navigateur n’est ici qu’un test : elle est gérée par l’opérateur.
reason-waiting-for-browser-anchor = En attente de la couche navigateur. Elle est prévue d’ici quelques minutes.
reason-browser-behind-anchor = La couche navigateur détient une version plus ancienne que celle du pôle d’ancrage. Une version plus récente est attendue.
reason-bad-browser-anchor = Un ancrage dans la couche navigateur est mal formé ou ne correspond pas.
reason-bad-waict-proof = La preuve de la couche navigateur n’est pas valide.
reason-waict-quorum-not-met = Trop peu de témoins de la couche navigateur ont signé.
reason-unknown-waict-service = L’ancrage dans la couche navigateur provient d’un service qui ne figure pas dans la politique.
reason-waict-service-not-independent = La couche navigateur est gérée par l’opérateur, elle ne compte donc pas.
reason-bad-bootstrap-link = La preuve d’un pôle d’amorçage est mal formée ou n’est pas valide.

# Trust policies
reason-policy-syntax = Une ligne de la politique de confiance est mal formée.
reason-policy-unknown-keyword = Une ligne de la politique de confiance commence par un mot inconnu.
reason-policy-count = Une ligne de la politique de confiance apparaît trop souvent, ou pas du tout.
reason-policy-undefined-name = La politique de confiance utilise un nom avant de le définir.
reason-policy-duplicate-name = La politique de confiance définit deux fois le même nom.
reason-policy-invalid = La politique de confiance enfreint l’une de ses règles.
reason-policy-unsafe-quorum = Le quorum de témoins de la politique de confiance n’est pas sûr.
reason-policy-unsigned = La politique de confiance ne porte pas assez de signatures de ses autorités.

reason-unknown = Motif « { $code } »
