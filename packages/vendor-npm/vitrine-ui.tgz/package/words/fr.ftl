# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in French (fr).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Inclus
fact-unchanged = Inchangé
fact-same-for-everyone = Identique pour tous

fact-state-done = Fait
fact-state-promised = Promis
fact-state-pending = En attente
fact-state-late = En retard
fact-state-invalid = Vérification impossible
fact-state-failed = Échec
fact-state-checking = Vérification en cours

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Votre entrée figure dans le registre.
fact-included-promised = Le registre a signé la promesse d’inclure votre entrée.
fact-included-pending = Certaines preuves que votre entrée figure dans le registre sont encore en route.
fact-included-late = Le registre aurait déjà dû inclure votre entrée.
fact-included-invalid = La preuve que votre entrée figure dans le registre n’a pas pu être vérifiée : les données semblent endommagées.
fact-included-failed = Les signatures du registre lui-même se contredisent au sujet de votre entrée.
fact-unchanged-done = Des témoins indépendants ont signé le registre, donc rien ne peut y changer sans que cela se voie.
fact-unchanged-pending = En attente de la signature du registre par les témoins indépendants.
fact-unchanged-late = Les témoins auraient déjà dû signer le registre.
fact-unchanged-invalid = Les preuves concernant l’historique du registre n’ont pas pu être vérifiées : les données semblent endommagées.
fact-unchanged-failed = Des preuves signées concernant l’historique du registre se contredisent.
fact-same-for-everyone-done = Toute personne qui vérifie voit ce même registre.
fact-same-for-everyone-pending = En attente de l’ancrage du registre là où chacun peut le vérifier.
fact-same-for-everyone-late = Le registre devrait déjà être ancré là où chacun peut le vérifier.
fact-same-for-everyone-invalid = Les ancrages n’ont pas pu être vérifiés : les données semblent endommagées.
fact-same-for-everyone-failed = Des preuves signées montrent que le registre présenté n’est pas le même pour tout le monde.
# Instead of the pending text: `fact-pending-successors` (any fact) when every
# tier the fact rests on waits only for the check for a newer trust policy
# (specs/policy.md, section 4, rule 7), and
# `fact-same-for-everyone-pending-attestation` when a private event's anchor
# hubs wait for an auditor to confirm the sealed anchors (specs/receipt.md,
# section 3.3).
fact-pending-successors = Les preuves sont valides. Cela apparaîtra comme fait une fois qu’on aura contrôlé si la politique de confiance a été remplacée par une plus récente.
fact-same-for-everyone-pending-attestation = Ancré. Un auditeur doit encore confirmer les ancrages scellés, ce qui peut prendre un certain temps.

## Tiers

tier-record = Registre
tier-witnesses = Témoins
tier-hubs = Pôles d’ancrage
tier-browser = Couche navigateur
tier-policy = Politique de confiance
tier-entry = Entrée

tier-status-verified = Vérifié
tier-status-pending = En attente
tier-status-late = En retard
tier-status-invalid = Vérification impossible
tier-status-failed = Échec
tier-status-unused = Non utilisé
tier-status-checking = Vérification en cours
tier-status-promised = Promis

tier-record-verified = Votre entrée figure dans le registre signé.
tier-record-promised = Le registre a signé la promesse d’inclure votre entrée.
tier-record-pending = Certaines preuves du registre sont encore en route.
tier-record-late = Le registre aurait déjà dû inclure votre entrée.
tier-record-invalid = Les preuves du registre semblent endommagées, elles n’ont donc pas pu être vérifiées.
tier-record-failed = Le registre a signé des preuves qui se contredisent.
tier-record-checking = Vérification des preuves du registre en cours.
tier-witnesses-verified = Suffisamment de témoins indépendants ont signé le registre.
tier-witnesses-pending = En attente de la signature des témoins. Cela prend quelques secondes.
tier-witnesses-late = Les témoins auraient déjà dû signer.
tier-witnesses-invalid = Les signatures des témoins semblent endommagées, elles n’ont donc pas pu être vérifiées.
tier-witnesses-failed = Des témoins ont signé un registre qui contredit le vôtre.
tier-witnesses-checking = Vérification des signatures des témoins en cours.
tier-hubs-verified = Chaque pôle d’ancrage détient le registre.
tier-hubs-pending = En route vers les pôles d’ancrage. Cela prend quelques secondes.
tier-hubs-late = Les pôles d’ancrage devraient déjà détenir le registre.
tier-hubs-invalid = La réponse d’un pôle d’ancrage semble endommagée, elle n’a donc pas pu être vérifiée.
tier-hubs-failed = Un pôle d’ancrage détient un registre signé qui contredit le vôtre.
tier-hubs-unused = Cette politique n’utilise aucun pôle d’ancrage.
tier-hubs-checking = Vérification des pôles d’ancrage en cours.
tier-browser-verified = Ancré là où les navigateurs vérifient.
tier-browser-pending = Prévu d’ici quelques minutes. Vous n’avez pas besoin d’attendre.
tier-browser-late = Le registre devrait déjà être ancré là où les navigateurs vérifient.
tier-browser-invalid = La réponse de la couche navigateur semble endommagée, elle n’a donc pas pu être vérifiée.
tier-browser-failed = Un ancrage signé, là où les navigateurs vérifient, contredit le registre.
tier-browser-unused = Cette politique n’utilise aucune couche navigateur indépendante.
tier-browser-checking = Vérification de la couche navigateur en cours.
# Instead of the pending text: `tier-pending-successors` (any tier) when every
# check of the tier passed but the check for a newer trust policy hasn't run
# yet; in a private event, `tier-hubs-pending-attestation` when the anchor hubs
# wait for an auditor, and `tier-browser-pending-hubs` when the browser layer
# waits for the anchor hubs.
tier-pending-successors = Ses preuves sont valides. Cela apparaîtra comme vérifié une fois qu’on aura contrôlé si la politique de confiance a été remplacée par une plus récente.
tier-hubs-pending-attestation = Ancré. Un auditeur doit encore confirmer les ancrages scellés. Cela peut prendre un certain temps, et ce n’est jamais considéré comme en retard.
tier-browser-pending-hubs = En attente des pôles d’ancrage : dans un événement privé, la couche navigateur ne compte qu’une fois ceux-ci vérifiés.
tier-test = Test uniquement : géré par l’opérateur, il ne compte donc pas.
tier-deadline = Attendu au plus tard à { TIME($deadline) }
hub-test = test

## Stages of a ballot in the log (specs/entry.md, section 4.1): a tag next to the status

stage-received = Non déposé
stage-cast = Déposé
stage-audited = Audité

## The one-line status

status-verified = Vérifié
status-checking = Vérification en cours…
status-pending = En attente
status-late = En retard
status-invalid = Vérification impossible
status-failed = Échec
status-summary-verified = Inclus, inchangé et identique pour tous.
status-summary-checking = Vérification des preuves du reçu en cours dans ce navigateur.
status-summary-pending = Certaines preuves sont encore en route. Vous n’avez pas besoin d’attendre.
status-summary-pending-successors = Les preuves sont valides. Le reçu apparaîtra comme vérifié une fois qu’on aura contrôlé si la politique de confiance a été remplacée par une plus récente.
status-summary-pending-attestation = Ancré. Un auditeur doit encore confirmer les ancrages scellés. Vous n’avez pas besoin d’attendre.
status-summary-late = Certaines preuves auraient déjà dû arriver.
status-summary-invalid = Certaines données n’ont pas pu être vérifiées : elles semblent endommagées, dans le fichier ou dans la réponse du serveur. Cela ne montre pas que quelqu’un ait triché.
status-summary-failed = Des preuves signées se contredisent. Conservez les éléments de preuve.

## <vitrine-receipt>

receipt-label = Reçu
receipt-entry = Entrée { $index } du registre { $log }
receipt-entry-promised = Entrée promise dans le registre { $log }
receipt-provenance-page = Vérifié par ce site
receipt-provenance-page-hint = Ce site a vérifié son propre registre. Pour en avoir la certitude, vérifiez-le indépendamment.
receipt-provenance-independent = Vérifié indépendamment du site
receipt-facts-heading = Ce que montrent les preuves
receipt-chain-heading = Jusqu’où il est parvenu
receipt-compare-heading = Comparer avec l’avis officiel
receipt-compare-hint = Cet identifiant de politique et ces témoins doivent correspondre à ceux que l’autorité a publiés, par exemple dans l’avis d’élection.
receipt-policy-in-force = Politique en vigueur
receipt-policy-in-force-hint = Elle a remplacé la politique précédente, comme les règles de celle-ci le permettent. Son identifiant doit correspondre à un avis plus récent de l’autorité.
receipt-policy-id = Identifiant de la politique
receipt-event = Événement
receipt-witnesses = Témoins
receipt-witness-party = géré par { $party }
receipt-hubs = Pôles d’ancrage
receipt-clock-warning = L’horloge de cet appareil s’écarte de plus d’une minute de l’heure la plus récente signée par les témoins. Les échéances sont évaluées selon l’heure signée, et non selon cette horloge.
receipt-action-check = Vérifier indépendamment
receipt-action-download = Télécharger le reçu
receipt-action-retry = Vérifier à nouveau
receipt-invalid = Certaines données n’ont pas pu être vérifiées : elles semblent endommagées, dans le fichier ou dans la réponse du serveur. Cela ne montre pas que quelqu’un ait triché. Vous pouvez vérifier à nouveau, ou vérifier indépendamment.
receipt-no-expect = Cette page n’a pas indiqué quelle entrée attendre, ce reçu ne peut donc pas être présenté comme le vôtre.
receipt-error = Ce reçu n’a pas pu être vérifié.
receipt-empty = Aucun reçu pour l’instant.
receipt-announce = { $tier } : { $status }.

## <vitrine-receipt>, the receipt card (the voter board). Its five steps are
## sealed on this device, then the four tiers. `$noun` is the profile's name for
## one entry ("ballot" in the election profile), or `receipt-noun`.

receipt-noun = entrée
receipt-fingerprint-label = Empreinte ({ $noun })

receipt-seal-checking = Vérification en cours
receipt-seal-sealed = Scellé
receipt-seal-record-public = Inclus dans le registre public
receipt-seal-record-private = Inclus dans le registre privé
receipt-seal-witnesses = Confirmé par des témoins indépendants
receipt-seal-hubs = { $hubs }. Ancrage de la couche navigateur attendu bientôt
receipt-seal-browser = Ancré là où les navigateurs vérifient

receipt-step-sealed = Scellé sur cet appareil
receipt-step-sealed-done = Scellé avant de quitter votre navigateur.
receipt-step-sealed-wait = Scellement dans votre navigateur…
receipt-step-record-public = Ajouté au registre public
receipt-step-record-private = Ajouté au registre privé
receipt-step-record-done = Entrée #{ $index }. Votre navigateur l’a vérifiée.
receipt-step-record-wait = En attente de son inclusion dans le registre…
receipt-step-record-promised = Le registre a signé la promesse de l’inclure.
receipt-step-witnesses = Confirmé par des témoins
receipt-step-witnesses-done = Signé par { $signed } des { $total } témoins indépendants.
receipt-step-witnesses-done-any = Signé par des témoins indépendants.
receipt-step-witnesses-wait = En attente des signatures des témoins…
receipt-step-hubs-public =
    { $count ->
        [one] Ancré dans { $count } pôle public
       *[other] Ancré dans { $count } pôles publics
    }
receipt-step-hubs-private =
    { $count ->
        [one] Ancré dans { $count } pôle, scellé
       *[other] Ancré dans { $count } pôles, scellé
    }
receipt-step-hubs-none = Pôles d’ancrage
receipt-step-hubs-done-public = Des registres partagés détiennent aussi ce registre.
receipt-step-hubs-done-private = Rien de ce qu’il contient n’est révélé.
receipt-step-hubs-wait = D’ici quelques secondes…
receipt-step-hubs-partial = Détenu par { $agree } des { $total } pôles pour l’instant…
receipt-step-browser = Ancré là où les navigateurs vérifient
receipt-step-browser-done = Dans le même registre que le code de ce site.
receipt-step-browser-done-bootstrap = Conservé par un pôle provisoire jusqu’à ce que les navigateurs vérifient eux-mêmes les registres.
receipt-step-browser-wait = D’ici quelques minutes. Vous n’avez pas besoin d’attendre.
receipt-step-browser-wait-minutes =
    { $minutes ->
        [one] D’ici une minute. Vous n’avez pas besoin d’attendre.
       *[other] D’ici { $minutes } minutes. Vous n’avez pas besoin d’attendre.
    }
receipt-step-late = Cela prend plus de temps que prévu.
receipt-step-invalid = Vérification impossible : les données semblent endommagées.
receipt-step-failed = Contredit le registre signé.
receipt-step-unused = Non utilisé par la politique de cet événement.
receipt-step-state-done = Fait
receipt-step-state-active = En cours
receipt-step-state-scheduled = Planifié
receipt-step-state-waiting = En attente

receipt-caption-checking-public = Votre navigateur vérifie le registre public…
receipt-caption-checking-private = Votre navigateur vérifie le registre privé…
receipt-caption-public = Vérifié par votre navigateur, avec un code que chacun peut inspecter.
receipt-caption-private = Registre privé. Les auditeurs accrédités peuvent le vérifier en entier.
receipt-caption-late = Certaines étapes prennent plus de temps que prévu.
receipt-caption-invalid = Certaines données n’ont pas pu être vérifiées. Elles semblent endommagées.
receipt-caption-failed = Votre navigateur a détecté un problème dans le registre.

receipt-check-elsewhere = Vérifier sur un autre appareil
receipt-action-save = Enregistrer le reçu

## <vitrine-receipt variant="summary">, the re-check on a later visit (the
## revisit board).

receipt-summary-label = Vérification du reçu
receipt-summary-title-public = Votre entrée figure toujours dans le registre public
receipt-summary-title-private = Votre entrée figure toujours dans le registre privé
receipt-summary-title-checking = Vérification de votre entrée dans le registre…
receipt-summary-title-late = Certaines preuves de votre entrée sont en retard
receipt-summary-title-invalid = Votre entrée n’a pas pu être vérifiée
receipt-summary-title-failed = Nous n’avons pas pu confirmer votre entrée dans le registre
receipt-summary-checked-now = Vérifié à l’instant par votre navigateur.
receipt-summary-checked-at = Vérifié par votre navigateur à { TIME($time) }.
receipt-summary-unchanged = Rien de ce qui a été enregistré avant n’a changé.
receipt-summary-witnesses = Témoins
receipt-summary-hubs-public = Pôles publics
receipt-summary-hubs-private = Pôles
receipt-summary-browser = Là où les navigateurs vérifient
receipt-summary-agree = { $agree } sur { $total } concordent
receipt-summary-agree-any = Concordent
receipt-summary-anchored = Ancré le { DATE($time) }
receipt-summary-anchored-plain = Ancré
receipt-summary-waiting = En attente
receipt-summary-due = Attendu bientôt
receipt-summary-unused = Non utilisé
receipt-view = Voir le reçu

## <vitrine-how-we-check>

how-label = Comment fonctionne la vérification
how-heading = Comment nous vérifions
how-receipt = Votre navigateur conserve un reçu signé. Il contient une empreinte de ce que vous avez déposé, jamais le contenu.
how-grew = À chaque visite, il demande au registre une courte preuve qu’il n’a fait que croître.
how-witnesses = Des témoins indépendants le signent, et des pôles publics l’ancrent là où les navigateurs vérifient, afin que chacun voie le même registre.

## <vitrine-proof-steps>

steps-heading = Toutes les vérifications
steps-summary =
    { $total ->
        [one] Vérification réussie : { $passed } sur { $total }
       *[other] Vérifications réussies : { $passed } sur { $total }
    }
steps-result-passed = Réussie
steps-result-failed = Échec
steps-result-not-run = Pas encore effectuée
steps-show-details = Afficher les détails
steps-hide-details = Masquer les détails
steps-objects = Objets signés concernés : { $objects }
steps-evidence = Enregistrer les éléments de preuve
steps-empty = Aucune vérification pour l’instant.

## <vitrine-chain>

chain-label = Chaîne du reçu

## <vitrine-alert>

alert-label = Problème avéré
alert-kind-split-view-title = Le registre a été présenté différemment selon les personnes
alert-kind-split-view-body = Deux versions du registre, toutes deux signées par son opérateur, ne peuvent pas être vraies à la fois. Il peut s’agir d’une défaillance ou d’une attaque. Votre entrée peut tout de même être prise en compte, mais un tiers indépendant devrait examiner la situation.
alert-kind-broken-promise-title = Le registre n’a pas tenu une promesse signée
alert-kind-broken-promise-body = Le registre avait promis d’inclure une entrée avant une échéance, et ses propres signatures montrent qu’il ne l’a pas fait. Un tiers indépendant devrait examiner la situation.
alert-kind-bad-entry-title = Le registre contient une entrée qui enfreint ses règles
alert-kind-bad-entry-body = Une entrée signée dans le registre enfreint une règle de son profil. Un tiers indépendant devrait examiner la situation.
alert-kind-hub-entry-title = Un pôle d’ancrage a accepté une entrée qu’il aurait dû refuser
alert-kind-hub-entry-body = Les témoins d’un pôle d’ancrage ont signé un registre du pôle contenant une entrée qui enfreint les règles de ce pôle : au moins l’un d’eux a donc signé sans vérifier.
alert-kind-time-regression-title = Le registre a signé une heure fausse
alert-kind-time-regression-body = Le registre a signé deux versions de lui-même, et la plus grande porte l’heure la plus ancienne. L’heure signée d’un registre ne recule jamais : l’une des deux est donc fausse. Un tiers indépendant devrait examiner la situation.
alert-kind-policy-equivocation-title = Les autorités de la politique de confiance ont signé deux remplacements différents
alert-kind-policy-equivocation-body = Suffisamment d’autorités de la politique de confiance ont signé deux remplacements différents de celle-ci, et les deux ont été enregistrés. Le premier enregistré fait foi, mais le second pourrait montrer des politiques différentes selon les personnes. Un tiers indépendant devrait examiner la situation.
alert-kind-bad-checkpoint-title = Un registre a signé une version impossible de lui-même
alert-kind-bad-checkpoint-body = Il a signé une version qui n’a aucune entrée, mais qui n’est pas vide. Aucun registre ni pôle d’ancrage honnête ne peut produire une telle version. Un tiers indépendant devrait examiner la situation.
alert-kind-unknown-title = Un problème a été détecté
alert-kind-unknown-body = Les éléments de preuve montrent un problème d’un type que cette page ne connaît pas : { $kind }.
alert-not-proven-title = Ce fichier ne prouve aucun problème
alert-not-proven-body = Le fichier a été vérifié et ne prouve aucun problème. Ce n’est pas un élément de preuve.
alert-unpinned-title = Ce fichier concerne une politique que cet appareil n’a pas épinglée
alert-unpinned-body = Il ne peut pas être présenté comme preuve sur cet appareil. Comparez l’identifiant de la politique du fichier avec l’avis officiel, puis épinglez cette politique avant de vérifier à nouveau le fichier.
alert-invalid-title = Ce fichier n’a pas pu être vérifié
alert-invalid-body = Le fichier semble endommagé. Cela ne montre pas que quelqu’un ait triché.
alert-proven-under = Avéré selon la politique portant cet identifiant :
alert-file-policy-id = Identifiant de la politique du fichier :
alert-parties = Responsables, d’après leurs propres signatures : { $parties }
alert-evidence-heading = Éléments de preuve conservés sur cet appareil
alert-evidence-hint = Les observateurs vérifient ces éléments de preuve sur leur propre ordinateur. Ils prouvent ce que le registre a signé et ne contiennent rien sur ce que vous avez déposé.
alert-download = Télécharger les éléments de preuve
alert-send = Envoyer les éléments de preuve aux observateurs
alert-monitors-heading = Observateurs désignés par la politique
alert-confirm-heading = Envoyer les éléments de preuve ?
alert-confirm-body =
    { $count ->
        [one] Le fichier des éléments de preuve sera envoyé à cet observateur. Il verra ce fichier et saura qu’il provient de cet appareil.
       *[other] Le fichier des éléments de preuve sera envoyé à ces { $count } observateurs. Ils verront ce fichier et sauront qu’il provient de cet appareil.
    }
alert-confirm-send = Oui, envoyer
alert-confirm-cancel = Annuler
alert-sending = Les éléments de preuve sont en cours d’envoi aux observateurs.
alert-no-monitors = La politique ne désigne aucun service de veille. Conservez le fichier et remettez-le à un observateur.
alert-delivery-waiting = En attente de confirmation
alert-delivery-sending = Envoi en cours
alert-delivery-confirmed = Confirmé
alert-delivery-failed = Non confirmé

## <vitrine-alert>, the alert board: the evidence kept on this device, as the
## signed items the file holds.

alert-yours-title = Nous n’avons pas pu confirmer votre entrée dans le registre
alert-yours-split-view-body = Le registre présenté à votre navigateur ne correspond pas à celui que les témoins indépendants ont signé. Il peut s’agir d’une défaillance ou d’une attaque. Votre entrée peut tout de même être prise en compte, mais un tiers indépendant devrait examiner la situation.
alert-evidence-count =
    { $count ->
        [one] { $count } élément signé
       *[other] { $count } éléments signés
    }
alert-item-receipt = Votre reçu pour l’entrée #{ $index }
alert-item-receipt-detail = Signé par le registre lors de son ajout
alert-item-receipt-other = Reçu pour l’entrée #{ $index }
alert-item-checkpoint = Registre signé, taille { $size }
alert-item-checkpoint-shown = Registre qui vous a été présenté, taille { $size }
alert-item-checkpoint-shown-detail = Contient votre entrée
alert-item-checkpoint-witnessed = Registre signé par les témoins, taille { $size }
alert-item-witnessed-detail =
    { $count ->
        [one] Signé par { $count } témoin
       *[other] Signé par { $count } témoins
    }
alert-item-hubs-detail =
    { $hubs ->
        [one] Ancré dans { $hubs } pôle public
       *[other] Ancré dans { $hubs } pôles publics
    }
alert-item-promise = Promesse signée d’inclure une entrée
alert-item-policy = Politique de confiance signée
alert-item-policy-ack = Reconnaissance signée de la politique de confiance
alert-item-why-split-view = Ne peut pas être issu du registre de taille { $size }
alert-item-why-time-regression = Son heure signée est antérieure à celle du registre plus petit
alert-item-why-bad-checkpoint = N’a aucune entrée, mais n’est pas vide
alert-what-next = Que se passe-t-il ensuite ?
alert-what-next-body = Des observateurs indépendants lisent les éléments de preuve sur leur propre ordinateur. Rien n’est envoyé, sauf si vous choisissez de l’envoyer. Vous pouvez aussi conserver le fichier et le remettre à une personne de confiance : il prouve ce que le registre a signé, où qu’il soit vérifié.

## <vitrine-badge>

badge-check = Vérifier indépendamment
badge-opens = ouvre un vérificateur indépendant

## Monitor reports (specs/evidence.md, section 3). `report-kind-<kind>` says
## what a report is about, with `$subject`, the record or hub it names. A
## report is its monitor's own statement, not proof: show `report-established`
## only when monitors of enough different parties report the same thing.

report-kind-cosign-late = Depuis trop longtemps, { $subject } n’a aucune version récente signée par suffisamment de ses témoins.
report-kind-anchor-late = L’ancrage de { $subject } n’a pas eu lieu à temps : le registre ou le pôle d’ancrage est en retard, et le rapport ne peut pas dire lequel.
report-kind-unreachable = Un serveur de { $subject } ne répond plus.
report-kind-mirror-behind = La copie de { $subject } tenue par un miroir a pris du retard.
report-kind-payload-missing = Certaines données enregistrées dans { $subject } ne sont pas disponibles, et aucun avis n’indique qu’elles ont été retenues.
report-kind-payload-mismatch = Certaines données servies par { $subject } ne correspondent pas à ce qui a été enregistré.
report-kind-rule-failing = Une entrée de { $subject } enfreint une règle de son profil. Le service de veille a publié des éléments de preuve que chacun peut vérifier.
report-kind-promise-pending = { $subject } a signé la promesse d’inclure une entrée, et ne l’a pas encore incluse.
report-kind-promise-unlisted = { $subject } omet de sa liste un lot de ses promesses signées.
report-kind-promise-late = { $subject } n’a pas tenu à temps une promesse signée : le registre ou ses témoins étaient en retard, ou leurs horloges sont décalées.
report-kind-promise-misdated = { $subject } a mal daté un lot de ses promesses signées : son heure ne correspond pas à l’heure où il a été listé, ou au moment où le service de veille l’a vu pour la première fois.
report-kind-opening-missing = { $subject } n’a pas ouvert à temps un ancrage scellé à l’auditeur.
report-kind-ack-missing = { $subject } ne fournit pas sa déclaration signée de respect de la politique de confiance en vigueur.
report-kind-config-mismatch = Un isoloir s’est vu présenter des paramètres d’élection que { $subject } n’a pas enregistrés, ou qui diffèrent de ceux enregistrés.
report-kind-code-mismatch = Un site web a servi un script qu’aucune version publiée enregistrée dans { $subject } ne contient.
report-kind-unknown = Rapport de veille « { $kind } » sur { $subject }
report-established = Établi : des services de veille de suffisamment de parties différentes le signalent.
report-statement = Signalé par { $monitor }. Un rapport est une déclaration du service de veille lui-même, pas une preuve concernant qui que ce soit d’autre.

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = Le fichier du reçu est bien formé
step-policy-pinned = Le reçu correspond à la politique de confiance épinglée
step-policy-successors = On a vérifié si une politique de confiance plus récente a remplacé celle épinglée
step-policy-ack = Le registre a signé qu’il suit la politique de confiance
step-log-known = Le registre du reçu figure dans la politique
step-entry-parse = L’entrée est bien formée
step-entry-profile = L’entrée a le type du registre et les champs de ce type
step-entry-expectation = L’entrée est celle que vous attendiez
step-promise-signature = Le registre a signé la promesse d’inclure l’entrée
step-promise-inclusion = La promesse signée couvre l’entrée
step-promise-leaf = La promesse concerne l’entrée que vous attendiez
step-promise-kept = Le registre a tenu sa promesse avant l’échéance
step-issued-signature = Le reçu remis lors du dépôt est signé par le registre
step-issued-inclusion = L’entrée figure dans le reçu remis lors du dépôt
step-record-signature = Le reçu du registre est signé par le registre
step-record-inclusion = L’entrée figure dans le registre
step-receipts-match = Les reçus concernent la même entrée, à la même position
step-record-consistency = Le registre n’a fait que croître depuis le reçu remis lors du dépôt
step-record-quorum = Suffisamment de témoins indépendants ont signé le registre
step-log-consistent = Les versions du registre vues ici ne se contredisent pas
step-hub-link = La preuve du pôle { $hub } est valide
step-hub-opening = Une fois ouvert, l’ancrage scellé du pôle { $hub } correspond au registre
step-hub-anchored-checkpoint = Le registre ancré dans le pôle { $hub } est signé par le registre et ses témoins
step-hub-previous-anchor = Le pôle { $hub } détient l’ancrage scellé précédent, qui, une fois ouvert, correspond au registre
step-hub-opening-consistency = Le registre n’a fait que croître entre ses deux derniers ancrages scellés dans le pôle { $hub }
step-hub-attestation = Un auditeur a confirmé l’ancrage scellé du pôle { $hub }
step-hub-anchor-consistency = Le registre n’a fait que croître jusqu’à son ancrage dans le pôle { $hub }
step-browser-link = La preuve du pôle { $hub } pour la couche navigateur est valide et couvre l’entrée
step-browser-link-consistency = Le registre n’a fait que croître entre votre reçu et la preuve du pôle { $hub } pour la couche navigateur
step-browser-anchor = La couche navigateur détient le registre du pôle { $hub }
step-browser-consistency = Le pôle { $hub } n’a fait que croître jusqu’à sa version ancrée là où les navigateurs vérifient
step-bootstrap-link = Un pôle d’amorçage ancre le pôle { $hub }
step-unknown = Vérification « { $code } »

## Reasons, why a check failed or is still waiting (`reason-<code>`). Their
## variables are the verifier's `params`. A message uses only those that the
## verifier always passes for its code: the tier, hub or step it belongs to is
## shown next to it anyway.

# Encodings and limits
reason-bad-base64 = Une valeur base64 est mal formée.
reason-bad-hex = Une valeur hexadécimale est mal formée.
reason-bad-text = Un texte n’est pas valide ou contient un caractère interdit.
reason-bad-number = Un nombre est mal formé ou hors limites.
reason-trailing-data = Des données inattendues suivent une partie du fichier.
reason-truncated = Une partie du fichier se termine trop tôt.
reason-too-large = Un élément dépasse les limites autorisées.

# Signed notes and keys
reason-bad-note = Une note signée est mal formée.
reason-bad-key-name = Un nom de clé est mal formé.
reason-bad-vkey = Une clé publique est mal formée ou n’est pas du bon type.
reason-bad-public-key = Une clé publique n’est pas valide.
reason-missing-signature = Il manque une signature obligatoire.

# Checkpoints and witness signatures
reason-bad-checkpoint = Un point de contrôle est mal formé.
reason-bad-empty-tree = Une version signée du registre est impossible : elle n’a aucune entrée, mais son contenu n’est pas vide.
reason-wrong-origin = Une note signée nomme un registre ou un pôle autre que celui attendu.
reason-log-time-missing = Il manque à un reçu l’heure signée du registre, il n’a donc pas pu être vérifié.
reason-cosignature-in-future = Une signature de témoin porte une date future, elle a donc été ignorée.
reason-quorum-not-met = Trop peu de témoins indépendants ont signé pour l’instant.

# Proofs
reason-bad-proof = Une preuve est mal formée.
reason-missing-extra = Un reçu ne contient pas l’entrée.
reason-index-out-of-range = La position de l’entrée se situe au-delà de la fin du registre.
reason-inclusion-failed = La preuve que l’entrée figure dans le registre n’est pas valide.
reason-consistency-failed = La preuve que le registre n’a fait que croître n’est pas valide.
reason-split-view = Deux versions signées du registre ont la même taille mais des contenus différents.

# Entries and expectations
reason-bad-entry = L’entrée est mal formée.
reason-wrong-profile = Le type de l’entrée diffère de celui du registre à cette position.
reason-bad-entry-layout = Les champs de l’entrée ne correspondent pas à son type.
reason-entry-mismatch = L’entrée n’est pas celle que vous attendiez.
reason-expectation-incomplete = La page n’a pas donné assez d’informations sur l’entrée pour la vérifier.
reason-expectation-unknown-field = La page a indiqué un champ que ce type d’entrée ne possède pas.
reason-expectation-unsupported = Ce vérificateur ne prend pas en charge les champs de ce type d’entrée.
reason-receipts-disagree = Les reçus du fichier concernent des entrées ou des positions différentes.

# Promises
reason-bad-promise = La promesse est mal formée.
reason-promise-policy-unknown = La promesse désigne une politique de confiance qui n’est ni celle épinglée ni une politique qui l’a remplacée.
reason-promise-mmd-too-large = La promesse accorde un délai plus long que la politique ne le permet.
reason-promise-leaf-mismatch = La promesse concerne une autre entrée.
reason-promise-time = Le registre a daté sa promesse à plus d’une minute du moment où elle est arrivée : elle ne compte donc pas comme une promesse.
reason-promise-pending = Le registre a promis d’inclure l’entrée. L’échéance de son reçu n’est pas encore arrivée.
reason-promise-deadline-passed = L’échéance de la promesse est passée et il n’y a pas encore de reçu.
reason-promise-kept-unproven = Rien dans le fichier ne montre que la promesse ait été tenue dans les délais.
reason-broken-promise = Le registre a promis d’inclure l’entrée avant l’échéance ({ TIME($deadline) }), mais sa propre heure signée ({ TIME($logTime) }) montre qu’il ne l’avait toujours pas fait.
reason-bad-promise-list = La liste des promesses que le registre a faites en une heure est mal formée ou ne leur correspond pas, elle n’a donc pas pu être vérifiée.

# Receipt chains
reason-malformed-chain = Le fichier du reçu est mal formé.
reason-duplicate-block = Le fichier du reçu contient deux fois la même partie.
reason-no-receipt = Le fichier ne contient ni promesse ni reçu.
reason-policy-mismatch = Le reçu désigne une autre politique de confiance que celle épinglée.
reason-policy-draft = La politique de confiance n’est encore qu’un brouillon, et un brouillon n’est jamais valide.
reason-bad-policy-ack = La déclaration signée par laquelle le registre affirme suivre cette politique de confiance est mal formée ou ne lui correspond pas.
reason-unknown-log = Le reçu désigne un registre qui ne figure pas dans la politique.
reason-unknown-hub = Une partie désigne un pôle d’ancrage qui ne figure pas dans la politique, elle a donc été ignorée.
reason-consistency-missing = Il manque une preuve que le registre n’a fait que croître.
reason-consistency-mismatch = Une preuve que le registre n’a fait que croître ne correspond pas aux versions qu’elle relie.
reason-waiting-for-cosignatures = En attente de la signature du registre par les témoins.
reason-waiting-for-record = En attente du registre signé par les témoins.
reason-no-signed-time = Il n’y a pas encore d’heure signée, les échéances ne peuvent donc pas être évaluées.
reason-deadline-passed = L’échéance est passée, selon l’heure signée.
reason-record-invalid = Vérification impossible, car les preuves du registre n’ont pas pu être vérifiées.
reason-bad-reference = Un lien vers un reçu est mal formé.
reason-reference-unpinned = Aucune politique de confiance épinglée sur cet appareil ne correspond à ce lien vers un reçu.
reason-reference-ambiguous = Ce lien vers un reçu correspond à plusieurs politiques de confiance épinglées sur cet appareil, il n’a donc pas été utilisé.

# The booth's configuration check
reason-bad-config = Les paramètres de l’élection, ou l’avis d’ouverture du vote, sont mal formés, non signés ou insuffisamment signés par les témoins : l’isoloir ne chiffrera donc aucun bulletin avec eux.
reason-config-mismatch = Les paramètres enregistrés de l’élection ne correspondent pas à l’événement, à l’élection, à la clé de l’élection, aux modèles de bulletin, à la politique de confiance ou au logiciel de l’isoloir, ou ne sont pas ceux en vigueur à l’ouverture du vote : l’isoloir ne chiffrera donc aucun bulletin.

# Keys logs
reason-bad-key-statement = Une déclaration d’un registre de clés est mal formée, désigne un autre registre, ne correspond pas à son entrée ou n’a pas les signatures nécessaires : elle ne compte donc pas.
reason-signed-by-failed = Une déclaration n’est pas signée par sa clé, la clé était révoquée ou n’était pas valide lors de l’enregistrement de l’entrée, ou trop peu d’autres clés valides l’ont aussi signée.
    .not-ed25519 = La déclaration, ou la clé censée la signer, est mal formée ou n’est pas du bon type.
    .not-signed = La déclaration n’est pas signée par sa clé.
    .revoked = La clé qui a signé la déclaration avait déjà été révoquée lors de l’enregistrement de l’entrée.
    .not-valid = La clé qui a signé la déclaration n’était pas valide lors de l’enregistrement de l’entrée.
    .cosigners = Trop peu d’autres clés valides ont aussi signé la déclaration : { $have } sur les { $need } nécessaires.

# Upgrades
reason-log-quiet = Le registre est en période de silence et ne montre rien de plus récent avant la fin de celle-ci, certaines preuves attendront donc jusque-là.
reason-log-private = Le registre est privé : seuls les auditeurs peuvent le lire, ses preuves passent donc par le site web de l’événement.
reason-monitor-evidence = Le service de veille { $monitor } a publié des éléments de preuve montrant que cette version du registre contredit celle qu’il détient. Ces éléments n’ont pas encore été vérifiés ici.

# Successor policies
reason-successors-unchecked = On n’a pas encore vérifié si une politique de confiance plus récente a remplacé celle-ci, rien n’apparaît donc comme vérifié.
reason-bad-policy-proofs = Les preuves concernant des politiques de confiance plus récentes sont mal formées ou ne sont pas valides.
reason-successor-rejected = Une politique de confiance plus récente a été publiée, mais elle enfreint les règles de remplacement d’une politique, la précédente reste donc en vigueur.
reason-policy-equivocation = Les autorités de la politique de confiance ont signé deux remplacements différents de celle-ci, ce qui prouve qu’elles se sont contredites. Le premier publié fait foi.

# Anchor hubs
reason-bad-subject = Le nom ou la clé sous lequel un pôle d’ancrage conserve les ancrages d’un registre est mal formé : il ne compte donc pas.
reason-waiting-for-anchor = En attente de l’ancrage du registre par le pôle d’ancrage.
reason-hub-quorum-not-met = Trop peu de témoins du pôle d’ancrage ont signé pour l’instant.
reason-bad-hub-link = La preuve du pôle d’ancrage est mal formée ou n’est pas valide.
reason-hub-link-mismatch = La preuve du pôle d’ancrage porte sur autre chose.
reason-hub-index-wrong = Les témoins du pôle { $hub } ont signé un index qui pointe vers une mauvaise entrée pour ce registre : ils ont donc signé sans vérifier.
reason-map-proof-failed = La preuve d’inclusion dans la table du pôle d’ancrage n’est pas valide.
reason-subject-rotated = La clé du registre a changé auprès de ce pôle d’ancrage. La nouvelle politique de confiance est nécessaire.
reason-rotation-unauthorized = Dans le pôle { $hub }, la clé du registre a été changée par une entrée qu’aucune politique de confiance connue n’autorise.
reason-anchor-behind-record = Le pôle d’ancrage détient une version du registre plus ancienne que votre reçu.
reason-anchor-quorum-not-met = Le registre ancré ne porte pas assez de signatures de témoins.
reason-hub-link-stale = La preuve du pôle { $hub } que détient le registre est bien plus ancienne que la dernière version du pôle : le registre devrait déjà en avoir une plus récente.
reason-bad-blinded-anchor = Un ancrage scellé n’est pas valide.
reason-opening-missing = Le fichier ne contient pas encore ce qui ouvre l’ancrage scellé.
reason-bad-opening = Ce qui devrait ouvrir l’ancrage scellé ne lui correspond pas.
reason-previous-anchor-missing = Le fichier ne contient pas encore l’ancrage scellé précédent du pôle { $hub }, ou ce qui l’ouvre.
reason-bad-previous-anchor = L’ancrage scellé précédent n’est pas l’ancrage du registre juste avant celui-ci, il n’a donc pas pu être vérifié.
reason-attestation-missing = Aucun auditeur n’a encore confirmé l’ancrage scellé du pôle { $hub }. Il reste en attente jusqu’à ce qu’un auditeur le fasse, et n’est jamais considéré comme en retard.
reason-attestation-not-covering = La confirmation de l’auditeur pour le pôle { $hub } couvre les ancrages scellés { $from } à { $to }, pas encore le numéro { $seq }.
reason-bad-attestation = La confirmation d’un auditeur n’a pas pu être vérifiée : elle est mal formée, n’est pas signée par un auditeur de la politique de confiance, ou ne correspond pas à l’ancrage scellé.
reason-hub-entry-refused = Un pôle d’ancrage a enregistré une entrée qui enfreint les règles du pôle : cette entrée ne compte donc pas.

# Browser layer
reason-browser-test-only = La couche navigateur n’est ici qu’un test : elle est gérée par l’opérateur.
reason-waiting-for-browser-anchor = En attente de la couche navigateur. Elle est prévue d’ici quelques minutes.
reason-pair-not-covering = La dernière preuve du registre pour la couche navigateur, issue du pôle { $hub }, est antérieure à l’entrée. La suivante la couvrira.
reason-browser-below-link = La couche navigateur montre une version du pôle { $hub } plus ancienne que la preuve à laquelle elle est associée : les deux ne concordent pas.
reason-waiting-for-hub-tier = En attente du pôle { $hub } : dans un événement privé, la couche navigateur ne compte qu’une fois le pôle vérifié.
reason-bad-browser-pair = Les preuves du registre pour la couche navigateur sont mal formées.
reason-bad-browser-anchor = Un ancrage dans la couche navigateur est mal formé ou ne correspond pas.
reason-bad-waict-proof = La preuve de la couche navigateur n’est pas valide.
reason-waict-quorum-not-met = Trop peu de témoins de la couche navigateur ont signé.
reason-unknown-waict-service = L’ancrage dans la couche navigateur provient d’un service qui ne figure pas dans la politique.
reason-waict-service-not-independent = La couche navigateur est gérée par l’opérateur, elle ne compte donc pas.
reason-bad-bootstrap-link = La preuve d’un pôle d’amorçage est mal formée ou n’est pas valide.

# Trust policies
reason-policy-syntax = Une ligne de la politique de confiance est mal formée.
reason-policy-unknown-keyword = Une ligne de la politique de confiance commence par un mot inconnu.
reason-policy-count = Une ligne de la politique de confiance apparaît trop souvent, ou pas du tout.
reason-policy-undefined-name = La politique de confiance utilise un nom avant de le définir.
reason-policy-duplicate-name = La politique de confiance définit deux fois le même nom.
reason-policy-invalid = La politique de confiance enfreint l’une de ses règles.
reason-policy-unsafe-quorum = Le quorum de témoins de la politique de confiance n’est pas sûr.
reason-policy-unsigned = La politique de confiance ne porte pas assez de signatures de ses autorités.

# Payloads and redaction
reason-payload-mismatch = Les données qu’un serveur a envoyées pour une entrée ne correspondent pas à ce que le registre en conserve : ce ne sont donc pas les données enregistrées. Un miroir du registre a peut-être les bonnes données.
reason-payload-missing = Des données enregistrées pour une entrée ne sont pas disponibles, et aucun avis valide de retrait de données n’indique qu’elles ont été retenues. Un miroir du registre les a peut-être encore.
reason-bad-payload-bundle = Les données qu’un serveur a envoyées pour un lot d’entrées sont mal formées ou ne correspondent pas à ces entrées : elles n’ont donc pas pu être vérifiées. Un miroir du registre les a peut-être.
reason-bad-notice = Un avis de retrait de données est mal formé : il ne compte donc pas.
reason-notice-unsigned = Un avis de retrait de données ne porte pas assez de signatures des autorités que la politique de confiance désigne pour ces avis : il ne compte donc pas.
    .no-redaction = La politique de confiance n’autorise aucun retrait de données : un avis de retrait de données ne compte donc pas.
reason-notice-mismatch = Un avis de retrait de données ne correspond ni aux données retenues en vertu de cet avis ni à sa copie enregistrée, ou il désigne des données qui ne peuvent pas être retirées : il ne compte donc pas.
    .profile = Un avis de retrait de données désigne une entrée dont les données ne peuvent pas être retirées, comme un bulletin de vote : il ne compte donc pas.
reason-notice-not-applied = Un avis de retrait de données n’a aucun effet : il ne renvoie pas au dernier avis appliqué à la même entrée, il en répète un précédent, ou il porte une date antérieure à l’enregistrement de cet avis.
reason-bad-notice-bundle = La preuve qu’un avis de retrait de données a été enregistré est mal formée, n’est pas valide ou ne porte pas assez de signatures de témoins : l’avis ne compte donc pas.

# Evidence files
reason-bad-evidence = Le fichier des éléments de preuve est mal formé, ou il lui manque une partie que son type exige.
reason-evidence-unknown-kind = Le fichier des éléments de preuve est d’un type que ce vérificateur ne connaît pas.
reason-evidence-unpinned = Le fichier des éléments de preuve concerne une politique de confiance que cet appareil n’a pas épinglée.
reason-evidence-wrong-subject = Le fichier des éléments de preuve porte sur un registre ou un pôle auquel son type ne s’applique pas selon sa politique de confiance.
reason-evidence-policy-mismatch = Une partie du fichier des éléments de preuve concerne une autre politique de confiance que celle du fichier.
reason-not-proven = Les signatures des éléments de preuve sont valides, mais elles ne montrent pas le problème allégué.
reason-needs-scan = Cela ne peut être tranché qu’en lisant les entrées du registre, ce que cette vérification n’a pas fait.
reason-rule-unsupported = Les éléments de preuve invoquent une règle que ce vérificateur ne sait pas appliquer. Un vérificateur complet peut la vérifier.
reason-faulty-witness = Ce témoin a signé deux versions qui se contredisent, ou une version d’un pôle comportant une entrée non conforme, ce qui prouve qu’il est défaillant.
reason-trust-assumption-failed = Assez de témoins ont signé les versions contradictoires pour atteindre le quorum : davantage de témoins sont défaillants que ne le suppose la politique de confiance.
reason-misbehaviour-proven = Les éléments de preuve prouvent le problème allégué, selon la politique de confiance du fichier.

reason-unknown = Motif « { $code } »

# Shared infrastructure. Draft translations need native-speaker review.
reason-bad-operator-list = The infrastructure list is damaged or uses an unsupported format.
reason-operator-list-refused = The infrastructure list could not be accepted under the pinned authorities, validity window or update history.
reason-bad-shared-submission = The shared-log request or enrolment is damaged or does not follow the format.
reason-shared-submission-refused = The shared log could not accept this request under its pinned policy, submitter key or namespace.

# New metadata reason: native translation review needed outside English.
reason-profile-meaning-unknown = The profile meaning is not available for validation.

## extension

# The names of the anchor hubs and the browser layer in the extension's compact receipt chain.
tier-hubs-short = Pôles
tier-browser-short = Navigateur
