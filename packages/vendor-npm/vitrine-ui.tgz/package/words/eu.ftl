# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Basque (eu).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Barneratuta
fact-unchanged = Aldatu gabe
fact-same-for-everyone = Guztientzat berdina

fact-state-done = Eginda
fact-state-promised = Hitzemanda
fact-state-pending = Zain
fact-state-late = Atzeratuta
fact-state-invalid = Ezin izan da egiaztatu
fact-state-failed = Huts egin du
fact-state-checking = Egiaztatzen

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Zure sarrera erregistroan dago.
fact-included-promised = Erregistroak zure sarrera barneratzeko promesa sinatu du.
fact-included-pending = Zure sarrera erregistroan barneratzeko zain dago.
fact-included-late = Erregistroak honezkero barneratu beharko zukeen zure sarrera.
fact-included-invalid = Zure sarrera erregistroan dagoela erakusten duen froga ezin izan da egiaztatu: datuek hondatuta dirudite.
fact-included-failed = Erregistroak berak egindako sinadurek elkar kontraesaten dute zure sarrerari buruz.
fact-unchanged-done = Lekuko independenteek erregistroa sinatu dute; beraz, bertan ezer ezin da aldatu inor ohartu gabe.
fact-unchanged-pending = Erregistroa lekuko independenteek sinatzeko zain dago.
fact-unchanged-late = Lekukoek honezkero sinatu beharko zuketen erregistroa.
fact-unchanged-invalid = Erregistroaren historiari buruzko frogak ezin izan dira egiaztatu: datuek hondatuta dirudite.
fact-unchanged-failed = Erregistroaren historiari buruzko froga sinatuek elkar kontraesaten dute.
fact-same-for-everyone-done = Egiaztatzen duten guztiei erregistro hau bera erakusten zaie.
fact-same-for-everyone-pending = Erregistroa guztiek egiazta dezaketen tokian ainguratzeko zain dago.
fact-same-for-everyone-late = Erregistroa honezkero ainguratuta egon beharko litzateke guztiek egiazta dezaketen tokian.
fact-same-for-everyone-invalid = Aingurak ezin izan dira egiaztatu: datuek hondatuta dirudite.
fact-same-for-everyone-failed = Froga sinatuek erakusten dute guztiek ez dutela erregistro bera ikusten.

## Tiers

tier-record = Erregistroa
tier-witnesses = Lekukoak
tier-hubs = Aingura-guneak
tier-browser = Nabigatzaile-geruza
tier-policy = Politika
tier-entry = Sarrera

tier-status-verified = Egiaztatuta
tier-status-pending = Zain
tier-status-late = Atzeratuta
tier-status-invalid = Ezin izan da egiaztatu
tier-status-failed = Huts egin du
tier-status-unused = Ez da erabiltzen
tier-status-checking = Egiaztatzen
tier-status-promised = Hitzemanda

tier-record-verified = Zure sarrera erregistro sinatuan dago.
tier-record-promised = Erregistroak zure sarrera barneratzeko promesa sinatu du.
tier-record-pending = Erregistroak ez du oraindik zure sarrera barneratu.
tier-record-late = Erregistroak honezkero barneratu beharko zukeen zure sarrera.
tier-record-invalid = Erregistroaren frogek hondatuta dirudite; beraz, ezin izan dira egiaztatu.
tier-record-failed = Erregistroak elkar kontraesaten duten frogak sinatu ditu.
tier-record-checking = Erregistroaren frogak egiaztatzen.
tier-witnesses-verified = Behar adina lekuko independentek sinatu dute erregistroa.
tier-witnesses-pending = Lekukoen sinaduren zain. Segundo batzuk behar dira.
tier-witnesses-late = Lekukoek honezkero sinatu beharko zuketen.
tier-witnesses-invalid = Lekukoen sinadurek hondatuta dirudite; beraz, ezin izan dira egiaztatu.
tier-witnesses-failed = Lekukoek zurea kontraesaten duen erregistro bat sinatu dute.
tier-witnesses-checking = Lekukoen sinadurak egiaztatzen.
tier-hubs-verified = Erregistroa aingura-gune guztietan dago.
tier-hubs-pending = Aingura-guneetarako bidean. Segundo batzuk behar dira.
tier-hubs-late = Erregistroa honezkero aingura-guneetan egon beharko litzateke.
tier-hubs-invalid = Aingura-gune baten erantzunak hondatuta dirudi; beraz, ezin izan da egiaztatu.
tier-hubs-failed = Aingura-gune batek zurea kontraesaten duen erregistro sinatu bat dauka.
tier-hubs-unused = Politika honek ez du aingura-gunerik erabiltzen.
tier-hubs-checking = Aingura-guneak egiaztatzen.
tier-browser-verified = Nabigatzaileek egiaztatzen duten tokian ainguratuta.
tier-browser-pending = Minutu gutxi barru iritsiko da. Ez duzu itxaron beharrik.
tier-browser-late = Honezkero ainguratuta egon beharko litzateke nabigatzaileek egiaztatzen duten tokian.
tier-browser-invalid = Nabigatzaile-geruzaren erantzunak hondatuta dirudi; beraz, ezin izan da egiaztatu.
tier-browser-failed = Nabigatzaileek egiaztatzen duten tokiko aingura sinatu batek erregistroa kontraesaten du.
tier-browser-unused = Politika honek ez du nabigatzaile-geruza independenterik erabiltzen.
tier-browser-checking = Nabigatzaile-geruza egiaztatzen.
tier-test = Proba soilik: operadoreak kudeatzen du; beraz, ez da kontuan hartzen.
tier-deadline = { TIME($deadline) } baino lehen espero da
hub-test = proba

## The one-line status

status-verified = Egiaztatuta
status-checking = Egiaztatzen…
status-pending = Zain
status-late = Atzeratuta
status-invalid = Ezin izan da egiaztatu
status-failed = Huts egin du
status-summary-verified = Barneratuta, aldatu gabe eta guztientzat berdina.
status-summary-checking = Hartu-agiriaren frogak nabigatzaile honetan egiaztatzen.
status-summary-pending = Froga batzuk bidean daude oraindik. Ez duzu itxaron beharrik.
status-summary-late = Honezkero froga batzuk iritsita egon beharko lirateke.
status-summary-invalid = Datu batzuk ezin izan dira egiaztatu: fitxategiak edo zerbitzariaren erantzunak hondatuta dirudi. Horrek ez du erakusten inork tranparik egin duenik.
status-summary-failed = Froga sinatuek elkar kontraesaten dute. Gorde ebidentzia.

## <vitrine-receipt>

receipt-label = Hartu-agiria
receipt-words-label = Hartu-agiriaren hitzak
receipt-entry = { $log } erregistroko { $index }. sarrera
receipt-entry-promised = { $log } erregistroak hitzemandako sarrera
receipt-provenance-page = Webgune honek egiaztatuta
receipt-provenance-page-hint = Webgune honek bere erregistroa egiaztatu du. Ziur egoteko, egiaztatu modu independentean.
receipt-provenance-independent = Webgunetik kanpo, modu independentean egiaztatuta
receipt-facts-heading = Frogek erakusten dutena
receipt-chain-heading = Noraino iritsi den
receipt-compare-heading = Alderatu iragarki ofizialarekin
receipt-compare-hint = Hitz eta lekuko hauek bat etorri behar dute agintaritzak argitaratutakoekin, adibidez hauteskunde-iragarkian.
receipt-policy-words = Politikaren hitzak
receipt-policy-id = Politikaren IDa
receipt-event = Ekitaldia
receipt-witnesses = Lekukoak
receipt-witness-party = kudeatzailea: { $party }
receipt-hubs = Aingura-guneak
receipt-clock-warning = Gailu honetako erlojua minutu bat baino gehiago dago aurreratuta edo atzeratuta. Epeak sinatutako orduaren arabera neurtzen dira, ez erloju honen arabera.
receipt-action-check = Egiaztatu modu independentean
receipt-action-download = Deskargatu hartu-agiria
receipt-action-retry = Egiaztatu berriro
receipt-invalid = Datu batzuk ezin izan dira egiaztatu: fitxategiak edo zerbitzariaren erantzunak hondatuta dirudi. Horrek ez du erakusten inork tranparik egin duenik. Berriro egiazta dezakezu, edo modu independentean.
receipt-no-expect = Orri honek ez du zehaztu zein sarrera espero den; beraz, ezin da erakutsi hartu-agiri hau zurea denik.
receipt-error = Hartu-agiri hau ezin izan da egiaztatu.
receipt-empty = Ez dago hartu-agiririk oraindik.
receipt-announce = { $tier }: { $status }.

## <vitrine-proof-steps>

steps-heading = Egiaztapen guztiak
steps-summary =
    { $total ->
        [one] { $total } egiaztapenetik { $passed } gaindituta
       *[other] { $total } egiaztapenetatik { $passed } gaindituta
    }
steps-result-passed = Gaindituta
steps-result-failed = Huts egin du
steps-result-not-run = Oraindik egin gabe
steps-show-details = Erakutsi xehetasunak
steps-hide-details = Ezkutatu xehetasunak
steps-objects = Tartean dauden objektu sinatuak: { $objects }
steps-evidence = Gorde ebidentzia
steps-empty = Ez dago egiaztapenik oraindik.

## <vitrine-chain>

chain-label = Hartu-agiriaren katea

## <vitrine-alert>

alert-label = Frogatutako arazoa
alert-kind-split-view-title = Erregistroa desberdin erakutsi zaie pertsona desberdinei
alert-kind-split-view-body = Erregistroaren bi bertsio daude, biak bere operadoreak sinatuak, eta ezin dira biak egiazkoak izan. Akats bat edo eraso bat izan daiteke. Baliteke zure sarrerak oraindik ere balio izatea, baina independentea den norbaitek aztertu beharko luke.
alert-kind-broken-promise-title = Erregistroak sinatutako promesa bat hautsi du
alert-kind-broken-promise-body = Erregistroak sarrera bat epe jakin baten barruan barneratzea hitzeman zuen, eta bere sinadurek berek erakusten dute ez zuela bete. Independentea den norbaitek aztertu beharko luke.
alert-kind-bad-entry-title = Erregistroak bere arauak hausten dituen sarrera bat dauka
alert-kind-bad-entry-body = Erregistroan sinatutako sarrera batek bere profileko arau bat hausten du. Independentea den norbaitek aztertu beharko luke.
alert-kind-stale-anchor-title = Erregistroa ez da garaiz ainguratu
alert-kind-stale-anchor-body = Erregistroak edo aingura-gune batek politikak baimentzen duena baino denbora gehiago behar izan du erregistroa ainguratzeko. Horrek hitzemandako zerbitzu-maila bat urratzen du, ez erregistroa bera.
alert-kind-hub-entry-title = Aingura-gune batek baztertu beharko zukeen sarrera bat onartu du
alert-kind-hub-entry-body = Aingura-gune bateko lekukoek gunearen erregistro bat sinatu dute, gunearen arauak hausten dituen sarrera bat duena; beraz, haietako batek gutxienez egiaztatu gabe sinatu du.
alert-kind-unknown-title = Arazo bat aurkitu da
alert-kind-unknown-body = Ebidentziak orri honek ezagutzen ez duen motako arazo bat erakusten du: { $kind }.
alert-not-proven-title = Fitxategi honek ez du arazorik frogatzen
alert-not-proven-body = Fitxategia egiaztatu da, eta ez du arazorik frogatzen. Ez da ebidentzia.
alert-unpinned-title = Fitxategi hau gailu honetan finkatu ez den politika bati dagokio
alert-unpinned-body = Ezin da froga gisa erakutsi gailu honetan. Alderatu fitxategiaren politikaren hitzak iragarki ofizialarekin, eta finkatu politika hori fitxategia berriro egiaztatu aurretik.
alert-invalid-title = Fitxategi hau ezin izan da egiaztatu
alert-invalid-body = Fitxategiak hondatuta dirudi. Horrek ez du erakusten inork tranparik egin duenik.
alert-proven-under = Hitz hauek dituen politikaren arabera frogatuta:
alert-file-policy-words = Fitxategiaren politikaren hitzak:
alert-parties = Arduradunak, beren sinaduren arabera: { $parties }
alert-evidence-heading = Gailu honetan gordetako ebidentzia
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } KB
alert-evidence-hint = Edonork egiazta dezake fitxategi hau bere ordenagailuan. Erregistroko objektu sinatuak soilik ditu.
alert-download = Deskargatu ebidentzia-fitxategia
alert-send = Bidali zaintza-zerbitzuei
alert-monitors-heading = Politikak izendatutako zaintza-zerbitzuak
alert-confirm-heading = Ebidentzia bidali?
alert-confirm-body =
    { $count ->
        [one] Ebidentzia-fitxategia zaintza-zerbitzu honi bidaliko zaio. Fitxategia ikusiko du, baita gailu honetatik bidali dela ere.
       *[other] Ebidentzia-fitxategia { $count } zaintza-zerbitzu hauei bidaliko zaie. Fitxategia ikusiko dute, baita gailu honetatik bidali dela ere.
    }
alert-confirm-send = Bai, bidali
alert-confirm-cancel = Utzi
alert-sending = Ebidentzia zaintza-zerbitzuetarako bidean dago.
alert-no-monitors = Politikak ez du zaintza-zerbitzurik izendatzen. Gorde fitxategia eta eman behatzaile bati.
alert-delivery-waiting = Berrespenaren zain
alert-delivery-sending = Bidaltzen
alert-delivery-confirmed = Berretsita
alert-delivery-failed = Berretsi gabe

## <vitrine-badge>

badge-check = Egiaztatu modu independentean
badge-opens = egiaztatzaile independente bat irekitzen du

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = Hartu-agiriaren fitxategia ondo osatuta dago
step-policy-pinned = Hartu-agiria finkatutako konfiantza-politikari dagokio
step-log-known = Hartu-agiriaren erregistroa politikan jasota dago
step-entry-parse = Sarrera ondo osatuta dago
step-entry-profile = Sarrerak erregistroaren mota du, baita mota horren eremuak ere
step-entry-expectation = Sarrera zuk espero zenuena da
step-promise-signature = Erregistroak sarrera barneratzeko promesa sinatu du
step-promise-inclusion = Sinatutako promesak sarrera jasotzen du
step-promise-leaf = Promesa zuk espero zenuen sarrerari dagokio
step-promise-kept = Erregistroak epearen barruan bete du bere promesa
step-issued-signature = Bidaltzean emandako hartu-agiria erregistroak sinatuta dago
step-issued-inclusion = Sarrera bidaltzean emandako hartu-agirian dago
step-record-signature = Erregistroaren hartu-agiria erregistroak sinatuta dago
step-record-inclusion = Sarrera erregistroan dago
step-receipts-match = Hartu-agiriak sarrera berari eta posizio berari dagozkie
step-record-consistency = Bidaltzean emandako hartu-agiriaz geroztik, erregistroak hazi besterik ez du egin
step-record-quorum = Behar adina lekuko independentek sinatu dute erregistroa
step-hub-link = { $hub } gunearen frogak egiaztapena gainditzen du
step-hub-opening = { $hub } guneko aingura zigilatuak, irekitzean, erregistroa erakusten du
step-hub-anchored-checkpoint = { $hub } gunean ainguratutako erregistroa erregistroak berak eta haren lekukoek sinatuta dago
step-hub-anchor-consistency = Erregistroak hazi besterik ez du egin { $hub } guneko bere aingurara arte
step-browser-anchor = Nabigatzaile-geruzak { $hub } gunearen erregistroa dauka
step-browser-consistency = { $hub } guneak hazi besterik ez du egin bere nabigatzaile-aingurara arte
step-bootstrap-link = Abiarazte-gune batek { $hub } gunea ainguratzen du
step-bootstrap-consistency = { $hub } guneak hazi besterik ez du egin bere abiarazte-aingurara arte
step-unknown = «{ $code }» egiaztapena

## Reasons, why a check failed or is still waiting (`reason-<code>`). They
## take no variables: the tier, hub or step they belong to is shown next to them.

# Encodings and limits
reason-bad-base64 = Base64 balio bat gaizki osatuta dago.
reason-bad-hex = Balio hamaseitar bat gaizki osatuta dago.
reason-bad-text = Testu zati bat ez da baliozkoa, edo debekatutako karaktereren bat du.
reason-bad-number = Zenbaki bat gaizki osatuta dago edo tartetik kanpo dago.
reason-trailing-data = Fitxategiaren zati baten ondoren ustekabeko datuak daude.
reason-truncated = Fitxategiaren zati bat goizegi amaitzen da.
reason-too-large = Zerbait mugek baimentzen dutena baino handiagoa da.

# Signed notes and keys
reason-bad-note = Ohar sinatu bat gaizki osatuta dago.
reason-bad-key-name = Gako-izen bat gaizki osatuta dago.
reason-bad-vkey = Gako publiko bat gaizki osatuta dago edo mota okerrekoa da.
reason-bad-public-key = Gako publiko bat ez da baliozkoa.
reason-duplicate-signature = Ohar batek sinadura bera bi aldiz dauka.
reason-bad-signature = Sinadura batek ez du egiaztapena gainditzen.
reason-missing-signature = Egon behar duen sinadura bat falta da.

# Checkpoints and witness signatures
reason-bad-checkpoint = Kontrol-puntu bat gaizki osatuta dago.
reason-wrong-origin = Ohar sinatu batek espero zenaz bestelako erregistro edo gune bat aipatzen du.
reason-cosignature-in-future = Lekuko-sinadura batek etorkizuneko data du; beraz, ez da kontuan hartu.
reason-quorum-not-met = Oraindik ez dute behar adina lekuko independentek sinatu.

# Proofs
reason-bad-proof = Froga bat gaizki osatuta dago.
reason-missing-extra = Hartu-agiri batek ez dauka sarrera.
reason-index-out-of-range = Sarreraren posizioa erregistroaren amaieratik haratago dago.
reason-inclusion-failed = Sarrera erregistroan dagoela erakusten duen frogak ez du egiaztapena gainditzen.
reason-consistency-failed = Erregistroak hazi besterik ez duela egin erakusten duen frogak ez du egiaztapena gainditzen.
reason-split-view = Erregistroaren bi bertsio sinatuk tamaina bera dute, baina eduki desberdina.

# Entries and expectations
reason-bad-entry = Sarrera gaizki osatuta dago.
reason-wrong-profile = Sarreraren mota ez dator bat erregistroak posizio horretan duen motarekin.
reason-bad-entry-layout = Sarreraren eremuak ez datoz bat haren motarekin.
reason-entry-mismatch = Sarrera ez da zuk espero zenuena.
reason-expectation-incomplete = Orriak ez du sarrerari buruz behar adina zehaztu hura egiaztatzeko.
reason-expectation-unknown-field = Orriak sarrera mota honek ez duen eremu bat aipatu du.
reason-expectation-unsupported = Egiaztatzaile honek ezin ditu sarrera mota honen eremuak egiaztatu.
reason-receipts-disagree = Fitxategiko hartu-agiriak sarrera edo posizio desberdinei dagozkie.

# Promises
reason-bad-promise = Promesa gaizki osatuta dago.
reason-promise-mmd-too-large = Promesak politikak baimentzen duena baino atzerapen handiagoa onartzen du.
reason-promise-leaf-mismatch = Promesa beste sarrera bati dagokio.
reason-promise-pending = Erregistroak sarrera barneratzea hitzeman du. Oraindik ez da hartu-agiria iristeko garaia.
reason-promise-deadline-passed = Promesaren epea igaro da, eta oraindik ez dago hartu-agiririk.
reason-promise-kept-unproven = Fitxategiko ezerk ez du erakusten promesa garaiz bete zenik.

# Receipt chains
reason-malformed-chain = Hartu-agiriaren fitxategia gaizki osatuta dago.
reason-duplicate-block = Hartu-agiriaren fitxategiak zati bera bi aldiz dauka.
reason-no-receipt = Fitxategiak ez dauka ez promesarik ez hartu-agiririk.
reason-policy-mismatch = Hartu-agiriak finkatutakoa ez den beste konfiantza-politika bat aipatzen du.
reason-unknown-log = Hartu-agiriak politikan ez dagoen erregistro bat aipatzen du.
reason-unknown-hub = Zati batek politikan ez dagoen aingura-gune bat aipatzen du; beraz, ez da kontuan hartu.
reason-consistency-missing = Erregistroak hazi besterik ez duela egin erakusten duen froga bat falta da.
reason-consistency-mismatch = Erregistroak hazi besterik ez duela egin erakusten duen froga bat ez dator bat lotzen dituen bertsioekin.
reason-waiting-for-cosignatures = Erregistroa lekukoek sinatzeko zain.
reason-waiting-for-record = Lekukoek sinatutako erregistroaren zain.
reason-no-signed-time = Oraindik ez dago ordu sinaturik; beraz, ezin dira epeak neurtu.
reason-deadline-passed = Epea igaro da, sinatutako orduaren arabera.
reason-record-invalid = Ezin izan da egiaztatu, erregistroaren frogak ezin izan direlako egiaztatu.
reason-bad-reference = Hartu-agiri baterako esteka bat gaizki osatuta dago.

# Anchor hubs
reason-waiting-for-anchor = Erregistroa aingura-gunean ainguratzeko zain.
reason-hub-quorum-not-met = Aingura-gunearen lekuko-sinadurak ez dira oraindik nahikoak.
reason-bad-hub-link = Aingura-gunearen froga gaizki osatuta dago edo ez du egiaztapena gainditzen.
reason-hub-link-mismatch = Aingura-gunearen froga beste zerbaiti buruzkoa da.
reason-map-proof-failed = Aingura-gunearen mapa-frogak ez du egiaztapena gainditzen.
reason-subject-rotated = Erregistroaren gakoa aldatu egin da aingura-gune honetan. Konfiantza-politika berriagoa behar da.
reason-anchor-behind-record = Aingura-guneak zure hartu-agirian dagoena baino erregistro-bertsio zaharragoa dauka.
reason-anchor-quorum-not-met = Ainguratutako erregistroak ez dauka behar adina lekuko-sinadurarik.
reason-bad-blinded-anchor = Aingura zigilatu batek ez du egiaztapena gainditzen.
reason-opening-missing = Fitxategiak oraindik ez dauka aingura zigilatua irekitzen duena.
reason-bad-opening = Aingura zigilatua ireki beharko lukeena ez dator bat harekin.

# Browser layer
reason-browser-test-only = Hemen nabigatzaile-geruza proba bat baino ez da: operadoreak kudeatzen du.
reason-waiting-for-browser-anchor = Nabigatzaile-geruzaren zain. Minutu gutxi barru iritsiko da.
reason-browser-behind-anchor = Nabigatzaile-geruzak aingura-guneak baino bertsio zaharragoa dauka. Berriago bat espero da.
reason-bad-browser-anchor = Nabigatzaile-aingura bat gaizki osatuta dago edo ez dator bat.
reason-bad-waict-proof = Nabigatzaile-geruzaren frogak ez du egiaztapena gainditzen.
reason-waict-quorum-not-met = Nabigatzaile-geruzaren lekuko-sinadurak ez dira nahikoak.
reason-unknown-waict-service = Nabigatzaile-aingura politikak zerrendatzen ez duen zerbitzu batetik dator.
reason-waict-service-not-independent = Nabigatzaile-geruza operadoreak kudeatzen du; beraz, ez da kontuan hartzen.
reason-bad-bootstrap-link = Abiarazte-gune baten froga gaizki osatuta dago edo ez du egiaztapena gainditzen.

# Trust policies
reason-policy-syntax = Konfiantza-politikaren lerro bat gaizki osatuta dago.
reason-policy-unknown-keyword = Konfiantza-politikaren lerro bat hitz ezezagun batekin hasten da.
reason-policy-count = Konfiantza-politikaren lerro bat gehiegitan agertzen da, edo ez da batere agertzen.
reason-policy-undefined-name = Konfiantza-politikak izen bat erabiltzen du hura definitu aurretik.
reason-policy-duplicate-name = Konfiantza-politikak izen bat bi aldiz definitzen du.
reason-policy-invalid = Konfiantza-politikak bere arauetako bat hausten du.
reason-policy-unsafe-quorum = Konfiantza-politikak eskatzen duen gutxieneko lekuko kopurua ez da segurua.
reason-policy-unsigned = Konfiantza-politikak ez dauka bere agintaritzen behar adina sinadurarik.

reason-unknown = «{ $code }» arrazoia
