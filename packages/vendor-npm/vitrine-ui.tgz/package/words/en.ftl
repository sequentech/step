# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in English (the source language).
# Every Vitrine page says the facts, tiers and states with these words; profiles
# can't override them (specs/profile.md, section 6). Variables in step and
# reason messages come from the verifier's `params`.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Included
fact-unchanged = Unchanged
fact-same-for-everyone = The same for everyone

fact-state-done = Done
fact-state-promised = Promised
fact-state-pending = Pending
fact-state-late = Late
fact-state-invalid = Couldn't be checked
fact-state-failed = Failed
fact-state-checking = Checking

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Your entry is in the record.
fact-included-promised = The record signed a promise to include your entry.
fact-included-pending = Waiting for the record to include your entry.
fact-included-late = The record should have included your entry by now.
fact-included-invalid = The proof that your entry is in the record couldn't be checked: the data looks damaged.
fact-included-failed = The record's own signatures contradict each other about your entry.
fact-unchanged-done = Independent witnesses signed the record, so nothing in it can change unnoticed.
fact-unchanged-pending = Waiting for the independent witnesses to sign the record.
fact-unchanged-late = The witnesses should have signed the record by now.
fact-unchanged-invalid = The proofs about the record's history couldn't be checked: the data looks damaged.
fact-unchanged-failed = Signed proofs about the record's history contradict each other.
fact-same-for-everyone-done = Everyone who checks is shown this same record.
fact-same-for-everyone-pending = Waiting for the record to be anchored where everyone can check it.
fact-same-for-everyone-late = The record should be anchored where everyone can check it by now.
fact-same-for-everyone-invalid = The anchors couldn't be checked: the data looks damaged.
fact-same-for-everyone-failed = Signed proofs show that not everyone is shown the same record.

## Tiers

tier-record = Record
tier-witnesses = Witnesses
tier-hubs = Anchor hubs
tier-browser = Browser layer
tier-policy = Policy
tier-entry = Entry

tier-status-verified = Verified
tier-status-pending = Pending
tier-status-late = Late
tier-status-invalid = Couldn't be checked
tier-status-failed = Failed
tier-status-unused = Not used
tier-status-checking = Checking
tier-status-promised = Promised

tier-record-verified = Your entry is in the signed record.
tier-record-promised = The record signed a promise to include your entry.
tier-record-pending = The record hasn't included your entry yet.
tier-record-late = The record should have included your entry by now.
tier-record-invalid = The record's proofs look damaged, so they couldn't be checked.
tier-record-failed = The record signed proofs that contradict each other.
tier-record-checking = Checking the record's proofs.
tier-witnesses-verified = Enough independent witnesses signed the record.
tier-witnesses-pending = Waiting for the witnesses to sign. This takes seconds.
tier-witnesses-late = The witnesses should have signed by now.
tier-witnesses-invalid = The witness signatures look damaged, so they couldn't be checked.
tier-witnesses-failed = Witnesses signed a record that contradicts yours.
tier-witnesses-checking = Checking the witness signatures.
tier-hubs-verified = Every anchor hub holds the record.
tier-hubs-pending = On its way to the anchor hubs. This takes seconds.
tier-hubs-late = The anchor hubs should hold the record by now.
tier-hubs-invalid = An anchor hub's answer looks damaged, so it couldn't be checked.
tier-hubs-failed = An anchor hub holds a signed record that contradicts yours.
tier-hubs-unused = This policy uses no anchor hubs.
tier-hubs-checking = Checking the anchor hubs.
tier-browser-verified = Anchored where browsers check.
tier-browser-pending = Due within minutes. There's no need to wait.
tier-browser-late = It should be anchored where browsers check by now.
tier-browser-invalid = The browser layer's answer looks damaged, so it couldn't be checked.
tier-browser-failed = A signed anchor where browsers check contradicts the record.
tier-browser-unused = This policy uses no independent browser layer.
tier-browser-checking = Checking the browser layer.
tier-test = Test only: run by the operator, so it doesn't count.
tier-deadline = Expected by { TIME($deadline) }
hub-test = test

## The one-line status

status-verified = Verified
status-checking = Checking…
status-pending = Pending
status-late = Late
status-invalid = Couldn't be checked
status-failed = Failed
status-summary-verified = Included, unchanged and the same for everyone.
status-summary-checking = Checking the receipt's proofs in this browser.
status-summary-pending = Some proofs are still on their way. There's no need to wait.
status-summary-late = Some proofs should have arrived by now.
status-summary-invalid = Some data couldn't be checked: the file or the server's answer looks damaged. This doesn't show that anyone cheated.
status-summary-failed = Signed proofs contradict each other. Keep the evidence.

## <vitrine-receipt>

receipt-label = Receipt
receipt-words-label = Receipt words
receipt-entry = Entry { $index } in { $log }
receipt-entry-promised = Promised entry in { $log }
receipt-provenance-page = Checked by this website
receipt-provenance-page-hint = This website checked its own record. To be sure, check it independently.
receipt-provenance-independent = Checked independently of the website
receipt-facts-heading = What the proofs show
receipt-chain-heading = How far it has reached
receipt-compare-heading = Compare with the official notice
receipt-compare-hint = These words and witnesses should match the ones the authority published, for example in the election notice.
receipt-policy-words = Policy words
receipt-policy-id = Policy ID
receipt-event = Event
receipt-witnesses = Witnesses
receipt-witness-party = run by { $party }
receipt-hubs = Anchor hubs
receipt-clock-warning = This device's clock is more than a minute off. Deadlines are judged by signed time, not by this clock.
receipt-action-check = Check independently
receipt-action-download = Download receipt
receipt-action-retry = Check again
receipt-invalid = Some data couldn't be checked: the file or the server's answer looks damaged. This doesn't show that anyone cheated. You can check again, or check independently.
receipt-no-expect = This page didn't say which entry to expect, so this receipt can't be shown as yours.
receipt-error = This receipt couldn't be checked.
receipt-empty = No receipt yet.
receipt-announce = { $tier }: { $status }.

## <vitrine-proof-steps>

steps-heading = Every check
steps-summary =
    { $total ->
        [one] { $passed } of { $total } check passed
       *[other] { $passed } of { $total } checks passed
    }
steps-result-passed = Passed
steps-result-failed = Failed
steps-result-not-run = Not run yet
steps-show-details = Show details
steps-hide-details = Hide details
steps-objects = Signed objects involved: { $objects }
steps-evidence = Save the evidence
steps-empty = No checks yet.

## <vitrine-chain>

chain-label = Receipt chain

## <vitrine-alert>

alert-label = Proven problem
alert-kind-split-view-title = The record was shown differently to different people
alert-kind-split-view-body = Two versions of the record, both signed by its operator, can't both be true. It may be a fault or an attack. Your entry may still count, but someone independent should look at it.
alert-kind-broken-promise-title = The record broke a signed promise
alert-kind-broken-promise-body = The record promised to include an entry by a deadline, and its own signatures show it didn't. Someone independent should look at it.
alert-kind-bad-entry-title = The record holds an entry that breaks its rules
alert-kind-bad-entry-body = An entry signed into the record breaks a rule of its profile. Someone independent should look at it.
alert-kind-stale-anchor-title = The record wasn't anchored in time
alert-kind-stale-anchor-body = The record or an anchor hub took longer than the policy allows to anchor the record. It breaks a promised service level, not the record itself.
alert-kind-hub-entry-title = An anchor hub accepted an entry it should have refused
alert-kind-hub-entry-body = An anchor hub's witnesses signed a hub record with an entry that breaks the hub's rules, so at least one of them signed without checking.
alert-kind-unknown-title = A problem was found
alert-kind-unknown-body = The evidence shows a problem of a kind this page doesn't know: { $kind }.
alert-not-proven-title = This file doesn't prove a problem
alert-not-proven-body = The file was checked, and it doesn't prove a problem. It isn't evidence.
alert-unpinned-title = This file is for a policy this device hasn't pinned
alert-unpinned-body = It can't be shown as proof on this device. Compare the file's policy words with the official notice, and pin that policy before checking the file again.
alert-invalid-title = This file couldn't be checked
alert-invalid-body = The file looks damaged. This doesn't show that anyone cheated.
alert-proven-under = Proven under the policy with these words:
alert-file-policy-words = The file's policy words:
alert-parties = Responsible, by their own signatures: { $parties }
alert-evidence-heading = Evidence kept on this device
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } KB
alert-evidence-hint = Anyone can check this file on their own computer. It holds only signed objects from the record.
alert-download = Download evidence file
alert-send = Send to the monitors
alert-monitors-heading = Monitors named by the policy
alert-confirm-heading = Send the evidence?
alert-confirm-body =
    { $count ->
        [one] This sends the evidence file to this monitor. It will see the file and that it came from this device.
       *[other] This sends the evidence file to these { $count } monitors. They will see the file and that it came from this device.
    }
alert-confirm-send = Yes, send it
alert-confirm-cancel = Cancel
alert-sending = The evidence is being sent to the monitors.
alert-no-monitors = The policy names no monitors. Keep the file and give it to an observer.
alert-delivery-waiting = Waiting for confirmation
alert-delivery-sending = Sending
alert-delivery-confirmed = Confirmed
alert-delivery-failed = Not confirmed

## <vitrine-badge>

badge-check = Check independently
badge-opens = opens an independent verifier

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = The receipt file is well formed
step-policy-pinned = The receipt is for the pinned trust policy
step-log-known = The receipt's record is in the policy
step-entry-parse = The entry is well formed
step-entry-profile = The entry has the record's type and its fields
step-entry-expectation = The entry is the one you expected
step-promise-signature = The record signed a promise to include the entry
step-promise-inclusion = The signed promise covers the entry
step-promise-leaf = The promise is for the entry you expected
step-promise-kept = The record kept its promise by the deadline
step-issued-signature = The receipt given at submission is signed by the record
step-issued-inclusion = The entry is in the receipt given at submission
step-record-signature = The record's receipt is signed by the record
step-record-inclusion = The entry is in the record
step-receipts-match = The receipts are for the same entry at the same position
step-record-consistency = The record only grew since the receipt given at submission
step-record-quorum = Enough independent witnesses signed the record
step-hub-link = Hub { $hub }'s proof verifies
step-hub-opening = The sealed anchor in hub { $hub } opens to the record
step-hub-anchored-checkpoint = The record anchored in hub { $hub } is signed by the record and its witnesses
step-hub-anchor-consistency = The record only grew up to its anchor in hub { $hub }
step-browser-anchor = The browser layer holds hub { $hub }'s record
step-browser-consistency = Hub { $hub } only grew up to its browser anchor
step-bootstrap-link = A bootstrap hub anchors hub { $hub }
step-bootstrap-consistency = Hub { $hub } only grew up to its bootstrap anchor
step-unknown = Check “{ $code }”

## Reasons, why a check failed or is still waiting (`reason-<code>`). They
## take no variables: the tier, hub or step they belong to is shown next to them.

# Encodings and limits
reason-bad-base64 = A base64 value is malformed.
reason-bad-hex = A hex value is malformed.
reason-bad-text = Some text isn't valid or holds a forbidden character.
reason-bad-number = A number is malformed or out of range.
reason-trailing-data = Unexpected data follows a part of the file.
reason-truncated = A part of the file ends too early.
reason-too-large = Something is larger than the limits allow.

# Signed notes and keys
reason-bad-note = A signed note is malformed.
reason-bad-key-name = A key name is malformed.
reason-bad-vkey = A public key is malformed or of the wrong type.
reason-bad-public-key = A public key isn't valid.
reason-duplicate-signature = A note carries the same signature twice.
reason-bad-signature = A signature doesn't verify.
reason-missing-signature = A signature that must be there is missing.

# Checkpoints and witness signatures
reason-bad-checkpoint = A checkpoint is malformed.
reason-wrong-origin = A signed note names another record or hub than expected.
reason-cosignature-in-future = A witness signature is dated in the future, so it was ignored.
reason-quorum-not-met = Not enough independent witnesses have signed yet.

# Proofs
reason-bad-proof = A proof is malformed.
reason-missing-extra = A receipt doesn't hold the entry.
reason-index-out-of-range = The entry's position is past the end of the record.
reason-inclusion-failed = The proof that the entry is in the record doesn't verify.
reason-consistency-failed = The proof that the record only grew doesn't verify.
reason-split-view = Two signed versions of the record have the same size but different contents.

# Entries and expectations
reason-bad-entry = The entry is malformed.
reason-wrong-profile = The entry's type differs from the record's type at that position.
reason-bad-entry-layout = The entry's fields don't match its type.
reason-entry-mismatch = The entry isn't the one you expected.
reason-expectation-incomplete = The page didn't say enough about the entry to check it.
reason-expectation-unknown-field = The page named a field this type of entry doesn't have.
reason-expectation-unsupported = This verifier can't check the fields of this type of entry.
reason-receipts-disagree = The receipts in the file are for different entries or positions.

# Promises
reason-bad-promise = The promise is malformed.
reason-promise-mmd-too-large = The promise allows more delay than the policy permits.
reason-promise-leaf-mismatch = The promise is for another entry.
reason-promise-pending = The record promised to include the entry. Its receipt isn't due yet.
reason-promise-deadline-passed = The promise's deadline has passed and there's no receipt yet.
reason-promise-kept-unproven = Nothing in the file shows that the promise was kept in time.

# Receipt chains
reason-malformed-chain = The receipt file is malformed.
reason-duplicate-block = The receipt file holds the same part twice.
reason-no-receipt = The file holds no promise and no receipt.
reason-policy-mismatch = The receipt names a different trust policy than the pinned one.
reason-unknown-log = The receipt names a record the policy doesn't have.
reason-unknown-hub = A part names an anchor hub the policy doesn't have, so it was ignored.
reason-consistency-missing = A proof that the record only grew is missing.
reason-consistency-mismatch = A proof that the record only grew doesn't fit the versions it links.
reason-waiting-for-cosignatures = Waiting for the witnesses to sign the record.
reason-waiting-for-record = Waiting for the witnessed record.
reason-no-signed-time = There's no signed time yet, so deadlines can't be judged.
reason-deadline-passed = The deadline has passed, by signed time.
reason-record-invalid = This couldn't be checked, because the record's proofs couldn't be checked.
reason-bad-reference = A link to a receipt is malformed.

# Anchor hubs
reason-waiting-for-anchor = Waiting for the anchor hub to anchor the record.
reason-hub-quorum-not-met = Not enough of the anchor hub's witnesses have signed yet.
reason-bad-hub-link = The anchor hub's proof is malformed or doesn't verify.
reason-hub-link-mismatch = The anchor hub's proof is about something else.
reason-map-proof-failed = The anchor hub's map proof doesn't verify.
reason-subject-rotated = The record's key changed at this anchor hub. The newer trust policy is needed.
reason-anchor-behind-record = The anchor hub holds an older version of the record than your receipt.
reason-anchor-quorum-not-met = The anchored record lacks enough witness signatures.
reason-bad-blinded-anchor = A sealed anchor doesn't verify.
reason-opening-missing = The file doesn't hold what opens the sealed anchor yet.
reason-bad-opening = What should open the sealed anchor doesn't match it.

# Browser layer
reason-browser-test-only = The browser layer is only a test here: it's run by the operator.
reason-waiting-for-browser-anchor = Waiting for the browser layer. It's due within minutes.
reason-browser-behind-anchor = The browser layer holds an older version than the anchor hub. A newer one is due.
reason-bad-browser-anchor = A browser anchor is malformed or doesn't match.
reason-bad-waict-proof = The browser layer's proof doesn't verify.
reason-waict-quorum-not-met = Not enough of the browser layer's witnesses signed.
reason-unknown-waict-service = The browser anchor comes from a service the policy doesn't list.
reason-waict-service-not-independent = The browser layer is run by the operator, so it doesn't count.
reason-bad-bootstrap-link = A bootstrap hub's proof is malformed or doesn't verify.

# Trust policies
reason-policy-syntax = A line of the trust policy is malformed.
reason-policy-unknown-keyword = A line of the trust policy starts with an unknown word.
reason-policy-count = A line of the trust policy appears too often or not at all.
reason-policy-undefined-name = The trust policy uses a name before defining it.
reason-policy-duplicate-name = The trust policy defines a name twice.
reason-policy-invalid = The trust policy breaks one of its rules.
reason-policy-unsafe-quorum = The trust policy's witness quorum isn't safe.
reason-policy-unsigned = The trust policy lacks enough signatures from its authorities.

reason-unknown = Reason “{ $code }”
