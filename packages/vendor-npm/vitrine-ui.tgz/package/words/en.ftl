# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in English (the source language).
# Every Vitrine page says the facts, tiers and states with these words; profiles
# can't override them (specs/profile.md, section 6). Variables in step and
# reason messages come from the verifier's `params`.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Included
fact-unchanged = Unchanged
fact-same-for-everyone = The same for everyone

fact-state-done = Done
fact-state-promised = Promised
fact-state-pending = Pending
fact-state-late = Late
fact-state-invalid = Couldn't be checked
fact-state-failed = Failed
fact-state-checking = Checking

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Your entry is in the record.
fact-included-promised = The record signed a promise to include your entry.
fact-included-pending = Some proofs that your entry is in the record are still on their way.
fact-included-late = The record should have included your entry by now.
fact-included-invalid = The proof that your entry is in the record couldn't be checked: the data looks damaged.
fact-included-failed = The record's own signatures contradict each other about your entry.
fact-unchanged-done = Independent witnesses signed the record, so nothing in it can change unnoticed.
fact-unchanged-pending = Waiting for the independent witnesses to sign the record.
fact-unchanged-late = The witnesses should have signed the record by now.
fact-unchanged-invalid = The proofs about the record's history couldn't be checked: the data looks damaged.
fact-unchanged-failed = Signed proofs about the record's history contradict each other.
fact-same-for-everyone-done = Everyone who checks is shown this same record.
fact-same-for-everyone-pending = Waiting for the record to be anchored where everyone can check it.
fact-same-for-everyone-late = The record should be anchored where everyone can check it by now.
fact-same-for-everyone-invalid = The anchors couldn't be checked: the data looks damaged.
fact-same-for-everyone-failed = Signed proofs show that not everyone is shown the same record.
# Instead of the pending text: `fact-pending-successors` (any fact) when every
# tier the fact rests on waits only for the check for a newer trust policy
# (specs/policy.md, section 4, rule 7), and
# `fact-same-for-everyone-pending-attestation` when a private event's anchor
# hubs wait for an auditor to confirm the sealed anchors (specs/receipt.md,
# section 3.3).
fact-pending-successors = The proofs check out. It shows as done once it's checked whether the trust policy was replaced by a newer one.
fact-same-for-everyone-pending-attestation = Anchored. An auditor still has to confirm the sealed anchors, which can take a while.

## Tiers

tier-record = Record
tier-witnesses = Witnesses
tier-hubs = Anchor hubs
tier-browser = Browser layer
tier-policy = Policy
tier-entry = Entry

tier-status-verified = Verified
tier-status-pending = Pending
tier-status-late = Late
tier-status-invalid = Couldn't be checked
tier-status-failed = Failed
tier-status-unused = Not used
tier-status-checking = Checking
tier-status-promised = Promised

tier-record-verified = Your entry is in the signed record.
tier-record-promised = The record signed a promise to include your entry.
tier-record-pending = Some of the record's proofs are still on their way.
tier-record-late = The record should have included your entry by now.
tier-record-invalid = The record's proofs look damaged, so they couldn't be checked.
tier-record-failed = The record signed proofs that contradict each other.
tier-record-checking = Checking the record's proofs.
tier-witnesses-verified = Enough independent witnesses signed the record.
tier-witnesses-pending = Waiting for the witnesses to sign. This takes seconds.
tier-witnesses-late = The witnesses should have signed by now.
tier-witnesses-invalid = The witness signatures look damaged, so they couldn't be checked.
tier-witnesses-failed = Witnesses signed a record that contradicts yours.
tier-witnesses-checking = Checking the witness signatures.
tier-hubs-verified = Every anchor hub holds the record.
tier-hubs-pending = On its way to the anchor hubs. This takes seconds.
tier-hubs-late = The anchor hubs should hold the record by now.
tier-hubs-invalid = An anchor hub's answer looks damaged, so it couldn't be checked.
tier-hubs-failed = An anchor hub holds a signed record that contradicts yours.
tier-hubs-unused = This policy uses no anchor hubs.
tier-hubs-checking = Checking the anchor hubs.
tier-browser-verified = Anchored where browsers check.
tier-browser-pending = Due within minutes. There's no need to wait.
tier-browser-late = It should be anchored where browsers check by now.
tier-browser-invalid = The browser layer's answer looks damaged, so it couldn't be checked.
tier-browser-failed = A signed anchor where browsers check contradicts the record.
tier-browser-unused = This policy uses no independent browser layer.
tier-browser-checking = Checking the browser layer.
# Instead of the pending text: `tier-pending-successors` (any tier) when every
# check of the tier passed but the check for a newer trust policy hasn't run
# yet; in a private event, `tier-hubs-pending-attestation` when the anchor hubs
# wait for an auditor, and `tier-browser-pending-hubs` when the browser layer
# waits for the anchor hubs.
tier-pending-successors = Its proofs check out. It shows as verified once it's checked whether the trust policy was replaced by a newer one.
tier-hubs-pending-attestation = Anchored. An auditor still has to confirm the sealed anchors. This can take a while, and it never turns late.
tier-browser-pending-hubs = Waits for the anchor hubs: in a private event, the browser layer counts only once they're verified.
tier-test = Test only: run by the operator, so it doesn't count.
tier-deadline = Expected by { TIME($deadline) }
hub-test = test

## Stages of a ballot in the log (specs/entry.md, section 4.1): a tag next to the status

stage-received = Not cast
stage-cast = Cast
stage-audited = Audited

## The one-line status

status-verified = Verified
status-checking = Checking…
status-pending = Pending
status-late = Late
status-invalid = Couldn't be checked
status-failed = Failed
status-summary-verified = Included, unchanged and the same for everyone.
status-summary-checking = Checking the receipt's proofs in this browser.
status-summary-pending = Some proofs are still on their way. There's no need to wait.
status-summary-pending-successors = The proofs check out. The receipt shows as verified once it's checked whether the trust policy was replaced by a newer one.
status-summary-pending-attestation = Anchored. An auditor still has to confirm the sealed anchors. There's no need to wait.
status-summary-late = Some proofs should have arrived by now.
status-summary-invalid = Some data couldn't be checked: the file or the server's answer looks damaged. This doesn't show that anyone cheated.
status-summary-failed = Signed proofs contradict each other. Keep the evidence.

## <vitrine-receipt>

receipt-label = Receipt
receipt-words-label = Receipt words
receipt-entry = Entry { $index } in { $log }
receipt-entry-promised = Promised entry in { $log }
receipt-provenance-page = Checked by this website
receipt-provenance-page-hint = This website checked its own record. To be sure, check it independently.
receipt-provenance-independent = Checked independently of the website
receipt-facts-heading = What the proofs show
receipt-chain-heading = How far it has reached
receipt-compare-heading = Compare with the official notice
receipt-compare-hint = These words and witnesses should match the ones the authority published, for example in the election notice.
receipt-policy-words = Policy words
receipt-policy-in-force = Policy in force now
receipt-policy-in-force-hint = It replaced the earlier policy, as that policy's rules allow. Its words should match a newer notice from the authority.
receipt-policy-id = Policy ID
receipt-event = Event
receipt-witnesses = Witnesses
receipt-witness-party = run by { $party }
receipt-hubs = Anchor hubs
receipt-clock-warning = This device's clock is more than a minute from the newest time the witnesses signed. Deadlines are judged by signed time, not by this clock.
receipt-action-check = Check independently
receipt-action-download = Download receipt
receipt-action-retry = Check again
receipt-invalid = Some data couldn't be checked: the file or the server's answer looks damaged. This doesn't show that anyone cheated. You can check again, or check independently.
receipt-no-expect = This page didn't say which entry to expect, so this receipt can't be shown as yours.
receipt-error = This receipt couldn't be checked.
receipt-empty = No receipt yet.
receipt-announce = { $tier }: { $status }.

## <vitrine-receipt>, the receipt card (the voter board). Its five steps are
## sealed on this device, then the four tiers. `$noun` is the profile's name for
## one entry ("ballot" in the election profile), or `receipt-noun`.

receipt-noun = entry
receipt-fingerprint-label = { $noun } fingerprint

receipt-seal-checking = Checking
receipt-seal-sealed = Sealed
receipt-seal-record-public = Included in the public record
receipt-seal-record-private = Included in the private record
receipt-seal-witnesses = Confirmed by independent witnesses
receipt-seal-hubs = { $hubs }. Browser anchor due soon
receipt-seal-browser = Anchored where browsers check

receipt-step-sealed = Sealed on this device
receipt-step-sealed-done = Sealed before it left your browser.
receipt-step-sealed-wait = Sealing in your browser…
receipt-step-record-public = Added to the public record
receipt-step-record-private = Added to the private record
receipt-step-record-done = Entry #{ $index }. Your browser checked it.
receipt-step-record-wait = Waiting for the record to include it…
receipt-step-record-promised = The record signed a promise to include it.
receipt-step-witnesses = Confirmed by witnesses
receipt-step-witnesses-done = { $signed } of { $total } independent witnesses signed it.
receipt-step-witnesses-done-any = Independent witnesses signed it.
receipt-step-witnesses-wait = Waiting for witness signatures…
receipt-step-hubs-public =
    { $count ->
        [one] Anchored in { $count } public hub
       *[other] Anchored in { $count } public hubs
    }
receipt-step-hubs-private =
    { $count ->
        [one] Anchored in { $count } hub, sealed
       *[other] Anchored in { $count } hubs, sealed
    }
receipt-step-hubs-none = Anchor hubs
receipt-step-hubs-done-public = Shared logs also hold this record.
receipt-step-hubs-done-private = Nothing about what it holds is revealed.
receipt-step-hubs-wait = Within seconds…
receipt-step-hubs-partial = { $agree } of { $total } hubs hold it so far…
receipt-step-browser = Anchored where browsers check
receipt-step-browser-done = In the same log as this site’s code.
receipt-step-browser-done-bootstrap = Held by a stand-in hub until browsers check logs themselves.
receipt-step-browser-wait = Within minutes. No need to wait.
receipt-step-browser-wait-minutes =
    { $minutes ->
        [one] Within a minute. No need to wait.
       *[other] Within { $minutes } minutes. No need to wait.
    }
receipt-step-late = Taking longer than it should.
receipt-step-invalid = Couldn't be checked: the data looks damaged.
receipt-step-failed = Contradicts the signed record.
receipt-step-unused = Not used by this event's policy.
receipt-step-state-done = Done
receipt-step-state-active = In progress
receipt-step-state-scheduled = Scheduled
receipt-step-state-waiting = Waiting

receipt-caption-checking-public = Your browser is checking the public record…
receipt-caption-checking-private = Your browser is checking the private record…
receipt-caption-public = Verified by your browser, with code anyone can inspect.
receipt-caption-private = Private record. Accredited auditors can check all of it.
receipt-caption-late = Some steps are taking longer than they should.
receipt-caption-invalid = Some data couldn't be checked. It looks damaged.
receipt-caption-failed = Your browser found a problem with the record.

receipt-check-elsewhere = Check it on another device
receipt-action-save = Save receipt

## <vitrine-receipt variant="summary">, the re-check on a later visit (the
## revisit board).

receipt-summary-label = Receipt check
receipt-summary-title-public = Your entry is still in the public record
receipt-summary-title-private = Your entry is still in the private record
receipt-summary-title-checking = Checking your entry in the record…
receipt-summary-title-late = Some proofs for your entry are late
receipt-summary-title-invalid = Your entry couldn't be checked
receipt-summary-title-failed = We could not confirm your entry in the record
receipt-summary-checked-now = Checked just now by your browser.
receipt-summary-checked-at = Checked by your browser at { TIME($time) }.
receipt-summary-unchanged = Nothing recorded before it has changed.
receipt-summary-witnesses = Witnesses
receipt-summary-hubs-public = Public hubs
receipt-summary-hubs-private = Hubs
receipt-summary-browser = Where browsers check
receipt-summary-agree = { $agree } of { $total } agree
receipt-summary-agree-any = Agree
receipt-summary-anchored = Anchored { DATE($time) }
receipt-summary-anchored-plain = Anchored
receipt-summary-waiting = Waiting
receipt-summary-due = Due soon
receipt-summary-unused = Not used
receipt-view = View receipt

## <vitrine-how-we-check>

how-label = How the check works
how-heading = How we check
how-receipt = Your browser keeps a signed receipt. It holds a fingerprint of what you submitted, never the content.
how-grew = Each visit it asks the record for a short proof that it only grew.
how-witnesses = Independent witnesses sign it, and public hubs anchor it where browsers check, so everyone sees the same record.

## <vitrine-proof-steps>

steps-heading = Every check
steps-summary =
    { $total ->
        [one] { $passed } of { $total } check passed
       *[other] { $passed } of { $total } checks passed
    }
steps-result-passed = Passed
steps-result-failed = Failed
steps-result-not-run = Not run yet
steps-show-details = Show details
steps-hide-details = Hide details
steps-objects = Signed objects involved: { $objects }
steps-evidence = Save the evidence
steps-empty = No checks yet.

## <vitrine-chain>

chain-label = Receipt chain

## <vitrine-alert>

alert-label = Proven problem
alert-kind-split-view-title = The record was shown differently to different people
alert-kind-split-view-body = Two versions of the record, both signed by its operator, can't both be true. It may be a fault or an attack. Your entry may still count, but someone independent should look at it.
alert-kind-broken-promise-title = The record broke a signed promise
alert-kind-broken-promise-body = The record promised to include an entry by a deadline, and its own signatures show it didn't. Someone independent should look at it.
alert-kind-bad-entry-title = The record holds an entry that breaks its rules
alert-kind-bad-entry-body = An entry signed into the record breaks a rule of its profile. Someone independent should look at it.
alert-kind-hub-entry-title = An anchor hub accepted an entry it should have refused
alert-kind-hub-entry-body = An anchor hub's witnesses signed a hub record with an entry that breaks the hub's rules, so at least one of them signed without checking.
alert-kind-time-regression-title = The record signed a false time
alert-kind-time-regression-body = The record signed two versions of itself, and the larger one has the earlier time. A record's signed time never goes back, so one of the two is false. Someone independent should look at it.
alert-kind-policy-equivocation-title = The trust policy's authorities signed two different replacements
alert-kind-policy-equivocation-body = Enough of the trust policy's authorities signed two different replacements for it, and both were recorded. The first one recorded is the one that counts, but the second could show different people different policies. Someone independent should look at it.
alert-kind-bad-checkpoint-title = A record signed an impossible version of itself
alert-kind-bad-checkpoint-body = It signed a version that has no entries, yet isn't empty. No honest record or anchor hub can produce one. Someone independent should look at it.
alert-kind-unknown-title = A problem was found
alert-kind-unknown-body = The evidence shows a problem of a kind this page doesn't know: { $kind }.
alert-not-proven-title = This file doesn't prove a problem
alert-not-proven-body = The file was checked, and it doesn't prove a problem. It isn't evidence.
alert-unpinned-title = This file is for a policy this device hasn't pinned
alert-unpinned-body = It can't be shown as proof on this device. Compare the file's policy words with the official notice, and pin that policy before checking the file again.
alert-invalid-title = This file couldn't be checked
alert-invalid-body = The file looks damaged. This doesn't show that anyone cheated.
alert-proven-under = Proven under the policy with these words:
alert-file-policy-words = The file's policy words:
alert-parties = Responsible, by their own signatures: { $parties }
alert-evidence-heading = Evidence kept on this device
alert-evidence-hint = Observers check this evidence on their own computers. It proves what the record signed, and it contains nothing about what you submitted.
alert-download = Download evidence file
alert-send = Send evidence to the observers
alert-monitors-heading = Observers named by the policy
alert-confirm-heading = Send the evidence?
alert-confirm-body =
    { $count ->
        [one] This sends the evidence file to this observer. It will see the file and that it came from this device.
       *[other] This sends the evidence file to these { $count } observers. They will see the file and that it came from this device.
    }
alert-confirm-send = Yes, send it
alert-confirm-cancel = Cancel
alert-sending = The evidence is being sent to the observers.
alert-no-monitors = The policy names no monitors. Keep the file and give it to an observer.
alert-delivery-waiting = Waiting for confirmation
alert-delivery-sending = Sending
alert-delivery-confirmed = Confirmed
alert-delivery-failed = Not confirmed

## <vitrine-alert>, the alert board: the evidence kept on this device, as the
## signed items the file holds.

alert-yours-title = We could not confirm your entry in the record
alert-yours-split-view-body = The record shown to your browser does not match the one the independent witnesses signed. It may be a fault or an attack. Your entry may still count, but someone independent should look at it.
alert-evidence-count =
    { $count ->
        [one] { $count } signed item
       *[other] { $count } signed items
    }
alert-item-receipt = Your receipt for entry #{ $index }
alert-item-receipt-detail = Signed by the record when it was added
alert-item-receipt-other = Receipt for entry #{ $index }
alert-item-checkpoint = Signed record, size { $size }
alert-item-checkpoint-shown = Record shown to you, size { $size }
alert-item-checkpoint-shown-detail = Contains your entry
alert-item-checkpoint-witnessed = Witnessed record, size { $size }
alert-item-witnessed-detail =
    { $count ->
        [one] Signed by { $count } witness
       *[other] Signed by { $count } witnesses
    }
alert-item-hubs-detail =
    { $hubs ->
        [one] Anchored in { $hubs } public hub
       *[other] Anchored in { $hubs } public hubs
    }
alert-item-promise = Signed promise to include an entry
alert-item-policy = Signed trust policy
alert-item-policy-ack = Signed acknowledgement of the trust policy
alert-item-why-split-view = Cannot have grown from the record of size { $size }
alert-item-why-time-regression = Its signed time is earlier than the smaller record's
alert-item-why-bad-checkpoint = Has no entries, yet isn't empty
alert-what-next = What happens next?
alert-what-next-body = Independent observers read the evidence on their own computers. Nothing is sent unless you choose to send it. You can also keep the file and give it to someone you trust: it proves what the record signed wherever it is checked.

## <vitrine-badge>

badge-check = Check independently
badge-opens = opens an independent verifier

## Monitor reports (specs/evidence.md, section 3). `report-kind-<kind>` says
## what a report is about, with `$subject`, the record or hub it names. A
## report is its monitor's own statement, not proof: show `report-established`
## only when monitors of enough different parties report the same thing.

report-kind-cosign-late = { $subject } has gone too long without a fresh version that enough of its witnesses signed.
report-kind-anchor-late = { $subject } wasn't anchored in time: the record or the anchor hub is late, and the report can't say which.
report-kind-unreachable = A server for { $subject } stopped answering.
report-kind-mirror-behind = A mirror's copy of { $subject } has fallen behind.
report-kind-payload-missing = Some data recorded in { $subject } isn't available, and no notice says it was withheld.
report-kind-payload-mismatch = Some data that { $subject } serves doesn't match what it recorded.
report-kind-rule-failing = An entry in { $subject } breaks a rule of its profile. The monitor published evidence that anyone can check.
report-kind-promise-pending = { $subject } signed a promise to include an entry, and hasn't included it yet.
report-kind-promise-unlisted = { $subject } leaves a batch of its signed promises out of its list.
report-kind-promise-late = { $subject } didn't keep a signed promise in time: the record or its witnesses were late, or their clocks are off.
report-kind-promise-misdated = { $subject } dated a batch of its signed promises wrongly: its time doesn't fit the hour it was listed in, or the time the monitor first saw it.
report-kind-opening-missing = { $subject } didn't open a sealed anchor to the auditor in time.
report-kind-ack-missing = { $subject } doesn't serve its signed statement that it follows the trust policy in force.
report-kind-config-mismatch = A client was shown settings that { $subject } has not recorded, or that differ from the recorded ones.
report-kind-code-mismatch = A website served a script that no release recorded in { $subject } contains.
report-kind-unknown = Monitor report “{ $kind }” about { $subject }
report-established = Established: monitors run by enough different parties report it.
report-statement = Reported by { $monitor }. A report is the monitor's own statement, not proof about anyone else.

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = The receipt file is well formed
step-policy-pinned = The receipt is for the pinned trust policy
step-policy-successors = It was checked whether a newer trust policy replaced the pinned one
step-policy-ack = The record signed that it follows the trust policy
step-log-known = The receipt's record is in the policy
step-entry-parse = The entry is well formed
step-entry-profile = The entry has the record's type and its fields
step-entry-expectation = The entry is the one you expected
step-promise-signature = The record signed a promise to include the entry
step-promise-inclusion = The signed promise covers the entry
step-promise-leaf = The promise is for the entry you expected
step-promise-kept = The record kept its promise by the deadline
step-issued-signature = The receipt given at submission is signed by the record
step-issued-inclusion = The entry is in the receipt given at submission
step-record-signature = The record's receipt is signed by the record
step-record-inclusion = The entry is in the record
step-receipts-match = The receipts are for the same entry at the same position
step-record-consistency = The record only grew since the receipt given at submission
step-record-quorum = Enough independent witnesses signed the record
step-log-consistent = The versions of the record seen here don't contradict each other
step-hub-link = Hub { $hub }'s proof verifies
step-hub-opening = The sealed anchor in hub { $hub } opens to the record
step-hub-anchored-checkpoint = The record anchored in hub { $hub } is signed by the record and its witnesses
step-hub-previous-anchor = Hub { $hub } holds the previous sealed anchor, and it opens to the record
step-hub-opening-consistency = The record only grew between its last two sealed anchors in hub { $hub }
step-hub-attestation = An auditor confirmed the sealed anchor in hub { $hub }
step-hub-anchor-consistency = The record only grew up to its anchor in hub { $hub }
step-browser-link = Hub { $hub }'s proof for the browser layer verifies and covers the entry
step-browser-link-consistency = The record only grew between your receipt and hub { $hub }'s proof for the browser layer
step-browser-anchor = The browser layer holds hub { $hub }'s record
step-browser-consistency = Hub { $hub } only grew up to its version anchored where browsers check
step-bootstrap-link = A bootstrap hub anchors hub { $hub }
step-unknown = Check “{ $code }”

## Reasons, why a check failed or is still waiting (`reason-<code>`). Their
## variables are the verifier's `params`. A message uses only those that the
## verifier always passes for its code: the tier, hub or step it belongs to is
## shown next to it anyway.

# Encodings and limits
reason-bad-base64 = A base64 value is malformed.
reason-bad-hex = A hex value is malformed.
reason-bad-text = Some text isn't valid or holds a forbidden character.
reason-bad-number = A number is malformed or out of range.
reason-trailing-data = Unexpected data follows a part of the file.
reason-truncated = A part of the file ends too early.
reason-too-large = Something is larger than the limits allow.

# Signed notes and keys
reason-bad-note = A signed note is malformed.
reason-bad-key-name = A key name is malformed.
reason-bad-vkey = A public key is malformed or of the wrong type.
reason-bad-public-key = A public key isn't valid.
reason-missing-signature = A signature that must be there is missing.

# Checkpoints and witness signatures
reason-bad-checkpoint = A checkpoint is malformed.
reason-bad-empty-tree = A signed version of the record is impossible: it has no entries, yet its contents aren't empty.
reason-wrong-origin = A signed note names another record or hub than expected.
reason-log-time-missing = A receipt lacks the record's signed time, so it couldn't be checked.
reason-cosignature-in-future = A witness signature is dated in the future, so it was ignored.
reason-quorum-not-met = Not enough independent witnesses have signed yet.

# Proofs
reason-bad-proof = A proof is malformed.
reason-missing-extra = A receipt doesn't hold the entry.
reason-index-out-of-range = The entry's position is past the end of the record.
reason-inclusion-failed = The proof that the entry is in the record doesn't verify.
reason-consistency-failed = The proof that the record only grew doesn't verify.
reason-split-view = Two signed versions of the record have the same size but different contents.

# Entries and expectations
reason-bad-entry = The entry is malformed.
reason-wrong-profile = The entry's type differs from the record's type at that position.
reason-bad-entry-layout = The entry's fields don't match its type.
reason-entry-mismatch = The entry isn't the one you expected.
reason-expectation-incomplete = The page didn't say enough about the entry to check it.
reason-expectation-unknown-field = The page named a field this type of entry doesn't have.
reason-expectation-unsupported = This verifier can't check the fields of this type of entry.
reason-receipts-disagree = The receipts in the file are for different entries or positions.

# Promises
reason-bad-promise = The promise is malformed.
reason-promise-policy-unknown = The promise names a trust policy that is neither the pinned one nor one that replaced it.
reason-promise-mmd-too-large = The promise allows more delay than the policy permits.
reason-promise-leaf-mismatch = The promise is for another entry.
reason-promise-time = The record dated its promise more than a minute away from when it arrived, so it doesn't count as a promise.
reason-promise-pending = The record promised to include the entry. Its receipt isn't due yet.
reason-promise-deadline-passed = The promise's deadline has passed and there's no receipt yet.
reason-promise-kept-unproven = Nothing in the file shows that the promise was kept in time.
reason-broken-promise = The record promised to include the entry by { TIME($deadline) }, but its own signed time shows it still hadn't at { TIME($logTime) }.
reason-bad-promise-list = The record's list of the promises it made in an hour is malformed or doesn't match them, so it couldn't be checked.

# Receipt chains
reason-malformed-chain = The receipt file is malformed.
reason-duplicate-block = The receipt file holds the same part twice.
reason-no-receipt = The file holds no promise and no receipt.
reason-policy-mismatch = The receipt names a different trust policy than the pinned one.
reason-policy-draft = The trust policy is still a draft, and a draft is never valid.
reason-bad-policy-ack = The record's signed statement that it follows this trust policy is malformed or doesn't match it.
reason-unknown-log = The receipt names a record the policy doesn't have.
reason-unknown-hub = A part names an anchor hub the policy doesn't have, so it was ignored.
reason-consistency-missing = A proof that the record only grew is missing.
reason-consistency-mismatch = A proof that the record only grew doesn't fit the versions it links.
reason-waiting-for-cosignatures = Waiting for the witnesses to sign the record.
reason-waiting-for-record = Waiting for the witnessed record.
reason-no-signed-time = There's no signed time yet, so deadlines can't be judged.
reason-deadline-passed = The deadline has passed, by signed time.
reason-record-invalid = This couldn't be checked, because the record's proofs couldn't be checked.
reason-bad-reference = A link to a receipt is malformed.
reason-reference-unpinned = No trust policy pinned on this device matches this receipt link.
reason-reference-ambiguous = This receipt link matches more than one trust policy pinned on this device, so it wasn't used.

# The booth's configuration check
reason-bad-config = The client settings or opening notice are malformed, unsigned or lack the required witness signatures, so the client cannot proceed.
reason-config-mismatch = The recorded settings differ from the client's deployment, key, styles, trust policy or software, or were not in force when the deployment opened, so the client cannot proceed.

# Keys logs
reason-bad-key-statement = A statement in a record of keys is malformed, names another record, doesn't match its entry, or lacks the signatures it needs, so it doesn't count.
reason-signed-by-failed = A statement isn't signed by its key, the key was revoked or wasn't valid when the entry was recorded, or too few other valid keys signed it too.
    .not-ed25519 = The statement, or the key that should have signed it, is malformed or of the wrong type.
    .not-signed = The statement isn't signed by its key.
    .revoked = The key that signed the statement had been revoked before the entry was recorded.
    .not-valid = The key that signed the statement wasn't valid when the entry was recorded.
    .cosigners = Too few other valid keys signed the statement too: { $have } of the { $need } needed.

# Upgrades
reason-log-quiet = The record is in a quiet period and shows nothing newer until it ends, so some proofs wait until then.
reason-log-private = The record is private: only auditors can read it, so its proofs come through the event's website.
reason-monitor-evidence = Monitor { $monitor } published evidence that this version of the record contradicts the one it holds. That evidence hasn't been checked here yet.

# Successor policies
reason-successors-unchecked = It hasn't been checked yet whether a newer trust policy replaced this one, so nothing shows as verified.
reason-bad-policy-proofs = The proofs about newer trust policies are malformed or don't verify.
reason-successor-rejected = A newer trust policy was published, but it breaks the rules for replacing one, so the earlier policy stays in force.
reason-policy-equivocation = The trust policy's authorities signed two different replacements for it, which proves they contradicted themselves. The first one published counts.

# Anchor hubs
reason-bad-subject = The name or key under which an anchor hub keeps a record's anchors is malformed, so it doesn't count.
reason-waiting-for-anchor = Waiting for the anchor hub to anchor the record.
reason-hub-quorum-not-met = Not enough of the anchor hub's witnesses have signed yet.
reason-bad-hub-link = The anchor hub's proof is malformed or doesn't verify.
reason-hub-link-mismatch = The anchor hub's proof is about something else.
reason-hub-index-wrong = Hub { $hub }'s witnesses signed an index that points to the wrong entry for this record, so they signed without checking.
reason-map-proof-failed = The anchor hub's map proof doesn't verify.
reason-subject-rotated = The record's key changed at this anchor hub. The newer trust policy is needed.
reason-rotation-unauthorized = At hub { $hub }, the record's key was changed by an entry that no known trust policy allows.
reason-anchor-behind-record = The anchor hub holds an older version of the record than your receipt.
reason-anchor-quorum-not-met = The anchored record lacks enough witness signatures.
reason-hub-link-stale = The record's proof from hub { $hub } is much older than the hub's latest version: the record should have a newer one by now.
reason-bad-blinded-anchor = A sealed anchor doesn't verify.
reason-opening-missing = The file doesn't hold what opens the sealed anchor yet.
reason-bad-opening = What should open the sealed anchor doesn't match it.
reason-previous-anchor-missing = The previous sealed anchor in hub { $hub }, or what opens it, isn't in the file yet.
reason-bad-previous-anchor = The previous sealed anchor isn't the record's anchor just before this one, so it couldn't be checked.
reason-attestation-missing = No auditor has confirmed the sealed anchor in hub { $hub } yet. It stays pending until one does, and never turns late.
reason-attestation-not-covering = The auditor's confirmation for hub { $hub } covers sealed anchors { $from } to { $to }, not yet number { $seq }.
reason-bad-attestation = An auditor's confirmation couldn't be checked: it's malformed, isn't signed by an auditor of the trust policy, or doesn't match the sealed anchor.
reason-hub-entry-refused = An anchor hub recorded an entry that breaks the hub's rules, so the entry doesn't count.

# Browser layer
reason-browser-test-only = The browser layer is only a test here: it's run by the operator.
reason-waiting-for-browser-anchor = Waiting for the browser layer. It's due within minutes.
reason-pair-not-covering = The record's latest proof for the browser layer, from hub { $hub }, is from before the entry. The next one will cover it.
reason-browser-below-link = The browser layer shows an older version of hub { $hub } than the proof it's paired with, so the two don't fit together.
reason-waiting-for-hub-tier = Waits for hub { $hub }: in a private event, the browser layer counts only once the hub is verified.
reason-bad-browser-pair = The record's proofs for the browser layer are malformed.
reason-bad-browser-anchor = A browser anchor is malformed or doesn't match.
reason-bad-waict-proof = The browser layer's proof doesn't verify.
reason-waict-quorum-not-met = Not enough of the browser layer's witnesses signed.
reason-unknown-waict-service = The browser anchor comes from a service the policy doesn't list.
reason-waict-service-not-independent = The browser layer is run by the operator, so it doesn't count.
reason-bad-bootstrap-link = A bootstrap hub's proof is malformed or doesn't verify.

# Trust policies
reason-policy-syntax = A line of the trust policy is malformed.
reason-policy-unknown-keyword = A line of the trust policy starts with an unknown word.
reason-policy-count = A line of the trust policy appears too often or not at all.
reason-policy-undefined-name = The trust policy uses a name before defining it.
reason-policy-duplicate-name = The trust policy defines a name twice.
reason-policy-invalid = The trust policy breaks one of its rules.
reason-policy-unsafe-quorum = The trust policy's witness quorum isn't safe.
reason-policy-unsigned = The trust policy lacks enough signatures from its authorities.

# Payloads and redaction
reason-payload-mismatch = The data a server sent for an entry doesn't match what the record holds for it, so it isn't the recorded data. A mirror of the record may have the right data.
reason-payload-missing = Data recorded for an entry isn't available, and no valid redaction notice says it was withheld. A mirror of the record may still have it.
reason-bad-payload-bundle = The data a server sent for a batch of entries is malformed or isn't for those entries, so it couldn't be checked. A mirror of the record may have it.
reason-bad-notice = A redaction notice is malformed, so it doesn't count.
reason-notice-unsigned = A redaction notice lacks enough signatures from the authorities the trust policy names for redactions, so it doesn't count.
    .no-redaction = The trust policy allows no redaction, so a redaction notice doesn't count.
reason-notice-mismatch = A redaction notice doesn't match the data withheld under it or its recorded copy, or names data that can't be redacted, so it doesn't count.
    .profile = A redaction notice names an entry whose profile forbids redaction, so it does not count.
reason-notice-not-applied = A redaction notice has no effect: it doesn't refer to the latest notice that applied to the same entry, repeats an earlier one, or is dated before that notice was recorded.
reason-bad-notice-bundle = The proof that a redaction notice was recorded is malformed, doesn't verify, or lacks enough witness signatures, so the notice doesn't count.

# Evidence files
reason-bad-evidence = The evidence file is malformed, or lacks a part its kind needs.
reason-evidence-unknown-kind = The evidence file is of a kind this verifier doesn't know.
reason-evidence-unpinned = The evidence file is for a trust policy this device hasn't pinned.
reason-evidence-wrong-subject = The evidence file is about a record or hub that its kind doesn't apply to under its trust policy.
reason-evidence-policy-mismatch = Part of the evidence file is for another trust policy than the file's.
reason-not-proven = The evidence's signatures check out, but they don't show the problem it claims.
reason-needs-scan = This can only be settled by reading the record's entries, which this check didn't do.
reason-rule-unsupported = The evidence names a rule this verifier can't run. A full verifier can check it.
reason-faulty-witness = This witness signed two versions that contradict each other, or a hub version with a bad entry, which proves it's faulty.
reason-trust-assumption-failed = Enough witnesses signed the contradicting versions to meet the quorum: more of them are faulty than the trust policy assumes.
reason-misbehaviour-proven = The evidence proves the problem it claims, under the file's trust policy.

reason-unknown = Reason “{ $code }”

# Shared infrastructure. Draft translations need native-speaker review.
reason-bad-operator-list = The infrastructure list is damaged or uses an unsupported format.
reason-operator-list-refused = The infrastructure list could not be accepted under the pinned authorities, validity window or update history.
reason-bad-shared-submission = The shared-log request or enrolment is damaged or does not follow the format.
reason-shared-submission-refused = The shared log could not accept this request under its pinned policy, submitter key or namespace.

# New metadata reason: native translation review needed outside English.
reason-profile-meaning-unknown = The profile meaning is not available for validation.

## extension

# The names of the anchor hubs and the browser layer in the extension's compact receipt chain.
tier-hubs-short = Hubs
tier-browser-short = Browser
