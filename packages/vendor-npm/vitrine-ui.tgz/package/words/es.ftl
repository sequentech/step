# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Spanish (es).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Incluido
fact-unchanged = Sin cambios
fact-same-for-everyone = Igual para todos

fact-state-done = Completado
fact-state-promised = Prometido
fact-state-pending = Pendiente
fact-state-late = Con retraso
fact-state-invalid = No se pudo comprobar
fact-state-failed = Fallido
fact-state-checking = Comprobando

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Su entrada está en el registro.
fact-included-promised = El registro firmó una promesa de incluir su entrada.
fact-included-pending = Algunas pruebas de que su entrada está en el registro aún están en camino.
fact-included-late = El registro ya debería haber incluido su entrada.
fact-included-invalid = No se pudo comprobar la prueba de que su entrada está en el registro: los datos parecen dañados.
fact-included-failed = Las propias firmas del registro se contradicen entre sí sobre su entrada.
fact-unchanged-done = El registro está firmado por testigos independientes, por lo que nada en él puede cambiar sin que se note.
fact-unchanged-pending = Esperando a que los testigos independientes firmen el registro.
fact-unchanged-late = Los testigos ya deberían haber firmado el registro.
fact-unchanged-invalid = No se pudieron comprobar las pruebas sobre el historial del registro: los datos parecen dañados.
fact-unchanged-failed = Hay pruebas firmadas sobre el historial del registro que se contradicen entre sí.
fact-same-for-everyone-done = Todos los que lo comprueban ven este mismo registro.
fact-same-for-everyone-pending = Esperando a que el registro quede anclado donde todos puedan comprobarlo.
fact-same-for-everyone-late = El registro ya debería estar anclado donde todos puedan comprobarlo.
fact-same-for-everyone-invalid = No se pudieron comprobar los anclajes: los datos parecen dañados.
fact-same-for-everyone-failed = Hay pruebas firmadas que demuestran que no todos ven el mismo registro.
# Instead of the pending text: `fact-pending-successors` (any fact) when every
# tier the fact rests on waits only for the check for a newer trust policy
# (specs/policy.md, section 4, rule 7), and
# `fact-same-for-everyone-pending-attestation` when a private event's anchor
# hubs wait for an auditor to confirm the sealed anchors (specs/receipt.md,
# section 3.3).
fact-pending-successors = Las pruebas son correctas. Aparecerá como completado cuando se compruebe si la política de confianza fue sustituida por una más reciente.
fact-same-for-everyone-pending-attestation = Anclado. Un auditor aún tiene que confirmar los anclajes sellados, lo que puede tardar.

## Tiers

tier-record = Registro
tier-witnesses = Testigos
tier-hubs = Centros de anclaje
tier-browser = Capa de navegadores
tier-policy = Política de confianza
tier-entry = Entrada

tier-status-verified = Verificado
tier-status-pending = Pendiente
tier-status-late = Con retraso
tier-status-invalid = No se pudo comprobar
tier-status-failed = Fallido
tier-status-unused = No se usa
tier-status-checking = Comprobando
tier-status-promised = Prometido

tier-record-verified = Su entrada está en el registro firmado.
tier-record-promised = El registro firmó una promesa de incluir su entrada.
tier-record-pending = Algunas pruebas del registro aún están en camino.
tier-record-late = El registro ya debería haber incluido su entrada.
tier-record-invalid = Las pruebas del registro parecen dañadas, por lo que no se pudieron comprobar.
tier-record-failed = El registro firmó pruebas que se contradicen entre sí.
tier-record-checking = Comprobando las pruebas del registro.
tier-witnesses-verified = El registro tiene la firma de suficientes testigos independientes.
tier-witnesses-pending = Esperando a que firmen los testigos. Tarda unos segundos.
tier-witnesses-late = Los testigos ya deberían haber firmado.
tier-witnesses-invalid = Las firmas de los testigos parecen dañadas, por lo que no se pudieron comprobar.
tier-witnesses-failed = Algunos testigos firmaron un registro que contradice el suyo.
tier-witnesses-checking = Comprobando las firmas de los testigos.
tier-hubs-verified = Todos los centros de anclaje contienen el registro.
tier-hubs-pending = En camino a los centros de anclaje. Tarda unos segundos.
tier-hubs-late = Los centros de anclaje ya deberían contener el registro.
tier-hubs-invalid = La respuesta de un centro de anclaje parece dañada, por lo que no se pudo comprobar.
tier-hubs-failed = Un centro de anclaje contiene un registro firmado que contradice el suyo.
tier-hubs-unused = Esta política no usa centros de anclaje.
tier-hubs-checking = Comprobando los centros de anclaje.
tier-browser-verified = Anclado donde los navegadores lo comprueban.
tier-browser-pending = Tardará pocos minutos. No es necesario esperar.
tier-browser-late = Ya debería estar anclado donde los navegadores lo comprueban.
tier-browser-invalid = La respuesta de la capa de navegadores parece dañada, por lo que no se pudo comprobar.
tier-browser-failed = Un anclaje firmado que comprueban los navegadores contradice el registro.
tier-browser-unused = Esta política no usa una capa de navegadores independiente.
tier-browser-checking = Comprobando la capa de navegadores.
# Instead of the pending text: `tier-pending-successors` (any tier) when every
# check of the tier passed but the check for a newer trust policy hasn't run
# yet; in a private event, `tier-hubs-pending-attestation` when the anchor hubs
# wait for an auditor, and `tier-browser-pending-hubs` when the browser layer
# waits for the anchor hubs.
tier-pending-successors = Sus pruebas son correctas. Aparecerá como verificado cuando se compruebe si la política de confianza fue sustituida por una más reciente.
tier-hubs-pending-attestation = Anclado. Un auditor aún tiene que confirmar los anclajes sellados. Esto puede tardar, y nunca se considera con retraso.
tier-browser-pending-hubs = Espera a los centros de anclaje: en un evento privado, la capa de navegadores solo cuenta cuando están verificados.
tier-test = Solo de ensayo: está a cargo del operador, por lo que no cuenta.
tier-deadline = Hora límite prevista: { TIME($deadline) }
hub-test = ensayo

## The one-line status

status-verified = Verificado
status-checking = Comprobando…
status-pending = Pendiente
status-late = Con retraso
status-invalid = No se pudo comprobar
status-failed = Fallido
status-summary-verified = Incluido, sin cambios e igual para todos.
status-summary-checking = Comprobando las pruebas del recibo en este navegador.
status-summary-pending = Algunas pruebas aún están en camino. No es necesario esperar.
status-summary-pending-successors = Las pruebas son correctas. El recibo aparecerá como verificado cuando se compruebe si la política de confianza fue sustituida por una más reciente.
status-summary-pending-attestation = Anclado. Un auditor aún tiene que confirmar los anclajes sellados. No es necesario esperar.
status-summary-late = Algunas pruebas ya deberían haber llegado.
status-summary-invalid = No se pudieron comprobar algunos datos: el archivo o la respuesta del servidor parecen dañados. Esto no indica que nadie haya hecho trampa.
status-summary-failed = Hay pruebas firmadas que se contradicen entre sí. Guarde la evidencia.

## <vitrine-receipt>

receipt-label = Recibo
receipt-words-label = Palabras del recibo
receipt-entry = Entrada { $index } en { $log }
receipt-entry-promised = Entrada prometida en { $log }
receipt-provenance-page = Comprobado por este sitio web
receipt-provenance-page-hint = Este sitio web comprobó su propio registro. Para mayor seguridad, compruébelo de forma independiente.
receipt-provenance-independent = Comprobado sin depender del sitio web
receipt-facts-heading = Lo que muestran las pruebas
receipt-chain-heading = Hasta dónde ha llegado
receipt-compare-heading = Comparar con el aviso oficial
receipt-compare-hint = Estas palabras y testigos deberían coincidir con los que publicó la autoridad, por ejemplo, en el aviso oficial de la elección.
receipt-policy-words = Palabras de la política
receipt-policy-in-force = Política vigente
receipt-policy-in-force-hint = Sustituyó a la política anterior, como permiten las reglas de esa política. Sus palabras deberían coincidir con un aviso más reciente de la autoridad.
receipt-policy-id = ID de la política
receipt-event = Evento
receipt-witnesses = Testigos
receipt-witness-party = a cargo de { $party }
receipt-hubs = Centros de anclaje
receipt-clock-warning = El reloj de este dispositivo tiene más de un minuto de desfase. Los plazos se evalúan con la hora firmada, no con este reloj.
receipt-action-check = Comprobar de forma independiente
receipt-action-download = Descargar recibo
receipt-action-retry = Volver a comprobar
receipt-invalid = No se pudieron comprobar algunos datos: el archivo o la respuesta del servidor parecen dañados. Esto no indica que nadie haya hecho trampa. Puede volver a comprobarlo o comprobarlo de forma independiente.
receipt-no-expect = Esta página no indicó qué entrada esperar, por lo que este recibo no se puede mostrar como suyo.
receipt-error = No se pudo comprobar este recibo.
receipt-empty = Aún no hay ningún recibo.
receipt-announce = { $tier }: { $status }.

## <vitrine-proof-steps>

steps-heading = Todas las comprobaciones
steps-summary =
    { $total ->
        [one] { $passed } de { $total } comprobación superada
       *[other] { $passed } de { $total } comprobaciones superadas
    }
steps-result-passed = Superada
steps-result-failed = No superada
steps-result-not-run = Aún no realizada
steps-show-details = Mostrar detalles
steps-hide-details = Ocultar detalles
steps-objects = Objetos firmados implicados: { $objects }
steps-evidence = Guardar la evidencia
steps-empty = Aún no hay comprobaciones.

## <vitrine-chain>

chain-label = Cadena del recibo

## <vitrine-alert>

alert-label = Problema demostrado
alert-kind-split-view-title = El registro se mostró de forma diferente a distintas personas
alert-kind-split-view-body = Dos versiones del registro, ambas firmadas por su operador, no pueden ser ciertas a la vez. Puede tratarse de un fallo o de un ataque. Es posible que su entrada siga contando, pero conviene que alguien independiente lo revise.
alert-kind-broken-promise-title = El registro incumplió una promesa firmada
alert-kind-broken-promise-body = El registro prometió incluir una entrada dentro de un plazo, y sus propias firmas muestran que no lo hizo. Conviene que alguien independiente lo revise.
alert-kind-bad-entry-title = El registro contiene una entrada que incumple sus reglas
alert-kind-bad-entry-body = Una entrada firmada en el registro incumple una regla de su perfil. Conviene que alguien independiente lo revise.
alert-kind-hub-entry-title = Un centro de anclaje aceptó una entrada que debería haber rechazado
alert-kind-hub-entry-body = Los testigos de un centro de anclaje firmaron un registro de ese centro con una entrada que incumple sus reglas, por lo que al menos uno de ellos firmó sin comprobar.
alert-kind-time-regression-title = El registro firmó una hora falsa
alert-kind-time-regression-body = El registro firmó dos versiones de sí mismo, y la más grande tiene la hora más temprana. La hora firmada de un registro nunca retrocede, así que una de las dos es falsa. Conviene que alguien independiente lo revise.
alert-kind-policy-equivocation-title = Las autoridades de la política de confianza firmaron dos sustituciones distintas
alert-kind-policy-equivocation-body = Suficientes autoridades de la política de confianza firmaron dos sustituciones distintas de ella, y las dos quedaron registradas. Cuenta la primera que se registró, pero la segunda podría mostrar políticas distintas a distintas personas. Conviene que alguien independiente lo revise.
alert-kind-bad-checkpoint-title = Un registro firmó una versión imposible de sí mismo
alert-kind-bad-checkpoint-body = Firmó una versión que no tiene entradas, pero no está vacía. Ningún registro ni centro de anclaje honesto puede producir algo así. Conviene que alguien independiente lo revise.
alert-kind-unknown-title = Se encontró un problema
alert-kind-unknown-body = La evidencia muestra un tipo de problema que esta página no conoce: { $kind }.
alert-not-proven-title = Este archivo no demuestra ningún problema
alert-not-proven-body = El archivo se comprobó y no demuestra ningún problema. No constituye evidencia.
alert-unpinned-title = Este archivo corresponde a una política que no está fijada en este dispositivo
alert-unpinned-body = No se puede mostrar como prueba en este dispositivo. Compare las palabras de la política del archivo con el aviso oficial y fije esa política antes de volver a comprobar el archivo.
alert-invalid-title = No se pudo comprobar este archivo
alert-invalid-body = El archivo parece dañado. Esto no indica que nadie haya hecho trampa.
alert-proven-under = Demostrado según la política con estas palabras:
alert-file-policy-words = Palabras de la política del archivo:
alert-parties = Responsables, según sus propias firmas: { $parties }
alert-evidence-heading = Evidencia guardada en este dispositivo
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } KB
alert-evidence-hint = Cualquier persona puede comprobar este archivo en su propio dispositivo. Solo contiene objetos firmados del registro.
alert-download = Descargar archivo de evidencia
alert-send = Enviar a los monitores
alert-monitors-heading = Monitores designados por la política
alert-confirm-heading = ¿Enviar la evidencia?
alert-confirm-body =
    { $count ->
        [one] Se enviará el archivo de evidencia a este monitor. Verá el archivo y sabrá que procede de este dispositivo.
       *[other] Se enviará el archivo de evidencia a estos { $count } monitores. Verán el archivo y sabrán que procede de este dispositivo.
    }
alert-confirm-send = Sí, enviar
alert-confirm-cancel = Cancelar
alert-sending = Se está enviando la evidencia a los monitores.
alert-no-monitors = La política no designa ningún monitor. Guarde el archivo y entrégueselo a un observador.
alert-delivery-waiting = Esperando confirmación
alert-delivery-sending = Enviando
alert-delivery-confirmed = Confirmado
alert-delivery-failed = No confirmado

## <vitrine-badge>

badge-check = Comprobar de forma independiente
badge-opens = abre un verificador independiente

## Monitor reports (specs/evidence.md, section 3). `report-kind-<kind>` says
## what a report is about, with `$subject`, the record or hub it names. A
## report is its monitor's own statement, not proof: show `report-established`
## only when monitors of enough different parties report the same thing.

report-kind-cosign-late = { $subject } lleva demasiado tiempo sin una versión reciente firmada por suficientes testigos.
report-kind-anchor-late = { $subject } no se ancló a tiempo: el registro o el centro de anclaje va con retraso, y el informe no puede decir cuál de los dos.
report-kind-unreachable = Un servidor de { $subject } dejó de responder.
report-kind-mirror-behind = La copia de { $subject } que guarda una réplica se ha quedado atrás.
report-kind-payload-missing = Algunos datos registrados en { $subject } no están disponibles, y ningún aviso indica que se hayan retenido.
report-kind-payload-mismatch = Algunos datos que sirve { $subject } no coinciden con lo que registró.
report-kind-rule-failing = Una entrada de { $subject } incumple una regla de su perfil. El monitor publicó evidencia que cualquiera puede comprobar.
report-kind-promise-pending = { $subject } firmó una promesa de incluir una entrada, y aún no la ha incluido.
report-kind-promise-unlisted = { $subject } deja fuera de su lista un lote de sus promesas firmadas.
report-kind-promise-late = { $subject } no cumplió a tiempo una promesa firmada: el registro o sus testigos se retrasaron, o sus relojes no están en hora.
report-kind-promise-misdated = { $subject } fechó mal un lote de sus promesas firmadas: su hora no encaja con la hora en que se listó, o con el momento en que el monitor lo vio por primera vez.
report-kind-opening-missing = { $subject } no abrió a tiempo un anclaje sellado para el auditor.
report-kind-ack-missing = { $subject } no ofrece su declaración firmada de que sigue la política de confianza vigente.
report-kind-config-mismatch = A una cabina de votación se le mostró una configuración de la elección que { $subject } no ha registrado, o que difiere de la registrada.
report-kind-code-mismatch = Un sitio web sirvió un script que no forma parte de ninguna versión publicada registrada en { $subject }.
report-kind-unknown = Informe de monitor «{ $kind }» sobre { $subject }
report-established = Confirmado: lo informan monitores de suficientes partes distintas.
report-statement = Informado por { $monitor }. Un informe es una declaración del propio monitor, no una prueba sobre nadie más.

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = El archivo del recibo está bien formado
step-policy-pinned = El recibo corresponde a la política de confianza fijada
step-policy-successors = Se comprobó si una política de confianza más reciente sustituyó a la fijada
step-policy-ack = El registro firmó que sigue la política de confianza
step-log-known = El registro del recibo figura en la política
step-entry-parse = La entrada está bien formada
step-entry-profile = La entrada es del tipo del registro y tiene sus campos
step-entry-expectation = La entrada es la que usted esperaba
step-promise-signature = El registro firmó una promesa de incluir la entrada
step-promise-inclusion = La promesa firmada cubre la entrada
step-promise-leaf = La promesa corresponde a la entrada que usted esperaba
step-promise-kept = El registro cumplió su promesa dentro del plazo
step-issued-signature = El recibo emitido al enviar la entrada está firmado por el registro
step-issued-inclusion = La entrada está en el recibo emitido al enviarla
step-record-signature = El recibo del registro está firmado por el registro
step-record-inclusion = La entrada está en el registro
step-receipts-match = Los recibos corresponden a la misma entrada en la misma posición
step-record-consistency = Desde el recibo emitido al enviar la entrada, el registro solo ha crecido
step-record-quorum = El registro tiene la firma de suficientes testigos independientes
step-log-consistent = Las versiones del registro vistas aquí no se contradicen
step-hub-link = La prueba del centro { $hub } es válida
step-hub-opening = El anclaje sellado del centro { $hub } se abre y coincide con el registro
step-hub-anchored-checkpoint = El registro anclado en el centro { $hub } está firmado por el registro y sus testigos
step-hub-previous-anchor = El centro { $hub } contiene el anclaje sellado anterior, y este se abre y coincide con el registro
step-hub-opening-consistency = Entre sus dos últimos anclajes sellados en el centro { $hub }, el registro solo ha crecido
step-hub-attestation = Un auditor confirmó el anclaje sellado del centro { $hub }
step-hub-anchor-consistency = Hasta su anclaje en el centro { $hub }, el registro solo ha crecido
step-browser-link = La prueba del centro { $hub } para la capa de navegadores es válida y cubre la entrada
step-browser-link-consistency = Entre su recibo y la prueba del centro { $hub } para la capa de navegadores, el registro solo ha crecido
step-browser-anchor = La capa de navegadores contiene el registro del centro { $hub }
step-browser-consistency = Hasta su versión anclada donde los navegadores lo comprueban, el centro { $hub } solo ha crecido
step-bootstrap-link = Un centro de arranque ancla el centro { $hub }
step-unknown = Comprobación «{ $code }»

## Reasons, why a check failed or is still waiting (`reason-<code>`). Their
## variables are the verifier's `params`. A message uses only those that the
## verifier always passes for its code: the tier, hub or step it belongs to is
## shown next to it anyway.

# Encodings and limits
reason-bad-base64 = Un valor en base64 está mal formado.
reason-bad-hex = Un valor hexadecimal está mal formado.
reason-bad-text = Un texto no es válido o contiene un carácter no permitido.
reason-bad-number = Un número está mal formado o fuera de rango.
reason-trailing-data = Hay datos inesperados después de una parte del archivo.
reason-truncated = Una parte del archivo termina antes de tiempo.
reason-too-large = Algo supera los límites permitidos.

# Signed notes and keys
reason-bad-note = Una nota firmada está mal formada.
reason-bad-key-name = Un nombre de clave está mal formado.
reason-bad-vkey = Una clave pública está mal formada o es de un tipo incorrecto.
reason-bad-public-key = Una clave pública no es válida.
reason-missing-signature = Falta una firma obligatoria.

# Checkpoints and witness signatures
reason-bad-checkpoint = Un punto de control está mal formado.
reason-bad-empty-tree = Una versión firmada del registro es imposible: no tiene entradas, pero su contenido no está vacío.
reason-wrong-origin = Una nota firmada menciona un registro o centro distinto del esperado.
reason-log-time-missing = A un recibo le falta la hora firmada del registro, por lo que no se pudo comprobar.
reason-cosignature-in-future = Una firma de testigo tiene fecha futura, por lo que no se tuvo en cuenta.
reason-quorum-not-met = Aún no han firmado suficientes testigos independientes.

# Proofs
reason-bad-proof = Una prueba está mal formada.
reason-missing-extra = Un recibo no contiene la entrada.
reason-index-out-of-range = La posición de la entrada está más allá del final del registro.
reason-inclusion-failed = La prueba de que la entrada está en el registro no es válida.
reason-consistency-failed = La prueba de que el registro solo ha crecido no es válida.
reason-split-view = Dos versiones firmadas del registro tienen el mismo tamaño pero distinto contenido.

# Entries and expectations
reason-bad-entry = La entrada está mal formada.
reason-wrong-profile = El tipo de la entrada no coincide con el tipo del registro en esa posición.
reason-bad-entry-layout = Los campos de la entrada no coinciden con su tipo.
reason-entry-mismatch = La entrada no es la que usted esperaba.
reason-expectation-incomplete = La página no indicó lo suficiente sobre la entrada para comprobarla.
reason-expectation-unknown-field = La página indicó un campo que este tipo de entrada no tiene.
reason-expectation-unsupported = Este verificador no puede comprobar los campos de este tipo de entrada.
reason-receipts-disagree = Los recibos del archivo corresponden a entradas o posiciones distintas.

# Promises
reason-bad-promise = La promesa está mal formada.
reason-promise-policy-unknown = La promesa menciona una política de confianza que no es la fijada ni una que la haya sustituido.
reason-promise-mmd-too-large = La promesa admite más demora de la que permite la política.
reason-promise-leaf-mismatch = La promesa corresponde a otra entrada.
reason-promise-pending = El registro prometió incluir la entrada. Aún no ha vencido el plazo de su recibo.
reason-promise-deadline-passed = El plazo de la promesa ha vencido y aún no hay recibo.
reason-promise-kept-unproven = Nada en el archivo muestra que la promesa se haya cumplido a tiempo.
reason-broken-promise = El registro prometió incluir la entrada antes de la hora límite ({ TIME($deadline) }), pero su propia hora firmada ({ TIME($logTime) }) muestra que después aún no lo había hecho.

# Receipt chains
reason-malformed-chain = El archivo del recibo está mal formado.
reason-duplicate-block = El archivo del recibo contiene la misma parte dos veces.
reason-no-receipt = El archivo no contiene ninguna promesa ni ningún recibo.
reason-policy-mismatch = El recibo menciona una política de confianza distinta de la fijada.
reason-policy-draft = La política de confianza aún es un borrador, y un borrador nunca es válido.
reason-bad-policy-ack = La declaración firmada del registro de que sigue esta política de confianza está mal formada o no coincide con ella.
reason-unknown-log = El recibo menciona un registro que no figura en la política.
reason-unknown-hub = Una parte del archivo menciona un centro de anclaje que no figura en la política, por lo que no se tuvo en cuenta.
reason-consistency-missing = Falta una prueba de que el registro solo ha crecido.
reason-consistency-mismatch = Una prueba de que el registro solo ha crecido no encaja con las versiones que relaciona.
reason-waiting-for-cosignatures = Esperando a que los testigos firmen el registro.
reason-waiting-for-record = Esperando el registro firmado por los testigos.
reason-no-signed-time = Aún no hay hora firmada, por lo que no se pueden evaluar los plazos.
reason-deadline-passed = El plazo ha vencido, según la hora firmada.
reason-record-invalid = No se pudo comprobar, porque las pruebas del registro no se pudieron comprobar.
reason-bad-reference = Un enlace a un recibo está mal formado.
reason-reference-unpinned = Ninguna política de confianza fijada en este dispositivo corresponde a este enlace al recibo.
reason-reference-ambiguous = Este enlace al recibo corresponde a más de una política de confianza fijada en este dispositivo, por lo que no se usó.

# The booth's configuration check
reason-bad-config = La configuración de la elección, o el aviso de que se abrió la votación, está mal formada, sin firmar o sin firmas suficientes de testigos, por lo que la cabina de votación no cifrará ninguna papeleta con ella.
reason-config-mismatch = La configuración registrada de la elección no coincide con el evento, la elección, la clave de la elección, los modelos de papeleta, la política de confianza o el software de la cabina de votación, o no es la vigente cuando se abrió la votación, por lo que la cabina no cifrará ninguna papeleta.

# Keys logs
reason-bad-key-statement = Una declaración de un registro de claves está mal formada, menciona otro registro, no coincide con su entrada o le faltan las firmas que necesita, por lo que no cuenta.
reason-signed-by-failed = Una declaración no está firmada por su clave, la clave estaba revocada o no era válida cuando se registró la entrada, o muy pocas otras claves válidas la firmaron también.
    .not-ed25519 = La declaración, o la clave que debía firmarla, está mal formada o es de un tipo incorrecto.
    .not-signed = La declaración no está firmada por su clave.
    .revoked = La clave que firmó la declaración ya estaba revocada cuando se registró la entrada.
    .not-valid = La clave que firmó la declaración no era válida cuando se registró la entrada.
    .cosigners = Muy pocas otras claves válidas firmaron también la declaración: { $have } de las { $need } necesarias.

# Upgrades
reason-log-quiet = El registro está en un periodo de silencio y no muestra nada más reciente hasta que termine, por lo que algunas pruebas esperarán hasta entonces.
reason-log-private = El registro es privado: solo los auditores pueden leerlo, por lo que sus pruebas llegan a través del sitio web del evento.
reason-monitor-evidence = El monitor { $monitor } publicó evidencia de que esta versión del registro contradice la que él tiene. Esa evidencia aún no se ha comprobado aquí.

# Successor policies
reason-successors-unchecked = Aún no se ha comprobado si una política de confianza más reciente sustituyó a esta, por lo que nada aparece como verificado.
reason-bad-policy-proofs = Las pruebas sobre políticas de confianza más recientes están mal formadas o no son válidas.
reason-successor-rejected = Se publicó una política de confianza más reciente, pero incumple las reglas para sustituir una política, por lo que sigue vigente la anterior.
reason-policy-equivocation = Las autoridades de la política de confianza firmaron dos sustituciones distintas de ella, lo que demuestra que se contradijeron. Cuenta la primera que se publicó.

# Anchor hubs
reason-waiting-for-anchor = Esperando a que el centro de anclaje ancle el registro.
reason-hub-quorum-not-met = Todavía no han firmado suficientes testigos del centro de anclaje.
reason-bad-hub-link = La prueba del centro de anclaje está mal formada o no es válida.
reason-hub-link-mismatch = La prueba del centro de anclaje se refiere a otra cosa.
reason-hub-index-wrong = Los testigos del centro { $hub } firmaron un índice que apunta a una entrada equivocada para este registro, por lo que firmaron sin comprobar.
reason-map-proof-failed = La prueba de mapa del centro de anclaje no es válida.
reason-subject-rotated = La clave del registro cambió en este centro de anclaje. Se necesita la política de confianza más reciente.
reason-rotation-unauthorized = En el centro { $hub }, la clave del registro la cambió una entrada que ninguna política de confianza conocida permite.
reason-anchor-behind-record = El centro de anclaje contiene una versión del registro más antigua que la de su recibo.
reason-anchor-quorum-not-met = El registro anclado no tiene suficientes firmas de testigos.
reason-hub-link-stale = La prueba del centro { $hub } que tiene el registro es mucho más antigua que la última versión del centro: el registro ya debería tener una más reciente.
reason-bad-blinded-anchor = Un anclaje sellado no es válido.
reason-opening-missing = El archivo aún no contiene lo que abre el anclaje sellado.
reason-bad-opening = Lo que debería abrir el anclaje sellado no coincide con él.
reason-previous-anchor-missing = El archivo aún no contiene el anclaje sellado anterior del centro { $hub }, o lo que lo abre.
reason-bad-previous-anchor = El anclaje sellado anterior no es el anclaje del registro inmediatamente previo a este, por lo que no se pudo comprobar.
reason-attestation-missing = Ningún auditor ha confirmado aún el anclaje sellado del centro { $hub }. Sigue pendiente hasta que uno lo haga, y nunca se considera con retraso.
reason-attestation-not-covering = La confirmación del auditor para el centro { $hub } cubre los anclajes sellados del { $from } al { $to }, todavía no el número { $seq }.
reason-bad-attestation = No se pudo comprobar la confirmación de un auditor: está mal formada, no la firma un auditor de la política de confianza o no coincide con el anclaje sellado.

# Browser layer
reason-browser-test-only = Aquí la capa de navegadores es solo de ensayo: está a cargo del operador.
reason-waiting-for-browser-anchor = Esperando a la capa de navegadores. Tardará pocos minutos.
reason-pair-not-covering = La última prueba del registro para la capa de navegadores, del centro { $hub }, es anterior a la entrada. La próxima la cubrirá.
reason-browser-below-link = La capa de navegadores muestra una versión del centro { $hub } más antigua que la de la prueba con la que va emparejada, por lo que no encajan.
reason-waiting-for-hub-tier = Espera al centro { $hub }: en un evento privado, la capa de navegadores solo cuenta cuando el centro está verificado.
reason-bad-browser-pair = Las pruebas del registro para la capa de navegadores están mal formadas.
reason-bad-browser-anchor = Un anclaje de la capa de navegadores está mal formado o no coincide.
reason-bad-waict-proof = La prueba de la capa de navegadores no es válida.
reason-waict-quorum-not-met = No firmaron suficientes testigos de la capa de navegadores.
reason-unknown-waict-service = El anclaje de la capa de navegadores procede de un servicio que no figura en la política.
reason-waict-service-not-independent = La capa de navegadores está a cargo del operador, por lo que no cuenta.
reason-bad-bootstrap-link = La prueba de un centro de arranque está mal formada o no es válida.

# Trust policies
reason-policy-syntax = Una línea de la política de confianza está mal formada.
reason-policy-unknown-keyword = Una línea de la política de confianza comienza con una palabra desconocida.
reason-policy-count = Una línea de la política de confianza aparece demasiadas veces o no aparece.
reason-policy-undefined-name = La política de confianza usa un nombre antes de definirlo.
reason-policy-duplicate-name = La política de confianza define un nombre dos veces.
reason-policy-invalid = La política de confianza incumple una de sus reglas.
reason-policy-unsafe-quorum = El quórum de testigos de la política de confianza no es seguro.
reason-policy-unsigned = La política de confianza no tiene suficientes firmas de sus autoridades.

# Evidence files
reason-bad-evidence = El archivo de evidencia está mal formado o le falta una parte que su tipo necesita.
reason-evidence-unknown-kind = El archivo de evidencia es de un tipo que este verificador no conoce.
reason-evidence-unpinned = El archivo de evidencia corresponde a una política de confianza que este dispositivo no ha fijado.
reason-evidence-wrong-subject = El archivo de evidencia trata de un registro o centro al que su tipo no se aplica según su política de confianza.
reason-evidence-policy-mismatch = Una parte del archivo de evidencia corresponde a una política de confianza distinta de la del archivo.
reason-not-proven = Las firmas de la evidencia son válidas, pero no muestran el problema que afirma.
reason-needs-scan = Esto solo se puede decidir leyendo las entradas del registro, y esta comprobación no lo hizo.
reason-rule-unsupported = La evidencia menciona una regla que este verificador no puede aplicar. Un verificador completo puede comprobarla.
reason-faulty-witness = Este testigo firmó dos versiones que se contradicen, o una versión de un centro con una entrada indebida, lo que demuestra que es defectuoso.
reason-trust-assumption-failed = Suficientes testigos firmaron las versiones contradictorias como para alcanzar el quórum: hay más testigos defectuosos de los que supone la política de confianza.
reason-misbehaviour-proven = La evidencia demuestra el problema que afirma, según la política de confianza del archivo.

reason-unknown = Motivo «{ $code }»
