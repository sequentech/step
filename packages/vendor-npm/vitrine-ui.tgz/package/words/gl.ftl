# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Galician (gl).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Incluído
fact-unchanged = Sen cambios
fact-same-for-everyone = Igual para todo o mundo

fact-state-done = Feito
fact-state-promised = Prometido
fact-state-pending = Pendente
fact-state-late = Con atraso
fact-state-invalid = Non se puido comprobar
fact-state-failed = Fallou
fact-state-checking = Comprobando

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = A súa entrada está no rexistro.
fact-included-promised = O rexistro asinou unha promesa de incluír a súa entrada.
fact-included-pending = Algunhas probas de que a súa entrada está no rexistro aínda están de camiño.
fact-included-late = O rexistro xa debería ter incluído a súa entrada.
fact-included-invalid = Non se puido comprobar a proba de que a súa entrada está no rexistro: os datos parecen danados.
fact-included-failed = As sinaturas do propio rexistro contradinse sobre a súa entrada.
fact-unchanged-done = Testemuñas asinaron o rexistro, así que nada nel pode cambiar sen que se note.
fact-unchanged-pending = Á espera de que as testemuñas asinen o rexistro.
fact-unchanged-late = As testemuñas xa deberían ter asinado o rexistro.
fact-unchanged-invalid = Non se puideron comprobar as probas sobre o historial do rexistro: os datos parecen danados.
fact-unchanged-failed = Hai probas asinadas sobre o historial do rexistro que se contradín.
fact-same-for-everyone-done = Calquera persoa que comprobe ve este mesmo rexistro.
fact-same-for-everyone-pending = Á espera de que o rexistro se ancore onde todo o mundo poida comprobalo.
fact-same-for-everyone-late = O rexistro xa debería estar ancorado onde todo o mundo poida comprobalo.
fact-same-for-everyone-invalid = Non se puideron comprobar as ancoraxes: os datos parecen danados.
fact-same-for-everyone-failed = Hai probas asinadas que mostran que non todo o mundo ve o mesmo rexistro.
# Instead of the pending text: `fact-pending-successors` (any fact) when every
# tier the fact rests on waits only for the check for a newer trust policy
# (specs/policy.md, section 4, rule 7), and
# `fact-same-for-everyone-pending-attestation` when a private event's anchor
# hubs wait for an auditor to confirm the sealed anchors (specs/receipt.md,
# section 3.3).
fact-pending-successors = As probas son correctas. Aparecerá como feito cando se comprobe se a política de confianza foi substituída por unha máis recente.
fact-same-for-everyone-pending-attestation = Ancorado. Un auditor aínda ten que confirmar as ancoraxes seladas, o que pode levar un tempo.

## Tiers

tier-record = Rexistro
tier-witnesses = Testemuñas
tier-hubs = Nodos de ancoraxe
tier-browser = Capa dos navegadores
tier-policy = Política
tier-entry = Entrada

tier-status-verified = Verificado
tier-status-pending = Pendente
tier-status-late = Con atraso
tier-status-invalid = Non se puido comprobar
tier-status-failed = Fallou
tier-status-unused = Non se usa
tier-status-checking = Comprobando
tier-status-promised = Prometido

tier-record-verified = A súa entrada está no rexistro asinado.
tier-record-promised = O rexistro asinou unha promesa de incluír a súa entrada.
tier-record-pending = Algunhas probas do rexistro aínda están de camiño.
tier-record-late = O rexistro xa debería ter incluído a súa entrada.
tier-record-invalid = As probas do rexistro parecen danadas, así que non se puideron comprobar.
tier-record-failed = O rexistro asinou probas que se contradín.
tier-record-checking = Comprobando as probas do rexistro.
tier-witnesses-verified = Asinaron o rexistro suficientes testemuñas.
tier-witnesses-pending = Á espera de que asinen as testemuñas. Isto leva uns segundos.
tier-witnesses-late = As testemuñas xa deberían ter asinado.
tier-witnesses-invalid = As sinaturas das testemuñas parecen danadas, así que non se puideron comprobar.
tier-witnesses-failed = Algunhas testemuñas asinaron un rexistro que contradí o do seu recibo.
tier-witnesses-checking = Comprobando as sinaturas das testemuñas.
tier-hubs-verified = Todos os nodos de ancoraxe conteñen o rexistro.
tier-hubs-pending = De camiño aos nodos de ancoraxe. Isto leva uns segundos.
tier-hubs-late = Os nodos de ancoraxe xa deberían conter o rexistro.
tier-hubs-invalid = A resposta dun nodo de ancoraxe parece danada, así que non se puido comprobar.
tier-hubs-failed = Un nodo de ancoraxe contén un rexistro asinado que contradí o do seu recibo.
tier-hubs-unused = Esta política non usa nodos de ancoraxe.
tier-hubs-checking = Comprobando os nodos de ancoraxe.
tier-browser-verified = Ancorado onde comproban os navegadores.
tier-browser-pending = Debería chegar nuns minutos. Non fai falta agardar.
tier-browser-late = O rexistro xa debería estar ancorado onde comproban os navegadores.
tier-browser-invalid = A resposta da capa dos navegadores parece danada, así que non se puido comprobar.
tier-browser-failed = Unha ancoraxe asinada alí onde comproban os navegadores contradí o rexistro.
tier-browser-unused = Esta política non usa ningunha capa dos navegadores.
tier-browser-checking = Comprobando a capa dos navegadores.
# Instead of the pending text: `tier-pending-successors` (any tier) when every
# check of the tier passed but the check for a newer trust policy hasn't run
# yet; in a private event, `tier-hubs-pending-attestation` when the anchor hubs
# wait for an auditor, and `tier-browser-pending-hubs` when the browser layer
# waits for the anchor hubs.
tier-pending-successors = As súas probas son correctas. Aparecerá como verificado cando se comprobe se a política de confianza foi substituída por unha máis recente.
tier-hubs-pending-attestation = Ancorado. Un auditor aínda ten que confirmar as ancoraxes seladas. Isto pode levar un tempo, e nunca se considera con atraso.
tier-browser-pending-hubs = Á espera dos nodos de ancoraxe: nun evento privado, a capa dos navegadores só conta cando están verificados.
tier-test = Só de proba: xestiónao o operador, así que non conta.
tier-deadline = Hora límite prevista: { TIME($deadline) }
hub-test = de proba

## Stages of a ballot in the log (specs/entry.md, section 4.1): a tag next to the status

stage-received = Sen emitir
stage-cast = Emitida
stage-audited = Auditada

## The one-line status

status-verified = Verificado
status-checking = Comprobando…
status-pending = Pendente
status-late = Con atraso
status-invalid = Non se puido comprobar
status-failed = Fallou
status-summary-verified = Incluído, sen cambios e igual para todo o mundo.
status-summary-checking = Comprobando as probas do recibo neste navegador.
status-summary-pending = Algunhas probas aínda están de camiño. Non fai falta agardar.
status-summary-pending-successors = As probas son correctas. O recibo aparecerá como verificado cando se comprobe se a política de confianza foi substituída por unha máis recente.
status-summary-pending-attestation = Ancorado. Un auditor aínda ten que confirmar as ancoraxes seladas. Non fai falta agardar.
status-summary-late = Algunhas probas xa deberían ter chegado.
status-summary-invalid = Non se puideron comprobar algúns datos: o ficheiro ou a resposta do servidor parecen danados. Isto non demostra que alguén fixese trampa.
status-summary-failed = Hai probas asinadas que se contradín. Garde as evidencias.

## <vitrine-receipt>

receipt-label = Recibo
receipt-entry = Entrada { $index } en { $log }
receipt-entry-promised = Entrada prometida en { $log }
receipt-provenance-page = Comprobado por este sitio web
receipt-provenance-page-hint = Este sitio web comprobou o seu propio rexistro. Para ter a certeza, compróbeo de forma independente.
receipt-provenance-independent = Comprobado de forma independente do sitio web
receipt-facts-heading = O que mostran as probas
receipt-chain-heading = Ata onde chegou
receipt-compare-heading = Compare co anuncio oficial
receipt-compare-hint = Este identificador de política e estas testemuñas deberían coincidir cos que publicou a autoridade, por exemplo, no anuncio das eleccións.
receipt-policy-in-force = Política vixente
receipt-policy-in-force-hint = Substituíu a política anterior, tal como o permiten as regras desa política. O seu identificador debería coincidir cun anuncio máis recente da autoridade.
receipt-policy-id = Identificador da política
receipt-event = Evento
receipt-witnesses = Testemuñas
receipt-witness-party = xestionada por { $party }
receipt-hubs = Nodos de ancoraxe
receipt-clock-warning = O reloxo deste dispositivo difire en máis dun minuto da hora máis recente que asinaron as testemuñas. Os prazos avalíanse coa hora asinada, non con este reloxo.
receipt-action-check = Comprobar de forma independente
receipt-action-download = Descargar recibo
receipt-action-retry = Comprobar de novo
receipt-invalid = Non se puideron comprobar algúns datos: o ficheiro ou a resposta do servidor parecen danados. Isto non demostra que alguén fixese trampa. Pode comprobar de novo ou facer unha comprobación independente.
receipt-no-expect = Esta páxina non indicou cal é a entrada esperada, así que non se pode mostrar este recibo como o seu.
receipt-error = Non se puido comprobar este recibo.
receipt-empty = Aínda non hai ningún recibo.
receipt-announce = { $tier }: { $status }.

## <vitrine-receipt>, the receipt card (the voter board). Its five steps are
## sealed on this device, then the four tiers. `$noun` is the profile's name for
## one entry ("ballot" in the election profile), or `receipt-noun`.

receipt-noun = entrada
receipt-fingerprint-label = Pegada de { $noun }

receipt-seal-checking = Comprobando
receipt-seal-sealed = Selado
receipt-seal-record-public = Incluído no rexistro público
receipt-seal-record-private = Incluído no rexistro privado
receipt-seal-witnesses = Confirmado por testemuñas
receipt-seal-hubs = { $hubs }. Ancoraxe da capa dos navegadores prevista en breve
receipt-seal-browser = Ancorado onde comproban os navegadores

receipt-step-sealed = Selado neste dispositivo
receipt-step-sealed-done = Selado antes de saír do seu navegador.
receipt-step-sealed-wait = Selando no seu navegador…
receipt-step-record-public = Engadido ao rexistro público
receipt-step-record-private = Engadido ao rexistro privado
receipt-step-record-done = Entrada #{ $index }. O seu navegador comprobouna.
receipt-step-record-wait = Á espera de que o rexistro a inclúa…
receipt-step-record-promised = O rexistro asinou unha promesa de incluíla.
receipt-step-witnesses = Confirmado por testemuñas
receipt-step-witnesses-done = Asinado por { $signed } das { $total } testemuñas.
receipt-step-witnesses-done-any = Asinado por testemuñas.
receipt-step-witnesses-wait = Á espera das sinaturas das testemuñas…
receipt-step-hubs-public =
    { $count ->
        [one] Ancorado en { $count } nodo público
       *[other] Ancorado en { $count } nodos públicos
    }
receipt-step-hubs-private =
    { $count ->
        [one] Ancorado en { $count } nodo, selado
       *[other] Ancorado en { $count } nodos, selado
    }
receipt-step-hubs-none = Nodos de ancoraxe
receipt-step-hubs-done-public = Os rexistros compartidos tamén conteñen este rexistro.
receipt-step-hubs-done-private = Non se revela nada do que contén.
receipt-step-hubs-wait = Nuns segundos…
receipt-step-hubs-partial = De momento, o rexistro está en { $agree } dos { $total } nodos…
receipt-step-browser = Ancorado onde comproban os navegadores
receipt-step-browser-done = No mesmo rexistro que o código deste sitio.
receipt-step-browser-done-bootstrap = Gárdao un nodo provisional ata que os navegadores comproben eles mesmos os rexistros.
receipt-step-browser-wait = Nuns minutos. Non fai falta agardar.
receipt-step-browser-wait-minutes =
    { $minutes ->
        [one] Nun minuto. Non fai falta agardar.
       *[other] En { $minutes } minutos. Non fai falta agardar.
    }
receipt-step-late = Está a tardar máis do debido.
receipt-step-invalid = Non se puido comprobar: os datos parecen danados.
receipt-step-failed = Contradí o rexistro asinado.
receipt-step-unused = A política deste evento non o usa.
receipt-step-state-done = Feito
receipt-step-state-active = En curso
receipt-step-state-scheduled = Programado
receipt-step-state-waiting = En espera

receipt-caption-checking-public = O seu navegador está a comprobar o rexistro público…
receipt-caption-checking-private = O seu navegador está a comprobar o rexistro privado…
receipt-caption-public = Verificado polo seu navegador, cun código que calquera pode inspeccionar.
receipt-caption-private = Rexistro privado. Os auditores acreditados poden comprobalo por completo.
receipt-caption-late = Algúns pasos están a tardar máis do debido.
receipt-caption-invalid = Non se puideron comprobar algúns datos. Parecen danados.
receipt-caption-failed = O seu navegador atopou un problema co rexistro.

receipt-check-elsewhere = Comprobar noutro dispositivo
receipt-action-save = Gardar recibo

## <vitrine-receipt variant="summary">, the re-check on a later visit (the
## revisit board).

receipt-summary-label = Comprobación do recibo
receipt-summary-title-public = A súa entrada segue no rexistro público
receipt-summary-title-private = A súa entrada segue no rexistro privado
receipt-summary-title-checking = Comprobando a súa entrada no rexistro…
receipt-summary-title-late = Algunhas probas da súa entrada van con atraso
receipt-summary-title-invalid = Non se puido comprobar a súa entrada
receipt-summary-title-failed = Non puidemos confirmar a súa entrada no rexistro
receipt-summary-checked-now = Comprobado agora mesmo polo seu navegador.
receipt-summary-checked-at = Comprobado polo seu navegador ás { TIME($time) }.
receipt-summary-unchanged = Nada do que se rexistrou antes cambiou.
receipt-summary-witnesses = Testemuñas
receipt-summary-hubs-public = Nodos públicos
receipt-summary-hubs-private = Nodos
receipt-summary-browser = Onde comproban os navegadores
receipt-summary-agree = { $agree } de { $total } coinciden
receipt-summary-agree-any = Coinciden
receipt-summary-anchored = Ancorado o { DATE($time) }
receipt-summary-anchored-plain = Ancorado
receipt-summary-waiting = En espera
receipt-summary-due = Previsto en breve
receipt-summary-unused = Non se usa
receipt-view = Ver recibo

## <vitrine-how-we-check>

how-label = Como funciona a comprobación
how-heading = Como comprobamos
how-receipt = O seu navegador garda un recibo asinado. Contén unha pegada do que enviou, nunca o contido.
how-grew = En cada visita, pídelle ao rexistro unha proba curta de que só creceu.
how-witnesses = O rexistro é asinado por testemuñas e ancorado por nodos públicos onde comproban os navegadores, así que todo o mundo ve o mesmo rexistro.

## <vitrine-proof-steps>

steps-heading = Todas as comprobacións
steps-summary =
    { $total ->
        [one] { $passed } de { $total } comprobación superada
       *[other] { $passed } de { $total } comprobacións superadas
    }
steps-result-passed = Superada
steps-result-failed = Fallou
steps-result-not-run = Aínda non se fixo
steps-show-details = Mostrar detalles
steps-hide-details = Ocultar detalles
steps-objects = Obxectos asinados implicados: { $objects }
steps-evidence = Gardar as evidencias
steps-empty = Aínda non hai comprobacións.

## <vitrine-chain>

chain-label = Cadea do recibo

## <vitrine-alert>

alert-label = Problema demostrado
alert-kind-split-view-title = O rexistro mostrouse de forma diferente a persoas distintas
alert-kind-split-view-body = Hai dúas versións do rexistro, ambas asinadas polo operador, e non poden ser certas as dúas. Pode tratarse dun fallo ou dun ataque. A súa entrada pode contar igualmente, pero alguén independente debería revisalo.
alert-kind-broken-promise-title = O rexistro incumpriu unha promesa asinada
alert-kind-broken-promise-body = O rexistro prometeu incluír unha entrada dentro dun prazo, e as sinaturas do propio rexistro mostran que non o fixo. Alguén independente debería revisalo.
alert-kind-bad-entry-title = O rexistro contén unha entrada que incumpre as súas regras
alert-kind-bad-entry-body = Unha entrada asinada no rexistro incumpre unha regra do perfil do rexistro. Alguén independente debería revisalo.
alert-kind-hub-entry-title = Un nodo de ancoraxe aceptou unha entrada que debería ter rexeitado
alert-kind-hub-entry-body = As testemuñas dun nodo de ancoraxe asinaron un rexistro do nodo cunha entrada que incumpre as regras do nodo, así que polo menos unha delas asinou sen comprobar.
alert-kind-time-regression-title = O rexistro asinou unha hora falsa
alert-kind-time-regression-body = O rexistro asinou dúas versións de si mesmo, e a máis grande ten a hora máis temperá. A hora asinada dun rexistro nunca retrocede, así que unha das dúas é falsa. Alguén independente debería revisalo.
alert-kind-policy-equivocation-title = As autoridades da política de confianza asinaron dúas substitucións distintas
alert-kind-policy-equivocation-body = Suficientes autoridades da política de confianza asinaron dúas substitucións distintas dela, e as dúas quedaron rexistradas. Conta a primeira que se rexistrou, pero a segunda podería mostrarlles políticas distintas a persoas distintas. Alguén independente debería revisalo.
alert-kind-bad-checkpoint-title = Un rexistro asinou unha versión imposible de si mesmo
alert-kind-bad-checkpoint-body = Asinou unha versión que non ten ningunha entrada, pero que non está baleira. Ningún rexistro nin nodo de ancoraxe honesto pode producir algo así. Alguén independente debería revisalo.
alert-kind-unlogged-code-title = Un sitio serviu código que o seu rexistro de versións non contén
alert-kind-unlogged-code-body = O manifesto do sitio no rexistro público enumera un script, e ningunha versión rexistrada da aplicación o contén. O código que serve o sitio non é o código que se publicou para poder comprobalo.
alert-kind-unknown-title = Atopouse un problema
alert-kind-unknown-body = As evidencias mostran un problema dun tipo que esta páxina non coñece: { $kind }.
alert-not-proven-title = Este ficheiro non demostra ningún problema
alert-not-proven-body = Comprobouse o ficheiro e non demostra ningún problema. Non serve como evidencia.
alert-unpinned-title = Este ficheiro é para unha política que non está fixada neste dispositivo
alert-unpinned-body = Neste dispositivo non se pode mostrar como proba. Compare o identificador da política do ficheiro co anuncio oficial e fixe esa política antes de comprobar de novo o ficheiro.
alert-invalid-title = Non se puido comprobar este ficheiro
alert-invalid-body = O ficheiro parece danado. Isto non demostra que alguén fixese trampa.
alert-proven-under = Demostrado segundo a política con este identificador:
alert-file-policy-id = Identificador da política do ficheiro:
alert-parties = Responsables, segundo as súas propias sinaturas: { $parties }
alert-evidence-heading = Evidencias gardadas neste dispositivo
alert-evidence-hint = Os observadores comproban estas evidencias nos seus propios ordenadores. Demostran o que asinou o rexistro e non conteñen nada sobre o que vostede enviou.
alert-download = Descargar ficheiro de evidencias
alert-send = Enviar evidencias aos observadores
alert-monitors-heading = Observadores indicados na política
alert-confirm-heading = Enviar as evidencias?
alert-confirm-body =
    { $count ->
        [one] Isto envía o ficheiro de evidencias a este observador. Verá o ficheiro e saberá que vén deste dispositivo.
       *[other] Isto envía o ficheiro de evidencias a estes { $count } observadores. Verán o ficheiro e saberán que vén deste dispositivo.
    }
alert-confirm-send = Si, enviar
alert-confirm-cancel = Cancelar
alert-sending = Estanse a enviar as evidencias aos observadores.
alert-no-monitors = A política non indica ningún monitor. Garde o ficheiro e entrégueo a un observador.
alert-delivery-waiting = Á espera de confirmación
alert-delivery-sending = Enviando
alert-delivery-confirmed = Confirmado
alert-delivery-failed = Sen confirmar

## <vitrine-alert>, the alert board: the evidence kept on this device, as the
## signed items the file holds.

alert-yours-title = Non puidemos confirmar a súa entrada no rexistro
alert-yours-split-view-body = O rexistro mostrado ao seu navegador non coincide co que asinaron as testemuñas. Pode tratarse dun fallo ou dun ataque. A súa entrada pode contar igualmente, pero alguén independente debería revisalo.
alert-evidence-count =
    { $count ->
        [one] { $count } elemento asinado
       *[other] { $count } elementos asinados
    }
alert-item-receipt = O seu recibo da entrada #{ $index }
alert-item-receipt-detail = Asinado polo rexistro cando se engadiu
alert-item-receipt-other = Recibo da entrada #{ $index }
alert-item-checkpoint = Rexistro asinado, tamaño { $size }
alert-item-checkpoint-shown = Rexistro que se lle mostrou, tamaño { $size }
alert-item-checkpoint-shown-detail = Contén a súa entrada
alert-item-checkpoint-witnessed = Rexistro asinado polas testemuñas, tamaño { $size }
alert-item-witnessed-detail =
    { $count ->
        [one] Asinado por { $count } testemuña
       *[other] Asinado por { $count } testemuñas
    }
alert-item-hubs-detail =
    { $hubs ->
        [one] Ancorado en { $hubs } nodo público
       *[other] Ancorado en { $hubs } nodos públicos
    }
alert-item-promise = Promesa asinada de incluír unha entrada
alert-item-policy = Política de confianza asinada
alert-item-policy-ack = Recoñecemento asinado da política de confianza
alert-item-why-split-view = Non pode ter crecido a partir do rexistro de tamaño { $size }
alert-item-why-time-regression = A hora asinada é anterior á do rexistro máis pequeno
alert-item-why-bad-checkpoint = Non ten ningunha entrada, pero non está baleiro
alert-what-next = Que pasa despois?
alert-what-next-body = Os observadores len as evidencias nos seus propios ordenadores. Non se envía nada a menos que vostede decida envialo. Tamén pode gardar o ficheiro e entregarllo a alguén de confianza: demostra o que asinou o rexistro onde queira que se comprobe.

## <vitrine-badge>

badge-check = Comprobar de forma independente
badge-opens = abre un verificador independente

## Monitor reports (specs/evidence.md, section 3). `report-kind-<kind>` says
## what a report is about, with `$subject`, the record or hub it names. A
## report is its monitor's own statement, not proof: show `report-established`
## only when monitors of enough different parties report the same thing.

report-kind-cosign-late = { $subject } leva demasiado tempo sen unha versión recente asinada por suficientes testemuñas.
report-kind-anchor-late = { $subject } non se ancorou a tempo: o rexistro ou o nodo de ancoraxe vai con atraso, e o informe non pode dicir cal dos dous.
report-kind-unreachable = Un servidor de { $subject } deixou de responder.
report-kind-mirror-behind = A copia de { $subject } que garda unha réplica quedou atrás.
report-kind-payload-missing = Algúns datos rexistrados en { $subject } non están dispoñibles, e ningún aviso indica que se retiveran.
report-kind-payload-mismatch = Algúns datos que serve { $subject } non coinciden co que rexistrou.
report-kind-rule-failing = Unha entrada de { $subject } incumpre unha regra do seu perfil. O monitor publicou evidencias que calquera pode comprobar.
report-kind-promise-pending = { $subject } asinou unha promesa de incluír unha entrada, e aínda non a incluíu.
report-kind-promise-unlisted = { $subject } deixa fóra da súa lista un lote das súas promesas asinadas.
report-kind-promise-late = { $subject } non cumpriu a tempo unha promesa asinada: o rexistro ou as súas testemuñas atrasáronse, ou os seus reloxos non están en hora.
report-kind-promise-misdated = { $subject } datou mal un lote das súas promesas asinadas: a súa hora non encaixa coa hora en que se listou, ou co momento en que o monitor o viu por primeira vez.
report-kind-opening-missing = { $subject } non lle abriu a tempo unha ancoraxe selada ao auditor.
report-kind-ack-missing = { $subject } non ofrece a súa declaración asinada de que segue a política de confianza vixente.
report-kind-config-mismatch = A unha cabina de votación mostróuselle unha configuración da elección que { $subject } non rexistrou, ou que difire da rexistrada.
report-kind-code-mismatch = Un sitio web serviu un script que non forma parte de ningunha versión publicada rexistrada en { $subject }.
report-kind-unknown = Informe de monitor «{ $kind }» sobre { $subject }
report-established = Confirmado: infórmano monitores de suficientes partes distintas.
report-statement = Informado por { $monitor }. Un informe é unha declaración do propio monitor, non unha proba sobre ninguén máis.

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = O ficheiro do recibo ten un formato correcto
step-policy-pinned = O recibo é para a política de confianza fixada
step-policy-successors = Comprobouse se unha política de confianza máis recente substituíu a fixada
step-policy-ack = O rexistro asinou que segue a política de confianza
step-log-known = O rexistro do recibo figura na política
step-entry-parse = A entrada ten un formato correcto
step-entry-profile = A entrada ten o tipo do rexistro e os campos dese tipo
step-entry-expectation = A entrada é a que esperaba
step-promise-signature = O rexistro asinou unha promesa de incluír a entrada
step-promise-inclusion = A promesa asinada abrangue a entrada
step-promise-leaf = A promesa é para a entrada que esperaba
step-promise-kept = O rexistro cumpriu a promesa dentro do prazo
step-issued-signature = O recibo entregado no envío está asinado polo rexistro
step-issued-inclusion = A entrada está no recibo entregado no envío
step-record-signature = O recibo do rexistro está asinado polo rexistro
step-record-inclusion = A entrada está no rexistro
step-receipts-match = Os recibos son da mesma entrada na mesma posición
step-record-consistency = O rexistro só creceu desde o recibo entregado no envío
step-record-quorum = Asinaron o rexistro suficientes testemuñas
step-log-consistent = As versións do rexistro vistas aquí non se contradín
step-hub-link = A proba do nodo { $hub } é válida
step-hub-opening = A ancoraxe selada do nodo { $hub } ábrese e coincide co rexistro
step-hub-anchored-checkpoint = O rexistro ancorado no nodo { $hub } está asinado polo rexistro e polas súas testemuñas
step-hub-previous-anchor = O nodo { $hub } contén a ancoraxe selada anterior, que se abre e coincide co rexistro
step-hub-opening-consistency = O rexistro só creceu entre as súas dúas últimas ancoraxes seladas no nodo { $hub }
step-hub-attestation = Un auditor confirmou a ancoraxe selada do nodo { $hub }
step-hub-anchor-consistency = O rexistro só creceu ata a súa ancoraxe no nodo { $hub }
step-browser-link = A proba do nodo { $hub } para a capa dos navegadores é válida e abrangue a entrada
step-browser-link-consistency = O rexistro só creceu entre o seu recibo e a proba do nodo { $hub } para a capa dos navegadores
step-browser-anchor = A capa dos navegadores contén o rexistro do nodo { $hub }
step-browser-consistency = O nodo { $hub } só creceu ata a súa versión ancorada onde os navegadores o comproban
step-bootstrap-link = Un nodo de arranque ancora o nodo { $hub }
step-unknown = Comprobación «{ $code }»

## Reasons, why a check failed or is still waiting (`reason-<code>`). Their
## variables are the verifier's `params`. A message uses only those that the
## verifier always passes for its code: the tier, hub or step it belongs to is
## shown next to it anyway.

# Encodings and limits
reason-bad-base64 = Un valor base64 ten un formato incorrecto.
reason-bad-hex = Un valor hexadecimal ten un formato incorrecto.
reason-bad-text = Hai un texto que non é válido ou que contén un carácter non permitido.
reason-bad-number = Un número ten un formato incorrecto ou está fóra do intervalo permitido.
reason-trailing-data = Hai datos inesperados despois dunha parte do ficheiro.
reason-truncated = Unha parte do ficheiro remata antes de tempo.
reason-too-large = Hai algo que supera os límites permitidos.

# Signed notes and keys
reason-bad-note = Unha nota asinada ten un formato incorrecto.
reason-bad-key-name = Un nome de chave ten un formato incorrecto.
reason-bad-vkey = Unha chave pública ten un formato incorrecto ou non é do tipo correcto.
reason-bad-public-key = Unha chave pública non é válida.
reason-missing-signature = Falta unha sinatura obrigatoria.

# Checkpoints and witness signatures
reason-bad-checkpoint = Un punto de control ten un formato incorrecto.
reason-bad-empty-tree = Unha versión asinada do rexistro é imposible: non ten ningunha entrada, pero o seu contido non está baleiro.
reason-wrong-origin = Unha nota asinada indica un rexistro ou nodo distinto do esperado.
reason-log-time-missing = A un recibo fáltalle a hora asinada do rexistro, así que non se puido comprobar.
reason-cosignature-in-future = Unha sinatura de testemuña ten unha data futura, así que non se tivo en conta.
reason-quorum-not-met = Aínda non asinaron suficientes testemuñas.

# Proofs
reason-bad-proof = Unha proba ten un formato incorrecto.
reason-missing-extra = Un recibo non contén a entrada.
reason-index-out-of-range = A posición da entrada está máis alá do final do rexistro.
reason-inclusion-failed = A proba de que a entrada está no rexistro non é válida.
reason-consistency-failed = A proba de que o rexistro só creceu non é válida.
reason-split-view = Dúas versións asinadas do rexistro teñen o mesmo tamaño pero contidos distintos.

# Entries and expectations
reason-bad-entry = A entrada ten un formato incorrecto.
reason-wrong-profile = O tipo da entrada non coincide co tipo do rexistro nesa posición.
reason-bad-entry-layout = Os campos da entrada non coinciden co seu tipo.
reason-entry-mismatch = A entrada non é a que esperaba.
reason-expectation-incomplete = A páxina non indicou o suficiente sobre a entrada para poder comprobala.
reason-expectation-unknown-field = A páxina indicou un campo que este tipo de entrada non ten.
reason-expectation-unsupported = Este verificador non pode comprobar os campos deste tipo de entrada.
reason-receipts-disagree = Os recibos do ficheiro son de entradas ou posicións distintas.

# Promises
reason-bad-promise = A promesa ten un formato incorrecto.
reason-promise-policy-unknown = A promesa indica unha política de confianza que non é a fixada nin ningunha das que a substituíron.
reason-promise-mmd-too-large = A promesa admite máis atraso do que permite a política.
reason-promise-leaf-mismatch = A promesa é para outra entrada.
reason-promise-time = O rexistro datou a súa promesa a máis dun minuto do momento en que chegou, así que non conta como promesa.
reason-promise-pending = O rexistro prometeu incluír a entrada. Aínda non venceu o prazo para o seu recibo.
reason-promise-deadline-passed = Pasou o prazo da promesa e aínda non hai recibo.
reason-promise-kept-unproven = Nada no ficheiro mostra que a promesa se cumprise a tempo.
reason-broken-promise = O rexistro prometeu incluír a entrada antes da hora límite ({ TIME($deadline) }), pero a súa propia hora asinada ({ TIME($logTime) }) mostra que despois aínda non o fixera.
reason-bad-promise-list = A lista das promesas que o rexistro fixo nunha hora ten un formato incorrecto ou non se corresponde con elas, así que non se puido comprobar.

# Receipt chains
reason-malformed-chain = O ficheiro do recibo ten un formato incorrecto.
reason-duplicate-block = O ficheiro do recibo contén a mesma parte dúas veces.
reason-no-receipt = O ficheiro non contén ningunha promesa nin ningún recibo.
reason-policy-mismatch = O recibo indica unha política de confianza distinta da fixada.
reason-policy-draft = A política de confianza aínda é un borrador, e un borrador nunca é válido.
reason-bad-policy-ack = A declaración asinada do rexistro de que segue esta política de confianza ten un formato incorrecto ou non se corresponde con ela.
reason-unknown-log = O recibo indica un rexistro que non figura na política.
reason-unknown-hub = Unha parte indica un nodo de ancoraxe que non figura na política, así que non se tivo en conta.
reason-consistency-missing = Falta unha proba de que o rexistro só creceu.
reason-consistency-mismatch = Unha proba de que o rexistro só creceu non encaixa coas versións que une.
reason-waiting-for-cosignatures = Á espera de que as testemuñas asinen o rexistro.
reason-waiting-for-record = Á espera do rexistro asinado polas testemuñas.
reason-no-signed-time = Aínda non hai hora asinada, así que non se poden avaliar os prazos.
reason-deadline-passed = Pasou o prazo, segundo a hora asinada.
reason-record-invalid = Non se puido comprobar, porque as probas do rexistro non se puideron comprobar.
reason-bad-reference = Unha ligazón a un recibo ten un formato incorrecto.
reason-reference-unpinned = Ningunha política de confianza fixada neste dispositivo corresponde a esta ligazón ao recibo.
reason-reference-ambiguous = Esta ligazón ao recibo corresponde a máis dunha política de confianza fixada neste dispositivo, así que non se usou.

# The booth's configuration check
reason-bad-config = A configuración da elección, ou o aviso de que se abriu a votación, ten un formato incorrecto, non está asinada ou non a asinaron suficientes testemuñas, así que a cabina de votación non cifrará ningunha papeleta con ela.
reason-config-mismatch = A configuración rexistrada da elección non coincide co evento, a elección, a chave da elección, os modelos de papeleta, a política de confianza ou o software da cabina de votación, ou non é a vixente cando se abriu a votación, así que a cabina non cifrará ningunha papeleta.

# Keys logs
reason-bad-key-statement = Unha declaración dun rexistro de chaves ten un formato incorrecto, indica outro rexistro, non se corresponde coa súa entrada ou fáltanlle as sinaturas que necesita, así que non conta.
reason-signed-by-failed = Unha declaración non está asinada pola súa chave, a chave estaba revogada ou non era válida cando se rexistrou a entrada, ou moi poucas outras chaves válidas a asinaron tamén.
    .not-ed25519 = A declaración, ou a chave que debía asinala, ten un formato incorrecto ou é dun tipo incorrecto.
    .not-signed = A declaración non está asinada pola súa chave.
    .revoked = A chave que asinou a declaración xa estaba revogada cando se rexistrou a entrada.
    .not-valid = A chave que asinou a declaración non era válida cando se rexistrou a entrada.
    .cosigners = Moi poucas outras chaves válidas asinaron tamén a declaración: { $have } das { $need } necesarias.

# Upgrades
reason-log-quiet = O rexistro está nun período de silencio e non mostra nada máis recente ata que remate, así que algunhas probas esperarán ata entón.
reason-log-private = O rexistro é privado: só o poden ler os auditores, así que as súas probas chegan a través do sitio web do evento.
reason-monitor-evidence = O monitor { $monitor } publicou evidencias de que esta versión do rexistro contradí a que el ten. Esas evidencias aínda non se comprobaron aquí.

# Successor policies
reason-successors-unchecked = Aínda non se comprobou se unha política de confianza máis recente substituíu esta, así que nada aparece como verificado.
reason-bad-policy-proofs = As probas sobre políticas de confianza máis recentes teñen un formato incorrecto ou non son válidas.
reason-successor-rejected = Publicouse unha política de confianza máis recente, pero incumpre as regras para substituír unha política, así que segue vixente a anterior.
reason-policy-equivocation = As autoridades da política de confianza asinaron dúas substitucións distintas dela, o que demostra que se contradixeron. Conta a primeira que se publicou.

# Anchor hubs
reason-bad-subject = O nome ou a chave co que un nodo de ancoraxe garda as ancoraxes dun rexistro ten un formato incorrecto, así que non conta.
reason-waiting-for-anchor = Á espera de que o nodo de ancoraxe ancore o rexistro.
reason-hub-quorum-not-met = Aínda non asinaron suficientes testemuñas do nodo de ancoraxe.
reason-bad-hub-link = A proba do nodo de ancoraxe ten un formato incorrecto ou non é válida.
reason-hub-link-mismatch = A proba do nodo de ancoraxe refírese a outra cousa.
reason-hub-index-wrong = As testemuñas do nodo { $hub } asinaron un índice que apunta a unha entrada equivocada para este rexistro, así que asinaron sen comprobar.
reason-map-proof-failed = A proba de mapa do nodo de ancoraxe non é válida.
reason-subject-rotated = A chave do rexistro cambiou neste nodo de ancoraxe. Necesítase a política de confianza máis recente.
reason-rotation-unauthorized = No nodo { $hub }, a chave do rexistro cambiouna unha entrada que ningunha política de confianza coñecida permite.
reason-anchor-behind-record = O nodo de ancoraxe contén unha versión do rexistro máis antiga que a do seu recibo.
reason-anchor-quorum-not-met = O rexistro ancorado non ten suficientes sinaturas de testemuñas.
reason-hub-link-stale = A proba do nodo { $hub } que ten o rexistro é moito máis antiga ca última versión do nodo: o rexistro xa debería ter unha máis recente.
reason-bad-blinded-anchor = Unha ancoraxe selada non é válida.
reason-opening-missing = O ficheiro aínda non contén o que abre a ancoraxe selada.
reason-bad-opening = O que debería abrir a ancoraxe selada non se corresponde con ela.
reason-previous-anchor-missing = O ficheiro aínda non contén a ancoraxe selada anterior do nodo { $hub }, ou o que a abre.
reason-bad-previous-anchor = A ancoraxe selada anterior non é a ancoraxe do rexistro inmediatamente anterior a esta, así que non se puido comprobar.
reason-attestation-missing = Ningún auditor confirmou aínda a ancoraxe selada do nodo { $hub }. Segue pendente ata que un o faga, e nunca se considera con atraso.
reason-attestation-not-covering = A confirmación do auditor para o nodo { $hub } abrangue as ancoraxes seladas da { $from } á { $to }, pero aínda non a número { $seq }.
reason-bad-attestation = Non se puido comprobar a confirmación dun auditor: ten un formato incorrecto, non a asina un auditor da política de confianza ou non se corresponde coa ancoraxe selada.
reason-hub-entry-refused = Un nodo de ancoraxe rexistrou unha entrada que incumpre as regras do nodo, así que a entrada non conta.

# Browser layer
reason-browser-test-only = Aquí a capa dos navegadores é só de proba: está xestionada polo operador.
reason-waiting-for-browser-anchor = Á espera da capa dos navegadores. Debería chegar nuns minutos.
reason-pair-not-covering = A última proba do rexistro para a capa dos navegadores, do nodo { $hub }, é anterior á entrada. A seguinte xa a incluirá.
reason-browser-below-link = A capa dos navegadores mostra unha versión do nodo { $hub } máis antiga ca da proba coa que vai emparellada, así que non encaixan.
reason-waiting-for-hub-tier = Á espera do nodo { $hub }: nun evento privado, a capa dos navegadores só conta cando o nodo está verificado.
reason-bad-browser-pair = As probas do rexistro para a capa dos navegadores teñen un formato incorrecto.
reason-bad-browser-anchor = Unha ancoraxe na capa dos navegadores ten un formato incorrecto ou non coincide.
reason-bad-waict-proof = A proba da capa dos navegadores non é válida.
reason-waict-quorum-not-met = Non asinaron suficientes testemuñas da capa dos navegadores.
reason-unknown-waict-service = A ancoraxe na capa dos navegadores procede dun servizo que non figura na política.
reason-waict-service-not-independent = A capa dos navegadores está xestionada polo operador, así que non conta.
reason-bad-bootstrap-link = A proba dun nodo de arranque ten un formato incorrecto ou non é válida.

# Trust policies
reason-policy-syntax = Unha liña da política de confianza ten un formato incorrecto.
reason-policy-unknown-keyword = Unha liña da política de confianza comeza cunha palabra descoñecida.
reason-policy-count = Unha liña da política de confianza aparece demasiadas veces ou non aparece.
reason-policy-undefined-name = A política de confianza usa un nome antes de definilo.
reason-policy-duplicate-name = A política de confianza define un nome dúas veces.
reason-policy-invalid = A política de confianza incumpre unha das súas regras.
reason-policy-unsafe-quorum = O quórum de testemuñas da política de confianza non é seguro.
reason-policy-unsigned = A política de confianza non ten suficientes sinaturas das súas autoridades.

# Payloads and redaction
reason-payload-mismatch = Os datos que un servidor enviou para unha entrada non coinciden co que o rexistro garda dela, así que non son os datos rexistrados. Pode que unha réplica do rexistro teña os datos correctos.
reason-payload-missing = Os datos rexistrados para unha entrada non están dispoñibles, e ningún aviso válido de retirada de datos indica que se retiveran. Pode que unha réplica do rexistro aínda os teña.
reason-bad-payload-bundle = Os datos que un servidor enviou para un lote de entradas teñen un formato incorrecto ou non se corresponden con esas entradas, así que non se puideron comprobar. Pode que unha réplica do rexistro os teña.
reason-bad-notice = Un aviso de retirada de datos ten un formato incorrecto, así que non conta.
reason-notice-unsigned = Un aviso de retirada de datos non ten suficientes sinaturas das autoridades que a política de confianza designa para estes avisos, así que non conta.
    .no-redaction = A política de confianza non permite retirar datos, así que un aviso de retirada de datos non conta.
reason-notice-mismatch = Un aviso de retirada de datos non coincide cos datos que se reteñen con el nin coa súa copia rexistrada, ou indica datos que non se poden retirar, así que non conta.
    .profile = Un aviso de retirada de datos indica unha entrada cuxos datos non se poden retirar, como unha papeleta, así que non conta.
reason-notice-not-applied = Un aviso de retirada de datos non ten ningún efecto: non fai referencia ao último aviso que se aplicou á mesma entrada, repite un anterior ou ten unha data anterior ao momento en que se rexistrou ese aviso.
reason-bad-notice-bundle = A proba de que se rexistrou un aviso de retirada de datos ten un formato incorrecto, non é válida ou non ten suficientes sinaturas de testemuñas, así que o aviso non conta.

# Evidence files
reason-bad-evidence = O ficheiro de evidencias ten un formato incorrecto ou fáltalle unha parte que o seu tipo necesita.
reason-evidence-unknown-kind = O ficheiro de evidencias é dun tipo que este verificador non coñece.
reason-evidence-unpinned = O ficheiro de evidencias corresponde a unha política de confianza que este dispositivo non fixou.
reason-evidence-wrong-subject = O ficheiro de evidencias trata dun rexistro ou nodo ao que o seu tipo non se aplica segundo a súa política de confianza.
reason-evidence-policy-mismatch = Unha parte do ficheiro de evidencias corresponde a unha política de confianza distinta da do ficheiro.
reason-not-proven = As sinaturas das evidencias son válidas, pero non mostran o problema que afirman.
reason-needs-scan = Isto só se pode decidir lendo as entradas do rexistro, e esta comprobación non o fixo.
reason-rule-unsupported = As evidencias mencionan unha regra que este verificador non pode aplicar. Un verificador completo pode comprobala.
reason-faulty-witness = Esta testemuña asinou dúas versións que se contradín, ou unha versión dun nodo cunha entrada indebida, o que demostra que é defectuosa.
reason-trust-assumption-failed = Suficientes testemuñas asinaron as versións contraditorias como para alcanzar o quórum: hai máis testemuñas defectuosas das que supón a política de confianza.
reason-misbehaviour-proven = As evidencias demostran o problema que afirman, segundo a política de confianza do ficheiro.

reason-unknown = Motivo «{ $code }»

# Shared infrastructure. Draft translations need native-speaker review.
reason-bad-operator-list = The infrastructure list is damaged or uses an unsupported format.
reason-operator-list-refused = The infrastructure list could not be accepted under the pinned authorities, validity window or update history.
reason-bad-shared-submission = The shared-log request or enrolment is damaged or does not follow the format.
reason-shared-submission-refused = The shared log could not accept this request under its pinned policy, submitter key or namespace.

# New metadata reason: native translation review needed outside English.
reason-profile-meaning-unknown = The profile meaning is not available for validation.

## extension

# The names of the anchor hubs and the browser layer in the extension's compact receipt chain.
tier-hubs-short = Nodos
tier-browser-short = Navegador
