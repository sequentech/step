# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Galician (gl).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Incluído
fact-unchanged = Sen cambios
fact-same-for-everyone = Igual para todo o mundo

fact-state-done = Feito
fact-state-promised = Prometido
fact-state-pending = Pendente
fact-state-late = Con atraso
fact-state-invalid = Non se puido comprobar
fact-state-failed = Fallou
fact-state-checking = Comprobando

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = A súa entrada está no rexistro.
fact-included-promised = O rexistro asinou unha promesa de incluír a súa entrada.
fact-included-pending = Á espera de que o rexistro inclúa a súa entrada.
fact-included-late = O rexistro xa debería ter incluído a súa entrada.
fact-included-invalid = Non se puido comprobar a proba de que a súa entrada está no rexistro: os datos parecen danados.
fact-included-failed = As sinaturas do propio rexistro contradinse sobre a súa entrada.
fact-unchanged-done = Testemuñas independentes asinaron o rexistro, así que nada nel pode cambiar sen que se note.
fact-unchanged-pending = Á espera de que as testemuñas independentes asinen o rexistro.
fact-unchanged-late = As testemuñas xa deberían ter asinado o rexistro.
fact-unchanged-invalid = Non se puideron comprobar as probas sobre o historial do rexistro: os datos parecen danados.
fact-unchanged-failed = Hai probas asinadas sobre o historial do rexistro que se contradín.
fact-same-for-everyone-done = Calquera persoa que comprobe ve este mesmo rexistro.
fact-same-for-everyone-pending = Á espera de que o rexistro se ancore onde todo o mundo poida comprobalo.
fact-same-for-everyone-late = O rexistro xa debería estar ancorado onde todo o mundo poida comprobalo.
fact-same-for-everyone-invalid = Non se puideron comprobar as ancoraxes: os datos parecen danados.
fact-same-for-everyone-failed = Hai probas asinadas que mostran que non todo o mundo ve o mesmo rexistro.

## Tiers

tier-record = Rexistro
tier-witnesses = Testemuñas
tier-hubs = Nodos de ancoraxe
tier-browser = Capa dos navegadores
tier-policy = Política
tier-entry = Entrada

tier-status-verified = Verificado
tier-status-pending = Pendente
tier-status-late = Con atraso
tier-status-invalid = Non se puido comprobar
tier-status-failed = Fallou
tier-status-unused = Non se usa
tier-status-checking = Comprobando
tier-status-promised = Prometido

tier-record-verified = A súa entrada está no rexistro asinado.
tier-record-promised = O rexistro asinou unha promesa de incluír a súa entrada.
tier-record-pending = O rexistro aínda non incluíu a súa entrada.
tier-record-late = O rexistro xa debería ter incluído a súa entrada.
tier-record-invalid = As probas do rexistro parecen danadas, así que non se puideron comprobar.
tier-record-failed = O rexistro asinou probas que se contradín.
tier-record-checking = Comprobando as probas do rexistro.
tier-witnesses-verified = Asinaron o rexistro suficientes testemuñas independentes.
tier-witnesses-pending = Á espera de que asinen as testemuñas. Isto leva uns segundos.
tier-witnesses-late = As testemuñas xa deberían ter asinado.
tier-witnesses-invalid = As sinaturas das testemuñas parecen danadas, así que non se puideron comprobar.
tier-witnesses-failed = Algunhas testemuñas asinaron un rexistro que contradí o do seu recibo.
tier-witnesses-checking = Comprobando as sinaturas das testemuñas.
tier-hubs-verified = Todos os nodos de ancoraxe conteñen o rexistro.
tier-hubs-pending = De camiño aos nodos de ancoraxe. Isto leva uns segundos.
tier-hubs-late = Os nodos de ancoraxe xa deberían conter o rexistro.
tier-hubs-invalid = A resposta dun nodo de ancoraxe parece danada, así que non se puido comprobar.
tier-hubs-failed = Un nodo de ancoraxe contén un rexistro asinado que contradí o do seu recibo.
tier-hubs-unused = Esta política non usa nodos de ancoraxe.
tier-hubs-checking = Comprobando os nodos de ancoraxe.
tier-browser-verified = Ancorado onde comproban os navegadores.
tier-browser-pending = Debería chegar nuns minutos. Non fai falta agardar.
tier-browser-late = O rexistro xa debería estar ancorado onde comproban os navegadores.
tier-browser-invalid = A resposta da capa dos navegadores parece danada, así que non se puido comprobar.
tier-browser-failed = Unha ancoraxe asinada alí onde comproban os navegadores contradí o rexistro.
tier-browser-unused = Esta política non usa ningunha capa dos navegadores independente.
tier-browser-checking = Comprobando a capa dos navegadores.
tier-test = Só de proba: xestiónao o operador, así que non conta.
tier-deadline = Hora límite prevista: { TIME($deadline) }
hub-test = de proba

## The one-line status

status-verified = Verificado
status-checking = Comprobando…
status-pending = Pendente
status-late = Con atraso
status-invalid = Non se puido comprobar
status-failed = Fallou
status-summary-verified = Incluído, sen cambios e igual para todo o mundo.
status-summary-checking = Comprobando as probas do recibo neste navegador.
status-summary-pending = Algunhas probas aínda están de camiño. Non fai falta agardar.
status-summary-late = Algunhas probas xa deberían ter chegado.
status-summary-invalid = Non se puideron comprobar algúns datos: o ficheiro ou a resposta do servidor parecen danados. Isto non demostra que alguén fixese trampa.
status-summary-failed = Hai probas asinadas que se contradín. Garde as evidencias.

## <vitrine-receipt>

receipt-label = Recibo
receipt-words-label = Palabras do recibo
receipt-entry = Entrada { $index } en { $log }
receipt-entry-promised = Entrada prometida en { $log }
receipt-provenance-page = Comprobado por este sitio web
receipt-provenance-page-hint = Este sitio web comprobou o seu propio rexistro. Para ter a certeza, compróbeo de forma independente.
receipt-provenance-independent = Comprobado de forma independente do sitio web
receipt-facts-heading = O que mostran as probas
receipt-chain-heading = Ata onde chegou
receipt-compare-heading = Compare co anuncio oficial
receipt-compare-hint = Estas palabras e testemuñas deberían coincidir coas que publicou a autoridade, por exemplo, no anuncio das eleccións.
receipt-policy-words = Palabras da política
receipt-policy-id = Identificador da política
receipt-event = Evento
receipt-witnesses = Testemuñas
receipt-witness-party = xestionada por { $party }
receipt-hubs = Nodos de ancoraxe
receipt-clock-warning = O reloxo deste dispositivo ten un desfase de máis dun minuto. Os prazos avalíanse coa hora asinada, non con este reloxo.
receipt-action-check = Comprobar de forma independente
receipt-action-download = Descargar recibo
receipt-action-retry = Comprobar de novo
receipt-invalid = Non se puideron comprobar algúns datos: o ficheiro ou a resposta do servidor parecen danados. Isto non demostra que alguén fixese trampa. Pode comprobar de novo ou facer unha comprobación independente.
receipt-no-expect = Esta páxina non indicou cal é a entrada esperada, así que non se pode mostrar este recibo como o seu.
receipt-error = Non se puido comprobar este recibo.
receipt-empty = Aínda non hai ningún recibo.
receipt-announce = { $tier }: { $status }.

## <vitrine-proof-steps>

steps-heading = Todas as comprobacións
steps-summary =
    { $total ->
        [one] { $passed } de { $total } comprobación superada
       *[other] { $passed } de { $total } comprobacións superadas
    }
steps-result-passed = Superada
steps-result-failed = Fallou
steps-result-not-run = Aínda non se fixo
steps-show-details = Mostrar detalles
steps-hide-details = Ocultar detalles
steps-objects = Obxectos asinados implicados: { $objects }
steps-evidence = Gardar as evidencias
steps-empty = Aínda non hai comprobacións.

## <vitrine-chain>

chain-label = Cadea do recibo

## <vitrine-alert>

alert-label = Problema demostrado
alert-kind-split-view-title = O rexistro mostrouse de forma diferente a persoas distintas
alert-kind-split-view-body = Hai dúas versións do rexistro, ambas asinadas polo operador, e non poden ser certas as dúas. Pode tratarse dun fallo ou dun ataque. A súa entrada pode contar igualmente, pero alguén independente debería revisalo.
alert-kind-broken-promise-title = O rexistro incumpriu unha promesa asinada
alert-kind-broken-promise-body = O rexistro prometeu incluír unha entrada dentro dun prazo, e as sinaturas do propio rexistro mostran que non o fixo. Alguén independente debería revisalo.
alert-kind-bad-entry-title = O rexistro contén unha entrada que incumpre as súas regras
alert-kind-bad-entry-body = Unha entrada asinada no rexistro incumpre unha regra do perfil do rexistro. Alguén independente debería revisalo.
alert-kind-stale-anchor-title = O rexistro non se ancorou a tempo
alert-kind-stale-anchor-body = O rexistro ou un nodo de ancoraxe tardou en ancorar o rexistro máis do que permite a política. Incumpre un nivel de servizo prometido, pero non afecta ao propio rexistro.
alert-kind-hub-entry-title = Un nodo de ancoraxe aceptou unha entrada que debería ter rexeitado
alert-kind-hub-entry-body = As testemuñas dun nodo de ancoraxe asinaron un rexistro do nodo cunha entrada que incumpre as regras do nodo, así que polo menos unha delas asinou sen comprobar.
alert-kind-unknown-title = Atopouse un problema
alert-kind-unknown-body = As evidencias mostran un problema dun tipo que esta páxina non coñece: { $kind }.
alert-not-proven-title = Este ficheiro non demostra ningún problema
alert-not-proven-body = Comprobouse o ficheiro e non demostra ningún problema. Non serve como evidencia.
alert-unpinned-title = Este ficheiro é para unha política que non está fixada neste dispositivo
alert-unpinned-body = Neste dispositivo non se pode mostrar como proba. Compare as palabras da política do ficheiro co anuncio oficial e fixe esa política antes de comprobar de novo o ficheiro.
alert-invalid-title = Non se puido comprobar este ficheiro
alert-invalid-body = O ficheiro parece danado. Isto non demostra que alguén fixese trampa.
alert-proven-under = Demostrado segundo a política con estas palabras:
alert-file-policy-words = Palabras da política do ficheiro:
alert-parties = Responsables, segundo as súas propias sinaturas: { $parties }
alert-evidence-heading = Evidencias gardadas neste dispositivo
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } KB
alert-evidence-hint = Calquera persoa pode comprobar este ficheiro no seu propio ordenador. Só contén obxectos asinados do rexistro.
alert-download = Descargar ficheiro de evidencias
alert-send = Enviar aos monitores
alert-monitors-heading = Monitores indicados na política
alert-confirm-heading = Enviar as evidencias?
alert-confirm-body =
    { $count ->
        [one] Isto envía o ficheiro de evidencias a este monitor. Verá o ficheiro e saberá que vén deste dispositivo.
       *[other] Isto envía o ficheiro de evidencias a estes { $count } monitores. Verán o ficheiro e saberán que vén deste dispositivo.
    }
alert-confirm-send = Si, enviar
alert-confirm-cancel = Cancelar
alert-sending = Estanse a enviar as evidencias aos monitores.
alert-no-monitors = A política non indica ningún monitor. Garde o ficheiro e entrégueo a un observador.
alert-delivery-waiting = Á espera de confirmación
alert-delivery-sending = Enviando
alert-delivery-confirmed = Confirmado
alert-delivery-failed = Sen confirmar

## <vitrine-badge>

badge-check = Comprobar de forma independente
badge-opens = abre un verificador independente

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = O ficheiro do recibo ten un formato correcto
step-policy-pinned = O recibo é para a política de confianza fixada
step-log-known = O rexistro do recibo figura na política
step-entry-parse = A entrada ten un formato correcto
step-entry-profile = A entrada ten o tipo do rexistro e os campos dese tipo
step-entry-expectation = A entrada é a que esperaba
step-promise-signature = O rexistro asinou unha promesa de incluír a entrada
step-promise-inclusion = A promesa asinada abrangue a entrada
step-promise-leaf = A promesa é para a entrada que esperaba
step-promise-kept = O rexistro cumpriu a promesa dentro do prazo
step-issued-signature = O recibo entregado no envío está asinado polo rexistro
step-issued-inclusion = A entrada está no recibo entregado no envío
step-record-signature = O recibo do rexistro está asinado polo rexistro
step-record-inclusion = A entrada está no rexistro
step-receipts-match = Os recibos son da mesma entrada na mesma posición
step-record-consistency = O rexistro só creceu desde o recibo entregado no envío
step-record-quorum = Asinaron o rexistro suficientes testemuñas independentes
step-hub-link = A proba do nodo { $hub } é válida
step-hub-opening = A ancoraxe selada do nodo { $hub } ábrese e coincide co rexistro
step-hub-anchored-checkpoint = O rexistro ancorado no nodo { $hub } está asinado polo rexistro e polas súas testemuñas
step-hub-anchor-consistency = O rexistro só creceu ata a súa ancoraxe no nodo { $hub }
step-browser-anchor = A capa dos navegadores contén o rexistro do nodo { $hub }
step-browser-consistency = O nodo { $hub } só creceu ata a súa ancoraxe na capa dos navegadores
step-bootstrap-link = Un nodo de arranque ancora o nodo { $hub }
step-bootstrap-consistency = O nodo { $hub } só creceu ata a súa ancoraxe de arranque
step-unknown = Comprobación «{ $code }»

## Reasons, why a check failed or is still waiting (`reason-<code>`). They
## take no variables: the tier, hub or step they belong to is shown next to them.

# Encodings and limits
reason-bad-base64 = Un valor base64 ten un formato incorrecto.
reason-bad-hex = Un valor hexadecimal ten un formato incorrecto.
reason-bad-text = Hai un texto que non é válido ou que contén un carácter non permitido.
reason-bad-number = Un número ten un formato incorrecto ou está fóra do intervalo permitido.
reason-trailing-data = Hai datos inesperados despois dunha parte do ficheiro.
reason-truncated = Unha parte do ficheiro remata antes de tempo.
reason-too-large = Hai algo que supera os límites permitidos.

# Signed notes and keys
reason-bad-note = Unha nota asinada ten un formato incorrecto.
reason-bad-key-name = Un nome de chave ten un formato incorrecto.
reason-bad-vkey = Unha chave pública ten un formato incorrecto ou non é do tipo correcto.
reason-bad-public-key = Unha chave pública non é válida.
reason-duplicate-signature = Unha nota leva a mesma sinatura dúas veces.
reason-bad-signature = Unha sinatura non é válida.
reason-missing-signature = Falta unha sinatura obrigatoria.

# Checkpoints and witness signatures
reason-bad-checkpoint = Un punto de control ten un formato incorrecto.
reason-wrong-origin = Unha nota asinada indica un rexistro ou nodo distinto do esperado.
reason-cosignature-in-future = Unha sinatura de testemuña ten unha data futura, así que non se tivo en conta.
reason-quorum-not-met = Aínda non asinaron suficientes testemuñas independentes.

# Proofs
reason-bad-proof = Unha proba ten un formato incorrecto.
reason-missing-extra = Un recibo non contén a entrada.
reason-index-out-of-range = A posición da entrada está máis alá do final do rexistro.
reason-inclusion-failed = A proba de que a entrada está no rexistro non é válida.
reason-consistency-failed = A proba de que o rexistro só creceu non é válida.
reason-split-view = Dúas versións asinadas do rexistro teñen o mesmo tamaño pero contidos distintos.

# Entries and expectations
reason-bad-entry = A entrada ten un formato incorrecto.
reason-wrong-profile = O tipo da entrada non coincide co tipo do rexistro nesa posición.
reason-bad-entry-layout = Os campos da entrada non coinciden co seu tipo.
reason-entry-mismatch = A entrada non é a que esperaba.
reason-expectation-incomplete = A páxina non indicou o suficiente sobre a entrada para poder comprobala.
reason-expectation-unknown-field = A páxina indicou un campo que este tipo de entrada non ten.
reason-expectation-unsupported = Este verificador non pode comprobar os campos deste tipo de entrada.
reason-receipts-disagree = Os recibos do ficheiro son de entradas ou posicións distintas.

# Promises
reason-bad-promise = A promesa ten un formato incorrecto.
reason-promise-mmd-too-large = A promesa admite máis atraso do que permite a política.
reason-promise-leaf-mismatch = A promesa é para outra entrada.
reason-promise-pending = O rexistro prometeu incluír a entrada. Aínda non venceu o prazo para o seu recibo.
reason-promise-deadline-passed = Pasou o prazo da promesa e aínda non hai recibo.
reason-promise-kept-unproven = Nada no ficheiro mostra que a promesa se cumprise a tempo.

# Receipt chains
reason-malformed-chain = O ficheiro do recibo ten un formato incorrecto.
reason-duplicate-block = O ficheiro do recibo contén a mesma parte dúas veces.
reason-no-receipt = O ficheiro non contén ningunha promesa nin ningún recibo.
reason-policy-mismatch = O recibo indica unha política de confianza distinta da fixada.
reason-unknown-log = O recibo indica un rexistro que non figura na política.
reason-unknown-hub = Unha parte indica un nodo de ancoraxe que non figura na política, así que non se tivo en conta.
reason-consistency-missing = Falta unha proba de que o rexistro só creceu.
reason-consistency-mismatch = Unha proba de que o rexistro só creceu non encaixa coas versións que une.
reason-waiting-for-cosignatures = Á espera de que as testemuñas asinen o rexistro.
reason-waiting-for-record = Á espera do rexistro asinado polas testemuñas.
reason-no-signed-time = Aínda non hai hora asinada, así que non se poden avaliar os prazos.
reason-deadline-passed = Pasou o prazo, segundo a hora asinada.
reason-record-invalid = Non se puido comprobar, porque as probas do rexistro non se puideron comprobar.
reason-bad-reference = Unha ligazón a un recibo ten un formato incorrecto.

# Anchor hubs
reason-waiting-for-anchor = Á espera de que o nodo de ancoraxe ancore o rexistro.
reason-hub-quorum-not-met = Aínda non asinaron suficientes testemuñas do nodo de ancoraxe.
reason-bad-hub-link = A proba do nodo de ancoraxe ten un formato incorrecto ou non é válida.
reason-hub-link-mismatch = A proba do nodo de ancoraxe refírese a outra cousa.
reason-map-proof-failed = A proba de mapa do nodo de ancoraxe non é válida.
reason-subject-rotated = A chave do rexistro cambiou neste nodo de ancoraxe. Necesítase a política de confianza máis recente.
reason-anchor-behind-record = O nodo de ancoraxe contén unha versión do rexistro máis antiga que a do seu recibo.
reason-anchor-quorum-not-met = O rexistro ancorado non ten suficientes sinaturas de testemuñas.
reason-bad-blinded-anchor = Unha ancoraxe selada non é válida.
reason-opening-missing = O ficheiro aínda non contén o que abre a ancoraxe selada.
reason-bad-opening = O que debería abrir a ancoraxe selada non se corresponde con ela.

# Browser layer
reason-browser-test-only = Aquí a capa dos navegadores é só de proba: está xestionada polo operador.
reason-waiting-for-browser-anchor = Á espera da capa dos navegadores. Debería chegar nuns minutos.
reason-browser-behind-anchor = A capa dos navegadores contén unha versión máis antiga ca do nodo de ancoraxe. Agárdase unha máis recente.
reason-bad-browser-anchor = Unha ancoraxe na capa dos navegadores ten un formato incorrecto ou non coincide.
reason-bad-waict-proof = A proba da capa dos navegadores non é válida.
reason-waict-quorum-not-met = Non asinaron suficientes testemuñas da capa dos navegadores.
reason-unknown-waict-service = A ancoraxe na capa dos navegadores procede dun servizo que non figura na política.
reason-waict-service-not-independent = A capa dos navegadores está xestionada polo operador, así que non conta.
reason-bad-bootstrap-link = A proba dun nodo de arranque ten un formato incorrecto ou non é válida.

# Trust policies
reason-policy-syntax = Unha liña da política de confianza ten un formato incorrecto.
reason-policy-unknown-keyword = Unha liña da política de confianza comeza cunha palabra descoñecida.
reason-policy-count = Unha liña da política de confianza aparece demasiadas veces ou non aparece.
reason-policy-undefined-name = A política de confianza usa un nome antes de definilo.
reason-policy-duplicate-name = A política de confianza define un nome dúas veces.
reason-policy-invalid = A política de confianza incumpre unha das súas regras.
reason-policy-unsafe-quorum = O quórum de testemuñas da política de confianza non é seguro.
reason-policy-unsigned = A política de confianza non ten suficientes sinaturas das súas autoridades.

reason-unknown = Motivo «{ $code }»
