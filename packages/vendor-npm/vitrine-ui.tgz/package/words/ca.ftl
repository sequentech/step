# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Catalan (ca).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Inclosa
fact-unchanged = Sense canvis
fact-same-for-everyone = Igual per a tothom

fact-state-done = Fet
fact-state-promised = Promesa
fact-state-pending = Pendent
fact-state-late = Amb retard
fact-state-invalid = No s’ha pogut verificar
fact-state-failed = Ha fallat
fact-state-checking = S’està verificant

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = La seva entrada és al registre.
fact-included-promised = El registre ha signat una promesa d’incloure la seva entrada.
fact-included-pending = A l’espera que el registre inclogui la seva entrada.
fact-included-late = El registre ja hauria d’haver inclòs la seva entrada.
fact-included-invalid = La prova que la seva entrada és al registre no s’ha pogut verificar: les dades semblen malmeses.
fact-included-failed = Les signatures del mateix registre es contradiuen pel que fa a la seva entrada.
fact-unchanged-done = El registre està signat per testimonis independents, així que no hi pot canviar res sense que es detecti.
fact-unchanged-pending = A l’espera que els testimonis independents signin el registre.
fact-unchanged-late = Els testimonis ja haurien d’haver signat el registre.
fact-unchanged-invalid = Les proves sobre l’historial del registre no s’han pogut verificar: les dades semblen malmeses.
fact-unchanged-failed = Hi ha proves signades sobre l’historial del registre que es contradiuen.
fact-same-for-everyone-done = Tothom qui ho verifica veu aquest mateix registre.
fact-same-for-everyone-pending = A l’espera que el registre quedi ancorat on tothom el pugui verificar.
fact-same-for-everyone-late = El registre ja hauria d’estar ancorat on tothom el pugui verificar.
fact-same-for-everyone-invalid = Els ancoratges no s’han pogut verificar: les dades semblen malmeses.
fact-same-for-everyone-failed = Hi ha proves signades que mostren que no tothom veu el mateix registre.

## Tiers

tier-record = Registre
tier-witnesses = Testimonis
tier-hubs = Nodes d’ancoratge
tier-browser = Capa de navegadors
tier-policy = Política
tier-entry = Entrada

tier-status-verified = Verificat
tier-status-pending = Pendent
tier-status-late = Amb retard
tier-status-invalid = No s’ha pogut verificar
tier-status-failed = Ha fallat
tier-status-unused = No s’utilitza
tier-status-checking = S’està verificant
tier-status-promised = Promesa

tier-record-verified = La seva entrada és al registre signat.
tier-record-promised = El registre ha signat una promesa d’incloure la seva entrada.
tier-record-pending = El registre encara no ha inclòs la seva entrada.
tier-record-late = El registre ja hauria d’haver inclòs la seva entrada.
tier-record-invalid = Les proves del registre semblen malmeses, així que no s’han pogut verificar.
tier-record-failed = El registre ha signat proves que es contradiuen.
tier-record-checking = S’estan verificant les proves del registre.
tier-witnesses-verified = El registre té la signatura de prou testimonis independents.
tier-witnesses-pending = A l’espera que els testimonis signin. Això només triga uns segons.
tier-witnesses-late = Els testimonis ja haurien d’haver signat.
tier-witnesses-invalid = Les signatures dels testimonis semblen malmeses, així que no s’han pogut verificar.
tier-witnesses-failed = Hi ha testimonis que han signat un registre que contradiu el del seu comprovant.
tier-witnesses-checking = S’estan verificant les signatures dels testimonis.
tier-hubs-verified = Tots els nodes d’ancoratge contenen el registre.
tier-hubs-pending = El registre va de camí cap als nodes d’ancoratge. Això només triga uns segons.
tier-hubs-late = Els nodes d’ancoratge ja haurien de contenir el registre.
tier-hubs-invalid = La resposta d’un node d’ancoratge sembla malmesa, així que no s’ha pogut verificar.
tier-hubs-failed = Un node d’ancoratge conté un registre signat que contradiu el del seu comprovant.
tier-hubs-unused = Aquesta política no utilitza nodes d’ancoratge.
tier-hubs-checking = S’estan verificant els nodes d’ancoratge.
tier-browser-verified = Ancorat on els navegadors el verifiquen.
tier-browser-pending = Es preveu d’aquí a pocs minuts. No cal esperar.
tier-browser-late = Ja hauria d’estar ancorat on els navegadors el verifiquen.
tier-browser-invalid = La resposta de la capa de navegadors sembla malmesa, així que no s’ha pogut verificar.
tier-browser-failed = Un ancoratge signat a la capa de navegadors contradiu el registre.
tier-browser-unused = Aquesta política no utilitza cap capa de navegadors independent.
tier-browser-checking = S’està verificant la capa de navegadors.
tier-test = Només de prova: és a càrrec de l’operador, per això no compta.
tier-deadline = Termini previst: { TIME($deadline) }
hub-test = de prova

## The one-line status

status-verified = Verificat
status-checking = S’està verificant…
status-pending = Pendent
status-late = Amb retard
status-invalid = No s’ha pogut verificar
status-failed = Ha fallat
status-summary-verified = Inclosa, sense canvis i igual per a tothom.
status-summary-checking = S’estan verificant les proves del comprovant en aquest navegador.
status-summary-pending = Algunes proves encara han d’arribar. No cal esperar.
status-summary-late = Algunes proves ja haurien d’haver arribat.
status-summary-invalid = Algunes dades no s’han pogut verificar: sembla que el fitxer o la resposta del servidor estan malmesos. Això no demostra que ningú hagi fet trampa.
status-summary-failed = Hi ha proves signades que es contradiuen. Conservi l’evidència.

## <vitrine-receipt>

receipt-label = Comprovant
receipt-words-label = Paraules del comprovant
receipt-entry = Entrada { $index } del registre { $log }
receipt-entry-promised = Entrada promesa del registre { $log }
receipt-provenance-page = Verificat per aquest lloc web
receipt-provenance-page-hint = Aquest lloc web ha verificat el seu propi registre. Per tenir-ne la certesa, verifiqui-ho de manera independent.
receipt-provenance-independent = Verificat sense dependre del lloc web
receipt-facts-heading = Què mostren les proves
receipt-chain-heading = Fins on ha arribat
receipt-compare-heading = Compari-ho amb l’anunci oficial
receipt-compare-hint = Aquestes paraules i aquests testimonis haurien de coincidir amb els que ha publicat l’autoritat, per exemple a l’anunci de les eleccions.
receipt-policy-words = Paraules de la política
receipt-policy-id = Identificador de la política
receipt-event = Esdeveniment
receipt-witnesses = Testimonis
receipt-witness-party = gestionat per { $party }
receipt-hubs = Nodes d’ancoratge
receipt-clock-warning = El rellotge d’aquest dispositiu té un desajust de més d’un minut. Els terminis s’avaluen amb l’hora signada, no amb aquest rellotge.
receipt-action-check = Verificar independentment
receipt-action-download = Baixar el comprovant
receipt-action-retry = Tornar a verificar
receipt-invalid = Algunes dades no s’han pogut verificar: sembla que el fitxer o la resposta del servidor estan malmesos. Això no demostra que ningú hagi fet trampa. Pot tornar a verificar-ho o fer-ne una verificació independent.
receipt-no-expect = Aquesta pàgina no ha indicat quina entrada cal esperar, de manera que aquest comprovant no es pot mostrar com a seu.
receipt-error = Aquest comprovant no s’ha pogut verificar.
receipt-empty = Encara no hi ha cap comprovant.
receipt-announce = { $tier }: { $status }.

## <vitrine-proof-steps>

steps-heading = Totes les verificacions
steps-summary =
    { $total ->
        [one] { $passed } d’{ $total } verificació superada
       *[other] { $passed } de { $total } verificacions superades
    }
steps-result-passed = Superada
steps-result-failed = Ha fallat
steps-result-not-run = Encara no s’ha fet
steps-show-details = Mostrar els detalls
steps-hide-details = Amagar els detalls
steps-objects = Objectes signats implicats: { $objects }
steps-evidence = Desar l’evidència
steps-empty = Encara no hi ha cap verificació.

## <vitrine-chain>

chain-label = Cadena del comprovant

## <vitrine-alert>

alert-label = Problema demostrat
alert-kind-split-view-title = El registre s’ha mostrat de manera diferent a persones diferents
alert-kind-split-view-body = Dues versions del registre, totes dues signades pel seu operador, no poden ser certes alhora. Pot ser una fallada o un atac. La seva entrada encara pot comptar, però convé que ho revisi algú independent.
alert-kind-broken-promise-title = El registre no ha complert una promesa signada
alert-kind-broken-promise-body = El registre ha promès incloure una entrada dins d’un termini, i les seves pròpies signatures mostren que no ho ha fet. Convé que ho revisi algú independent.
alert-kind-bad-entry-title = El registre conté una entrada que incompleix les seves regles
alert-kind-bad-entry-body = Una entrada signada al registre incompleix una regla del perfil del registre. Convé que ho revisi algú independent.
alert-kind-stale-anchor-title = El registre no s’ha ancorat a temps
alert-kind-stale-anchor-body = El registre o un node d’ancoratge ha trigat més del que permet la política a ancorar el registre. Això incompleix un nivell de servei promès, però el registre en si no queda afectat.
alert-kind-hub-entry-title = Un node d’ancoratge ha acceptat una entrada que hauria d’haver rebutjat
alert-kind-hub-entry-body = Els testimonis d’un node d’ancoratge han signat un registre del node amb una entrada que incompleix les regles del node, de manera que almenys un d’ells ha signat sense verificar.
alert-kind-unknown-title = S’ha trobat un problema
alert-kind-unknown-body = L’evidència mostra un problema d’un tipus que aquesta pàgina no coneix: { $kind }.
alert-not-proven-title = Aquest fitxer no demostra cap problema
alert-not-proven-body = El fitxer s’ha verificat i no demostra cap problema. No constitueix cap evidència.
alert-unpinned-title = Aquest fitxer correspon a una política que no s’ha fixat en aquest dispositiu
alert-unpinned-body = No es pot mostrar com a prova en aquest dispositiu. Compari les paraules de la política del fitxer amb l’anunci oficial i fixi aquesta política abans de tornar a verificar el fitxer.
alert-invalid-title = Aquest fitxer no s’ha pogut verificar
alert-invalid-body = Sembla que el fitxer està malmès. Això no demostra que ningú hagi fet trampa.
alert-proven-under = Demostrat segons la política amb aquestes paraules:
alert-file-policy-words = Les paraules de la política del fitxer:
alert-parties = Responsables, segons les seves pròpies signatures: { $parties }
alert-evidence-heading = Evidència desada en aquest dispositiu
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } KB
alert-evidence-hint = Qualsevol persona pot verificar aquest fitxer al seu propi ordinador. Només conté objectes signats del registre.
alert-download = Baixar el fitxer d’evidència
alert-send = Enviar als monitors
alert-monitors-heading = Monitors que indica la política
alert-confirm-heading = Vol enviar l’evidència?
alert-confirm-body =
    { $count ->
        [one] S’enviarà el fitxer d’evidència a aquest monitor. Veurà el fitxer i sabrà que s’ha enviat des d’aquest dispositiu.
       *[other] S’enviarà el fitxer d’evidència a aquests { $count } monitors. Veuran el fitxer i sabran que s’ha enviat des d’aquest dispositiu.
    }
alert-confirm-send = Sí, enviar-la
alert-confirm-cancel = Cancel·lar
alert-sending = S’està enviant l’evidència als monitors.
alert-no-monitors = La política no indica cap monitor. Conservi el fitxer i lliuri’l a un observador.
alert-delivery-waiting = A l’espera de confirmació
alert-delivery-sending = S’està enviant
alert-delivery-confirmed = Confirmat
alert-delivery-failed = No confirmat

## <vitrine-badge>

badge-check = Verificar independentment
badge-opens = obre un verificador independent

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = El fitxer del comprovant té un format correcte
step-policy-pinned = El comprovant correspon a la política de confiança fixada
step-log-known = La política inclou el registre del comprovant
step-entry-parse = L’entrada té un format correcte
step-entry-profile = L’entrada és del tipus del registre i té els camps d’aquest tipus
step-entry-expectation = L’entrada és la que s’esperava
step-promise-signature = El registre ha signat una promesa d’incloure l’entrada
step-promise-inclusion = La promesa signada abasta l’entrada
step-promise-leaf = La promesa és per a l’entrada que s’esperava
step-promise-kept = El registre ha complert la promesa dins del termini
step-issued-signature = El comprovant lliurat en l’enviament està signat pel registre
step-issued-inclusion = L’entrada és al comprovant lliurat en l’enviament
step-record-signature = El comprovant del registre està signat pel mateix registre
step-record-inclusion = L’entrada és al registre
step-receipts-match = Els comprovants corresponen a la mateixa entrada i a la mateixa posició
step-record-consistency = El registre només ha crescut des del comprovant lliurat en l’enviament
step-record-quorum = El registre té la signatura de prou testimonis independents
step-hub-link = La prova del node { $hub } és vàlida
step-hub-opening = L’ancoratge segellat al node { $hub } s’obre i correspon al registre
step-hub-anchored-checkpoint = El registre ancorat al node { $hub } està signat pel registre i pels seus testimonis
step-hub-anchor-consistency = El registre només ha crescut fins al seu ancoratge al node { $hub }
step-browser-anchor = La capa de navegadors conté el registre del node { $hub }
step-browser-consistency = El node { $hub } només ha crescut fins al seu ancoratge a la capa de navegadors
step-bootstrap-link = Un node d’arrencada ancora el node { $hub }
step-bootstrap-consistency = El node { $hub } només ha crescut fins al seu ancoratge al node d’arrencada
step-unknown = Verificació «{ $code }»

## Reasons, why a check failed or is still waiting (`reason-<code>`). They
## take no variables: the tier, hub or step they belong to is shown next to them.

# Encodings and limits
reason-bad-base64 = Un valor en base64 té un format incorrecte.
reason-bad-hex = Un valor hexadecimal té un format incorrecte.
reason-bad-text = Un text no és vàlid o conté un caràcter no permès.
reason-bad-number = Un nombre té un format incorrecte o és fora de l’interval permès.
reason-trailing-data = Hi ha dades inesperades després d’una part del fitxer.
reason-truncated = Una part del fitxer s’acaba abans d’hora.
reason-too-large = Un element supera els límits permesos.

# Signed notes and keys
reason-bad-note = Una nota signada té un format incorrecte.
reason-bad-key-name = Un nom de clau té un format incorrecte.
reason-bad-vkey = Una clau pública té un format incorrecte o és d’un tipus equivocat.
reason-bad-public-key = Una clau pública no és vàlida.
reason-duplicate-signature = Una nota porta la mateixa signatura dues vegades.
reason-bad-signature = Una signatura no és vàlida.
reason-missing-signature = Falta una signatura obligatòria.

# Checkpoints and witness signatures
reason-bad-checkpoint = Un punt de control té un format incorrecte.
reason-wrong-origin = Una nota signada indica un registre o un node diferent de l’esperat.
reason-cosignature-in-future = La signatura d’un testimoni té una data futura, així que no s’ha tingut en compte.
reason-quorum-not-met = Encara no han signat prou testimonis independents.

# Proofs
reason-bad-proof = Una prova té un format incorrecte.
reason-missing-extra = Un comprovant no conté l’entrada.
reason-index-out-of-range = La posició de l’entrada va més enllà del final del registre.
reason-inclusion-failed = La prova que l’entrada és al registre no és vàlida.
reason-consistency-failed = La prova que el registre només ha crescut no és vàlida.
reason-split-view = Dues versions signades del registre tenen la mateixa mida però continguts diferents.

# Entries and expectations
reason-bad-entry = L’entrada té un format incorrecte.
reason-wrong-profile = El tipus de l’entrada és diferent del tipus del registre en aquesta posició.
reason-bad-entry-layout = Els camps de l’entrada no corresponen al seu tipus.
reason-entry-mismatch = L’entrada no és la que s’esperava.
reason-expectation-incomplete = La pàgina no ha donat prou informació sobre l’entrada per poder-la verificar.
reason-expectation-unknown-field = La pàgina ha indicat un camp que aquest tipus d’entrada no té.
reason-expectation-unsupported = Aquest verificador no pot verificar els camps d’aquest tipus d’entrada.
reason-receipts-disagree = Els comprovants del fitxer corresponen a entrades o posicions diferents.

# Promises
reason-bad-promise = La promesa té un format incorrecte.
reason-promise-mmd-too-large = La promesa permet més retard del que admet la política.
reason-promise-leaf-mismatch = La promesa és per a una altra entrada.
reason-promise-pending = El registre ha promès incloure l’entrada. Encara no ha arribat el termini del comprovant.
reason-promise-deadline-passed = El termini de la promesa ha passat i encara no hi ha cap comprovant.
reason-promise-kept-unproven = No hi ha res al fitxer que mostri que la promesa s’ha complert a temps.

# Receipt chains
reason-malformed-chain = El fitxer del comprovant té un format incorrecte.
reason-duplicate-block = El fitxer del comprovant conté la mateixa part dues vegades.
reason-no-receipt = El fitxer no conté cap promesa ni cap comprovant.
reason-policy-mismatch = El comprovant indica una política de confiança diferent de la fixada.
reason-unknown-log = El comprovant indica un registre que la política no inclou.
reason-unknown-hub = Una part indica un node d’ancoratge que la política no inclou, així que no s’ha tingut en compte.
reason-consistency-missing = Falta una prova que el registre només ha crescut.
reason-consistency-mismatch = Una prova que el registre només ha crescut no encaixa amb les versions que enllaça.
reason-waiting-for-cosignatures = A l’espera que els testimonis signin el registre.
reason-waiting-for-record = A l’espera del registre signat pels testimonis.
reason-no-signed-time = Encara no hi ha cap hora signada, així que no es poden avaluar els terminis.
reason-deadline-passed = El termini ha passat, segons l’hora signada.
reason-record-invalid = No s’ha pogut verificar, perquè les proves del registre no s’han pogut verificar.
reason-bad-reference = Un enllaç a un comprovant té un format incorrecte.

# Anchor hubs
reason-waiting-for-anchor = A l’espera que el node d’ancoratge ancori el registre.
reason-hub-quorum-not-met = Encara no han signat prou testimonis del node d’ancoratge.
reason-bad-hub-link = La prova del node d’ancoratge té un format incorrecte o no és vàlida.
reason-hub-link-mismatch = La prova del node d’ancoratge es refereix a una altra cosa.
reason-map-proof-failed = La prova de mapa del node d’ancoratge no és vàlida.
reason-subject-rotated = La clau del registre ha canviat en aquest node d’ancoratge. Cal la política de confiança més recent.
reason-anchor-behind-record = El node d’ancoratge conté una versió del registre més antiga que la del seu comprovant.
reason-anchor-quorum-not-met = El registre ancorat no té prou signatures de testimonis.
reason-bad-blinded-anchor = Un ancoratge segellat no és vàlid.
reason-opening-missing = El fitxer encara no conté el que obre l’ancoratge segellat.
reason-bad-opening = El que hauria d’obrir l’ancoratge segellat no hi correspon.

# Browser layer
reason-browser-test-only = Aquí la capa de navegadors només és de prova: la gestiona l’operador.
reason-waiting-for-browser-anchor = A l’espera de la capa de navegadors. Es preveu d’aquí a pocs minuts.
reason-browser-behind-anchor = La capa de navegadors conté una versió més antiga que la del node d’ancoratge. Se n’espera una de més recent.
reason-bad-browser-anchor = Un ancoratge de la capa de navegadors té un format incorrecte o no coincideix.
reason-bad-waict-proof = La prova de la capa de navegadors no és vàlida.
reason-waict-quorum-not-met = No han signat prou testimonis de la capa de navegadors.
reason-unknown-waict-service = L’ancoratge de la capa de navegadors prové d’un servei que la política no inclou.
reason-waict-service-not-independent = La capa de navegadors la gestiona l’operador, així que no compta.
reason-bad-bootstrap-link = La prova d’un node d’arrencada té un format incorrecte o no és vàlida.

# Trust policies
reason-policy-syntax = Una línia de la política de confiança té un format incorrecte.
reason-policy-unknown-keyword = Una línia de la política de confiança comença amb una paraula desconeguda.
reason-policy-count = Una línia de la política de confiança apareix massa vegades o no hi apareix.
reason-policy-undefined-name = La política de confiança fa servir un nom abans de definir-lo.
reason-policy-duplicate-name = La política de confiança defineix un nom dues vegades.
reason-policy-invalid = La política de confiança incompleix una de les seves regles.
reason-policy-unsafe-quorum = El quòrum de testimonis de la política de confiança no és segur.
reason-policy-unsigned = La política de confiança no té prou signatures de les seves autoritats.

reason-unknown = Motiu «{ $code }»
