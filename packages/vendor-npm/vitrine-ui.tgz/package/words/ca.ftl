# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Catalan (ca).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production.

## The three facts (specs/receipt.md, section 3.1)

fact-included = Inclosa
fact-unchanged = Sense canvis
fact-same-for-everyone = Igual per a tothom

fact-state-done = Fet
fact-state-promised = Promesa
fact-state-pending = Pendent
fact-state-late = Amb retard
fact-state-invalid = No s’ha pogut verificar
fact-state-failed = Ha fallat
fact-state-checking = S’està verificant

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = La seva entrada és al registre.
fact-included-promised = El registre ha signat una promesa d’incloure la seva entrada.
fact-included-pending = Algunes proves que la seva entrada és al registre encara han d’arribar.
fact-included-late = El registre ja hauria d’haver inclòs la seva entrada.
fact-included-invalid = La prova que la seva entrada és al registre no s’ha pogut verificar: les dades semblen malmeses.
fact-included-failed = Les signatures del mateix registre es contradiuen pel que fa a la seva entrada.
fact-unchanged-done = El registre està signat per testimonis independents, així que no hi pot canviar res sense que es detecti.
fact-unchanged-pending = A l’espera que els testimonis independents signin el registre.
fact-unchanged-late = Els testimonis ja haurien d’haver signat el registre.
fact-unchanged-invalid = Les proves sobre l’historial del registre no s’han pogut verificar: les dades semblen malmeses.
fact-unchanged-failed = Hi ha proves signades sobre l’historial del registre que es contradiuen.
fact-same-for-everyone-done = Tothom qui ho verifica veu aquest mateix registre.
fact-same-for-everyone-pending = A l’espera que el registre quedi ancorat on tothom el pugui verificar.
fact-same-for-everyone-late = El registre ja hauria d’estar ancorat on tothom el pugui verificar.
fact-same-for-everyone-invalid = Els ancoratges no s’han pogut verificar: les dades semblen malmeses.
fact-same-for-everyone-failed = Hi ha proves signades que mostren que no tothom veu el mateix registre.
# Instead of the pending text: `fact-pending-successors` (any fact) when every
# tier the fact rests on waits only for the check for a newer trust policy
# (specs/policy.md, section 4, rule 7), and
# `fact-same-for-everyone-pending-attestation` when a private event's anchor
# hubs wait for an auditor to confirm the sealed anchors (specs/receipt.md,
# section 3.3).
fact-pending-successors = Les proves són correctes. Apareixerà com a fet quan es comprovi si la política de confiança ha estat substituïda per una de més recent.
fact-same-for-everyone-pending-attestation = Ancorat. Un auditor encara ha de confirmar els ancoratges segellats, i això pot trigar.

## Tiers

tier-record = Registre
tier-witnesses = Testimonis
tier-hubs = Nodes d’ancoratge
tier-browser = Capa de navegadors
tier-policy = Política
tier-entry = Entrada

tier-status-verified = Verificat
tier-status-pending = Pendent
tier-status-late = Amb retard
tier-status-invalid = No s’ha pogut verificar
tier-status-failed = Ha fallat
tier-status-unused = No s’utilitza
tier-status-checking = S’està verificant
tier-status-promised = Promesa

tier-record-verified = La seva entrada és al registre signat.
tier-record-promised = El registre ha signat una promesa d’incloure la seva entrada.
tier-record-pending = Algunes proves del registre encara han d’arribar.
tier-record-late = El registre ja hauria d’haver inclòs la seva entrada.
tier-record-invalid = Les proves del registre semblen malmeses, així que no s’han pogut verificar.
tier-record-failed = El registre ha signat proves que es contradiuen.
tier-record-checking = S’estan verificant les proves del registre.
tier-witnesses-verified = El registre té la signatura de prou testimonis independents.
tier-witnesses-pending = A l’espera que els testimonis signin. Això només triga uns segons.
tier-witnesses-late = Els testimonis ja haurien d’haver signat.
tier-witnesses-invalid = Les signatures dels testimonis semblen malmeses, així que no s’han pogut verificar.
tier-witnesses-failed = Hi ha testimonis que han signat un registre que contradiu el del seu comprovant.
tier-witnesses-checking = S’estan verificant les signatures dels testimonis.
tier-hubs-verified = Tots els nodes d’ancoratge contenen el registre.
tier-hubs-pending = El registre va de camí cap als nodes d’ancoratge. Això només triga uns segons.
tier-hubs-late = Els nodes d’ancoratge ja haurien de contenir el registre.
tier-hubs-invalid = La resposta d’un node d’ancoratge sembla malmesa, així que no s’ha pogut verificar.
tier-hubs-failed = Un node d’ancoratge conté un registre signat que contradiu el del seu comprovant.
tier-hubs-unused = Aquesta política no utilitza nodes d’ancoratge.
tier-hubs-checking = S’estan verificant els nodes d’ancoratge.
tier-browser-verified = Ancorat on els navegadors el verifiquen.
tier-browser-pending = Es preveu d’aquí a pocs minuts. No cal esperar.
tier-browser-late = Ja hauria d’estar ancorat on els navegadors el verifiquen.
tier-browser-invalid = La resposta de la capa de navegadors sembla malmesa, així que no s’ha pogut verificar.
tier-browser-failed = Un ancoratge signat a la capa de navegadors contradiu el registre.
tier-browser-unused = Aquesta política no utilitza cap capa de navegadors independent.
tier-browser-checking = S’està verificant la capa de navegadors.
# Instead of the pending text: `tier-pending-successors` (any tier) when every
# check of the tier passed but the check for a newer trust policy hasn't run
# yet; in a private event, `tier-hubs-pending-attestation` when the anchor hubs
# wait for an auditor, and `tier-browser-pending-hubs` when the browser layer
# waits for the anchor hubs.
tier-pending-successors = Les seves proves són correctes. Apareixerà com a verificat quan es comprovi si la política de confiança ha estat substituïda per una de més recent.
tier-hubs-pending-attestation = Ancorat. Un auditor encara ha de confirmar els ancoratges segellats. Això pot trigar, i mai no passa a estar amb retard.
tier-browser-pending-hubs = Espera els nodes d’ancoratge: en un esdeveniment privat, la capa de navegadors només compta quan estan verificats.
tier-test = Només de prova: és a càrrec de l’operador, per això no compta.
tier-deadline = Termini previst: { TIME($deadline) }
hub-test = de prova

## Stages of a ballot in the log (specs/entry.md, section 4.1): a tag next to the status

stage-received = Sense emetre
stage-cast = Emesa
stage-audited = Auditada

## The one-line status

status-verified = Verificat
status-checking = S’està verificant…
status-pending = Pendent
status-late = Amb retard
status-invalid = No s’ha pogut verificar
status-failed = Ha fallat
status-summary-verified = Inclosa, sense canvis i igual per a tothom.
status-summary-checking = S’estan verificant les proves del comprovant en aquest navegador.
status-summary-pending = Algunes proves encara han d’arribar. No cal esperar.
status-summary-pending-successors = Les proves són correctes. El comprovant apareixerà com a verificat quan es comprovi si la política de confiança ha estat substituïda per una de més recent.
status-summary-pending-attestation = Ancorat. Un auditor encara ha de confirmar els ancoratges segellats. No cal esperar.
status-summary-late = Algunes proves ja haurien d’haver arribat.
status-summary-invalid = Algunes dades no s’han pogut verificar: sembla que el fitxer o la resposta del servidor estan malmesos. Això no demostra que ningú hagi fet trampa.
status-summary-failed = Hi ha proves signades que es contradiuen. Conservi l’evidència.

## <vitrine-receipt>

receipt-label = Comprovant
receipt-entry = Entrada { $index } del registre { $log }
receipt-entry-promised = Entrada promesa del registre { $log }
receipt-provenance-page = Verificat per aquest lloc web
receipt-provenance-page-hint = Aquest lloc web ha verificat el seu propi registre. Per tenir-ne la certesa, verifiqui-ho de manera independent.
receipt-provenance-independent = Verificat sense dependre del lloc web
receipt-facts-heading = Què mostren les proves
receipt-chain-heading = Fins on ha arribat
receipt-compare-heading = Compari-ho amb l’anunci oficial
receipt-compare-hint = Aquest identificador de política i aquests testimonis haurien de coincidir amb els que ha publicat l’autoritat, per exemple a l’anunci de les eleccions.
receipt-policy-in-force = Política vigent ara
receipt-policy-in-force-hint = Va substituir la política anterior, tal com ho permeten les regles d’aquella política. El seu identificador hauria de coincidir amb un anunci més recent de l’autoritat.
receipt-policy-id = Identificador de la política
receipt-event = Esdeveniment
receipt-witnesses = Testimonis
receipt-witness-party = gestionat per { $party }
receipt-hubs = Nodes d’ancoratge
receipt-clock-warning = El rellotge d’aquest dispositiu difereix en més d’un minut de l’hora més recent que han signat els testimonis. Els terminis s’avaluen amb l’hora signada, no amb aquest rellotge.
receipt-action-check = Verificar independentment
receipt-action-download = Baixar el comprovant
receipt-action-retry = Tornar a verificar
receipt-invalid = Algunes dades no s’han pogut verificar: sembla que el fitxer o la resposta del servidor estan malmesos. Això no demostra que ningú hagi fet trampa. Pot tornar a verificar-ho o fer-ne una verificació independent.
receipt-no-expect = Aquesta pàgina no ha indicat quina entrada cal esperar, de manera que aquest comprovant no es pot mostrar com a seu.
receipt-error = Aquest comprovant no s’ha pogut verificar.
receipt-empty = Encara no hi ha cap comprovant.
receipt-announce = { $tier }: { $status }.

## <vitrine-receipt>, the receipt card (the voter board). Its five steps are
## sealed on this device, then the four tiers. `$noun` is the profile's name for
## one entry ("ballot" in the election profile), or `receipt-noun`.

receipt-noun = entrada
receipt-fingerprint-label = Empremta digital ({ $noun })

receipt-seal-checking = S’està verificant
receipt-seal-sealed = Segellat
receipt-seal-record-public = Inclòs al registre públic
receipt-seal-record-private = Inclòs al registre privat
receipt-seal-witnesses = Confirmat per testimonis independents
receipt-seal-hubs = { $hubs }. Ancoratge de la capa de navegadors previst aviat
receipt-seal-browser = Ancorat on els navegadors el verifiquen

receipt-step-sealed = Segellat en aquest dispositiu
receipt-step-sealed-done = Segellat abans de sortir del seu navegador.
receipt-step-sealed-wait = S’està segellant al seu navegador…
receipt-step-record-public = Afegit al registre públic
receipt-step-record-private = Afegit al registre privat
receipt-step-record-done = Entrada #{ $index }. El seu navegador l’ha verificada.
receipt-step-record-wait = A l’espera que el registre l’inclogui…
receipt-step-record-promised = El registre ha signat una promesa d’incloure-la.
receipt-step-witnesses = Confirmat per testimonis
receipt-step-witnesses-done = Signat per { $signed } dels { $total } testimonis independents.
receipt-step-witnesses-done-any = Signat per testimonis independents.
receipt-step-witnesses-wait = A l’espera de les signatures dels testimonis…
receipt-step-hubs-public =
    { $count ->
        [one] Ancorat en { $count } node públic
       *[other] Ancorat en { $count } nodes públics
    }
receipt-step-hubs-private =
    { $count ->
        [one] Ancorat en { $count } node, segellat
       *[other] Ancorat en { $count } nodes, segellat
    }
receipt-step-hubs-none = Nodes d’ancoratge
receipt-step-hubs-done-public = Els registres compartits també contenen aquest registre.
receipt-step-hubs-done-private = No es revela res del que conté.
receipt-step-hubs-wait = D’aquí a pocs segons…
receipt-step-hubs-partial = De moment, el registre es troba en { $agree } dels { $total } nodes…
receipt-step-browser = Ancorat on els navegadors el verifiquen
receipt-step-browser-done = Al mateix registre que el codi d’aquest lloc.
receipt-step-browser-done-bootstrap = El guarda un node provisional fins que els navegadors comprovin ells mateixos els registres.
receipt-step-browser-wait = D’aquí a pocs minuts. No cal esperar.
receipt-step-browser-wait-minutes =
    { $minutes ->
        [one] D’aquí a un minut. No cal esperar.
       *[other] D’aquí a { $minutes } minuts. No cal esperar.
    }
receipt-step-late = Està tardant més del que caldria.
receipt-step-invalid = No s’ha pogut verificar: les dades semblen malmeses.
receipt-step-failed = Contradiu el registre signat.
receipt-step-unused = No l’utilitza la política d’aquest esdeveniment.
receipt-step-state-done = Fet
receipt-step-state-active = En curs
receipt-step-state-scheduled = Programat
receipt-step-state-waiting = En espera

receipt-caption-checking-public = El seu navegador està verificant el registre públic…
receipt-caption-checking-private = El seu navegador està verificant el registre privat…
receipt-caption-public = Verificat pel seu navegador, amb un codi que qualsevol pot inspeccionar.
receipt-caption-private = Registre privat. Els auditors acreditats poden verificar-lo per complet.
receipt-caption-late = Alguns passos tarden més del que caldria.
receipt-caption-invalid = Algunes dades no s’han pogut verificar. Semblen malmeses.
receipt-caption-failed = El seu navegador ha trobat un problema amb el registre.

receipt-check-elsewhere = Verificar-ho en un altre dispositiu
receipt-action-save = Desar el comprovant

## <vitrine-receipt variant="summary">, the re-check on a later visit (the
## revisit board).

receipt-summary-label = Verificació del comprovant
receipt-summary-title-public = La seva entrada continua al registre públic
receipt-summary-title-private = La seva entrada continua al registre privat
receipt-summary-title-checking = S’està verificant la seva entrada al registre…
receipt-summary-title-late = Algunes proves de la seva entrada van amb retard
receipt-summary-title-invalid = La seva entrada no s’ha pogut verificar
receipt-summary-title-failed = No hem pogut confirmar la seva entrada al registre
receipt-summary-checked-now = Verificat fa un moment pel seu navegador.
receipt-summary-checked-at = Verificat pel seu navegador a les { TIME($time) }.
receipt-summary-unchanged = Res del que es va registrar abans no ha canviat.
receipt-summary-witnesses = Testimonis
receipt-summary-hubs-public = Nodes públics
receipt-summary-hubs-private = Nodes
receipt-summary-browser = On els navegadors verifiquen
receipt-summary-agree = { $agree } de { $total } coincideixen
receipt-summary-agree-any = Coincideixen
receipt-summary-anchored = Ancorat { DATE($time) }
receipt-summary-anchored-plain = Ancorat
receipt-summary-waiting = En espera
receipt-summary-due = Previst aviat
receipt-summary-unused = No s’utilitza
receipt-view = Veure el comprovant

## <vitrine-how-we-check>

how-label = Com funciona la verificació
how-heading = Com verifiquem
how-receipt = El seu navegador conserva un comprovant signat. Conté una empremta digital del que ha enviat, mai el contingut.
how-grew = A cada visita, demana al registre una prova breu que només ha crescut.
how-witnesses = Testimonis independents el signen, i nodes públics l’ancoren on els navegadors el verifiquen, de manera que tothom veu el mateix registre.

## <vitrine-proof-steps>

steps-heading = Totes les verificacions
steps-summary =
    { $total ->
        [one] { $passed } d’{ $total } verificació superada
       *[other] { $passed } de { $total } verificacions superades
    }
steps-result-passed = Superada
steps-result-failed = Ha fallat
steps-result-not-run = Encara no s’ha fet
steps-show-details = Mostrar els detalls
steps-hide-details = Amagar els detalls
steps-objects = Objectes signats implicats: { $objects }
steps-evidence = Desar l’evidència
steps-empty = Encara no hi ha cap verificació.

## <vitrine-chain>

chain-label = Cadena del comprovant

## <vitrine-alert>

alert-label = Problema demostrat
alert-kind-split-view-title = El registre s’ha mostrat de manera diferent a persones diferents
alert-kind-split-view-body = Dues versions del registre, totes dues signades pel seu operador, no poden ser certes alhora. Pot ser una fallada o un atac. La seva entrada encara pot comptar, però convé que ho revisi algú independent.
alert-kind-broken-promise-title = El registre no ha complert una promesa signada
alert-kind-broken-promise-body = El registre ha promès incloure una entrada dins d’un termini, i les seves pròpies signatures mostren que no ho ha fet. Convé que ho revisi algú independent.
alert-kind-bad-entry-title = El registre conté una entrada que incompleix les seves regles
alert-kind-bad-entry-body = Una entrada signada al registre incompleix una regla del perfil del registre. Convé que ho revisi algú independent.
alert-kind-hub-entry-title = Un node d’ancoratge ha acceptat una entrada que hauria d’haver rebutjat
alert-kind-hub-entry-body = Els testimonis d’un node d’ancoratge han signat un registre del node amb una entrada que incompleix les regles del node, de manera que almenys un d’ells ha signat sense verificar.
alert-kind-time-regression-title = El registre ha signat una hora falsa
alert-kind-time-regression-body = El registre ha signat dues versions de si mateix, i la més gran té l’hora més primerenca. L’hora signada d’un registre mai no retrocedeix, així que una de les dues és falsa. Convé que ho revisi algú independent.
alert-kind-policy-equivocation-title = Les autoritats de la política de confiança han signat dues substitucions diferents
alert-kind-policy-equivocation-body = Prou autoritats de la política de confiança n’han signat dues substitucions diferents, i totes dues han quedat registrades. Compta la primera que es va registrar, però la segona podria mostrar polítiques diferents a persones diferents. Convé que ho revisi algú independent.
alert-kind-bad-checkpoint-title = Un registre ha signat una versió impossible de si mateix
alert-kind-bad-checkpoint-body = Ha signat una versió que no té cap entrada, però que no és buida. Cap registre ni node d’ancoratge honest no pot produir-ne una així. Convé que ho revisi algú independent.
alert-kind-unlogged-code-title = Un lloc ha servit codi que el seu registre de versions no conté
alert-kind-unlogged-code-body = El manifest del lloc al registre públic enumera un script, i cap versió registrada de l'aplicació el conté. El codi que serveix el lloc no és el codi que es va publicar perquè es pogués comprovar.
alert-kind-unknown-title = S’ha trobat un problema
alert-kind-unknown-body = L’evidència mostra un problema d’un tipus que aquesta pàgina no coneix: { $kind }.
alert-not-proven-title = Aquest fitxer no demostra cap problema
alert-not-proven-body = El fitxer s’ha verificat i no demostra cap problema. No constitueix cap evidència.
alert-unpinned-title = Aquest fitxer correspon a una política que no s’ha fixat en aquest dispositiu
alert-unpinned-body = No es pot mostrar com a prova en aquest dispositiu. Compari l’identificador de la política del fitxer amb l’anunci oficial i fixi aquesta política abans de tornar a verificar el fitxer.
alert-invalid-title = Aquest fitxer no s’ha pogut verificar
alert-invalid-body = Sembla que el fitxer està malmès. Això no demostra que ningú hagi fet trampa.
alert-proven-under = Demostrat segons la política amb aquest identificador:
alert-file-policy-id = Identificador de la política del fitxer:
alert-parties = Responsables, segons les seves pròpies signatures: { $parties }
alert-evidence-heading = Evidència desada en aquest dispositiu
alert-evidence-hint = Els observadors verifiquen aquesta evidència als seus propis ordinadors. Demostra el que ha signat el registre i no conté res del que vostè ha enviat.
alert-download = Baixar el fitxer d’evidència
alert-send = Enviar l’evidència als observadors
alert-monitors-heading = Observadors que indica la política
alert-confirm-heading = Vol enviar l’evidència?
alert-confirm-body =
    { $count ->
        [one] S’enviarà el fitxer d’evidència a aquest observador. Veurà el fitxer i sabrà que s’ha enviat des d’aquest dispositiu.
       *[other] S’enviarà el fitxer d’evidència a aquests { $count } observadors. Veuran el fitxer i sabran que s’ha enviat des d’aquest dispositiu.
    }
alert-confirm-send = Sí, enviar-la
alert-confirm-cancel = Cancel·lar
alert-sending = S’està enviant l’evidència als observadors.
alert-no-monitors = La política no indica cap monitor. Conservi el fitxer i lliuri’l a un observador.
alert-delivery-waiting = A l’espera de confirmació
alert-delivery-sending = S’està enviant
alert-delivery-confirmed = Confirmat
alert-delivery-failed = No confirmat

## <vitrine-alert>, the alert board: the evidence kept on this device, as the
## signed items the file holds.

alert-yours-title = No hem pogut confirmar la seva entrada al registre
alert-yours-split-view-body = El registre mostrat al seu navegador no coincideix amb el que han signat els testimonis independents. Pot ser una fallada o un atac. La seva entrada encara pot comptar, però convé que ho revisi algú independent.
alert-evidence-count =
    { $count ->
        [one] { $count } element signat
       *[other] { $count } elements signats
    }
alert-item-receipt = El seu comprovant de l’entrada #{ $index }
alert-item-receipt-detail = Signat pel registre quan es va afegir
alert-item-receipt-other = Comprovant de l’entrada #{ $index }
alert-item-checkpoint = Registre signat, mida { $size }
alert-item-checkpoint-shown = Registre que se li ha mostrat, mida { $size }
alert-item-checkpoint-shown-detail = Conté la seva entrada
alert-item-checkpoint-witnessed = Registre signat pels testimonis, mida { $size }
alert-item-witnessed-detail =
    { $count ->
        [one] Signat per { $count } testimoni
       *[other] Signat per { $count } testimonis
    }
alert-item-hubs-detail =
    { $hubs ->
        [one] Ancorat en { $hubs } node públic
       *[other] Ancorat en { $hubs } nodes públics
    }
alert-item-promise = Promesa signada d’incloure una entrada
alert-item-policy = Política de confiança signada
alert-item-policy-ack = Reconeixement signat de la política de confiança
alert-item-why-split-view = No pot haver crescut a partir del registre de mida { $size }
alert-item-why-time-regression = L’hora signada és anterior a la del registre més petit
alert-item-why-bad-checkpoint = No té cap entrada, però no és buit
alert-what-next = Què passa després?
alert-what-next-body = Els observadors independents llegeixen l’evidència als seus propis ordinadors. No s’envia res si vostè no decideix enviar-ho. També pot conservar el fitxer i lliurar-lo a algú de confiança: demostra el que ha signat el registre allà on es verifiqui.

## <vitrine-badge>

badge-check = Verificar independentment
badge-opens = obre un verificador independent

## Monitor reports (specs/evidence.md, section 3). `report-kind-<kind>` says
## what a report is about, with `$subject`, the record or hub it names. A
## report is its monitor's own statement, not proof: show `report-established`
## only when monitors of enough different parties report the same thing.

report-kind-cosign-late = { $subject } fa massa temps que no té una versió recent signada per prou testimonis.
report-kind-anchor-late = { $subject } no s’ha ancorat a temps: el registre o el node d’ancoratge va amb retard, i l’informe no pot dir quin dels dos.
report-kind-unreachable = Un servidor de { $subject } ha deixat de respondre.
report-kind-mirror-behind = La còpia de { $subject } que manté una rèplica s’ha quedat enrere.
report-kind-payload-missing = Algunes dades registrades a { $subject } no estan disponibles, i cap avís no indica que s’hagin retingut.
report-kind-payload-mismatch = Algunes dades que serveix { $subject } no coincideixen amb el que va registrar.
report-kind-rule-failing = Una entrada de { $subject } incompleix una regla del seu perfil. El monitor n’ha publicat una evidència que qualsevol pot verificar.
report-kind-promise-pending = { $subject } ha signat una promesa d’incloure una entrada, i encara no l’ha inclosa.
report-kind-promise-unlisted = { $subject } deixa fora de la seva llista un lot de les seves promeses signades.
report-kind-promise-late = { $subject } no ha complert a temps una promesa signada: el registre o els seus testimonis van anar amb retard, o els seus rellotges no van bé.
report-kind-promise-misdated = { $subject } ha datat malament un lot de les seves promeses signades: la seva hora no encaixa amb l’hora en què es va llistar, o amb el moment en què el monitor el va veure per primera vegada.
report-kind-opening-missing = { $subject } no ha obert a temps un ancoratge segellat per a l’auditor.
report-kind-ack-missing = { $subject } no ofereix la seva declaració signada que segueix la política de confiança vigent.
report-kind-config-mismatch = A una cabina de votació se li ha mostrat una configuració de l’elecció que { $subject } no ha registrat, o que és diferent de la registrada.
report-kind-code-mismatch = Un lloc web ha servit un script que no forma part de cap versió publicada registrada a { $subject }.
report-kind-unknown = Informe de monitor «{ $kind }» sobre { $subject }
report-established = Confirmat: ho informen monitors de prou parts diferents.
report-statement = Informat per { $monitor }. Un informe és una declaració del mateix monitor, no una prova sobre ningú més.

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = El fitxer del comprovant té un format correcte
step-policy-pinned = El comprovant correspon a la política de confiança fixada
step-policy-successors = S’ha verificat si una política de confiança més recent ha substituït la fixada
step-policy-ack = El registre ha signat que segueix la política de confiança
step-log-known = La política inclou el registre del comprovant
step-entry-parse = L’entrada té un format correcte
step-entry-profile = L’entrada és del tipus del registre i té els camps d’aquest tipus
step-entry-expectation = L’entrada és la que s’esperava
step-promise-signature = El registre ha signat una promesa d’incloure l’entrada
step-promise-inclusion = La promesa signada abasta l’entrada
step-promise-leaf = La promesa és per a l’entrada que s’esperava
step-promise-kept = El registre ha complert la promesa dins del termini
step-issued-signature = El comprovant lliurat en l’enviament està signat pel registre
step-issued-inclusion = L’entrada és al comprovant lliurat en l’enviament
step-record-signature = El comprovant del registre està signat pel mateix registre
step-record-inclusion = L’entrada és al registre
step-receipts-match = Els comprovants corresponen a la mateixa entrada i a la mateixa posició
step-record-consistency = El registre només ha crescut des del comprovant lliurat en l’enviament
step-record-quorum = El registre té la signatura de prou testimonis independents
step-log-consistent = Les versions del registre vistes aquí no es contradiuen
step-hub-link = La prova del node { $hub } és vàlida
step-hub-opening = L’ancoratge segellat al node { $hub } s’obre i correspon al registre
step-hub-anchored-checkpoint = El registre ancorat al node { $hub } està signat pel registre i pels seus testimonis
step-hub-previous-anchor = El node { $hub } conté l’ancoratge segellat anterior, i s’obre i correspon al registre
step-hub-opening-consistency = El registre només ha crescut entre els seus dos últims ancoratges segellats al node { $hub }
step-hub-attestation = Un auditor ha confirmat l’ancoratge segellat al node { $hub }
step-hub-anchor-consistency = El registre només ha crescut fins al seu ancoratge al node { $hub }
step-browser-link = La prova del node { $hub } per a la capa de navegadors és vàlida i abasta l’entrada
step-browser-link-consistency = El registre només ha crescut entre el seu comprovant i la prova del node { $hub } per a la capa de navegadors
step-browser-anchor = La capa de navegadors conté el registre del node { $hub }
step-browser-consistency = El node { $hub } només ha crescut fins a la seva versió ancorada on els navegadors la verifiquen
step-bootstrap-link = Un node d’arrencada ancora el node { $hub }
step-unknown = Verificació «{ $code }»

## Reasons, why a check failed or is still waiting (`reason-<code>`). Their
## variables are the verifier's `params`. A message uses only those that the
## verifier always passes for its code: the tier, hub or step it belongs to is
## shown next to it anyway.

# Encodings and limits
reason-bad-base64 = Un valor en base64 té un format incorrecte.
reason-bad-hex = Un valor hexadecimal té un format incorrecte.
reason-bad-text = Un text no és vàlid o conté un caràcter no permès.
reason-bad-number = Un nombre té un format incorrecte o és fora de l’interval permès.
reason-trailing-data = Hi ha dades inesperades després d’una part del fitxer.
reason-truncated = Una part del fitxer s’acaba abans d’hora.
reason-too-large = Un element supera els límits permesos.

# Signed notes and keys
reason-bad-note = Una nota signada té un format incorrecte.
reason-bad-key-name = Un nom de clau té un format incorrecte.
reason-bad-vkey = Una clau pública té un format incorrecte o és d’un tipus equivocat.
reason-bad-public-key = Una clau pública no és vàlida.
reason-missing-signature = Falta una signatura obligatòria.

# Checkpoints and witness signatures
reason-bad-checkpoint = Un punt de control té un format incorrecte.
reason-bad-empty-tree = Una versió signada del registre és impossible: no té cap entrada, però el seu contingut no és buit.
reason-wrong-origin = Una nota signada indica un registre o un node diferent de l’esperat.
reason-log-time-missing = A un comprovant li falta l’hora signada del registre, així que no s’ha pogut verificar.
reason-cosignature-in-future = La signatura d’un testimoni té una data futura, així que no s’ha tingut en compte.
reason-quorum-not-met = Encara no han signat prou testimonis independents.

# Proofs
reason-bad-proof = Una prova té un format incorrecte.
reason-missing-extra = Un comprovant no conté l’entrada.
reason-index-out-of-range = La posició de l’entrada va més enllà del final del registre.
reason-inclusion-failed = La prova que l’entrada és al registre no és vàlida.
reason-consistency-failed = La prova que el registre només ha crescut no és vàlida.
reason-split-view = Dues versions signades del registre tenen la mateixa mida però continguts diferents.

# Entries and expectations
reason-bad-entry = L’entrada té un format incorrecte.
reason-wrong-profile = El tipus de l’entrada és diferent del tipus del registre en aquesta posició.
reason-bad-entry-layout = Els camps de l’entrada no corresponen al seu tipus.
reason-entry-mismatch = L’entrada no és la que s’esperava.
reason-expectation-incomplete = La pàgina no ha donat prou informació sobre l’entrada per poder-la verificar.
reason-expectation-unknown-field = La pàgina ha indicat un camp que aquest tipus d’entrada no té.
reason-expectation-unsupported = Aquest verificador no pot verificar els camps d’aquest tipus d’entrada.
reason-receipts-disagree = Els comprovants del fitxer corresponen a entrades o posicions diferents.

# Promises
reason-bad-promise = La promesa té un format incorrecte.
reason-promise-policy-unknown = La promesa indica una política de confiança que no és la fixada ni cap de les que l’han substituïda.
reason-promise-mmd-too-large = La promesa permet més retard del que admet la política.
reason-promise-leaf-mismatch = La promesa és per a una altra entrada.
reason-promise-time = El registre va datar la seva promesa a més d’un minut del moment en què va arribar, així que no compta com a promesa.
reason-promise-pending = El registre ha promès incloure l’entrada. Encara no ha arribat el termini del comprovant.
reason-promise-deadline-passed = El termini de la promesa ha passat i encara no hi ha cap comprovant.
reason-promise-kept-unproven = No hi ha res al fitxer que mostri que la promesa s’ha complert a temps.
reason-broken-promise = El registre va prometre incloure l’entrada abans de l’hora límit ({ TIME($deadline) }), però la seva pròpia hora signada ({ TIME($logTime) }) mostra que després encara no ho havia fet.
reason-bad-promise-list = La llista de les promeses que el registre va fer en una hora té un format incorrecte o no correspon a aquestes promeses, així que no s’ha pogut verificar.

# Receipt chains
reason-malformed-chain = El fitxer del comprovant té un format incorrecte.
reason-duplicate-block = El fitxer del comprovant conté la mateixa part dues vegades.
reason-no-receipt = El fitxer no conté cap promesa ni cap comprovant.
reason-policy-mismatch = El comprovant indica una política de confiança diferent de la fixada.
reason-policy-draft = La política de confiança encara és un esborrany, i un esborrany no és mai vàlid.
reason-bad-policy-ack = La declaració signada del registre que segueix aquesta política de confiança té un format incorrecte o no hi correspon.
reason-unknown-log = El comprovant indica un registre que la política no inclou.
reason-unknown-hub = Una part indica un node d’ancoratge que la política no inclou, així que no s’ha tingut en compte.
reason-consistency-missing = Falta una prova que el registre només ha crescut.
reason-consistency-mismatch = Una prova que el registre només ha crescut no encaixa amb les versions que enllaça.
reason-waiting-for-cosignatures = A l’espera que els testimonis signin el registre.
reason-waiting-for-record = A l’espera del registre signat pels testimonis.
reason-no-signed-time = Encara no hi ha cap hora signada, així que no es poden avaluar els terminis.
reason-deadline-passed = El termini ha passat, segons l’hora signada.
reason-record-invalid = No s’ha pogut verificar, perquè les proves del registre no s’han pogut verificar.
reason-bad-reference = Un enllaç a un comprovant té un format incorrecte.
reason-reference-unpinned = Cap política de confiança fixada en aquest dispositiu no correspon a aquest enllaç al comprovant.
reason-reference-ambiguous = Aquest enllaç al comprovant correspon a més d’una política de confiança fixada en aquest dispositiu, així que no s’ha fet servir.

# The booth's configuration check
reason-bad-config = La configuració de l’elecció, o l’avís que s’ha obert la votació, té un format incorrecte, no està signada o no la signen prou testimonis, així que la cabina de votació no xifrarà cap papereta amb aquesta configuració.
reason-config-mismatch = La configuració registrada de l’elecció no coincideix amb l’esdeveniment, l’elecció, la clau de l’elecció, els models de papereta, la política de confiança o el programari de la cabina de votació, o no és la vigent quan es va obrir la votació, així que la cabina no xifrarà cap papereta.

# Keys logs
reason-bad-key-statement = Una declaració d’un registre de claus té un format incorrecte, indica un altre registre, no correspon a la seva entrada o li falten les signatures que necessita, així que no compta.
reason-signed-by-failed = Una declaració no està signada per la seva clau, la clau estava revocada o no era vàlida quan es va registrar l’entrada, o massa poques altres claus vàlides també l’han signada.
    .not-ed25519 = La declaració, o la clau que l’havia de signar, té un format incorrecte o és d’un tipus incorrecte.
    .not-signed = La declaració no està signada per la seva clau.
    .revoked = La clau que va signar la declaració ja estava revocada quan es va registrar l’entrada.
    .not-valid = La clau que va signar la declaració no era vàlida quan es va registrar l’entrada.
    .cosigners = Massa poques altres claus vàlides també han signat la declaració: { $have } de les { $need } necessàries.

# Upgrades
reason-log-quiet = El registre és en un període de silenci i no mostra res de més recent fins que s’acabi, així que algunes proves esperaran fins aleshores.
reason-log-private = El registre és privat: només el poden llegir els auditors, així que les seves proves arriben a través del lloc web de l’esdeveniment.
reason-monitor-evidence = El monitor { $monitor } ha publicat una evidència que aquesta versió del registre contradiu la que té ell. Aquesta evidència encara no s’ha verificat aquí.

# Successor policies
reason-successors-unchecked = Encara no s’ha verificat si una política de confiança més recent ha substituït aquesta, així que res no apareix com a verificat.
reason-bad-policy-proofs = Les proves sobre polítiques de confiança més recents tenen un format incorrecte o no són vàlides.
reason-successor-rejected = S’ha publicat una política de confiança més recent, però incompleix les regles per substituir-ne una, així que continua vigent l’anterior.
reason-policy-equivocation = Les autoritats de la política de confiança n’han signat dues substitucions diferents, cosa que demostra que s’han contradit. Compta la primera que es va publicar.

# Anchor hubs
reason-bad-subject = El nom o la clau amb què un node d’ancoratge guarda els ancoratges d’un registre té un format incorrecte, així que no compta.
reason-waiting-for-anchor = A l’espera que el node d’ancoratge ancori el registre.
reason-hub-quorum-not-met = Encara no han signat prou testimonis del node d’ancoratge.
reason-bad-hub-link = La prova del node d’ancoratge té un format incorrecte o no és vàlida.
reason-hub-link-mismatch = La prova del node d’ancoratge es refereix a una altra cosa.
reason-hub-index-wrong = Els testimonis del node { $hub } han signat un índex que apunta a una entrada equivocada per a aquest registre, així que han signat sense verificar.
reason-map-proof-failed = La prova de mapa del node d’ancoratge no és vàlida.
reason-subject-rotated = La clau del registre ha canviat en aquest node d’ancoratge. Cal la política de confiança més recent.
reason-rotation-unauthorized = Al node { $hub }, la clau del registre l’ha canviada una entrada que cap política de confiança coneguda no permet.
reason-anchor-behind-record = El node d’ancoratge conté una versió del registre més antiga que la del seu comprovant.
reason-anchor-quorum-not-met = El registre ancorat no té prou signatures de testimonis.
reason-hub-link-stale = La prova del node { $hub } que té el registre és molt més antiga que l’última versió del node: el registre ja n’hauria de tenir una de més recent.
reason-bad-blinded-anchor = Un ancoratge segellat no és vàlid.
reason-opening-missing = El fitxer encara no conté el que obre l’ancoratge segellat.
reason-bad-opening = El que hauria d’obrir l’ancoratge segellat no hi correspon.
reason-previous-anchor-missing = El fitxer encara no conté l’ancoratge segellat anterior al node { $hub }, o el que l’obre.
reason-bad-previous-anchor = L’ancoratge segellat anterior no és l’ancoratge del registre immediatament anterior a aquest, així que no s’ha pogut verificar.
reason-attestation-missing = Encara cap auditor no ha confirmat l’ancoratge segellat al node { $hub }. Continua pendent fins que algun ho faci, i mai no passa a estar amb retard.
reason-attestation-not-covering = La confirmació de l’auditor per al node { $hub } abasta els ancoratges segellats del { $from } al { $to }, però encara no el número { $seq }.
reason-bad-attestation = No s’ha pogut verificar la confirmació d’un auditor: té un format incorrecte, no la signa cap auditor de la política de confiança o no correspon a l’ancoratge segellat.
reason-hub-entry-refused = Un node d’ancoratge ha registrat una entrada que incompleix les regles del node, així que l’entrada no compta.

# Browser layer
reason-browser-test-only = Aquí la capa de navegadors només és de prova: la gestiona l’operador.
reason-waiting-for-browser-anchor = A l’espera de la capa de navegadors. Es preveu d’aquí a pocs minuts.
reason-pair-not-covering = L’última prova del registre per a la capa de navegadors, del node { $hub }, és anterior a l’entrada. La pròxima l’abastarà.
reason-browser-below-link = La capa de navegadors mostra una versió del node { $hub } més antiga que la de la prova amb què va aparellada, així que no encaixen.
reason-waiting-for-hub-tier = Espera el node { $hub }: en un esdeveniment privat, la capa de navegadors només compta quan el node està verificat.
reason-bad-browser-pair = Les proves del registre per a la capa de navegadors tenen un format incorrecte.
reason-bad-browser-anchor = Un ancoratge de la capa de navegadors té un format incorrecte o no coincideix.
reason-bad-waict-proof = La prova de la capa de navegadors no és vàlida.
reason-waict-quorum-not-met = No han signat prou testimonis de la capa de navegadors.
reason-unknown-waict-service = L’ancoratge de la capa de navegadors prové d’un servei que la política no inclou.
reason-waict-service-not-independent = La capa de navegadors la gestiona l’operador, així que no compta.
reason-bad-bootstrap-link = La prova d’un node d’arrencada té un format incorrecte o no és vàlida.

# Trust policies
reason-policy-syntax = Una línia de la política de confiança té un format incorrecte.
reason-policy-unknown-keyword = Una línia de la política de confiança comença amb una paraula desconeguda.
reason-policy-count = Una línia de la política de confiança apareix massa vegades o no hi apareix.
reason-policy-undefined-name = La política de confiança fa servir un nom abans de definir-lo.
reason-policy-duplicate-name = La política de confiança defineix un nom dues vegades.
reason-policy-invalid = La política de confiança incompleix una de les seves regles.
reason-policy-unsafe-quorum = El quòrum de testimonis de la política de confiança no és segur.
reason-policy-unsigned = La política de confiança no té prou signatures de les seves autoritats.

# Payloads and redaction
reason-payload-mismatch = Les dades que un servidor ha enviat per a una entrada no coincideixen amb el que en guarda el registre, així que no són les dades registrades. Pot ser que una rèplica del registre tingui les dades correctes.
reason-payload-missing = Les dades registrades per a una entrada no estan disponibles, i cap avís vàlid de retirada de dades no indica que s’hagin retingut. Pot ser que una rèplica del registre encara les tingui.
reason-bad-payload-bundle = Les dades que un servidor ha enviat per a un lot d’entrades tenen un format incorrecte o no corresponen a aquestes entrades, així que no s’han pogut verificar. Pot ser que una rèplica del registre les tingui.
reason-bad-notice = Un avís de retirada de dades té un format incorrecte, així que no compta.
reason-notice-unsigned = Un avís de retirada de dades no té prou signatures de les autoritats que la política de confiança designa per a aquests avisos, així que no compta.
    .no-redaction = La política de confiança no permet retirar dades, així que un avís de retirada de dades no compta.
reason-notice-mismatch = Un avís de retirada de dades no coincideix amb les dades que es retenen amb aquest avís ni amb la seva còpia registrada, o indica dades que no es poden retirar, així que no compta.
    .profile = Un avís de retirada de dades indica una entrada les dades de la qual no es poden retirar, com ara una papereta, així que no compta.
reason-notice-not-applied = Un avís de retirada de dades no té cap efecte: no fa referència a l’últim avís que es va aplicar a la mateixa entrada, en repeteix un d’anterior o porta una data anterior al moment en què es va registrar aquell avís.
reason-bad-notice-bundle = La prova que es va registrar un avís de retirada de dades té un format incorrecte, no és vàlida o no té prou signatures de testimonis, així que l’avís no compta.

# Evidence files
reason-bad-evidence = El fitxer d’evidència té un format incorrecte o li falta una part que el seu tipus necessita.
reason-evidence-unknown-kind = El fitxer d’evidència és d’un tipus que aquest verificador no coneix.
reason-evidence-unpinned = El fitxer d’evidència correspon a una política de confiança que aquest dispositiu no ha fixat.
reason-evidence-wrong-subject = El fitxer d’evidència tracta d’un registre o d’un node al qual el seu tipus no s’aplica segons la seva política de confiança.
reason-evidence-policy-mismatch = Una part del fitxer d’evidència correspon a una política de confiança diferent de la del fitxer.
reason-not-proven = Les signatures de l’evidència són vàlides, però no mostren el problema que afirma.
reason-needs-scan = Això només es pot decidir llegint les entrades del registre, i aquesta verificació no ho ha fet.
reason-rule-unsupported = L’evidència indica una regla que aquest verificador no pot aplicar. Un verificador complet la pot verificar.
reason-faulty-witness = Aquest testimoni ha signat dues versions que es contradiuen, o una versió d’un node amb una entrada indeguda, cosa que demostra que és defectuós.
reason-trust-assumption-failed = Prou testimonis han signat les versions contradictòries per arribar al quòrum: n’hi ha més de defectuosos dels que suposa la política de confiança.
reason-misbehaviour-proven = L’evidència demostra el problema que afirma, segons la política de confiança del fitxer.

reason-unknown = Motiu «{ $code }»

# Shared infrastructure. Draft translations need native-speaker review.
reason-bad-operator-list = The infrastructure list is damaged or uses an unsupported format.
reason-operator-list-refused = The infrastructure list could not be accepted under the pinned authorities, validity window or update history.
reason-bad-shared-submission = The shared-log request or enrolment is damaged or does not follow the format.
reason-shared-submission-refused = The shared log could not accept this request under its pinned policy, submitter key or namespace.

# New metadata reason: native translation review needed outside English.
reason-profile-meaning-unknown = The profile meaning is not available for validation.

## extension

# The names of the anchor hubs and the browser layer in the extension's compact receipt chain.
tier-hubs-short = Nodes
tier-browser-short = Navegador
