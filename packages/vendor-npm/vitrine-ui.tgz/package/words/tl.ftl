# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Tagalog (tl).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production. It uses no plural
# selectors: the CLDR rule for Filipino calls 2 and 3 "one".

## The three facts (specs/receipt.md, section 3.1)

fact-included = Kasama sa talaan
fact-unchanged = Hindi nagbago
fact-same-for-everyone = Pareho para sa lahat

fact-state-done = Tapos na
fact-state-promised = Ipinangako
fact-state-pending = Nakabinbin
fact-state-late = Naantala
fact-state-invalid = Hindi masuri
fact-state-failed = Hindi pumasa
fact-state-checking = Sinusuri

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Nasa talaan ang inyong tala.
fact-included-promised = Lumagda ang talaan sa pangakong isasama ang inyong tala.
fact-included-pending = Parating pa ang ilang patunay na nasa talaan ang inyong tala.
fact-included-late = Dapat ay naisama na ng talaan ang inyong tala.
fact-included-invalid = Hindi masuri ang patunay na nasa talaan ang inyong tala: mukhang sira ang datos.
fact-included-failed = Magkasalungat ang sariling mga lagda ng talaan tungkol sa inyong tala.
fact-unchanged-done = Nilagdaan ng mga independiyenteng saksi ang talaan, kaya walang anumang bahagi nito ang mababago nang hindi napapansin.
fact-unchanged-pending = Hinihintay na lumagda sa talaan ang mga independiyenteng saksi.
fact-unchanged-late = Dapat ay nakalagda na sa talaan ang mga saksi.
fact-unchanged-invalid = Hindi masuri ang mga patunay tungkol sa kasaysayan ng talaan: mukhang sira ang datos.
fact-unchanged-failed = Magkasalungat ang mga nilagdaang patunay tungkol sa kasaysayan ng talaan.
fact-same-for-everyone-done = Ito ring talaan ang ipinapakita sa lahat ng sumusuri.
fact-same-for-everyone-pending = Hinihintay na maiangkla ang talaan kung saan ito masusuri ng lahat.
fact-same-for-everyone-late = Dapat ay nakaangkla na ang talaan kung saan ito masusuri ng lahat.
fact-same-for-everyone-invalid = Hindi masuri ang mga angkla: mukhang sira ang datos.
fact-same-for-everyone-failed = Makikita sa mga nilagdaang patunay na hindi iisang talaan ang ipinapakita sa lahat.
# Instead of the pending text: `fact-pending-successors` (any fact) when every
# tier the fact rests on waits only for the check for a newer trust policy
# (specs/policy.md, section 4, rule 7), and
# `fact-same-for-everyone-pending-attestation` when a private event's anchor
# hubs wait for an auditor to confirm the sealed anchors (specs/receipt.md,
# section 3.3).
fact-pending-successors = Tama ang mga patunay. Ipapakita itong tapos na kapag nasuri na kung napalitan ng mas bagong patakaran ang patakaran ng tiwala.
fact-same-for-everyone-pending-attestation = Naiangkla na. Kailangan pang kumpirmahin ng isang auditor ang mga selyadong angkla, at maaaring matagalan ito.

## Tiers

tier-record = Talaan
tier-witnesses = Mga saksi
tier-hubs = Mga angklang hub
tier-browser = Layer ng browser
tier-policy = Patakaran
tier-entry = Tala

tier-status-verified = Napatunayan
tier-status-pending = Nakabinbin
tier-status-late = Naantala
tier-status-invalid = Hindi masuri
tier-status-failed = Hindi pumasa
tier-status-unused = Hindi ginagamit
tier-status-checking = Sinusuri
tier-status-promised = Ipinangako

tier-record-verified = Nasa nilagdaang talaan ang inyong tala.
tier-record-promised = Lumagda ang talaan sa pangakong isasama ang inyong tala.
tier-record-pending = Parating pa ang ilan sa mga patunay ng talaan.
tier-record-late = Dapat ay naisama na ng talaan ang inyong tala.
tier-record-invalid = Mukhang sira ang mga patunay ng talaan, kaya hindi masuri ang mga ito.
tier-record-failed = Nilagdaan ng talaan ang mga patunay na magkasalungat.
tier-record-checking = Sinusuri ang mga patunay ng talaan.
tier-witnesses-verified = Sapat na independiyenteng saksi ang lumagda sa talaan.
tier-witnesses-pending = Hinihintay na lumagda ang mga saksi. Ilang segundo lamang ito.
tier-witnesses-late = Dapat ay nakalagda na ang mga saksi.
tier-witnesses-invalid = Mukhang sira ang mga lagda ng saksi, kaya hindi masuri ang mga ito.
tier-witnesses-failed = Lumagda ang mga saksi sa isang talaang salungat sa nasa inyong resibo.
tier-witnesses-checking = Sinusuri ang mga lagda ng saksi.
tier-hubs-verified = Hawak ng bawat angklang hub ang talaan.
tier-hubs-pending = Papunta na sa mga angklang hub. Ilang segundo lamang ito.
tier-hubs-late = Dapat ay hawak na ng mga angklang hub ang talaan.
tier-hubs-invalid = Mukhang sira ang sagot ng isang angklang hub, kaya hindi ito masuri.
tier-hubs-failed = Hawak ng isang angklang hub ang isang nilagdaang talaang salungat sa nasa inyong resibo.
tier-hubs-unused = Walang ginagamit na angklang hub ang patakarang ito.
tier-hubs-checking = Sinusuri ang mga angklang hub.
tier-browser-verified = Nakaangkla na kung saan sumusuri ang mga browser.
tier-browser-pending = Inaasahan sa loob ng ilang minuto. Hindi ninyo kailangang maghintay.
tier-browser-late = Dapat ay nakaangkla na ito kung saan sumusuri ang mga browser.
tier-browser-invalid = Mukhang sira ang sagot ng layer ng browser, kaya hindi ito masuri.
tier-browser-failed = Salungat sa talaan ang isang nilagdaang angkla kung saan sumusuri ang mga browser.
tier-browser-unused = Walang ginagamit na independiyenteng layer ng browser ang patakarang ito.
tier-browser-checking = Sinusuri ang layer ng browser.
# Instead of the pending text: `tier-pending-successors` (any tier) when every
# check of the tier passed but the check for a newer trust policy hasn't run
# yet; in a private event, `tier-hubs-pending-attestation` when the anchor hubs
# wait for an auditor, and `tier-browser-pending-hubs` when the browser layer
# waits for the anchor hubs.
tier-pending-successors = Tama ang mga patunay nito. Ipapakita itong napatunayan kapag nasuri na kung napalitan ng mas bagong patakaran ang patakaran ng tiwala.
tier-hubs-pending-attestation = Naiangkla na. Kailangan pang kumpirmahin ng isang auditor ang mga selyadong angkla. Maaaring matagalan ito, at hindi ito kailanman ituturing na naantala.
tier-browser-pending-hubs = Hinihintay ang mga angklang hub: sa isang pribadong kaganapan, binibilang lamang ang layer ng browser kapag napatunayan na ang mga ito.
tier-test = Pagsubok lamang: pinapatakbo ng tagapamahala ng talaan, kaya hindi ito binibilang.
tier-deadline = Inaasahan pagsapit ng { TIME($deadline) }
hub-test = pagsubok

## Stages of a ballot in the log (specs/entry.md, section 4.1): a tag next to the status

stage-received = Hindi pa naiboto
stage-cast = Naiboto
stage-audited = Na-audit

## The one-line status

status-verified = Napatunayan
status-checking = Sinusuri…
status-pending = Nakabinbin
status-late = Naantala
status-invalid = Hindi masuri
status-failed = Hindi pumasa
status-summary-verified = Kasama sa talaan, hindi nagbago, at pareho para sa lahat.
status-summary-checking = Sinusuri ang mga patunay ng resibo sa browser na ito.
status-summary-pending = Parating pa ang ilang patunay. Hindi ninyo kailangang maghintay.
status-summary-pending-successors = Tama ang mga patunay. Ipapakita ang resibo bilang napatunayan kapag nasuri na kung napalitan ng mas bagong patakaran ang patakaran ng tiwala.
status-summary-pending-attestation = Naiangkla na. Kailangan pang kumpirmahin ng isang auditor ang mga selyadong angkla. Hindi ninyo kailangang maghintay.
status-summary-late = Dapat ay dumating na ang ilang patunay.
status-summary-invalid = Hindi masuri ang ilang datos: mukhang sira ang file o ang sagot ng server. Hindi nito ipinapakita na may nandaya.
status-summary-failed = Magkasalungat ang mga nilagdaang patunay. Pakitabi ang ebidensya.

## <vitrine-receipt>

receipt-label = Resibo
receipt-entry = Tala { $index } sa { $log }
receipt-entry-promised = Ipinangakong tala sa { $log }
receipt-provenance-page = Sinuri ng website na ito
receipt-provenance-page-hint = Sinuri ng website na ito ang sarili nitong talaan. Para makatiyak, suriin ito nang independiyente.
receipt-provenance-independent = Sinuri nang independiyente sa website
receipt-facts-heading = Ang ipinapakita ng mga patunay
receipt-chain-heading = Gaano na kalayo ang narating nito
receipt-compare-heading = Ihambing sa opisyal na abiso
receipt-compare-hint = Dapat tumugma ang ID ng patakaran at mga saksing ito sa mga inilathala ng awtoridad, halimbawa sa abiso ng halalan.
receipt-policy-in-force = Patakarang may bisa ngayon
receipt-policy-in-force-hint = Pinalitan nito ang naunang patakaran, ayon sa pinapayagan ng mga tuntunin ng patakarang iyon. Dapat tumugma ang ID nito sa mas bagong abiso ng awtoridad.
receipt-policy-id = ID ng patakaran
receipt-event = Kaganapan
receipt-witnesses = Mga saksi
receipt-witness-party = pinapatakbo ng { $party }
receipt-hubs = Mga angklang hub
receipt-clock-warning = Mahigit isang minuto ang agwat ng orasan ng device na ito sa pinakabagong oras na nilagdaan ng mga saksi. Ang nilagdaang oras ang batayan ng mga takdang oras, hindi ang orasang ito.
receipt-action-check = Suriin nang independiyente
receipt-action-download = I-download ang resibo
receipt-action-retry = Suriin muli
receipt-invalid = Hindi masuri ang ilang datos: mukhang sira ang file o ang sagot ng server. Hindi nito ipinapakita na may nandaya. Maaari ninyong suriin muli, o suriin nang independiyente.
receipt-no-expect = Hindi sinabi ng pahinang ito kung aling tala ang aasahan, kaya hindi maipapakitang sa inyo ang resibong ito.
receipt-error = Hindi masuri ang resibong ito.
receipt-empty = Wala pang resibo.
receipt-announce = { $tier }: { $status }.

## <vitrine-receipt>, the receipt card (the voter board). Its five steps are
## sealed on this device, then the four tiers. `$noun` is the profile's name for
## one entry ("ballot" in the election profile), or `receipt-noun`.

receipt-noun = tala
receipt-fingerprint-label = Fingerprint ng { $noun }

receipt-seal-checking = Sinusuri
receipt-seal-sealed = Selyado
receipt-seal-record-public = Kasama sa pampublikong talaan
receipt-seal-record-private = Kasama sa pribadong talaan
receipt-seal-witnesses = Kinumpirma ng mga independiyenteng saksi
receipt-seal-hubs = { $hubs }. Malapit nang dumating ang angkla sa layer ng browser
receipt-seal-browser = Nakaangkla kung saan sumusuri ang mga browser

receipt-step-sealed = Selyado sa device na ito
receipt-step-sealed-done = Selyado bago ito umalis sa inyong browser.
receipt-step-sealed-wait = Ginagawa ang pagselyo sa inyong browser…
receipt-step-record-public = Idinagdag sa pampublikong talaan
receipt-step-record-private = Idinagdag sa pribadong talaan
receipt-step-record-done = Tala #{ $index }. Sinuri ito ng inyong browser.
receipt-step-record-wait = Hinihintay na isama ito ng talaan…
receipt-step-record-promised = Lumagda ang talaan sa pangakong isasama ito.
receipt-step-witnesses = Kinumpirma ng mga saksi
receipt-step-witnesses-done = Nilagdaan ng { $signed } sa { $total } na independiyenteng saksi.
receipt-step-witnesses-done-any = Nilagdaan ng mga independiyenteng saksi.
receipt-step-witnesses-wait = Hinihintay ang mga lagda ng mga saksi…
receipt-step-hubs-public = Naiangkla sa { $count } pampublikong hub
receipt-step-hubs-private = Naiangkla sa { $count } hub, selyado
receipt-step-hubs-none = Mga angklang hub
receipt-step-hubs-done-public = Hawak din ng mga nakabahaging talaan ang talaang ito.
receipt-step-hubs-done-private = Walang nabubunyag tungkol sa laman nito.
receipt-step-hubs-wait = Sa loob ng ilang segundo…
receipt-step-hubs-partial = Sa ngayon, hawak ng { $agree } sa { $total } na hub ang talaan…
receipt-step-browser = Nakaangkla kung saan sumusuri ang mga browser
receipt-step-browser-done = Sa iisang talaan kung nasaan ang code ng website na ito.
receipt-step-browser-done-bootstrap = Hawak ng pansamantalang hub hanggang ang mga browser na mismo ang sumuri sa mga talaan.
receipt-step-browser-wait = Sa loob ng ilang minuto. Hindi ninyo kailangang maghintay.
receipt-step-browser-wait-minutes = Sa loob ng { $minutes } minuto. Hindi ninyo kailangang maghintay.
receipt-step-late = Mas matagal ito kaysa sa dapat.
receipt-step-invalid = Hindi masuri: mukhang sira ang datos.
receipt-step-failed = Salungat sa nilagdaang talaan.
receipt-step-unused = Hindi ginagamit ng patakaran ng kaganapang ito.
receipt-step-state-done = Tapos na
receipt-step-state-active = Isinasagawa
receipt-step-state-scheduled = Nakaiskedyul
receipt-step-state-waiting = Naghihintay

receipt-caption-checking-public = Sinusuri ng inyong browser ang pampublikong talaan…
receipt-caption-checking-private = Sinusuri ng inyong browser ang pribadong talaan…
receipt-caption-public = Napatunayan ng inyong browser, gamit ang code na masusuri ng sinuman.
receipt-caption-private = Pribadong talaan. Masusuri ng mga akreditadong auditor ang lahat ng laman nito.
receipt-caption-late = May ilang hakbang na mas matagal kaysa sa dapat.
receipt-caption-invalid = Hindi masuri ang ilang datos. Mukhang sira ang mga ito.
receipt-caption-failed = May nakitang problema ang inyong browser sa talaan.

receipt-check-elsewhere = Suriin ito sa ibang device
receipt-action-save = I-save ang resibo

## <vitrine-receipt variant="summary">, the re-check on a later visit (the
## revisit board).

receipt-summary-label = Pagsusuri sa resibo
receipt-summary-title-public = Nasa pampublikong talaan pa rin ang inyong tala
receipt-summary-title-private = Nasa pribadong talaan pa rin ang inyong tala
receipt-summary-title-checking = Sinusuri ang inyong tala sa talaan…
receipt-summary-title-late = Naantala ang ilang patunay para sa inyong tala
receipt-summary-title-invalid = Hindi masuri ang inyong tala
receipt-summary-title-failed = Hindi namin makumpirma ang inyong tala sa talaan
receipt-summary-checked-now = Katatapos lang suriin ng inyong browser.
receipt-summary-checked-at = Sinuri ng inyong browser noong { TIME($time) }.
receipt-summary-unchanged = Walang nagbago sa anumang naitala bago nito.
receipt-summary-witnesses = Mga saksi
receipt-summary-hubs-public = Mga pampublikong hub
receipt-summary-hubs-private = Mga hub
receipt-summary-browser = Kung saan sumusuri ang mga browser
receipt-summary-agree = Sang-ayon ang { $agree } sa { $total }
receipt-summary-agree-any = Sang-ayon
receipt-summary-anchored = Naiangkla noong { DATE($time) }
receipt-summary-anchored-plain = Naiangkla
receipt-summary-waiting = Naghihintay
receipt-summary-due = Malapit nang dumating
receipt-summary-unused = Hindi ginagamit
receipt-view = Tingnan ang resibo

## <vitrine-how-we-check>

how-label = Paano gumagana ang pagsusuri
how-heading = Paano kami sumusuri
how-receipt = Nag-iingat ang inyong browser ng nilagdaang resibo. May fingerprint ito ng isinumite ninyo, hindi kailanman ang nilalaman.
how-grew = Sa bawat pagbisita, humihingi ito sa talaan ng maikling patunay na nadagdagan lamang ito.
how-witnesses = Nilalagdaan ito ng mga independiyenteng saksi, at inaangkla ito ng mga pampublikong hub kung saan sumusuri ang mga browser, kaya iisang talaan ang nakikita ng lahat.

## <vitrine-proof-steps>

steps-heading = Lahat ng pagsusuri
steps-summary = { $passed } sa { $total } na pagsusuri ang pumasa
steps-result-passed = Pumasa
steps-result-failed = Hindi pumasa
steps-result-not-run = Hindi pa naisasagawa
steps-show-details = Ipakita ang detalye
steps-hide-details = Itago ang detalye
steps-objects = Mga nilagdaang bagay na kasangkot: { $objects }
steps-evidence = I-save ang ebidensya
steps-empty = Wala pang pagsusuri.

## <vitrine-chain>

chain-label = Kadena ng resibo

## <vitrine-alert>

alert-label = Napatunayang problema
alert-kind-split-view-title = Hindi pare-pareho ang talaang ipinakita sa iba't ibang tao
alert-kind-split-view-body = Hindi maaaring parehong totoo ang dalawang bersyon ng talaan na kapwa nilagdaan ng tagapamahala nito. Maaaring aberya ito o pag-atake. Posibleng mabilang pa rin ang inyong tala, ngunit dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-broken-promise-title = Hindi tinupad ng talaan ang isang nilagdaang pangako
alert-kind-broken-promise-body = Nangako ang talaan na isasama nito ang isang tala sa loob ng takdang oras, at ipinapakita ng sarili nitong mga lagda na hindi ito natupad. Dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-bad-entry-title = May tala sa talaan na lumalabag sa mga tuntunin nito
alert-kind-bad-entry-body = Lumalabag sa isang tuntunin ng profile ng talaan ang isang talang nilagdaan dito. Dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-hub-entry-title = Tumanggap ang isang angklang hub ng talang dapat sana ay tinanggihan nito
alert-kind-hub-entry-body = Nilagdaan ng mga saksi ng isang angklang hub ang isang talaan ng hub na may talang lumalabag sa mga tuntunin ng hub, kaya hindi bababa sa isa sa kanila ang lumagda nang hindi muna nagsusuri.
alert-kind-time-regression-title = Lumagda ang talaan sa isang hindi totoong oras
alert-kind-time-regression-body = Lumagda ang talaan sa dalawang bersyon nito, at ang mas malaki ang may mas maagang oras. Hindi kailanman umaatras ang nilagdaang oras ng isang talaan, kaya hindi totoo ang isa sa dalawa. Dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-policy-equivocation-title = Lumagda ang mga awtoridad ng patakaran ng tiwala sa dalawang magkaibang kapalit
alert-kind-policy-equivocation-body = Sapat na awtoridad ng patakaran ng tiwala ang lumagda sa dalawang magkaibang kapalit nito, at kapwa naitala ang dalawa. Ang unang naitala ang binibilang, ngunit maaaring magpakita ang ikalawa ng magkakaibang patakaran sa iba't ibang tao. Dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-bad-checkpoint-title = Lumagda ang isang talaan sa isang imposibleng bersyon nito
alert-kind-bad-checkpoint-body = Lumagda ito sa isang bersyong walang anumang tala, ngunit hindi blangko. Walang tapat na talaan o angklang hub na makagagawa nito. Dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-unlogged-code-title = Naghatid ang isang site ng code na wala sa talaan nito ng mga bersyon
alert-kind-unlogged-code-body = Naglilista ang manifest ng site sa pampublikong talaan ng isang script, at walang naitalang bersyon ng app na may ganoong script. Ang code na inihahatid ng site ay hindi ang code na inilathala para masuri.
alert-kind-unknown-title = May natagpuang problema
alert-kind-unknown-body = Nagpapakita ang ebidensya ng isang uri ng problemang hindi kilala ng pahinang ito: { $kind }.
alert-not-proven-title = Hindi nagpapatunay ng problema ang file na ito
alert-not-proven-body = Nasuri ang file, at hindi ito nagpapatunay ng problema. Hindi ito ebidensya.
alert-unpinned-title = Ang file na ito ay para sa patakarang hindi pa naka-pin sa device na ito
alert-unpinned-body = Hindi ito maipapakita bilang patunay sa device na ito. Ihambing ang ID ng patakaran ng file sa opisyal na abiso, at i-pin ang patakarang iyon bago muling suriin ang file.
alert-invalid-title = Hindi masuri ang file na ito
alert-invalid-body = Mukhang sira ang file. Hindi nito ipinapakita na may nandaya.
alert-proven-under = Napatunayan ayon sa patakarang may ganitong ID:
alert-file-policy-id = ID ng patakaran ng file:
alert-parties = May pananagutan, ayon sa sarili nilang mga lagda: { $parties }
alert-evidence-heading = Ebidensyang nakatabi sa device na ito
alert-evidence-hint = Sinusuri ng mga tagamasid ang ebidensyang ito sa sarili nilang mga computer. Pinatutunayan nito ang nilagdaan ng talaan, at wala itong laman tungkol sa isinumite ninyo.
alert-download = I-download ang file ng ebidensya
alert-send = Ipadala ang ebidensya sa mga tagamasid
alert-monitors-heading = Mga tagamasid na itinakda ng patakaran
alert-confirm-heading = Ipadala ang ebidensya?
alert-confirm-body = Kapag ipinadala, makikita ng { $count } tagamasid ang file ng ebidensya, pati na ang pagkakapadala nito mula sa device na ito.
alert-confirm-send = Oo, ipadala
alert-confirm-cancel = Kanselahin
alert-sending = Ipinapadala na ang ebidensya sa mga tagamasid.
alert-no-monitors = Walang itinakdang tagasubaybay ang patakaran. Pakitabi ang file at ibigay ito sa isang tagamasid.
alert-delivery-waiting = Hinihintay ang kumpirmasyon
alert-delivery-sending = Ipinapadala
alert-delivery-confirmed = Nakumpirma
alert-delivery-failed = Hindi nakumpirma

## <vitrine-alert>, the alert board: the evidence kept on this device, as the
## signed items the file holds.

alert-yours-title = Hindi namin makumpirma ang inyong tala sa talaan
alert-yours-split-view-body = Hindi tugma ang talaang ipinakita sa inyong browser sa nilagdaan ng mga independiyenteng saksi. Maaaring aberya ito o pag-atake. Posibleng mabilang pa rin ang inyong tala, ngunit dapat itong tingnan ng isang independiyenteng tagasuri.
alert-evidence-count = { $count } nilagdaang bagay
alert-item-receipt = Inyong resibo para sa tala #{ $index }
alert-item-receipt-detail = Nilagdaan ng talaan nang idagdag ito
alert-item-receipt-other = Resibo para sa tala #{ $index }
alert-item-checkpoint = Nilagdaang talaan, laki { $size }
alert-item-checkpoint-shown = Talaang ipinakita sa inyo, laki { $size }
alert-item-checkpoint-shown-detail = Naglalaman ng inyong tala
alert-item-checkpoint-witnessed = Talaang nilagdaan ng mga saksi, laki { $size }
alert-item-witnessed-detail = Nilagdaan ng { $count } saksi
alert-item-hubs-detail = Naiangkla sa { $hubs } pampublikong hub
alert-item-promise = Nilagdaang pangako na isasama ang isang tala
alert-item-policy = Nilagdaang patakaran ng tiwala
alert-item-policy-ack = Nilagdaang pagkilala sa patakaran ng tiwala
alert-item-why-split-view = Hindi maaaring lumaki mula sa talaan (laki { $size })
alert-item-why-time-regression = Mas maaga ang nilagdaang oras nito kaysa sa oras ng mas maliit na talaan
alert-item-why-bad-checkpoint = Walang anumang tala, ngunit hindi blangko
alert-what-next = Ano ang susunod na mangyayari?
alert-what-next-body = Binabasa ng mga independiyenteng tagamasid ang ebidensya sa sarili nilang mga computer. Walang ipinapadala maliban kung piliin ninyong ipadala ito. Maaari rin ninyong itabi ang file at ibigay ito sa taong pinagkakatiwalaan ninyo: pinatutunayan nito ang nilagdaan ng talaan saanman ito suriin.

## <vitrine-badge>

badge-check = Suriin nang independiyente
badge-opens = nagbubukas ng independiyenteng pansuri

## Monitor reports (specs/evidence.md, section 3). `report-kind-<kind>` says
## what a report is about, with `$subject`, the record or hub it names. A
## report is its monitor's own statement, not proof: show `report-established`
## only when monitors of enough different parties report the same thing.

report-kind-cosign-late = Matagal nang walang bagong bersyon ang { $subject } na nilagdaan ng sapat na saksi nito.
report-kind-anchor-late = Hindi naiangkla sa takdang oras ang { $subject }: naantala ang talaan o ang angklang hub, at hindi masabi ng ulat kung alin.
report-kind-unreachable = Tumigil sa pagsagot ang isang server ng { $subject }.
report-kind-mirror-behind = Nahuhuli na ang kopya ng { $subject } na hawak ng isang mirror.
report-kind-payload-missing = Hindi makuha ang ilang datos na nakatala sa { $subject }, at walang abisong nagsasabing sinadya itong hindi ilabas.
report-kind-payload-mismatch = Hindi tugma ang ilang datos na inihahatid ng { $subject } sa itinala nito.
report-kind-rule-failing = Lumalabag ang isang tala sa { $subject } sa isang tuntunin ng profile nito. Naglathala ang tagasubaybay ng ebidensyang masusuri ng sinuman.
report-kind-promise-pending = Lumagda ang { $subject } sa pangakong isasama ang isang tala, at hindi pa nito ito naisasama.
report-kind-promise-unlisted = Hindi isinama ng { $subject } sa listahan nito ang isang batch ng mga nilagdaan nitong pangako.
report-kind-promise-late = Hindi natupad ng { $subject } sa takdang oras ang isang nilagdaang pangako: naantala ang talaan o ang mga saksi nito, o mali ang oras ng kanilang mga orasan.
report-kind-promise-misdated = Mali ang petsang ibinigay ng { $subject } sa isang batch ng mga nilagdaan nitong pangako: hindi tugma ang oras nito sa oras kung kailan ito inilista, o sa oras kung kailan ito unang nakita ng tagasubaybay.
report-kind-opening-missing = Hindi binuksan ng { $subject } sa auditor ang isang selyadong angkla sa takdang oras.
report-kind-ack-missing = Hindi inihahatid ng { $subject } ang nilagdaan nitong pahayag na sinusunod nito ang patakaran ng tiwala na may bisa.
report-kind-config-mismatch = Ipinakita sa isang booth ng pagboto ang mga setting ng halalan na hindi itinala ng { $subject }, o iba sa mga itinala.
report-kind-code-mismatch = Naghatid ang isang website ng script na wala sa alinmang release na nakatala sa { $subject }.
report-kind-unknown = Ulat ng tagasubaybay na “{ $kind }” tungkol sa { $subject }
report-established = Kumpirmado: iniuulat ito ng mga tagasubaybay mula sa sapat na bilang ng magkakaibang partido.
report-statement = Iniulat ng { $monitor }. Sariling pahayag ng tagasubaybay ang isang ulat, hindi patunay tungkol sa iba.

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = Maayos ang anyo ng file ng resibo
step-policy-pinned = Para sa naka-pin na patakaran ng tiwala ang resibo
step-policy-successors = Nasuri kung may mas bagong patakaran ng tiwala na pumalit sa naka-pin
step-policy-ack = Lumagda ang talaan na sinusunod nito ang patakaran ng tiwala
step-log-known = Nasa patakaran ang talaan ng resibo
step-entry-parse = Maayos ang anyo ng tala
step-entry-profile = Tugma ang tala sa uri ng talaan at sa mga field ng uring iyon
step-entry-expectation = Tugma ang tala sa inaasahan ninyo
step-promise-signature = Lumagda ang talaan sa pangakong isasama ang tala
step-promise-inclusion = Saklaw ng nilagdaang pangako ang tala
step-promise-leaf = Para sa talang inaasahan ninyo ang pangako
step-promise-kept = Tinupad ng talaan ang pangako nito sa takdang oras
step-issued-signature = Nilagdaan ng talaan ang resibong ibinigay sa pagsusumite
step-issued-inclusion = Nasa resibong ibinigay sa pagsusumite ang tala
step-record-signature = Nilagdaan ng talaan ang sarili nitong resibo
step-record-inclusion = Nasa talaan ang tala
step-receipts-match = Para sa iisang tala sa iisang posisyon ang mga resibo
step-record-consistency = Nadagdagan lamang ang talaan mula nang ibigay ang resibo sa pagsusumite
step-record-quorum = Sapat na independiyenteng saksi ang lumagda sa talaan
step-log-consistent = Hindi nagsasalungatan ang mga bersyon ng talaang nakita rito
step-hub-link = Pumapasa sa pagsusuri ang patunay ng hub { $hub }
step-hub-opening = Nabubuksan ang selyadong angkla sa hub { $hub } at tugma ito sa talaan
step-hub-anchored-checkpoint = Nilagdaan ng talaan at ng mga saksi nito ang talaang nakaangkla sa hub { $hub }
step-hub-previous-anchor = Hawak ng hub { $hub } ang naunang selyadong angkla, at kapag binuksan ay tugma ito sa talaan
step-hub-opening-consistency = Nadagdagan lamang ang talaan sa pagitan ng huling dalawang selyadong angkla nito sa hub { $hub }
step-hub-attestation = Kinumpirma ng isang auditor ang selyadong angkla sa hub { $hub }
step-hub-anchor-consistency = Nadagdagan lamang ang talaan hanggang sa angkla nito sa hub { $hub }
step-browser-link = Pumapasa sa pagsusuri ang patunay ng hub { $hub } para sa layer ng browser, at saklaw nito ang tala
step-browser-link-consistency = Nadagdagan lamang ang talaan sa pagitan ng inyong resibo at ng patunay ng hub { $hub } para sa layer ng browser
step-browser-anchor = Hawak ng layer ng browser ang talaan ng hub { $hub }
step-browser-consistency = Nadagdagan lamang ang hub { $hub } hanggang sa bersyon nitong nakaangkla kung saan sumusuri ang mga browser
step-bootstrap-link = Nakaangkla ang hub { $hub } sa isang panimulang hub
step-unknown = Pagsusuring “{ $code }”

## Reasons, why a check failed or is still waiting (`reason-<code>`). Their
## variables are the verifier's `params`. A message uses only those that the
## verifier always passes for its code: the tier, hub or step it belongs to is
## shown next to it anyway.

# Encodings and limits
reason-bad-base64 = Mali ang anyo ng isang base64 na halaga.
reason-bad-hex = Mali ang anyo ng isang hex na halaga.
reason-bad-text = May tekstong hindi wasto o may ipinagbabawal na karakter.
reason-bad-number = Mali ang anyo ng isang numero, o lampas ito sa saklaw.
reason-trailing-data = May hindi inaasahang datos pagkatapos ng isang bahagi ng file.
reason-truncated = Masyadong maagang nagtatapos ang isang bahagi ng file.
reason-too-large = May bahaging mas malaki kaysa sa pinapayagan ng mga limitasyon.

# Signed notes and keys
reason-bad-note = Mali ang anyo ng isang nilagdaang pahayag.
reason-bad-key-name = Mali ang anyo ng pangalan ng isang susi.
reason-bad-vkey = Mali ang anyo o ang uri ng isang pampublikong susi.
reason-bad-public-key = Hindi wasto ang isang pampublikong susi.
reason-missing-signature = Nawawala ang isang lagdang dapat ay naroon.

# Checkpoints and witness signatures
reason-bad-checkpoint = Mali ang anyo ng isang checkpoint.
reason-bad-empty-tree = Imposible ang isang nilagdaang bersyon ng talaan: wala itong anumang tala, ngunit hindi blangko ang laman nito.
reason-wrong-origin = Ibang talaan o hub ang binabanggit ng isang nilagdaang pahayag kaysa sa inaasahan.
reason-log-time-missing = Walang nilagdaang oras ng talaan ang isang resibo, kaya hindi ito masuri.
reason-cosignature-in-future = May petsa sa hinaharap ang isang lagda ng saksi, kaya hindi ito isinaalang-alang.
reason-quorum-not-met = Hindi pa sapat ang bilang ng lumagdang independiyenteng saksi.

# Proofs
reason-bad-proof = Mali ang anyo ng isang patunay.
reason-missing-extra = Wala sa isang resibo ang tala.
reason-index-out-of-range = Lampas sa dulo ng talaan ang posisyon ng tala.
reason-inclusion-failed = Hindi pumasa sa pagsusuri ang patunay na nasa talaan ang tala.
reason-consistency-failed = Hindi pumasa sa pagsusuri ang patunay na nadagdagan lamang ang talaan.
reason-split-view = Magkapareho ang laki ng dalawang nilagdaang bersyon ng talaan, ngunit magkaiba ang laman ng mga ito.

# Entries and expectations
reason-bad-entry = Mali ang anyo ng tala.
reason-wrong-profile = Iba ang uri ng tala sa uri ng talaan sa posisyong iyon.
reason-bad-entry-layout = Hindi tugma ang mga field ng tala sa uri nito.
reason-entry-mismatch = Hindi tugma ang tala sa inaasahan ninyo.
reason-expectation-incomplete = Hindi sapat ang sinabi ng pahina tungkol sa tala para masuri ito.
reason-expectation-unknown-field = Nagbanggit ang pahina ng field na wala sa ganitong uri ng tala.
reason-expectation-unsupported = Hindi kayang suriin ng pansuring ito ang mga field ng ganitong uri ng tala.
reason-receipts-disagree = Para sa magkakaibang tala o posisyon ang mga resibo sa file.

# Promises
reason-bad-promise = Mali ang anyo ng pangako.
reason-promise-policy-unknown = Binabanggit ng pangako ang isang patakaran ng tiwala na hindi ang naka-pin at hindi rin ang pumalit dito.
reason-promise-mmd-too-large = Mas mahabang pagkaantala ang pinapayagan ng pangako kaysa sa pinahihintulutan ng patakaran.
reason-promise-leaf-mismatch = Para sa ibang tala ang pangako.
reason-promise-time = Higit sa isang minuto ang layo ng petsang inilagay ng talaan sa pangako nito mula sa oras na dumating ito, kaya hindi ito binibilang bilang pangako.
reason-promise-pending = Nangako ang talaan na isasama ang tala. Hindi pa sumasapit ang takdang oras ng resibo nito.
reason-promise-deadline-passed = Lumampas na ang takdang oras ng pangako, at wala pang resibo.
reason-promise-kept-unproven = Walang anuman sa file na nagpapakitang natupad ang pangako sa takdang oras.
reason-broken-promise = Nangako ang talaan na isasama ang tala bago ang takdang oras ({ TIME($deadline) }), ngunit ipinapakita ng sarili nitong nilagdaang oras ({ TIME($logTime) }) na hindi pa rin nito iyon nagagawa noon.
reason-bad-promise-list = Mali ang anyo ng listahan ng mga pangakong ginawa ng talaan sa loob ng isang oras, o hindi ito tugma sa mga pangakong iyon, kaya hindi ito masuri.

# Receipt chains
reason-malformed-chain = Mali ang anyo ng file ng resibo.
reason-duplicate-block = Dalawang beses na nasa file ng resibo ang iisang bahagi.
reason-no-receipt = Walang pangako at walang resibo sa file.
reason-policy-mismatch = Ibang patakaran ng tiwala ang binabanggit ng resibo kaysa sa naka-pin.
reason-policy-draft = Borador pa lamang ang patakaran ng tiwala, at hindi kailanman wasto ang isang borador.
reason-bad-policy-ack = Mali ang anyo ng nilagdaang pahayag ng talaan na sinusunod nito ang patakarang ito ng tiwala, o hindi ito tugma rito.
reason-unknown-log = Binabanggit ng resibo ang isang talaang wala sa patakaran.
reason-unknown-hub = Binabanggit ng isang bahagi ang isang angklang hub na wala sa patakaran, kaya hindi ito isinaalang-alang.
reason-consistency-missing = Nawawala ang isang patunay na nadagdagan lamang ang talaan.
reason-consistency-mismatch = Hindi tugma ang isang patunay na nadagdagan lamang ang talaan sa mga bersyong pinag-uugnay nito.
reason-waiting-for-cosignatures = Hinihintay na lumagda ang mga saksi sa talaan.
reason-waiting-for-record = Hinihintay ang talaang nilagdaan ng mga saksi.
reason-no-signed-time = Wala pang nilagdaang oras, kaya hindi pa matitiyak kung lumampas na ang mga takdang oras.
reason-deadline-passed = Lumampas na ang takdang oras, ayon sa nilagdaang oras.
reason-record-invalid = Hindi ito masuri, dahil hindi masuri ang mga patunay ng talaan.
reason-bad-reference = Mali ang anyo ng isang link sa resibo.
reason-reference-unpinned = Walang patakaran ng tiwala na naka-pin sa device na ito na tugma sa link na ito ng resibo.
reason-reference-ambiguous = Tugma ang link na ito ng resibo sa higit sa isang patakaran ng tiwala na naka-pin sa device na ito, kaya hindi ito ginamit.

# The booth's configuration check
reason-bad-config = Mali ang anyo ng mga setting ng halalan o ng abisong nagbukas na ang botohan, hindi ito nilagdaan, o hindi ito nilagdaan ng sapat na saksi, kaya hindi gagamitin ng booth ng pagboto ang mga ito para i-encrypt ang isang balota.
reason-config-mismatch = Hindi tugma ang nakatalang mga setting ng halalan sa kaganapan, halalan, susi ng halalan, mga istilo ng balota, patakaran ng tiwala, o software ng booth ng pagboto, o hindi ito ang may bisa nang magbukas ang botohan, kaya hindi mag-e-encrypt ng balota ang booth.

# Keys logs
reason-bad-key-statement = Mali ang anyo ng isang pahayag sa talaan ng mga susi, ibang talaan ang binabanggit nito, hindi ito tugma sa tala nito, o kulang ito ng mga lagdang kailangan nito, kaya hindi ito binibilang.
reason-signed-by-failed = Hindi nilagdaan ng susi nito ang isang pahayag, binawi na o hindi wasto ang susi nang itala ang tala, o masyadong kaunti ang ibang wastong susi na lumagda rin dito.
    .not-ed25519 = Mali ang anyo o ang uri ng pahayag, o ng susing dapat sanang lumagda rito.
    .not-signed = Hindi nilagdaan ng susi nito ang pahayag.
    .revoked = Binawi na ang susing lumagda sa pahayag bago pa itala ang tala.
    .not-valid = Hindi wasto ang susing lumagda sa pahayag nang itala ang tala.
    .cosigners = Masyadong kaunti ang ibang wastong susi na lumagda rin sa pahayag: { $have } sa { $need } na kailangan.

# Upgrades
reason-log-quiet = Nasa tahimik na panahon ang talaan at walang ipinapakitang mas bago hanggang matapos ito, kaya maghihintay hanggang doon ang ilang patunay.
reason-log-private = Pribado ang talaan: mga auditor lamang ang makababasa nito, kaya dumarating ang mga patunay nito sa pamamagitan ng website ng kaganapan.
reason-monitor-evidence = Naglathala ang tagasubaybay na { $monitor } ng ebidensyang sumasalungat ang bersyong ito ng talaan sa bersyong hawak nito. Hindi pa nasusuri rito ang ebidensyang iyon.

# Successor policies
reason-successors-unchecked = Hindi pa nasusuri kung may mas bagong patakaran ng tiwala na pumalit dito, kaya walang ipinapakitang napatunayan.
reason-bad-policy-proofs = Mali ang anyo ng mga patunay tungkol sa mas bagong patakaran ng tiwala, o hindi pumasa ang mga ito sa pagsusuri.
reason-successor-rejected = May inilathalang mas bagong patakaran ng tiwala, ngunit lumalabag ito sa mga tuntunin sa pagpapalit ng patakaran, kaya nananatiling may bisa ang nauna.
reason-policy-equivocation = Lumagda ang mga awtoridad ng patakaran ng tiwala sa dalawang magkaibang kapalit nito, na nagpapatunay na sinalungat nila ang kanilang sarili. Ang unang nailathala ang binibilang.

# Anchor hubs
reason-bad-subject = Mali ang anyo ng pangalan o susi na ginagamit ng isang angklang hub sa pag-iingat ng mga angkla ng isang talaan, kaya hindi ito binibilang.
reason-waiting-for-anchor = Hinihintay na iangkla ng angklang hub ang talaan.
reason-hub-quorum-not-met = Hindi pa sapat ang bilang ng lumagdang saksi ng angklang hub.
reason-bad-hub-link = Mali ang anyo ng patunay ng angklang hub, o hindi ito pumasa sa pagsusuri.
reason-hub-link-mismatch = Tungkol sa ibang bagay ang patunay ng angklang hub.
reason-hub-index-wrong = Lumagda ang mga saksi ng hub { $hub } sa isang index na tumuturo sa maling tala para sa talaang ito, kaya lumagda sila nang hindi sumusuri.
reason-map-proof-failed = Hindi pumasa sa pagsusuri ang patunay ng mapa ng angklang hub.
reason-subject-rotated = Nagbago ang susi ng talaan sa angklang hub na ito. Kailangan ang mas bagong patakaran ng tiwala.
reason-rotation-unauthorized = Sa hub { $hub }, pinalitan ang susi ng talaan ng isang talang hindi pinapayagan ng anumang kilalang patakaran ng tiwala.
reason-anchor-behind-record = Mas lumang bersyon ng talaan ang hawak ng angklang hub kaysa sa nasa inyong resibo.
reason-anchor-quorum-not-met = Hindi sapat ang mga lagda ng saksi sa nakaangklang talaan.
reason-hub-link-stale = Mas luma nang husto ang patunay ng talaan mula sa hub { $hub } kaysa sa pinakabagong bersyon ng hub: dapat ay may mas bago na ang talaan ngayon.
reason-bad-blinded-anchor = Hindi pumasa sa pagsusuri ang isang selyadong angkla.
reason-opening-missing = Wala pa sa file ang pambukas ng selyadong angkla.
reason-bad-opening = Hindi tugma sa selyadong angkla ang dapat sanang pambukas nito.
reason-previous-anchor-missing = Wala pa sa file ang naunang selyadong angkla sa hub { $hub }, o ang pambukas nito.
reason-bad-previous-anchor = Hindi ang naunang selyadong angkla ang angkla ng talaan na nauna mismo sa isang ito, kaya hindi ito masuri.
reason-attestation-missing = Wala pang auditor na nagkumpirma sa selyadong angkla sa hub { $hub }. Mananatili itong nakabinbin hanggang may magkumpirma, at hindi kailanman ituturing na naantala.
reason-attestation-not-covering = Saklaw ng kumpirmasyon ng auditor para sa hub { $hub } ang mga selyadong angkla mula { $from } hanggang { $to }, at hindi pa ang numero { $seq }.
reason-bad-attestation = Hindi masuri ang kumpirmasyon ng isang auditor: mali ang anyo nito, hindi ito nilagdaan ng isang auditor ng patakaran ng tiwala, o hindi ito tugma sa selyadong angkla.
reason-hub-entry-refused = Nagtala ang isang angklang hub ng talang lumalabag sa mga tuntunin ng hub, kaya hindi binibilang ang talang iyon.

# Browser layer
reason-browser-test-only = Pagsubok lamang dito ang layer ng browser: pinapatakbo ito ng tagapamahala ng talaan.
reason-waiting-for-browser-anchor = Hinihintay ang layer ng browser. Inaasahan ito sa loob ng ilang minuto.
reason-pair-not-covering = Mas nauna sa tala ang pinakabagong patunay ng talaan para sa layer ng browser, mula sa hub { $hub }. Sasaklawin ito ng susunod.
reason-browser-below-link = Mas lumang bersyon ng hub { $hub } ang ipinapakita ng layer ng browser kaysa sa patunay na kapares nito, kaya hindi magkatugma ang dalawa.
reason-waiting-for-hub-tier = Hinihintay ang hub { $hub }: sa isang pribadong kaganapan, binibilang lamang ang layer ng browser kapag napatunayan na ang hub.
reason-bad-browser-pair = Mali ang anyo ng mga patunay ng talaan para sa layer ng browser.
reason-bad-browser-anchor = Mali ang anyo ng isang angkla sa layer ng browser, o hindi ito tugma.
reason-bad-waict-proof = Hindi pumasa sa pagsusuri ang patunay ng layer ng browser.
reason-waict-quorum-not-met = Hindi sapat ang bilang ng lumagdang saksi ng layer ng browser.
reason-unknown-waict-service = Nagmula sa isang serbisyong hindi nakalista sa patakaran ang angkla sa layer ng browser.
reason-waict-service-not-independent = Pinapatakbo ng tagapamahala ng talaan ang layer ng browser, kaya hindi ito binibilang.
reason-bad-bootstrap-link = Mali ang anyo ng patunay ng isang panimulang hub, o hindi ito pumasa sa pagsusuri.

# Trust policies
reason-policy-syntax = Mali ang anyo ng isang linya ng patakaran ng tiwala.
reason-policy-unknown-keyword = Nagsisimula sa hindi kilalang salita ang isang linya ng patakaran ng tiwala.
reason-policy-count = May linya ng patakaran ng tiwala na masyadong madalas lumitaw, o hindi lumitaw kahit minsan.
reason-policy-undefined-name = Gumagamit ang patakaran ng tiwala ng isang pangalan bago ito itakda.
reason-policy-duplicate-name = Dalawang beses na itinakda ng patakaran ng tiwala ang iisang pangalan.
reason-policy-invalid = Lumalabag ang patakaran ng tiwala sa isa sa mga tuntunin nito.
reason-policy-unsafe-quorum = Hindi ligtas ang korum ng mga saksi sa patakaran ng tiwala.
reason-policy-unsigned = Hindi sapat ang mga lagda ng mga awtoridad ng patakaran ng tiwala.

# Payloads and redaction
reason-payload-mismatch = Hindi tugma ang datos na ipinadala ng isang server para sa isang tala sa iniingatan ng talaan para dito, kaya hindi ito ang naitalang datos. Maaaring nasa isang mirror ng talaan ang tamang datos.
reason-payload-missing = Hindi makuha ang datos na naitala para sa isang tala, at walang wastong abisong nagsasabing sinadya itong hindi ilabas. Maaaring mayroon pa nito ang isang mirror ng talaan.
reason-bad-payload-bundle = Mali ang anyo ng datos na ipinadala ng isang server para sa isang batch ng mga tala, o hindi ito para sa mga talang iyon, kaya hindi ito masuri. Maaaring mayroon nito ang isang mirror ng talaan.
reason-bad-notice = Mali ang anyo ng isang abiso ng pagtatago ng datos, kaya hindi ito binibilang.
reason-notice-unsigned = Kulang ang isang abiso ng pagtatago ng datos ng sapat na lagda mula sa mga awtoridad na itinalaga ng patakaran ng tiwala para rito, kaya hindi ito binibilang.
    .no-redaction = Hindi pinapayagan ng patakaran ng tiwala ang pagtatago ng datos, kaya hindi binibilang ang isang abiso ng pagtatago ng datos.
reason-notice-mismatch = Hindi tugma ang isang abiso ng pagtatago ng datos sa datos na itinatago sa ilalim nito o sa naitalang kopya nito, o binabanggit nito ang datos na hindi maaaring itago, kaya hindi ito binibilang.
    .profile = Binabanggit ng isang abiso ng pagtatago ng datos ang isang talang hindi maaaring itago ang datos, gaya ng isang balota, kaya hindi ito binibilang.
reason-notice-not-applied = Walang epekto ang isang abiso ng pagtatago ng datos: hindi nito tinutukoy ang pinakahuling abisong inilapat sa parehong tala, inuulit nito ang isang naunang abiso, o mas maaga ang petsa nito kaysa sa oras na naitala ang abisong iyon.
reason-bad-notice-bundle = Mali ang anyo ng patunay na naitala ang isang abiso ng pagtatago ng datos, hindi ito pumasa sa pagsusuri, o hindi sapat ang mga lagda ng saksi rito, kaya hindi binibilang ang abiso.

# Evidence files
reason-bad-evidence = Mali ang anyo ng file ng ebidensya, o kulang ito ng bahaging kailangan ng uri nito.
reason-evidence-unknown-kind = Hindi kilala ng pansuring ito ang uri ng file ng ebidensya.
reason-evidence-unpinned = Para sa isang patakaran ng tiwala na hindi naka-pin sa device na ito ang file ng ebidensya.
reason-evidence-wrong-subject = Tungkol sa isang talaan o hub ang file ng ebidensya na hindi saklaw ng uri nito, ayon sa patakaran nito ng tiwala.
reason-evidence-policy-mismatch = Para sa ibang patakaran ng tiwala ang isang bahagi ng file ng ebidensya, hindi sa patakaran ng file.
reason-not-proven = Pumapasa sa pagsusuri ang mga lagda ng ebidensya, ngunit hindi nito ipinapakita ang problemang sinasabi nito.
reason-needs-scan = Malulutas lamang ito sa pagbasa sa mga tala ng talaan, na hindi ginawa ng pagsusuring ito.
reason-rule-unsupported = Binabanggit ng ebidensya ang isang tuntuning hindi kayang patakbuhin ng pansuring ito. Kaya itong suriin ng isang buong pansuri.
reason-faulty-witness = Lumagda ang saksing ito sa dalawang bersyong nagsasalungatan, o sa bersyon ng hub na may maling tala, na nagpapatunay na may depekto ito.
reason-trust-assumption-failed = Sapat na saksi ang lumagda sa mga nagsasalungatang bersyon para maabot ang korum: mas marami ang may depekto kaysa sa ipinagpapalagay ng patakaran ng tiwala.
reason-misbehaviour-proven = Pinatutunayan ng ebidensya ang problemang sinasabi nito, ayon sa patakaran ng tiwala ng file.

reason-unknown = Dahilang “{ $code }”

# Shared infrastructure. Draft translations need native-speaker review.
reason-bad-operator-list = The infrastructure list is damaged or uses an unsupported format.
reason-operator-list-refused = The infrastructure list could not be accepted under the pinned authorities, validity window or update history.
reason-bad-shared-submission = The shared-log request or enrolment is damaged or does not follow the format.
reason-shared-submission-refused = The shared log could not accept this request under its pinned policy, submitter key or namespace.

# New metadata reason: native translation review needed outside English.
reason-profile-meaning-unknown = The profile meaning is not available for validation.

## extension

# The names of the anchor hubs and the browser layer in the extension's compact receipt chain.
tier-hubs-short = Mga hub
tier-browser-short = Browser
