# SPDX-License-Identifier: Apache-2.0
#
# Words of the Vitrine UI kit, in Tagalog (tl).
# Translated from en.ftl, the source. This translation needs review by a
# native speaker before it is used in production. It uses no plural
# selectors: the CLDR rule for Filipino calls 2 and 3 "one".

## The three facts (specs/receipt.md, section 3.1)

fact-included = Kasama sa talaan
fact-unchanged = Hindi nagbago
fact-same-for-everyone = Pareho para sa lahat

fact-state-done = Tapos na
fact-state-promised = Ipinangako
fact-state-pending = Nakabinbin
fact-state-late = Naantala
fact-state-invalid = Hindi masuri
fact-state-failed = Hindi pumasa
fact-state-checking = Sinusuri

# `invalid`: data that didn't parse, verify or match. It is damaged, and it
# proves nothing. `failed`: validly signed objects that contradict each other
# or the policy. That is proven, and the objects are evidence.
fact-included-done = Nasa talaan ang inyong tala.
fact-included-promised = Lumagda ang talaan sa pangakong isasama ang inyong tala.
fact-included-pending = Hinihintay na isama ng talaan ang inyong tala.
fact-included-late = Dapat ay naisama na ng talaan ang inyong tala.
fact-included-invalid = Hindi masuri ang patunay na nasa talaan ang inyong tala: mukhang sira ang datos.
fact-included-failed = Magkasalungat ang sariling mga lagda ng talaan tungkol sa inyong tala.
fact-unchanged-done = Nilagdaan ng mga independiyenteng saksi ang talaan, kaya walang anumang bahagi nito ang mababago nang hindi napapansin.
fact-unchanged-pending = Hinihintay na lumagda sa talaan ang mga independiyenteng saksi.
fact-unchanged-late = Dapat ay nakalagda na sa talaan ang mga saksi.
fact-unchanged-invalid = Hindi masuri ang mga patunay tungkol sa kasaysayan ng talaan: mukhang sira ang datos.
fact-unchanged-failed = Magkasalungat ang mga nilagdaang patunay tungkol sa kasaysayan ng talaan.
fact-same-for-everyone-done = Ito ring talaan ang ipinapakita sa lahat ng sumusuri.
fact-same-for-everyone-pending = Hinihintay na maiangkla ang talaan kung saan ito masusuri ng lahat.
fact-same-for-everyone-late = Dapat ay nakaangkla na ang talaan kung saan ito masusuri ng lahat.
fact-same-for-everyone-invalid = Hindi masuri ang mga angkla: mukhang sira ang datos.
fact-same-for-everyone-failed = Makikita sa mga nilagdaang patunay na hindi iisang talaan ang ipinapakita sa lahat.

## Tiers

tier-record = Talaan
tier-witnesses = Mga saksi
tier-hubs = Mga angklang hub
tier-browser = Layer ng browser
tier-policy = Patakaran
tier-entry = Tala

tier-status-verified = Napatunayan
tier-status-pending = Nakabinbin
tier-status-late = Naantala
tier-status-invalid = Hindi masuri
tier-status-failed = Hindi pumasa
tier-status-unused = Hindi ginagamit
tier-status-checking = Sinusuri
tier-status-promised = Ipinangako

tier-record-verified = Nasa nilagdaang talaan ang inyong tala.
tier-record-promised = Lumagda ang talaan sa pangakong isasama ang inyong tala.
tier-record-pending = Hindi pa naisasama ng talaan ang inyong tala.
tier-record-late = Dapat ay naisama na ng talaan ang inyong tala.
tier-record-invalid = Mukhang sira ang mga patunay ng talaan, kaya hindi masuri ang mga ito.
tier-record-failed = Nilagdaan ng talaan ang mga patunay na magkasalungat.
tier-record-checking = Sinusuri ang mga patunay ng talaan.
tier-witnesses-verified = Sapat na independiyenteng saksi ang lumagda sa talaan.
tier-witnesses-pending = Hinihintay na lumagda ang mga saksi. Ilang segundo lamang ito.
tier-witnesses-late = Dapat ay nakalagda na ang mga saksi.
tier-witnesses-invalid = Mukhang sira ang mga lagda ng saksi, kaya hindi masuri ang mga ito.
tier-witnesses-failed = Lumagda ang mga saksi sa isang talaang salungat sa nasa inyong resibo.
tier-witnesses-checking = Sinusuri ang mga lagda ng saksi.
tier-hubs-verified = Hawak ng bawat angklang hub ang talaan.
tier-hubs-pending = Papunta na sa mga angklang hub. Ilang segundo lamang ito.
tier-hubs-late = Dapat ay hawak na ng mga angklang hub ang talaan.
tier-hubs-invalid = Mukhang sira ang sagot ng isang angklang hub, kaya hindi ito masuri.
tier-hubs-failed = Hawak ng isang angklang hub ang isang nilagdaang talaang salungat sa nasa inyong resibo.
tier-hubs-unused = Walang ginagamit na angklang hub ang patakarang ito.
tier-hubs-checking = Sinusuri ang mga angklang hub.
tier-browser-verified = Nakaangkla na kung saan sumusuri ang mga browser.
tier-browser-pending = Inaasahan sa loob ng ilang minuto. Hindi ninyo kailangang maghintay.
tier-browser-late = Dapat ay nakaangkla na ito kung saan sumusuri ang mga browser.
tier-browser-invalid = Mukhang sira ang sagot ng layer ng browser, kaya hindi ito masuri.
tier-browser-failed = Salungat sa talaan ang isang nilagdaang angkla kung saan sumusuri ang mga browser.
tier-browser-unused = Walang ginagamit na independiyenteng layer ng browser ang patakarang ito.
tier-browser-checking = Sinusuri ang layer ng browser.
tier-test = Pagsubok lamang: pinapatakbo ng tagapamahala ng talaan, kaya hindi ito binibilang.
tier-deadline = Inaasahan pagsapit ng { TIME($deadline) }
hub-test = pagsubok

## The one-line status

status-verified = Napatunayan
status-checking = Sinusuri…
status-pending = Nakabinbin
status-late = Naantala
status-invalid = Hindi masuri
status-failed = Hindi pumasa
status-summary-verified = Kasama sa talaan, hindi nagbago, at pareho para sa lahat.
status-summary-checking = Sinusuri ang mga patunay ng resibo sa browser na ito.
status-summary-pending = Parating pa ang ilang patunay. Hindi ninyo kailangang maghintay.
status-summary-late = Dapat ay dumating na ang ilang patunay.
status-summary-invalid = Hindi masuri ang ilang datos: mukhang sira ang file o ang sagot ng server. Hindi nito ipinapakita na may nandaya.
status-summary-failed = Magkasalungat ang mga nilagdaang patunay. Pakitabi ang ebidensya.

## <vitrine-receipt>

receipt-label = Resibo
receipt-words-label = Mga salita ng resibo
receipt-entry = Tala { $index } sa { $log }
receipt-entry-promised = Ipinangakong tala sa { $log }
receipt-provenance-page = Sinuri ng website na ito
receipt-provenance-page-hint = Sinuri ng website na ito ang sarili nitong talaan. Para makatiyak, suriin ito nang independiyente.
receipt-provenance-independent = Sinuri nang independiyente sa website
receipt-facts-heading = Ang ipinapakita ng mga patunay
receipt-chain-heading = Gaano na kalayo ang narating nito
receipt-compare-heading = Ihambing sa opisyal na abiso
receipt-compare-hint = Dapat tumugma ang mga salita at saksing ito sa mga inilathala ng awtoridad, halimbawa sa abiso ng halalan.
receipt-policy-words = Mga salita ng patakaran
receipt-policy-id = ID ng patakaran
receipt-event = Kaganapan
receipt-witnesses = Mga saksi
receipt-witness-party = pinapatakbo ng { $party }
receipt-hubs = Mga angklang hub
receipt-clock-warning = Mahigit isang minuto ang lihis ng orasan ng device na ito. Ang nilagdaang oras ang batayan ng mga takdang oras, hindi ang orasang ito.
receipt-action-check = Suriin nang independiyente
receipt-action-download = I-download ang resibo
receipt-action-retry = Suriin muli
receipt-invalid = Hindi masuri ang ilang datos: mukhang sira ang file o ang sagot ng server. Hindi nito ipinapakita na may nandaya. Maaari ninyong suriin muli, o suriin nang independiyente.
receipt-no-expect = Hindi sinabi ng pahinang ito kung aling tala ang aasahan, kaya hindi maipapakitang sa inyo ang resibong ito.
receipt-error = Hindi masuri ang resibong ito.
receipt-empty = Wala pang resibo.
receipt-announce = { $tier }: { $status }.

## <vitrine-proof-steps>

steps-heading = Lahat ng pagsusuri
steps-summary = { $passed } sa { $total } na pagsusuri ang pumasa
steps-result-passed = Pumasa
steps-result-failed = Hindi pumasa
steps-result-not-run = Hindi pa naisasagawa
steps-show-details = Ipakita ang detalye
steps-hide-details = Itago ang detalye
steps-objects = Mga nilagdaang bagay na kasangkot: { $objects }
steps-evidence = I-save ang ebidensya
steps-empty = Wala pang pagsusuri.

## <vitrine-chain>

chain-label = Kadena ng resibo

## <vitrine-alert>

alert-label = Napatunayang problema
alert-kind-split-view-title = Hindi pare-pareho ang talaang ipinakita sa iba't ibang tao
alert-kind-split-view-body = Hindi maaaring parehong totoo ang dalawang bersyon ng talaan na kapwa nilagdaan ng tagapamahala nito. Maaaring aberya ito o pag-atake. Posibleng mabilang pa rin ang inyong tala, ngunit dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-broken-promise-title = Hindi tinupad ng talaan ang isang nilagdaang pangako
alert-kind-broken-promise-body = Nangako ang talaan na isasama nito ang isang tala sa loob ng takdang oras, at ipinapakita ng sarili nitong mga lagda na hindi ito natupad. Dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-bad-entry-title = May tala sa talaan na lumalabag sa mga tuntunin nito
alert-kind-bad-entry-body = Lumalabag sa isang tuntunin ng profile ng talaan ang isang talang nilagdaan dito. Dapat tingnan ng isang independiyenteng tagasuri ang problemang ito.
alert-kind-stale-anchor-title = Hindi naiangkla ang talaan sa takdang oras
alert-kind-stale-anchor-body = Mas natagalan ang talaan o ang isang angklang hub sa pag-angkla ng talaan kaysa sa pinapayagan ng patakaran. Paglabag ito sa ipinangakong antas ng serbisyo, hindi sa mismong talaan.
alert-kind-hub-entry-title = Tumanggap ang isang angklang hub ng talang dapat sana ay tinanggihan nito
alert-kind-hub-entry-body = Nilagdaan ng mga saksi ng isang angklang hub ang isang talaan ng hub na may talang lumalabag sa mga tuntunin ng hub, kaya hindi bababa sa isa sa kanila ang lumagda nang hindi muna nagsusuri.
alert-kind-unknown-title = May natagpuang problema
alert-kind-unknown-body = Nagpapakita ang ebidensya ng isang uri ng problemang hindi kilala ng pahinang ito: { $kind }.
alert-not-proven-title = Hindi nagpapatunay ng problema ang file na ito
alert-not-proven-body = Nasuri ang file, at hindi ito nagpapatunay ng problema. Hindi ito ebidensya.
alert-unpinned-title = Ang file na ito ay para sa patakarang hindi pa naka-pin sa device na ito
alert-unpinned-body = Hindi ito maipapakita bilang patunay sa device na ito. Ihambing ang mga salita ng patakaran ng file sa opisyal na abiso, at i-pin ang patakarang iyon bago muling suriin ang file.
alert-invalid-title = Hindi masuri ang file na ito
alert-invalid-body = Mukhang sira ang file. Hindi nito ipinapakita na may nandaya.
alert-proven-under = Napatunayan ayon sa patakarang may ganitong mga salita:
alert-file-policy-words = Mga salita ng patakaran ng file:
alert-parties = May pananagutan, ayon sa sarili nilang mga lagda: { $parties }
alert-evidence-heading = Ebidensyang nakatabi sa device na ito
alert-evidence-file = { $name } · { NUMBER($size, maximumFractionDigits: 1) } KB
alert-evidence-hint = Masusuri ng sinuman ang file na ito sa sarili niyang computer. Mga nilagdaang bagay lamang mula sa talaan ang laman nito.
alert-download = I-download ang file ng ebidensya
alert-send = Ipadala sa mga tagasubaybay
alert-monitors-heading = Mga tagasubaybay na itinakda ng patakaran
alert-confirm-heading = Ipadala ang ebidensya?
alert-confirm-body = Kapag ipinadala, makikita ng { $count } tagasubaybay ang file ng ebidensya, pati na ang pagkakapadala nito mula sa device na ito.
alert-confirm-send = Oo, ipadala
alert-confirm-cancel = Kanselahin
alert-sending = Ipinapadala na ang ebidensya sa mga tagasubaybay.
alert-no-monitors = Walang itinakdang tagasubaybay ang patakaran. Pakitabi ang file at ibigay ito sa isang tagamasid.
alert-delivery-waiting = Hinihintay ang kumpirmasyon
alert-delivery-sending = Ipinapadala
alert-delivery-confirmed = Nakumpirma
alert-delivery-failed = Hindi nakumpirma

## <vitrine-badge>

badge-check = Suriin nang independiyente
badge-opens = nagbubukas ng independiyenteng pansuri

## Steps, one per check the verifier runs (`step-<code>`, the codes of
## @vitrine/verify's codes.ts). Hub and browser steps get `$hub`.

step-chain-format = Maayos ang anyo ng file ng resibo
step-policy-pinned = Para sa naka-pin na patakaran ng tiwala ang resibo
step-log-known = Nasa patakaran ang talaan ng resibo
step-entry-parse = Maayos ang anyo ng tala
step-entry-profile = Tugma ang tala sa uri ng talaan at sa mga field ng uring iyon
step-entry-expectation = Tugma ang tala sa inaasahan ninyo
step-promise-signature = Lumagda ang talaan sa pangakong isasama ang tala
step-promise-inclusion = Saklaw ng nilagdaang pangako ang tala
step-promise-leaf = Para sa talang inaasahan ninyo ang pangako
step-promise-kept = Tinupad ng talaan ang pangako nito sa takdang oras
step-issued-signature = Nilagdaan ng talaan ang resibong ibinigay sa pagsusumite
step-issued-inclusion = Nasa resibong ibinigay sa pagsusumite ang tala
step-record-signature = Nilagdaan ng talaan ang sarili nitong resibo
step-record-inclusion = Nasa talaan ang tala
step-receipts-match = Para sa iisang tala sa iisang posisyon ang mga resibo
step-record-consistency = Nadagdagan lamang ang talaan mula nang ibigay ang resibo sa pagsusumite
step-record-quorum = Sapat na independiyenteng saksi ang lumagda sa talaan
step-hub-link = Pumapasa sa pagsusuri ang patunay ng hub { $hub }
step-hub-opening = Nabubuksan ang selyadong angkla sa hub { $hub } at tugma ito sa talaan
step-hub-anchored-checkpoint = Nilagdaan ng talaan at ng mga saksi nito ang talaang nakaangkla sa hub { $hub }
step-hub-anchor-consistency = Nadagdagan lamang ang talaan hanggang sa angkla nito sa hub { $hub }
step-browser-anchor = Hawak ng layer ng browser ang talaan ng hub { $hub }
step-browser-consistency = Nadagdagan lamang ang hub { $hub } hanggang sa angkla nito sa layer ng browser
step-bootstrap-link = Nakaangkla ang hub { $hub } sa isang panimulang hub
step-bootstrap-consistency = Nadagdagan lamang ang hub { $hub } hanggang sa angkla nito sa panimulang hub
step-unknown = Pagsusuring “{ $code }”

## Reasons, why a check failed or is still waiting (`reason-<code>`). They
## take no variables: the tier, hub or step they belong to is shown next to them.

# Encodings and limits
reason-bad-base64 = Mali ang anyo ng isang base64 na halaga.
reason-bad-hex = Mali ang anyo ng isang hex na halaga.
reason-bad-text = May tekstong hindi wasto o may ipinagbabawal na karakter.
reason-bad-number = Mali ang anyo ng isang numero, o lampas ito sa saklaw.
reason-trailing-data = May hindi inaasahang datos pagkatapos ng isang bahagi ng file.
reason-truncated = Masyadong maagang nagtatapos ang isang bahagi ng file.
reason-too-large = May bahaging mas malaki kaysa sa pinapayagan ng mga limitasyon.

# Signed notes and keys
reason-bad-note = Mali ang anyo ng isang nilagdaang pahayag.
reason-bad-key-name = Mali ang anyo ng pangalan ng isang susi.
reason-bad-vkey = Mali ang anyo o ang uri ng isang pampublikong susi.
reason-bad-public-key = Hindi wasto ang isang pampublikong susi.
reason-duplicate-signature = Dalawang beses na nakalagay ang iisang lagda sa isang pahayag.
reason-bad-signature = Hindi pumasa sa pagsusuri ang isang lagda.
reason-missing-signature = Nawawala ang isang lagdang dapat ay naroon.

# Checkpoints and witness signatures
reason-bad-checkpoint = Mali ang anyo ng isang checkpoint.
reason-wrong-origin = Ibang talaan o hub ang binabanggit ng isang nilagdaang pahayag kaysa sa inaasahan.
reason-cosignature-in-future = May petsa sa hinaharap ang isang lagda ng saksi, kaya hindi ito isinaalang-alang.
reason-quorum-not-met = Hindi pa sapat ang bilang ng lumagdang independiyenteng saksi.

# Proofs
reason-bad-proof = Mali ang anyo ng isang patunay.
reason-missing-extra = Wala sa isang resibo ang tala.
reason-index-out-of-range = Lampas sa dulo ng talaan ang posisyon ng tala.
reason-inclusion-failed = Hindi pumasa sa pagsusuri ang patunay na nasa talaan ang tala.
reason-consistency-failed = Hindi pumasa sa pagsusuri ang patunay na nadagdagan lamang ang talaan.
reason-split-view = Magkapareho ang laki ng dalawang nilagdaang bersyon ng talaan, ngunit magkaiba ang laman ng mga ito.

# Entries and expectations
reason-bad-entry = Mali ang anyo ng tala.
reason-wrong-profile = Iba ang uri ng tala sa uri ng talaan sa posisyong iyon.
reason-bad-entry-layout = Hindi tugma ang mga field ng tala sa uri nito.
reason-entry-mismatch = Hindi tugma ang tala sa inaasahan ninyo.
reason-expectation-incomplete = Hindi sapat ang sinabi ng pahina tungkol sa tala para masuri ito.
reason-expectation-unknown-field = Nagbanggit ang pahina ng field na wala sa ganitong uri ng tala.
reason-expectation-unsupported = Hindi kayang suriin ng pansuring ito ang mga field ng ganitong uri ng tala.
reason-receipts-disagree = Para sa magkakaibang tala o posisyon ang mga resibo sa file.

# Promises
reason-bad-promise = Mali ang anyo ng pangako.
reason-promise-mmd-too-large = Mas mahabang pagkaantala ang pinapayagan ng pangako kaysa sa pinahihintulutan ng patakaran.
reason-promise-leaf-mismatch = Para sa ibang tala ang pangako.
reason-promise-pending = Nangako ang talaan na isasama ang tala. Hindi pa sumasapit ang takdang oras ng resibo nito.
reason-promise-deadline-passed = Lumampas na ang takdang oras ng pangako, at wala pang resibo.
reason-promise-kept-unproven = Walang anuman sa file na nagpapakitang natupad ang pangako sa takdang oras.

# Receipt chains
reason-malformed-chain = Mali ang anyo ng file ng resibo.
reason-duplicate-block = Dalawang beses na nasa file ng resibo ang iisang bahagi.
reason-no-receipt = Walang pangako at walang resibo sa file.
reason-policy-mismatch = Ibang patakaran ng tiwala ang binabanggit ng resibo kaysa sa naka-pin.
reason-unknown-log = Binabanggit ng resibo ang isang talaang wala sa patakaran.
reason-unknown-hub = Binabanggit ng isang bahagi ang isang angklang hub na wala sa patakaran, kaya hindi ito isinaalang-alang.
reason-consistency-missing = Nawawala ang isang patunay na nadagdagan lamang ang talaan.
reason-consistency-mismatch = Hindi tugma ang isang patunay na nadagdagan lamang ang talaan sa mga bersyong pinag-uugnay nito.
reason-waiting-for-cosignatures = Hinihintay na lumagda ang mga saksi sa talaan.
reason-waiting-for-record = Hinihintay ang talaang nilagdaan ng mga saksi.
reason-no-signed-time = Wala pang nilagdaang oras, kaya hindi pa matitiyak kung lumampas na ang mga takdang oras.
reason-deadline-passed = Lumampas na ang takdang oras, ayon sa nilagdaang oras.
reason-record-invalid = Hindi ito masuri, dahil hindi masuri ang mga patunay ng talaan.
reason-bad-reference = Mali ang anyo ng isang link sa resibo.

# Anchor hubs
reason-waiting-for-anchor = Hinihintay na iangkla ng angklang hub ang talaan.
reason-hub-quorum-not-met = Hindi pa sapat ang bilang ng lumagdang saksi ng angklang hub.
reason-bad-hub-link = Mali ang anyo ng patunay ng angklang hub, o hindi ito pumasa sa pagsusuri.
reason-hub-link-mismatch = Tungkol sa ibang bagay ang patunay ng angklang hub.
reason-map-proof-failed = Hindi pumasa sa pagsusuri ang patunay ng mapa ng angklang hub.
reason-subject-rotated = Nagbago ang susi ng talaan sa angklang hub na ito. Kailangan ang mas bagong patakaran ng tiwala.
reason-anchor-behind-record = Mas lumang bersyon ng talaan ang hawak ng angklang hub kaysa sa nasa inyong resibo.
reason-anchor-quorum-not-met = Hindi sapat ang mga lagda ng saksi sa nakaangklang talaan.
reason-bad-blinded-anchor = Hindi pumasa sa pagsusuri ang isang selyadong angkla.
reason-opening-missing = Wala pa sa file ang pambukas ng selyadong angkla.
reason-bad-opening = Hindi tugma sa selyadong angkla ang dapat sanang pambukas nito.

# Browser layer
reason-browser-test-only = Pagsubok lamang dito ang layer ng browser: pinapatakbo ito ng tagapamahala ng talaan.
reason-waiting-for-browser-anchor = Hinihintay ang layer ng browser. Inaasahan ito sa loob ng ilang minuto.
reason-browser-behind-anchor = Mas luma ang bersyong hawak ng layer ng browser kaysa sa angklang hub. May inaasahang mas bago.
reason-bad-browser-anchor = Mali ang anyo ng isang angkla sa layer ng browser, o hindi ito tugma.
reason-bad-waict-proof = Hindi pumasa sa pagsusuri ang patunay ng layer ng browser.
reason-waict-quorum-not-met = Hindi sapat ang bilang ng lumagdang saksi ng layer ng browser.
reason-unknown-waict-service = Nagmula sa isang serbisyong hindi nakalista sa patakaran ang angkla sa layer ng browser.
reason-waict-service-not-independent = Pinapatakbo ng tagapamahala ng talaan ang layer ng browser, kaya hindi ito binibilang.
reason-bad-bootstrap-link = Mali ang anyo ng patunay ng isang panimulang hub, o hindi ito pumasa sa pagsusuri.

# Trust policies
reason-policy-syntax = Mali ang anyo ng isang linya ng patakaran ng tiwala.
reason-policy-unknown-keyword = Nagsisimula sa hindi kilalang salita ang isang linya ng patakaran ng tiwala.
reason-policy-count = May linya ng patakaran ng tiwala na masyadong madalas lumitaw, o hindi lumitaw kahit minsan.
reason-policy-undefined-name = Gumagamit ang patakaran ng tiwala ng isang pangalan bago ito itakda.
reason-policy-duplicate-name = Dalawang beses na itinakda ng patakaran ng tiwala ang iisang pangalan.
reason-policy-invalid = Lumalabag ang patakaran ng tiwala sa isa sa mga tuntunin nito.
reason-policy-unsafe-quorum = Hindi ligtas ang korum ng mga saksi sa patakaran ng tiwala.
reason-policy-unsigned = Hindi sapat ang mga lagda ng mga awtoridad ng patakaran ng tiwala.

reason-unknown = Dahilang “{ $code }”
