/* @ts-self-types="./index.d.ts" */

/**
 * A census CSV, read a batch at a time.
 *
 * A handle rather than a function returning every voter, and that is the whole
 * point: a hundred thousand members crossing the boundary at once is the copy
 * this exists to avoid. The caller asks for a batch, turns it into whatever it
 * stores, and drops it before asking for the next.
 *
 * The wizard used to parse this in TypeScript. Two parsers meant two answers to
 * "what is in this file", and on a census that is how a quoted comma read one way
 * by the loader and another by the saver turns one member into two on the way
 * out.
 */
export class CensusCsvReader {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CensusCsvReaderFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_censuscsvreader_free(ptr, 0);
    }
    /**
     * The columns a voter will have, in order, with the derived ones dropped.
     * @returns {any}
     */
    columns() {
        const ret = wasm.censuscsvreader_columns(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Read a native census or a recognized source format. Throws if the file is
     * empty or its required identity column is missing.
     * @param {string} text
     */
    constructor(text) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.censuscsvreader_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        CensusCsvReaderFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * The next `size` rows as arrays of strings. Empty when the file is done.
     * @param {number} size
     * @returns {any}
     */
    nextBatch(size) {
        const ret = wasm.censuscsvreader_nextBatch(this.__wbg_ptr, size);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * What was odd about the file without being wrong with it.
     * @returns {any}
     */
    notes() {
        const ret = wasm.censuscsvreader_notes(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) CensusCsvReader.prototype[Symbol.dispose] = CensusCsvReader.prototype.free;

/**
 * A census the core holds, handed out under the interface it takes in.
 *
 * **The same three methods as `CensusPull`, pointing the other way.** A host that
 * opens a save file gets one of these and can pass it straight back to
 * `compilePlan` as `options.census`, so ten million members are read from the zip,
 * counted, and written into a bundle without ever being a JavaScript value.
 *
 * `CensusCsvReader` is the same shape and stays, because a dropped CSV has no
 * `Opened` to come from. The two are interchangeable wherever a `CensusPull` is
 * wanted, which is the whole reason the interface was written before either.
 */
export class CensusHandle {
    static __wrap(ptr) {
        const obj = Object.create(CensusHandle.prototype);
        obj.__wbg_ptr = ptr;
        CensusHandleFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CensusHandleFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_censushandle_free(ptr, 0);
    }
    /**
     * The columns a row will have, in order.
     * @returns {any}
     */
    columns() {
        const ret = wasm.censushandle_columns(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The next `size` rows as arrays of strings, aligned to `columns()`.
     * @param {number} size
     * @returns {any}
     */
    nextBatch(size) {
        const ret = wasm.censushandle_nextBatch(this.__wbg_ptr, size);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Back to the first row.
     */
    rewind() {
        const ret = wasm.censushandle_rewind(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
}
if (Symbol.dispose) CensusHandle.prototype[Symbol.dispose] = CensusHandle.prototype.free;

/**
 * What `openFile` made of the bytes.
 *
 * A struct rather than a plain object because two of its members must not be
 * serialised: the census is a handle, and the files are bytes a host wants as
 * `Uint8Array`s rather than as arrays of numbers.
 */
export class OpenedConfiguration {
    static __wrap(ptr) {
        const obj = Object.create(OpenedConfiguration.prototype);
        obj.__wbg_ptr = ptr;
        OpenedConfigurationFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        OpenedConfigurationFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_openedconfiguration_free(ptr, 0);
    }
    /**
     * The bytes the plan's file names point at, as `Record<string, Uint8Array>`.
     *
     * Serialised in one go, unlike the census, because these are a logo and some
     * photographs — kilobytes each, and a host wants them as values to put in
     * state rather than as a stream to pull.
     * @returns {any}
     */
    files() {
        const ret = wasm.openedconfiguration_files(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The plan, or `null` when nothing could be read. Read `report` then.
     * @returns {any}
     */
    plan() {
        const ret = wasm.openedconfiguration_plan(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Everything found on the way, errors and warnings together.
     * @returns {any}
     */
    report() {
        const ret = wasm.openedconfiguration_report(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * What the bytes turned out to be: `delivery`, `plan-archive`, `workbook`…
     * @returns {any}
     */
    source() {
        const ret = wasm.openedconfiguration_source(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The census that travelled with it, if one did.
     *
     * **Taken, not borrowed.** A handle owns its cursor, and two of them over one
     * census would each think they were at the start. Calling this twice returns
     * `undefined` the second time rather than a second reader of the same rows.
     * @returns {CensusHandle | undefined}
     */
    takeCensus() {
        const ret = wasm.openedconfiguration_takeCensus(this.__wbg_ptr);
        return ret === 0 ? undefined : CensusHandle.__wrap(ret);
    }
}
if (Symbol.dispose) OpenedConfiguration.prototype[Symbol.dispose] = OpenedConfiguration.prototype.free;

/**
 * What a profile hides, so the wizard knows what not to draw.
 *
 * Rust decides which *paths*, because that is a statement about the plan.
 * Which screens that empties is a question about screens, and belongs to
 * whoever draws them.
 * A plan with the profile's own values already in it.
 *
 * The wizard could not do this, and the hole was visible: a delivery engineer
 * fixes "SMART Elections" as the event name, opens the client's link, and the
 * field is empty. The value was real — `apply_profile` runs inside
 * `compile_plan`, so the *built* archive had it — but nothing put it on the
 * screen, so the client saw a blank box above an error telling them to fill it
 * in.
 *
 * Exposed rather than reimplemented in TypeScript. The rules are not obvious —
 * a **fixed** path (locked or hidden) is written unconditionally, while any
 * other default is written only where the plan says nothing, so seeding cannot
 * overwrite an answer somebody already gave — and a second copy of that in
 * another language is a second opinion about what a profile means.
 * @param {any} plan
 * @param {any} profile
 * @returns {any}
 */
export function applyProfile(plan, profile) {
    const ret = wasm.applyProfile(plan, profile);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the selection that choosing a slate produces from the current one,
 * and what it changes. Throws the list of problems of a slate that cannot be
 * applied.
 * @param {any} slate_json
 * @param {any} contests_json
 * @param {any} current_json
 * @returns {any}
 */
export function apply_slate_js(slate_json, contests_json, current_json) {
    const ret = wasm.apply_slate_js(slate_json, contests_json, current_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The authentication presets a front end can offer.
 *
 * **The list comes from a profile, not from Rust.** A client's identity provider
 * is theirs, so the four Sequent ships are a default rather than a ceiling —
 * pass the profile document a build loaded and get that client's own flows;
 * pass nothing and get the shipped four out of `default_profile.json`.
 *
 * Returned rather than duplicated in TypeScript, so a dropdown cannot list a
 * flow the platform cannot provision or miss one it can.
 * @param {any} profile
 * @returns {any}
 */
export function authPresets(profile) {
    const ret = wasm.authPresets(profile);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Build the reviewed legacy-seat-v1 profile locally, sharing the workbook build.
 * @param {Uint8Array} sql
 * @param {Uint8Array} workbook
 * @param {any} decisions
 * @param {any} options
 * @returns {any}
 */
export function buildFromHistorical(sql, workbook, decisions, options) {
    const ptr0 = passArray8ToWasm0(sql, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(workbook, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.buildFromHistorical(ptr0, len0, ptr1, len1, decisions, options);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Build an importable bundle from a workbook the user picked.
 *
 * `workbook` is the bytes of an `.xlsx` — what a file input hands over. The
 * options are all optional: `tenantId`, `baseExport` (a parsed export document),
 * `slug`, `createdAt` and `authPreset`.
 *
 * Returns the files to download and everything found. On failure the files are
 * empty and the report says why, rather than throwing: a list of problems is
 * something a page can render, and an exception is not.
 * @param {Uint8Array} workbook
 * @param {any} options
 * @returns {BuildOutput}
 */
export function buildFromWorkbook(workbook, options) {
    const ptr0 = passArray8ToWasm0(workbook, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.buildFromWorkbook(ptr0, len0, options);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the slate configuration in the form it is stored and published.
 * Throws the list of problems of a configuration that cannot be read.
 * @param {string} annotation
 * @returns {string}
 */
export function canonicalize_slates_js(annotation) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(annotation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canonicalize_slates_js(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Check an existing export, the way the server would.
 *
 * Takes the `export_election_event-<id>.json` document as text. Returns the same
 * [`Report`] the importer produces, so a page can show the problems before anyone
 * uploads anything.
 * @param {string} document
 * @returns {Report}
 */
export function checkBundle(document) {
    const ptr0 = passStringToWasm0(document, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.checkBundle(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Checks a slate configuration against the contests and candidates of its
 * election, given as JSON arrays of rows. Returns the list of problems,
 * empty when the configuration can be published.
 * @param {string} annotation
 * @param {string} default_language
 * @param {string} contests_json
 * @param {string} candidates_json
 * @returns {any}
 */
export function check_election_slates_js(annotation, default_language, contests_json, candidates_json) {
    const ptr0 = passStringToWasm0(annotation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(default_language, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(contests_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ptr3 = passStringToWasm0(candidates_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len3 = WASM_VECTOR_LEN;
    const ret = wasm.check_election_slates_js(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} decoded_contest_json
 * @returns {any}
 */
export function check_is_blank_js(decoded_contest_json) {
    const ret = wasm.check_is_blank_js(decoded_contest_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} contests
 * @param {any} decoded_contests
 * @returns {any}
 */
export function check_voting_error_dialog(contests, decoded_contests) {
    const ret = wasm.check_voting_error_dialog(contests, decoded_contests);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} contests
 * @param {any} decoded_contests
 * @returns {any}
 */
export function check_voting_not_allowed_next(contests, decoded_contests) {
    const ret = wasm.check_voting_not_allowed_next(contests, decoded_contests);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Compile a plan into the bundle and the files that travel beside it.
 *
 * The same [`Output`] `buildFromWorkbook` returns, because a wizard and a
 * spreadsheet produce the same thing and a front end should not need two shapes
 * to hold it.
 *
 * A bad plan comes back as a report with no files rather than as an exception:
 * a list of problems is something a page can render. An exception here means
 * the core itself failed, which is a different thing and belongs somewhere
 * else in the interface.
 * @param {any} plan
 * @param {any} options
 * @returns {BuildOutput}
 */
export function compilePlan(plan, options) {
    const ret = wasm.compilePlan(plan, options);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} areas_json
 * @param {any} area_contests_json
 * @returns {any}
 */
export function create_tree_js(areas_json, area_contests_json) {
    const ret = wasm.create_tree_js(areas_json, area_contests_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} auditable_ballot_json
 * @returns {any}
 */
export function decode_auditable_ballot_js(auditable_ballot_json) {
    const ret = wasm.decode_auditable_ballot_js(auditable_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} auditable_multi_ballot_json
 * @returns {any}
 */
export function decode_auditable_multi_ballot_js(auditable_multi_ballot_json) {
    const ret = wasm.decode_auditable_multi_ballot_js(auditable_multi_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The shipped profile, as the document a profile author would edit.
 *
 * Handed over whole rather than as a list of presets: a build with no
 * `?profile=` is running *on* this profile, and a front end that fetched a
 * profile and a front end that did not should be holding the same kind of thing
 * afterwards. It is also what a profile author copies from — a default nobody
 * can read is a default nobody can override deliberately.
 * @returns {any}
 */
export function defaultProfile() {
    const ret = wasm.defaultProfile();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} decoded_contests_json
 * @param {any} election_json
 * @returns {any}
 */
export function encrypt_decoded_contest_js(decoded_contests_json, election_json) {
    const ret = wasm.encrypt_decoded_contest_js(decoded_contests_json, election_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} decoded_multi_contests_json
 * @param {any} election_json
 * @returns {any}
 */
export function encrypt_decoded_multi_contest_js(decoded_multi_contests_json, election_json) {
    const ret = wasm.encrypt_decoded_multi_contest_js(decoded_multi_contests_json, election_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The bundles a front end's own tests should agree with.
 *
 * The same list the Rust tests run, handed over as data rather than reimplemented
 * in TypeScript. A front end asserting `checkBundle(case.bundle)` matches
 * `case.expect` is checking that the browser and the server reach the same verdict
 * — which is the only thing that makes one validator worth having. A suite written
 * separately would prove only that each side agrees with itself.
 * @returns {any}
 */
export function fixtureCases() {
    const ret = wasm.fixtureCases();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} election_id
 */
export function forget_voter_signing_key_js(election_id) {
    const ret = wasm.forget_voter_signing_key_js(election_id);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * @returns {any}
 */
export function generate_sample_auditable_ballot_js() {
    const ret = wasm.generate_sample_auditable_ballot_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} base_url_json
 * @param {any} tenant_id_json
 * @param {any} event_id_json
 * @param {any} auth_action_json
 * @returns {any}
 */
export function get_auth_url_js(base_url_json, tenant_id_json, event_id_json, auth_action_json) {
    const ret = wasm.get_auth_url_js(base_url_json, tenant_id_json, event_id_json, auth_action_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns what each slate covers of the ballot style's contests, in the
 * configured order and without the slates that have no candidate in them.
 * Returns null when the election has no slates. Throws the list of problems
 * of an invalid configuration.
 * @param {any} ballot_style_json
 * @returns {any}
 */
export function get_ballot_style_slates_coverage_js(ballot_style_json) {
    const ret = wasm.get_ballot_style_slates_coverage_js(ballot_style_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the slates the ballot style carries, or null when its election
 * has none. Throws the list of problems of an invalid configuration.
 * @param {any} ballot_style_json
 * @returns {any}
 */
export function get_ballot_style_slates_js(ballot_style_json) {
    const ret = wasm.get_ballot_style_slates_js(ballot_style_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} contest_json
 * @param {any} candidate_val
 * @returns {any}
 */
export function get_candidate_points_js(contest_json, candidate_val) {
    const ret = wasm.get_candidate_points_js(contest_json, candidate_val);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} contests_tree_js
 * @param {any} contest_id_js
 * @returns {any}
 */
export function get_contest_matches_js(contests_tree_js, contest_id_js) {
    const ret = wasm.get_contest_matches_js(contests_tree_js, contest_id_js);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the default blank ballots policy
 * @returns {any}
 */
export function get_default_blank_ballots_policy_js() {
    const ret = wasm.get_default_blank_ballots_policy_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @returns {any}
 */
export function get_default_consolidated_report_policy_js() {
    const ret = wasm.get_default_consolidated_report_policy_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the default decline to vote policy
 * @returns {any}
 */
export function get_default_decline_to_vote_policy_js() {
    const ret = wasm.get_default_decline_to_vote_policy_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @returns {any}
 */
export function get_default_duplicated_rank_policy_js() {
    const ret = wasm.get_default_duplicated_rank_policy_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @returns {any}
 */
export function get_default_language_detection_policy_js() {
    const ret = wasm.get_default_language_detection_policy_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @returns {any}
 */
export function get_default_preference_gaps_policy_js() {
    const ret = wasm.get_default_preference_gaps_policy_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the default voting screen back policy
 * @returns {any}
 */
export function get_default_voting_screen_back_policy_js() {
    const ret = wasm.get_default_voting_screen_back_policy_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} contest_json
 * @returns {any}
 */
export function get_layout_properties_from_contest_js(contest_json) {
    const ret = wasm.get_layout_properties_from_contest_js(contest_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns all the voting screen back policy values
 * @returns {any}
 */
export function get_voting_screen_back_policy_values_js() {
    const ret = wasm.get_voting_screen_back_policy_values_js();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} decoded_contest_json
 * @param {any} ballot_style_json
 * @returns {any}
 */
export function get_write_in_available_characters_js(decoded_contest_json, ballot_style_json) {
    const ret = wasm.get_write_in_available_characters_js(decoded_contest_json, ballot_style_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} auditable_ballot_json
 * @returns {any}
 */
export function hash_auditable_ballot_js(auditable_ballot_json) {
    const ret = wasm.hash_auditable_ballot_js(auditable_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} auditable_multi_ballot_json
 * @returns {any}
 */
export function hash_auditable_multi_ballot_js(auditable_multi_ballot_json) {
    const ret = wasm.hash_auditable_multi_ballot_js(auditable_multi_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Versioned handshake for an opt-in browser converter loaded as static assets.
 * @returns {any}
 */
export function historicalImportInfo() {
    const ret = wasm.historicalImportInfo();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Exposes the canonical acclaimed-candidate policy to browser consumers.
 * @param {any} candidate_json
 * @returns {boolean}
 */
export function is_eligible_acclaimed_candidate_js(candidate_json) {
    const ret = wasm.is_eligible_acclaimed_candidate_js(candidate_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] !== 0;
}

/**
 * @param {any} counting_algorithm_js
 * @returns {any}
 */
export function is_preferential_js(counting_algorithm_js) {
    const ret = wasm.is_preferential_js(counting_algorithm_js);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} lang
 * @returns {string}
 */
export function iso_639_2t_to_bcp47_js(lang) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(lang, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.iso_639_2t_to_bcp47_js(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} lang
 * @returns {string}
 */
export function locale_to_internal_language_code_js(lang) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ptr0 = passStringToWasm0(lang, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.locale_to_internal_language_code_js(ptr0, len0);
        deferred2_0 = ret[0];
        deferred2_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} typed
 * @returns {any}
 */
export function normalize_ballot_id_js(typed) {
    const ret = wasm.normalize_ballot_id_js(typed);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * A delivery zip, a plan `.json` or a workbook `.xlsx` — whichever this is.
 *
 * One call for all three, because telling them apart cannot be done outside Rust:
 * an `.xlsx` has the same `PK` magic as a delivery, so a host sniffing bytes hands
 * a spreadsheet to the delivery reader and gets "no plan in this zip" about a
 * perfectly good workbook. Opening the archive and looking inside is the archive
 * reader's job.
 *
 * **A bad file comes back as a report rather than as an exception**, which is the
 * rule the rest of this module follows and the reason it matters here: a report is
 * something a screen can group by tab and point at cells with, and an exception is
 * a string. `plan` is `null` when nothing could be read.
 * @param {Uint8Array} bytes
 * @param {string | null} [name]
 * @returns {any}
 */
export function openConfiguration(bytes, name) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    var ptr1 = isLikeNone(name) ? 0 : passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    const ret = wasm.openConfiguration(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Open a delivery, a save file, a plan, a workbook or an event export.
 *
 * The successor to [`open_configuration`], which stays for now because beyond's
 * CI builds this crate's live tip and a boundary that only grows is the only kind
 * that can be pushed first. The difference is everything the older one had no
 * place for: a save file's census and the files it carries.
 * @param {Uint8Array} bytes
 * @param {string | null} [name]
 * @returns {OpenedConfiguration}
 */
export function openFile(bytes, name) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    var ptr1 = isLikeNone(name) ? 0 : passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    const ret = wasm.openFile(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return OpenedConfiguration.__wrap(ret[0]);
}

/**
 * The plan inside a delivery zip, so `Import Configuration` can open what a client kept.
 *
 * A client keeps the whole delivery, not the `blueprint.json` inside it — so the wizard
 * has to open the zip rather than asking somebody to unzip it and pick the right file out
 * of eight, one of which can carry administrator passwords.
 *
 * Returns the plan as a `JsValue`, already parsed, because the host's next move is to put
 * it into wizard state. A zip with no plan in it comes back as an error naming what the
 * zip *did* contain, which is the difference between fixing it and guessing.
 * @param {Uint8Array} bytes
 * @returns {any}
 */
export function planInDelivery(bytes) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.planInDelivery(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The ballot-behaviour values a picker may offer.
 *
 * Returned rather than duplicated in TypeScript, for the same reason
 * [`auth_presets`] is: a dropdown cannot list a value the platform does not
 * have, and cannot miss one it does. `labels` is the namespace the Admin
 * Portal's translations are keyed by, so a front end labels a value without a
 * second table of its own.
 *
 * This is the third place the value space appears — `ContestPresentation.ts`
 * and `contest.hbs` being the others — and handing it over as data is what
 * stops a fourth.
 * @returns {any}
 */
export function policyCatalog() {
    const ret = wasm.policyCatalog();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The ballots this plan's voters would be given.
 *
 * Compiles the plan the way [`compile_plan_js`] does — profile applied,
 * validated, built — and then hands the resulting entities to the platform's own
 * ballot-style builder. So the preview is generated from the bytes that would be
 * imported, and nothing in this crate decides what a ballot contains.
 *
 * No zip. A review screen asking "what will voters see?" does not need the
 * archive, and compressing one to answer would be a second of a delivery
 * engineer's time on every keystroke.
 *
 * Like the other entry points, a plan that cannot be compiled comes back as a
 * report with no preview rather than as an exception.
 * @param {any} plan
 * @param {any} options
 * @returns {PreviewOutput}
 */
export function previewBallot(plan, options) {
    const ret = wasm.previewBallot(plan, options);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} profile
 * @returns {any}
 */
export function readProfile(profile) {
    const ret = wasm.readProfile(profile);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Every report type and the formats it can be generated in, the first being
 * its default, so the Reports step offers only what the platform renders.
 * @returns {any}
 */
export function reportCatalog() {
    const ret = wasm.reportCatalog();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The zip the wizard hands over when somebody saves.
 *
 * **Never a bare `blueprint.json`.** A plan on its own is a plan with the members'
 * names and the candidates' photographs missing, so what comes back is always an
 * archive: the plan, its census and the files it names.
 * @param {any} plan
 * @param {any} options
 * @returns {any}
 */
export function saveFile(plan, options) {
    const ret = wasm.saveFile(plan, options);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

export function set_hooks() {
    wasm.set_hooks();
}

/**
 * @param {any} election_id
 * @param {any} voter_signing_pk
 * @param {any} ballot_id
 * @returns {any}
 */
export function sign_ballot_cast_js(election_id, voter_signing_pk, ballot_id) {
    const ret = wasm.sign_ballot_cast_js(election_id, voter_signing_pk, ballot_id);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} ballot_id
 * @param {any} election_id
 * @param {any} content
 * @returns {any}
 */
export function sign_hashable_ballot_with_ephemeral_voter_signing_key_js(ballot_id, election_id, content) {
    const ret = wasm.sign_hashable_ballot_with_ephemeral_voter_signing_key_js(ballot_id, election_id, content);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} ballot_id
 * @param {any} election_id
 * @param {any} auditable_multi_ballot_json
 * @returns {any}
 */
export function sign_hashable_multi_ballot_with_ephemeral_voter_signing_key_js(ballot_id, election_id, auditable_multi_ballot_json) {
    const ret = wasm.sign_hashable_multi_ballot_with_ephemeral_voter_signing_key_js(ballot_id, election_id, auditable_multi_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} all_candidates
 * @param {any} order
 * @param {any} apply_random
 * @returns {any}
 */
export function sort_candidates_list_js(all_candidates, order, apply_random) {
    const ret = wasm.sort_candidates_list_js(all_candidates, order, apply_random);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} contests_json
 * @param {any} order
 * @param {any} apply_random
 * @returns {any}
 */
export function sort_contests_list_js(contests_json, order, apply_random) {
    const ret = wasm.sort_contests_list_js(contests_json, order, apply_random);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} elections_json
 * @param {any} order
 * @param {any} apply_random
 * @returns {any}
 */
export function sort_elections_list_js(elections_json, order, apply_random) {
    const ret = wasm.sort_elections_list_js(elections_json, order, apply_random);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} decoded_contest_json
 * @param {any} ballot_style_json
 * @returns {any}
 */
export function test_contest_reencoding_js(decoded_contest_json, ballot_style_json) {
    const ret = wasm.test_contest_reencoding_js(decoded_contest_json, ballot_style_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} decoded_multi_contest_json
 * @param {any} ballot_style_json
 * @returns {any}
 */
export function test_multi_contest_reencoding_js(decoded_multi_contest_json, ballot_style_json) {
    const ret = wasm.test_multi_contest_reencoding_js(decoded_multi_contest_json, ballot_style_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} auditable_ballot_json
 * @returns {any}
 */
export function to_hashable_ballot_js(auditable_ballot_json) {
    const ret = wasm.to_hashable_ballot_js(auditable_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} auditable_multi_ballot_json
 * @returns {any}
 */
export function to_hashable_multi_ballot_js(auditable_multi_ballot_json) {
    const ret = wasm.to_hashable_multi_ballot_js(auditable_multi_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Check a plan, in the wizard's own vocabulary.
 *
 * A trustee threshold no number of trustees can meet, a key ceremony after
 * voting opens, a contest electing more people than are standing. Different
 * questions from [`check_bundle`], which asks about a built bundle in the
 * bundle's vocabulary — both run, because a problem phrased as
 * `contests[2].winning_candidates_num` is no use to somebody looking at a
 * wizard, and a bundle-level problem has no wizard field to point at.
 * @param {any} plan
 * @param {any} options
 * @returns {Report}
 */
export function validatePlan(plan, options) {
    const ret = wasm.validatePlan(plan, options);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} content_json
 * @param {any} contest_bounds_json
 * @returns {any}
 */
export function validate_area_contest_results_js(content_json, contest_bounds_json) {
    const ret = wasm.validate_area_contest_results_js(content_json, contest_bounds_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} contest_sheets_json
 * @returns {any}
 */
export function validate_ballot_box_blank_ballots_js(contest_sheets_json) {
    const ret = wasm.validate_ballot_box_blank_ballots_js(contest_sheets_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Checks a signed configuration package before `Import Configuration`
 * reads anything in it: the same checks windmill runs at import, at the
 * browser's own time.
 *
 * A package that fails comes back as a report with no manifest, not as an
 * exception, so the screen can name each problem.
 * @param {Uint8Array} bytes
 * @param {any} trust
 * @returns {any}
 */
export function verifyConfigurationPackage(bytes, trust) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.verifyConfigurationPackage(ptr0, len0, trust);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns `true` when every ciphertext in the auditable ballot is the
 * encryption of the plaintext and randomness the ballot carries. Returns
 * `false` on a mismatch and fails on any ballot that cannot be checked, so
 * callers fail closed either way.
 * @param {any} auditable_ballot_json
 * @returns {any}
 */
export function verify_auditable_ballot_ciphertext_js(auditable_ballot_json) {
    const ret = wasm.verify_auditable_ballot_ciphertext_js(auditable_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Multi-contest counterpart of [`verify_auditable_ballot_ciphertext_js`].
 * @param {any} auditable_multi_ballot_json
 * @returns {any}
 */
export function verify_auditable_multi_ballot_ciphertext_js(auditable_multi_ballot_json) {
    const ret = wasm.verify_auditable_multi_ballot_ciphertext_js(auditable_multi_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Run the canonical four-step check with independently published trusted keys.
 * @param {any} trusted
 * @param {any} proof
 * @returns {any}
 */
export function verify_ballot_log_proof_js(trusted, proof) {
    const ret = wasm.verify_ballot_log_proof_js(trusted, proof);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} ballot_id
 * @param {any} election_id
 * @param {any} content
 * @returns {any}
 */
export function verify_ballot_signature_js(ballot_id, election_id, content) {
    const ret = wasm.verify_ballot_signature_js(ballot_id, election_id, content);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} ballot_box_key
 * @param {any} cast_receipt
 * @returns {any}
 */
export function verify_cast_receipt_js(ballot_box_key, cast_receipt) {
    const ret = wasm.verify_cast_receipt_js(ballot_box_key, cast_receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} ballot_id
 * @param {any} election_id
 * @param {any} auditable_multi_ballot_json
 * @returns {any}
 */
export function verify_multi_ballot_signature_js(ballot_id, election_id, auditable_multi_ballot_json) {
    const ret = wasm.verify_multi_ballot_signature_js(ballot_id, election_id, auditable_multi_ballot_json);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} ballot_box_key
 * @param {any} received_ballot
 * @returns {any}
 */
export function verify_received_ballot_js(ballot_box_key, received_ballot) {
    const ret = wasm.verify_received_ballot_js(ballot_box_key, received_ballot);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_67e7344beaa85059: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_Number_c54e7112a3fa7e3e: function(arg0) {
            const ret = Number(arg0);
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_bigint_get_as_i64_b482365c149396c8: function(arg0, arg1) {
            const v = arg1;
            const ret = typeof(v) === 'bigint' ? v : undefined;
            getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_boolean_get_7a12af2b3f899c5a: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_debug_string_0e68cf47c9cbd9b0: function(arg0, arg1) {
            const ret = debugString(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_in_50072d4d6e45c193: function(arg0, arg1) {
            const ret = arg0 in arg1;
            return ret;
        },
        __wbg___wbindgen_is_bigint_60fc0336cb14f5d7: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_fcda5e3902d732fe: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_5160b3e381865372: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_edb6b15aa3afe12e: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_c4f7cb494a2a21f1: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_8c687d0b90d5b524: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_9fdcd3c0a860dd3b: function(arg0, arg1) {
            const ret = arg0 === arg1;
            return ret;
        },
        __wbg___wbindgen_jsval_loose_eq_3c30021c243b64cd: function(arg0, arg1) {
            const ret = arg0 == arg1;
            return ret;
        },
        __wbg___wbindgen_number_get_1dc732b810cb937c: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_92ab86bb19cbc12f: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_5d9e815e6fdf150f: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_call_269c5566fbede3eb: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_call_6bcf8d3e20937e46: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.call(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_census_ab2ae7726ad5e865: function(arg0) {
            const ret = arg0.census;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_columns_47d6c583cf9dcbda: function() { return handleError(function (arg0) {
            const ret = arg0.columns();
            return ret;
        }, arguments); },
        __wbg_crypto_48300657fced39f9: function(arg0) {
            const ret = arg0.crypto;
            return ret;
        },
        __wbg_done_cffed884d87aa22e: function(arg0) {
            const ret = arg0.done;
            return ret;
        },
        __wbg_entries_972a87586902cf87: function(arg0) {
            const ret = Object.entries(arg0);
            return ret;
        },
        __wbg_error_757e9472f8410341: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_getRandomValues_263d0aa5464054ee: function() { return handleError(function (arg0, arg1) {
            arg0.getRandomValues(arg1);
        }, arguments); },
        __wbg_getRandomValues_436a51d0629d84e1: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_getTime_65922ba0b59d55a7: function(arg0) {
            const ret = arg0.getTime();
            return ret;
        },
        __wbg_getTimezoneOffset_6e4850ad528ac37d: function(arg0) {
            const ret = arg0.getTimezoneOffset();
            return ret;
        },
        __wbg_get_6cf5a4d4d8ad3c5a: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_b1f0ab13c737f856: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_unchecked_363572bdd397d473: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_with_ref_key_6412cf3094599694: function(arg0, arg1) {
            const ret = arg0[arg1];
            return ret;
        },
        __wbg_instanceof_ArrayBuffer_d4ff01f8247925ae: function(arg0) {
            let result;
            try {
                result = arg0 instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Map_1ff6a2b54c899f0d: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_598adc0fef426aa8: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_5674713bb7b79043: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_isSafeInteger_8f51c743827d1ec5: function(arg0) {
            const ret = Number.isSafeInteger(arg0);
            return ret;
        },
        __wbg_iterator_22ddeb808cf55a6f: function() {
            const ret = Symbol.iterator;
            return ret;
        },
        __wbg_length_31bdaf014f5fbde2: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_4e1adc0d42e23620: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_log_363d83b9114c8831: function(arg0) {
            console.log(arg0);
        },
        __wbg_msCrypto_8c6d45a75ef1d3da: function(arg0) {
            const ret = arg0.msCrypto;
            return ret;
        },
        __wbg_new_0_35540e542ba689d2: function() {
            const ret = new Date();
            return ret;
        },
        __wbg_new_180f1022bb6ee517: function(arg0) {
            const ret = new Date(arg0);
            return ret;
        },
        __wbg_new_1da3429bc3c4541c: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_227d7c05414eb861: function() {
            const ret = new Error();
            return ret;
        },
        __wbg_new_8d36e20aa758e411: function() {
            const ret = new Map();
            return ret;
        },
        __wbg_new_bebc3f4757acf305: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_ffa92086ea89f79c: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_with_length_5ffeddb9d9fbb96f: function(arg0) {
            const ret = new Uint8Array(arg0 >>> 0);
            return ret;
        },
        __wbg_nextBatch_90181756045f2618: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.nextBatch(arg1 >>> 0);
            return ret;
        }, arguments); },
        __wbg_next_95053e306b1c3aed: function(arg0) {
            const ret = arg0.next;
            return ret;
        },
        __wbg_next_f31ecb8646d2c605: function() { return handleError(function (arg0) {
            const ret = arg0.next();
            return ret;
        }, arguments); },
        __wbg_node_95beb7570492fd97: function(arg0) {
            const ret = arg0.node;
            return ret;
        },
        __wbg_now_bbc1cddf6e758152: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_process_b2fea42461d03994: function(arg0) {
            const ret = arg0.process;
            return ret;
        },
        __wbg_prototypesetcall_ae9f5e7459250748: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_randomFillSync_ca9f178fb14c88cb: function() { return handleError(function (arg0, arg1) {
            arg0.randomFillSync(arg1);
        }, arguments); },
        __wbg_require_7a9419e39d796c95: function() { return handleError(function () {
            const ret = module.require;
            return ret;
        }, arguments); },
        __wbg_rewind_5ce49f739d167975: function() { return handleError(function (arg0) {
            arg0.rewind();
        }, arguments); },
        __wbg_set_13d25b81ab403f5e: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
            arg0[arg1] = arg2;
        },
        __wbg_set_bf6dde4923b9b059: function(arg0, arg1, arg2) {
            const ret = arg0.set(arg1, arg2);
            return ret;
        },
        __wbg_stack_3b0d974bbf31e44f: function(arg0, arg1) {
            const ret = arg1.stack;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_static_accessor_GLOBAL_8eb4cd83130a11a0: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_THIS_1e7044f654e934db: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_d8b50611246a6d92: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_fd0bc376bf0f8b42: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_subarray_1daff70dde20c145: function(arg0, arg1, arg2) {
            const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
            return ret;
        },
        __wbg_value_c227f843d21da141: function(arg0) {
            const ret = arg0.value;
            return ret;
        },
        __wbg_versions_215a3ab1c9d5745a: function(arg0) {
            const ret = arg0.versions;
            return ret;
        },
        __wbindgen_generic_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000002: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
            const ret = getArrayU8FromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000005: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./index_bg.js": import0,
    };
}

const CensusCsvReaderFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_censuscsvreader_free(ptr, 1));
const CensusHandleFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_censushandle_free(ptr, 1));
const OpenedConfigurationFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_openedconfiguration_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (!module.ok) {
            throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
        }

        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('index_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
