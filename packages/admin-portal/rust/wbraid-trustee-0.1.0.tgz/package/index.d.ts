/* tslint:disable */
/* eslint-disable */

export class BrowserTrustee {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Called sequentially. Halted boards stay halted, including between retries.
     */
    advance(boards: string): Promise<string>;
    attest(request: string): string;
    /**
     * Includes irreversible commitments and staged-message handles, not just keys.
     */
    backup(boards: string): Promise<string>;
    /**
     * Generate the same owner-only TOML identity the native CLI accepts.
     */
    static generateKeys(): string;
    constructor(name: string, keys: string, board_url: string);
    publicKeys(): string;
    /**
     * Parse all records before writing. Existing commitments are never cleared.
     */
    restoreBackup(contents: string): Promise<string>;
    settle(board: string): void;
}

/**
 * An interactive in-browser emulator for a single `Setup` (one `Configuration`)
 * against a live b4.
 *
 * `create` generates the keys, creates the DKG board on b4, posts the
 * `Configuration` (as manager), and connects one DKG board client per trustee over
 * [`WasmHttpTransport`] with its own IndexedDB store. The protocol is driven a
 * round at a time (`step`); once the DKG reaches its fixpoint, `new_tally`
 * creates a fresh child board (unioned with the DKG parent, §8.2), posts a fresh
 * ciphertext set, and rebuilds the clients to run that tally. `state`/`verify_plaintexts`
 * inspect the current board; `export`/`import` bridge the Setup across a refresh.
 *
 * All methods do real HTTP, so they are async; mutable state sits behind a
 * `RefCell` so they can take `&self` (wasm-bindgen disallows `&mut self` on
 * async), and the driving page disables its controls while an op runs so there is
 * no re-entrancy.
 */
export class Emulator {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Generate the keys, create the DKG board on b4, post the `Configuration`,
     * and connect one DKG board client per trustee (each with its own IndexedDB store).
     *
     * Replaces whatever setup was saved: the emulator holds one at a time.
     */
    static create(b4_url: string, trustees: number, threshold: number, width: number): Promise<Emulator>;
    /**
     * The saved setup as a paste string, for moving it to another browser.
     *
     * The same bytes storage holds, so this is a copy rather than a separate
     * mechanism: a refresh needs no export, and [`restore`](Self::restore)
     * happens without it.
     */
    export(): string;
    /**
     * Forget the saved setup. The boards and IndexedDB stores it named are left
     * alone on b4 — this only drops the way back to them.
     */
    static forget(): void;
    /**
     * Whether a setup is saved and [`restore`](Self::restore) would find one.
     */
    static has_saved(): boolean;
    /**
     * Rebuild a setup from an [`export`](Self::export)ed string and reconnect it
     * to the same b4 boards + IndexedDB stores, saving it as the current setup.
     */
    static import(b4_url: string, blob: string): Promise<Emulator>;
    /**
     * Start a new tally over the completed DKG (§8.2): create a fresh child board,
     * post a fresh ciphertext set (as manager), and reconnect the clients as union
     * clients (child ∪ DKG parent, seeded with the trustees' own DKG digests).
     * Requires the DKG to have produced a public key (step it to a fixpoint first).
     */
    new_tally(ciphertexts: number): Promise<any>;
    /**
     * Reattach the trustees to a tally already started, leaving its board and
     * per-trustee stores as they are.
     *
     * The child board and each trustee's IndexedDB store outlive the clients
     * pointing at them, so returning to an earlier tally is a reconnect rather
     * than a rebuild — it resumes where that tally was left, and does not
     * disturb where the next new one goes.
     */
    open_tally(index: number): Promise<any>;
    /**
     * Reconnect to the saved setup, resuming a tally if one was under way.
     *
     * This is the ordinary way back after a page refresh — no paste involved.
     * The keys and `Configuration` come from storage; the board contents, the
     * committed sets and the DKG public key reload from b4 and IndexedDB.
     */
    static restore(b4_url: string): Promise<Emulator>;
    /**
     * This Setup's stable id (for display; also the root of every board/DB name).
     */
    setup_id(): string;
    /**
     * A snapshot of the current board's contents by message type (fetched from b4):
     * the DKG parent while in the DKG phase, or the active tally's child board.
     */
    state(): Promise<any>;
    /**
     * Advance every trustee one update-first round over the active clients. Returns
     * whether the round produced anything (false ⇒ this phase reached its fixpoint).
     */
    step(): Promise<any>;
    /**
     * Drive one trustee through update -> step -> post, leaving the others where
     * they are.
     *
     * Trustees are independent: each runs the pure `step` over its own board
     * client's view, so stepping one produces exactly what it would have
     * produced in its turn of a full round. What this buys is the interleavings
     * a lockstep round cannot show — one trustee running ahead, another left
     * behind, a message observed by some and not yet by others.
     */
    step_trustee(index: number): Promise<any>;
    /**
     * Every tally started: index, ciphertext count, board, and which is
     * attached.
     */
    tallies(): any;
    /**
     * The given trustee's persisted **committed** predicate set (§6.2) — the
     * anti-rewrite baseline. Identical to the store in the happy path; diverges
     * under anti-rewrite. Returned as readable `Debug` strings.
     */
    trustee_committed(index: number): any;
    /**
     * The number of trustees (for the page's trustee selector).
     */
    trustee_count(): number;
    /**
     * The given trustee's persisted **own-post** record (§6.4) — the outbound
     * counterpart of [`trustee_committed`](Self::trustee_committed): what this
     * trustee has staged for b4, rather than what b4 has shown it.
     *
     * In the happy path each entry appears in the committed set too, one cycle
     * later, once the message loops back. An entry that stays here *without* a
     * committed counterpart is the interesting state: b4 took the message and is
     * not serving it back, and the record is what stops the trustee recomputing
     * a second artifact for that slot. Each entry is rendered as the predicate
     * followed by its staging handle.
     */
    trustee_own_posts(index: number): any;
    /**
     * The message-store predicates the given trustee (0-based) currently holds
     * — the datalog EDB it runs on (§6.1). Returned as readable `Debug` strings.
     */
    trustee_predicates(index: number): any;
    /**
     * Compare the current tally's decrypted plaintexts with the set its
     * parameters derive.
     *
     * Deliberately not called `verify`: this checks an *outcome*, not a proof.
     * The trustees' proofs are checked by each other during the protocol; this
     * asks only whether the plaintexts that came out are the ones that went in.
     */
    verify_plaintexts(): Promise<any>;
}

export class WasmVerifier {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Pin the Ballots body from the trusted platform's original publication.
     * The full verifier subsequently checks the manager's signature as well.
     */
    static ballotsHash(encoded: string): string;
    /**
     * Derive a pin from a configuration message obtained independently from
     * a trusted election record, rather than from the board being audited.
     */
    static configurationHash(encoded: string): string;
    /**
     * Lossless public evidence, including every Configuration publication.
     * Fetching alone does not authenticate or verify the export.
     */
    static fetchTranscript(board_url: string, dkg_board: string, tally_board?: string | null): Promise<string>;
    /**
     * Verify an offline export, without private keys or trustee registration.
     */
    static verifyTranscript(evidence: string, anchors: string): string;
}

export function initThreadPool(num_threads: number): Promise<any>;

/**
 * Module-load hook: route Rust panics to the browser console. Idempotent.
 */
export function wasm_init(): void;

export class wbg_rayon_PoolBuilder {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    build(): void;
    mainJS(): string;
    numThreads(): number;
    receiver(): number;
}

export function wbg_rayon_start_worker(receiver: number): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly __wbg_browsertrustee_free: (a: number, b: number) => void;
    readonly __wbg_emulator_free: (a: number, b: number) => void;
    readonly __wbg_wasmverifier_free: (a: number, b: number) => void;
    readonly __wbg_wbg_rayon_poolbuilder_free: (a: number, b: number) => void;
    readonly browsertrustee_advance: (a: number, b: number, c: number) => any;
    readonly browsertrustee_attest: (a: number, b: number, c: number) => [number, number, number, number];
    readonly browsertrustee_backup: (a: number, b: number, c: number) => any;
    readonly browsertrustee_generateKeys: () => [number, number, number, number];
    readonly browsertrustee_new: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly browsertrustee_publicKeys: (a: number) => [number, number, number, number];
    readonly browsertrustee_restoreBackup: (a: number, b: number, c: number) => any;
    readonly browsertrustee_settle: (a: number, b: number, c: number) => [number, number];
    readonly emulator_create: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly emulator_export: (a: number) => [number, number, number, number];
    readonly emulator_forget: () => [number, number];
    readonly emulator_has_saved: () => number;
    readonly emulator_import: (a: number, b: number, c: number, d: number) => any;
    readonly emulator_new_tally: (a: number, b: number) => any;
    readonly emulator_open_tally: (a: number, b: number) => any;
    readonly emulator_restore: (a: number, b: number) => any;
    readonly emulator_setup_id: (a: number) => [number, number];
    readonly emulator_state: (a: number) => any;
    readonly emulator_step: (a: number) => any;
    readonly emulator_step_trustee: (a: number, b: number) => any;
    readonly emulator_tallies: (a: number) => [number, number, number];
    readonly emulator_trustee_committed: (a: number, b: number) => [number, number, number];
    readonly emulator_trustee_count: (a: number) => number;
    readonly emulator_trustee_own_posts: (a: number, b: number) => [number, number, number];
    readonly emulator_trustee_predicates: (a: number, b: number) => [number, number, number];
    readonly emulator_verify_plaintexts: (a: number) => any;
    readonly initThreadPool: (a: number) => any;
    readonly wasm_init: () => void;
    readonly wasmverifier_ballotsHash: (a: number, b: number) => [number, number, number, number];
    readonly wasmverifier_configurationHash: (a: number, b: number) => [number, number, number, number];
    readonly wasmverifier_fetchTranscript: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly wasmverifier_verifyTranscript: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly wbg_rayon_poolbuilder_build: (a: number) => void;
    readonly wbg_rayon_poolbuilder_mainJS: (a: number) => any;
    readonly wbg_rayon_poolbuilder_numThreads: (a: number) => number;
    readonly wbg_rayon_poolbuilder_receiver: (a: number) => number;
    readonly wbg_rayon_start_worker: (a: number) => void;
    readonly wasm_bindgen_c6801da9de488736___convert__closures_____invoke___js_sys_d4e756d15b75f0ff___Function_fn_wasm_bindgen_c6801da9de488736___JsValue_____wasm_bindgen_c6801da9de488736___sys__Undefined___js_sys_d4e756d15b75f0ff___Function_fn_wasm_bindgen_c6801da9de488736___JsValue_____wasm_bindgen_c6801da9de488736___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_c6801da9de488736___convert__closures_____invoke___wasm_bindgen_c6801da9de488736___JsValue__core_40942630fbe58d9f___result__Result_____wasm_bindgen_c6801da9de488736___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_c6801da9de488736___convert__closures_____invoke___web_sys_1df2bc3cd8971cf4___features__gen_IdbVersionChangeEvent__IdbVersionChangeEvent__core_40942630fbe58d9f___result__Result_____wasm_bindgen_c6801da9de488736___JsValue___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_c6801da9de488736___convert__closures_____invoke___js_sys_d4e756d15b75f0ff___futures__task__wait_async_polyfill__MessageEvent______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_c6801da9de488736___convert__closures_____invoke___wasm_bindgen_c6801da9de488736___JsValue______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_c6801da9de488736___convert__closures_____invoke___web_sys_1df2bc3cd8971cf4___features__gen_Event__Event______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_c6801da9de488736___convert__closures_____invoke_______true_: (a: number, b: number) => void;
    readonly memory: WebAssembly.Memory;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_thread_destroy: (a?: number, b?: number, c?: number) => void;
    readonly __wbindgen_start: (a: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number }} module - Passing `SyncInitInput` directly is deprecated.
 * @param {WebAssembly.Memory} memory - Deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number } | SyncInitInput, memory?: WebAssembly.Memory): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number }} module_or_path - Passing `InitInput` directly is deprecated.
 * @param {WebAssembly.Memory} memory - Deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number } | InitInput | Promise<InitInput>, memory?: WebAssembly.Memory): Promise<InitOutput>;
