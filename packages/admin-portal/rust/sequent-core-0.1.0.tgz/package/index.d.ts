/* tslint:disable */
/* eslint-disable */

enum IAudienceSelection {
    ALL_USERS = "ALL_USERS",
    NOT_VOTED = "NOT_VOTED",
    VOTED = "VOTED",
    SELECTED = "SELECTED"
}



enum IContestStateEnum {
    ElectionChooserScreen = "ElectionChooserScreen",
    ReceivingElection = "ReceivingElection",
    ErrorScreen = "ErrorScreen",
    HelpScreen = "HelpScreen",
    StartScreen = "StartScreen",
    MultiContest = "MultiContest",
    PairwiseBeta = "PairwiseBeta",
    DraftsElectionScreen = "DraftsElectionScreen",
    AuditBallotScreen = "AuditBallotScreen",
    PcandidatesElectionScreen = "PcandidatesElectionScreen",
    TwoContestsConditionalScreen = "TwoContestsConditionalScreen",
    SimultaneousContestsScreen = "SimultaneousContestsScreen",
    ConditionalAccordionScreen = "ConditionalAccordionScreen",
    EncryptingBallotScreen = "EncryptingBallotScreen",
    CastOrCancelScreen = "CastOrCancelScreen",
    ReviewScreen = "ReviewScreen",
    CastingBallotScreen = "CastingBallotScreen",
    SuccessScreen = "SuccessScreen",
    ShowPdf = "ShowPdf"
}



enum IInvalidPlaintextErrorType {
    Explicit = "Explicit",
    Implicit = "Implicit",
    EncodingError = "EncodingError"
}



enum ITemplateMethod {
    EMAIL = "EMAIL",
    SMS = "SMS",
    DOCUMENT = "DOCUMENT",
    WHATSAPP = "WHATSAPP",
    VIBER = "VIBER",
    MESSENGER = "MESSENGER"
}



enum ITemplateType {
    CREDENTIALS = "CREDENTIALS",
    BALLOT_RECEIPT = "BALLOT_RECEIPT",
    PARTICIPATION_REPORT = "PARTICIPATION_REPORT",
    ELECTORAL_RESULTS = "ELECTORAL_RESULTS",
    OTP = "OTP",
    MANUALLY_VERIFY_VOTER = "MANUALLY_VERIFY_VOTER",
}



export enum IPermissions {
    TENANT_CREATE = "tenant-create",
    TENANT_READ = "tenant-read",
    TENANT_WRITE = "tenant-write",
    TENANT_DELETE = "tenant-delete",
    ELECTION_EVENT_CREATE = "election-event-create",
    ELECTION_EVENT_READ = "election-event-read",
    ELECTION_EVENT_WRITE = "election-event-write",
    KEYCLOAK_REALM_ATTRIBUTES_READ = "keycloak-realm-attributes-read",
    KEYCLOAK_REALM_ATTRIBUTES_WRITE = "keycloak-realm-attributes-write",
    ELECTION_EVENT_DELETE = "election-event-delete",
    VOTER_CREATE  = "voter-create",
    VOTER_READ = "voter-read",
    VOTER_WRITE = "voter-write",
    VOTER_SECRET_ATTRIBUTE_READ = "voter-secret-attribute-read",
    VOTER_SECRET_ATTRIBUTE_WRITE = "voter-secret-attribute-write",
    USER_CREATE = "user-create",
    USER_READ = "user-read",
    USER_WRITE = "user-write",
    USER_PERMISSION_CREATE = "user-permission-create",
    USER_PERMISSION_READ = "user-permission-read",
    USER_PERMISSION_WRITE = "user-permission-write",
    ROLE_CREATE = "role-create",
    ROLE_READ = "role-read",
    ROLE_WRITE = "role-write",
    ROLE_ASSIGN = "role-assign",
    template_CREATE = "communication-template-create",
    template_READ = "communication-template-read",
    template_WRITE = "communication-template-write",
    NOTIFICATION_READ = "notification-read",
    NOTIFICATION_WRITE = "notification-write",
    NOTIFICATION_SEND = "notification-send",
    AREA_READ = "area-read",
    AREA_WRITE = "area-write",
    ELECTION_STATE_WRITE = "election-state-write",
    ELECTION_TYPE_CREATE = "election-type-create",
    ELECTION_TYPE_READ = "election-type-read",
    ELECTION_TYPE_WRITE = "election-type-write",
    VOTING_CHANNEL_READ = "voting-channel-read",
    VOTING_CHANNEL_WRITE = "voting-channel-write",
    TRUSTEE_CREATE = "trustee-create",
    TRUSTEE_READ = "trustee-read",
    TRUSTEE_WRITE = "trustee-write",
    TRUSTEE_CEREMONY = "trustee-ceremony",
    TALLY_READ = "tally-read",
    TALLY_START = "tally-start",
    TALLY_WRITE = "tally-write",
    TALLY_RESULTS_READ = "tally-results-read",
    TALLY_SHEET_IMPORT_VIEW = "tally-sheet-import-view",
    TALLY_SHEET_IMPORT_CREATE = "tally-sheet-import-create",
    TALLY_SHEET_IMPORT_REVIEW = "tally-sheet-import-review",
    TALLY_RECOUNT_EXECUTE = "tally-recount-execute",
    PUBLISH_READ = "publish-read",
    PUBLISH_WRITE = "publish-write",
    PUBLISH_RESULTS_READ = "publish-results-read",
    PUBLISH_RESULTS_WRITE = "publish-results-write",
    LOGS_READ = "logs-read",
    TASKS_READ = "tasks-read",
    KEYS_READ = "keys-read",
    DOCUMENT_UPLOAD = "document-upload",
    DOCUMENT_DOWNLOAD = "document-download",
    DOCUMENT_PASSWORD_READ = "document-password-read",
    ADMIN_CEREMONY = "admin-ceremony",
    ADMIN_DASHBOARD_VIEW = "admin-dashboard-view",
    MONITORING_VIEW = "monitoring-view",
    MONITORING_CONFIGURE = "monitoring-configure",
    TALLY_RESOLUTION_SUBMIT = "tally-resolution-submit",
    ELECTION_EVENT_SIGNATURES_TAB = "election-event-signatures-tab",
    SIGNING_RULES_READ = "signing-rules-read",
    SIGNING_RULES_WRITE = "signing-rules-write",
    SIGNING_CERTIFICATES_READ = "signing-certificates-read",
    SIGNING_ISSUERS_WRITE = "signing-issuers-write",
    SIGNING_CHECKS_WRITE = "signing-checks-write",
    SIGNING_CERTIFICATES_REGISTER = "signing-certificates-register",
    SIGNING_CERTIFICATES_REVOKE = "signing-certificates-revoke",
    SIGNING_REQUESTS_READ = "signing-requests-read",
    SIGNING_REQUESTS_CANCEL = "signing-requests-cancel",
    SIGNING_REQUESTS_EXPORT = "signing-requests-export",
    SIGN_INITIALIZE_VOTING = "sign-initialize-voting",
    SIGN_OPEN_VOTING = "sign-open-voting",
    SIGN_CLOSE_VOTING = "sign-close-voting",
    SIGN_GENERATE_ELECTION_RETURNS = "sign-generate-election-returns",
    SIGN_GENERATE_REPORTS = "sign-generate-reports",
    SIGN_TRANSMIT_RESULTS = "sign-transmit-results",
    SIGN_APPROVE_VOTER = "sign-approve-voter",
    SIGN_APPROVE_CONFIGURATION = "sign-approve-configuration",
    SIGN_KEY_CEREMONY = "sign-key-ceremony",
    SIGN_TALLY_KEY = "sign-tally-key",
}



export interface MonitoringProblem {
    severity: "error" | "warning";
    /** Stable identifier, safe to match on. Message wording is not. */
    code: string;
    /** Dotted path into the document: `chart.charts.bars[0].query`. */
    path: string;
    message: string;
    engine_code?: string;
}

export interface MonitoringReport {
    problems: MonitoringProblem[];
}



export type Severity = "error" | "warning";

export interface Problem {
    severity: Severity;
    /** Stable identifier, safe to match on. Message wording is not. */
    code: string;
    /** Where: a bundle path, or a sheet and row for a source document. */
    path: string;
    message: string;
    external_id?: string;
    /**
     * Where in a source spreadsheet, structurally — so a screen can group by tab
     * and point at a cell rather than parsing `path` back apart. Absent for a
     * problem about a plan or a bundle, neither of which has a row 12.
     */
    at?: {sheet: string; row?: number; column?: string};
}

export interface Report {
    problems: Problem[];
}

/**
 * What `openConfiguration` made of the bytes it was given.
 *
 * `plan` is null when nothing could be read, and `report` says why — a report
 * rather than a thrown error, because a screen can group one by tab and point at
 * cells with it.
 */
export interface Opened {
    plan: unknown | null;
    report: Report;
    source?:
    | "delivery"
    | "plan"
    | "workbook"
    | "election-event"
    | "election-event-archive";
}

/** The verdict every caller of the validator must reach on a fixture. */
export interface Expect {
    errors: string[];
    warnings: string[];
}

/** A bundle with a known verdict, for a front end's own test suite. */
export interface FixtureCase {
    name: string;
    /** Why the case exists. Read this before changing what it expects. */
    why: string;
    bundle: unknown;
    expect: Expect;
}

/** One file to offer as a download. */
export interface Artifact {
    name: string;
    bytes: Uint8Array;
}

export interface BuildOutput {
    /** Empty when the build failed; check `report` first. */
    importable: Artifact[];
    /** Files that must NOT go inside the archive. */
    auxiliary: Artifact[];
    /**
     * The whole delivery: a zip that is *not* importable, holding one that is.
     *
     * `official_election_setup.zip` nested beside the reopenable plan and the files a
     * person needs. Only a plan build produces one.
     */
    delivery?: Artifact;

    /** The importable archive, ready to download. */
    archive?: Artifact;
    /** Everything found, errors and warnings together. */
    report: Report;
    /** Absent when the build failed. */
    event_external_id?: string;
}

/**
 * The ballots a plan's voters would be given.
 *
 * The same five keys, in the same shape, as the publication preview the platform
 * writes to its public bucket — so the Voting Portal itself can open this
 * document, and what it draws is not our idea of a ballot but its own.
 *
 * `ballot_styles` holds one entry per area and election, each of them the
 * `ballot_eml` a `ballot_style` row carries. Its type is `IBallotStyle` from
 * `@sequentech/ui-core`, which this package does not depend on, so it is left as
 * `unknown` rather than described a second time and allowed to drift.
 */
export interface BallotPreview {
    ballot_styles: unknown[];
    election_event: unknown;
    elections: unknown[];
    support_materials: unknown[];
    documents: unknown[];
}

export interface PreviewOutput {
    /** Absent when the plan could not be compiled; read `report`. */
    preview?: BallotPreview;
    /**
     * The areas those ballots belong to, named.
     *
     * Not inside `preview`, on purpose: a ballot style names its area by id and
     * that is exactly what the platform writes, so adding a key would stop the
     * document being the same file. This sits beside it because a picker
     * offering four uuids is not a choice anybody can make.
     */
    areas: Array<{id: string; name: string}>;
    /**
     * The elections those ballots belong to, named, for the same reason.
     *
     * A voter is handed one area's ballot for one election, so the preview shows
     * one of each — every election at once is a page nobody ever sees. An
     * election carries no `name` column; the platform keeps it under
     * `presentation.i18n.<lang>.name`, and this falls back to `external_id`,
     * which is a word the author typed.
     */
    elections: Array<{id: string; name: string}>;
    /** Everything found on the way, errors and warnings together. */
    report: Report;
}

/**
 * A census the host holds, read a batch at a time.
 *
 * The reason this is an interface and not an array: a census can be ten million
 * members, and handing that over as one value means holding it twice while the
 * boundary copies it. So the core pulls, and the rows are alive only for as long
 * as it takes to turn one batch into voters.
 *
 * `CensusCsvReader` implements it as it stands — deliberately. A CSV the browser
 * has already parsed should not be parsed again to be handed over.
 */
export interface CensusPull {
    /** The columns a row will have, in order. Answerable before any row. */
    columns(): string[];
    /** Back to the first row; one compile reads the census more than once. */
    rewind(): void;
    /** The next `size` rows, aligned to `columns()`. Empty when done. */
    nextBatch(size: number): string[][];
}

/**
 * What `compilePlan` and `previewBallot` accept beside the plan.
 *
 * Both fields are optional and both are new. Passing neither is what every caller
 * did until now and still means the same thing: the census and the files are read
 * off the plan itself.
 */
export interface CompileOptions {
    /** Where the voters come from, instead of `plan.voters`. */
    census?: CensusPull;
    /**
     * The bytes the plan's file names refer to — a logo, a candidate's
     * photograph, a support material. Keyed by the name the plan carries.
     */
    files?: Record<string, Uint8Array>;
}

/**
 * What the bytes handed to `openFile` turned out to be.
 *
 * `plan-archive` is the wizard's own save file. `delivery` is what a build hands
 * over. `plan` is a bare `blueprint.json`, which still opens and no longer gets
 * written.
 */
export type OpenedSource =
| "delivery"
| "plan"
| "plan-archive"
| "workbook"
| "election-event"
| "election-event-archive";



interface ICandidateProperties {
    points?: number;
    write_in?: string;
}



interface ICommTemplates {
    email: IEmail;
    sms: ISmsConfig;
}



interface IContestLayoutProperties {
    state: string;
    sorted: boolean;
    ordered: boolean;
}



interface IDecodedVoteChoice {
    id: string;
    selected: number;
    write_in_text?: string;
}



interface IDecodedVoteContest {
    contest_id: string;
    is_explicit_invalid: boolean;
    is_decline_to_vote: boolean;
    is_blank_ballot: boolean;
    invalid_errors: Array<IInvalidPlaintextError>;
    invalid_alerts: Array<IInvalidPlaintextError>;
    choices: Array<IDecodedVoteChoice>;
}



interface IEmailConfig {
    subject: string;
    plaintext_body: string;
    html_body: string;
}



interface IExtraConfig {
    pdf_options: string;
    report_options: string;
    communication_templates: ICommTemplates;
}



interface IInvalidPlaintextError {
    error_type: IInvalidPlaintextErrorType;
    candidate_id?: string;
    message?: string;
    message_map: { [key: string]: string };
}



interface IPermission {
    id?: string;
    attributes: {[key: string]: any};
    container_id?: string;
    description?: string;
    name?: string;
}



interface IRole {
    id?: string;
    name?: string;
    permissions?: Array<string>;
    access?: {[key: string]: any};
    attributes?: {[key: string]: any};
    client_roles?: {[key: string]: any};
}



interface ISendTemplateBody {
    audience_selection: IAudienceSelection;
    audience_voter_ids?: Array<string>;
    type: ITemplateType;
    communication_method: ITemplateMethod;
    schedule_now: boolean;
    schedule_date?: string;
    name?: string;
    alias?: string;
    document?: string;
    extra_config?: IExtraConfig;
    secret_attribute_names?: Array<string>;
    schedule_local?: string;
    schedule_timezone?: string;
}



interface ISmsConfig {
    message: string;
}



interface IUser {
    id?: string;
    attributes?: {[key: string]: any};
    email?: string;
    email_verified?: boolean;
    enabled?: boolean;
    first_name?: string;
    last_name?: string;
    username?: string;
    password?: string;
    area?: IUserArea;
    votes_info?: Array<IVotesInfo>;
}



interface IUserArea {
    id?: string;
    name?: string;
}



interface IVotesInfo {
    election_id: string;
    num_votes: Int;
    last_voted_at: string;
}



interface IVotingChannels {
    online?: boolean;
    kiosk?: boolean;
    telephone?: boolean;
    paper?: boolean;
}



type IVotingScreenBackPolicy = "election-selection-screen" | "start-screen";



/**
 * A census CSV, read a batch at a time.
 *
 * A handle rather than a function returning every voter, and that is the whole
 * point: a hundred thousand members crossing the boundary at once is the copy
 * this exists to avoid. The caller asks for a batch, turns it into whatever it
 * stores, and drops it before asking for the next.
 *
 * The wizard used to parse this in TypeScript. Two parsers meant two answers to
 * "what is in this file", and on a census that is how a quoted comma read one way
 * by the loader and another by the saver turns one member into two on the way
 * out.
 */
export class CensusCsvReader {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The columns a voter will have, in order, with the derived ones dropped.
     */
    columns(): any;
    /**
     * Read a native census or a recognized source format. Throws if the file is
     * empty or its required identity column is missing.
     */
    constructor(text: string);
    /**
     * The next `size` rows as arrays of strings. Empty when the file is done.
     */
    nextBatch(size: number): any;
    /**
     * What was odd about the file without being wrong with it.
     */
    notes(): any;
}

/**
 * Returns the selection that choosing a slate produces from the current one,
 * and what it changes. Throws the list of problems of a slate that cannot be
 * applied.
 */
export function apply_slate_js(slate_json: any, contests_json: any, current_json: any): any;

export function bench(n: number): void;

export function bench_enc_pok(n: number): void;

export function bench_modpow(n: number): void;

/**
 * Returns the slate configuration in the form it is stored and published.
 * Throws the list of problems of a configuration that cannot be read.
 */
export function canonicalize_slates_js(annotation: string): string;

/**
 * Check an existing export, the way the server would.
 *
 * Takes the `export_election_event-<id>.json` document as text. Returns the same
 * [`Report`] the importer produces, so a page can show the problems before anyone
 * uploads anything.
 */
export function checkBundle(document: string): Report;

/**
 * Checks a slate configuration against the contests and candidates of its
 * election, given as JSON arrays of rows. Returns the list of problems,
 * empty when the configuration can be published.
 */
export function check_election_slates_js(annotation: string, default_language: string, contests_json: string, candidates_json: string): any;

export function check_is_blank_js(decoded_contest_json: any): any;

export function check_voting_error_dialog(contests: any, decoded_contests: any): any;

export function check_voting_not_allowed_next(contests: any, decoded_contests: any): any;

export function create_tree_js(areas_json: any, area_contests_json: any): any;

export function decode_auditable_ballot_js(auditable_ballot_json: any): any;

export function decode_auditable_multi_ballot_js(auditable_multi_ballot_json: any): any;

export function encrypt_decoded_contest_js(decoded_contests_json: any, election_json: any): any;

export function encrypt_decoded_multi_contest_js(decoded_multi_contests_json: any, election_json: any): any;

/**
 * The bundles a front end's own tests should agree with.
 *
 * The same list the Rust tests run, handed over as data rather than reimplemented
 * in TypeScript. A front end asserting `checkBundle(case.bundle)` matches
 * `case.expect` is checking that the browser and the server reach the same verdict
 * — which is the only thing that makes one validator worth having. A suite written
 * separately would prove only that each side agrees with itself.
 */
export function fixtureCases(): any;

export function forget_voter_signing_key_js(election_id: any): void;

export function generate_sample_auditable_ballot_js(): any;

export function get_auth_url_js(base_url_json: any, tenant_id_json: any, event_id_json: any, auth_action_json: any): any;

/**
 * Returns what each slate covers of the ballot style's contests, in the
 * configured order and without the slates that have no candidate in them.
 * Returns null when the election has no slates. Throws the list of problems
 * of an invalid configuration.
 */
export function get_ballot_style_slates_coverage_js(ballot_style_json: any): any;

/**
 * Returns the slates the ballot style carries, or null when its election
 * has none. Throws the list of problems of an invalid configuration.
 */
export function get_ballot_style_slates_js(ballot_style_json: any): any;

export function get_candidate_points_js(contest_json: any, candidate_val: any): any;

export function get_contest_matches_js(contests_tree_js: any, contest_id_js: any): any;

/**
 * Returns the default blank ballots policy
 */
export function get_default_blank_ballots_policy_js(): any;

export function get_default_consolidated_report_policy_js(): any;

/**
 * Returns the default decline to vote policy
 */
export function get_default_decline_to_vote_policy_js(): any;

export function get_default_duplicated_rank_policy_js(): any;

export function get_default_language_detection_policy_js(): any;

export function get_default_preference_gaps_policy_js(): any;

/**
 * Returns the default voting screen back policy
 */
export function get_default_voting_screen_back_policy_js(): any;

export function get_layout_properties_from_contest_js(contest_json: any): any;

/**
 * Returns all the voting screen back policy values
 */
export function get_voting_screen_back_policy_values_js(): any;

export function get_write_in_available_characters_js(decoded_contest_json: any, ballot_style_json: any): any;

export function hash_auditable_ballot_js(auditable_ballot_json: any): any;

export function hash_auditable_multi_ballot_js(auditable_multi_ballot_json: any): any;

/**
 * Exposes the canonical acclaimed-candidate policy to browser consumers.
 */
export function is_eligible_acclaimed_candidate_js(candidate_json: any): boolean;

export function is_preferential_js(counting_algorithm_js: any): any;

export function iso_639_2t_to_bcp47_js(lang: string): string;

export function locale_to_internal_language_code_js(lang: string): string;

export function normalize_ballot_id_js(typed: any): any;

/**
 * Every report type and the formats it can be generated in, the first being
 * its default, so the Reports step offers only what the platform renders.
 */
export function reportCatalog(): any;

export function set_hooks(): void;

export function sign_ballot_cast_js(election_id: any, voter_signing_pk: any, ballot_id: any): any;

export function sign_hashable_ballot_with_ephemeral_voter_signing_key_js(ballot_id: any, election_id: any, content: any): any;

export function sign_hashable_multi_ballot_with_ephemeral_voter_signing_key_js(ballot_id: any, election_id: any, auditable_multi_ballot_json: any): any;

export function sort_candidates_list_js(all_candidates: any, order: any, apply_random: any): any;

export function sort_contests_list_js(contests_json: any, order: any, apply_random: any): any;

export function sort_elections_list_js(elections_json: any, order: any, apply_random: any): any;

export function test(): void;

export function test_chaumpedersen(): void;

export function test_contest_reencoding_js(decoded_contest_json: any, ballot_style_json: any): any;

export function test_elgamal(): void;

export function test_multi_contest_reencoding_js(decoded_multi_contest_json: any, ballot_style_json: any): any;

export function test_rerand(): void;

export function test_schnorr(): void;

export function test_vdecryption(): void;

export function to_hashable_ballot_js(auditable_ballot_json: any): any;

export function to_hashable_multi_ballot_js(auditable_multi_ballot_json: any): any;

/**
 * Checks `yaml` as the monitoring document of `kind` (`widget`,
 * `dashboard`, `theme` or `settings`) stored under `key`, alone or, given
 * the event's documents as JSON in `config_set_json`, against them.
 */
export function validateMonitoringConfig(kind: string, key: string, yaml: string, config_set_json: string): any;

export function validate_area_contest_results_js(content_json: any, contest_bounds_json: any): any;

export function validate_ballot_box_blank_ballots_js(contest_sheets_json: any): any;

export function verify_ballot_signature_js(ballot_id: any, election_id: any, content: any): any;

export function verify_cast_receipt_js(ballot_box_key: any, cast_receipt: any): any;

export function verify_multi_ballot_signature_js(ballot_id: any, election_id: any, auditable_multi_ballot_json: any): any;

export function verify_received_ballot_js(ballot_box_key: any, received_ballot: any): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_censuscsvreader_free: (a: number, b: number) => void;
    readonly apply_slate_js: (a: any, b: any, c: any) => [number, number, number];
    readonly bench: (a: number) => void;
    readonly bench_enc_pok: (a: number) => void;
    readonly bench_modpow: (a: number) => void;
    readonly canonicalize_slates_js: (a: number, b: number) => [number, number, number, number];
    readonly censuscsvreader_columns: (a: number) => [number, number, number];
    readonly censuscsvreader_new: (a: number, b: number) => [number, number, number];
    readonly censuscsvreader_nextBatch: (a: number, b: number) => [number, number, number];
    readonly censuscsvreader_notes: (a: number) => [number, number, number];
    readonly checkBundle: (a: number, b: number) => [number, number, number];
    readonly check_election_slates_js: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly check_is_blank_js: (a: any) => [number, number, number];
    readonly check_voting_error_dialog: (a: any, b: any) => [number, number, number];
    readonly check_voting_not_allowed_next: (a: any, b: any) => [number, number, number];
    readonly create_tree_js: (a: any, b: any) => [number, number, number];
    readonly decode_auditable_ballot_js: (a: any) => [number, number, number];
    readonly decode_auditable_multi_ballot_js: (a: any) => [number, number, number];
    readonly encrypt_decoded_contest_js: (a: any, b: any) => [number, number, number];
    readonly encrypt_decoded_multi_contest_js: (a: any, b: any) => [number, number, number];
    readonly fixtureCases: () => [number, number, number];
    readonly forget_voter_signing_key_js: (a: any) => [number, number];
    readonly generate_sample_auditable_ballot_js: () => [number, number, number];
    readonly get_auth_url_js: (a: any, b: any, c: any, d: any) => [number, number, number];
    readonly get_ballot_style_slates_coverage_js: (a: any) => [number, number, number];
    readonly get_ballot_style_slates_js: (a: any) => [number, number, number];
    readonly get_candidate_points_js: (a: any, b: any) => [number, number, number];
    readonly get_contest_matches_js: (a: any, b: any) => [number, number, number];
    readonly get_default_blank_ballots_policy_js: () => [number, number, number];
    readonly get_default_consolidated_report_policy_js: () => [number, number, number];
    readonly get_default_decline_to_vote_policy_js: () => [number, number, number];
    readonly get_default_duplicated_rank_policy_js: () => [number, number, number];
    readonly get_default_language_detection_policy_js: () => [number, number, number];
    readonly get_default_preference_gaps_policy_js: () => [number, number, number];
    readonly get_default_voting_screen_back_policy_js: () => [number, number, number];
    readonly get_layout_properties_from_contest_js: (a: any) => [number, number, number];
    readonly get_voting_screen_back_policy_values_js: () => [number, number, number];
    readonly get_write_in_available_characters_js: (a: any, b: any) => [number, number, number];
    readonly hash_auditable_ballot_js: (a: any) => [number, number, number];
    readonly hash_auditable_multi_ballot_js: (a: any) => [number, number, number];
    readonly is_eligible_acclaimed_candidate_js: (a: any) => [number, number, number];
    readonly is_preferential_js: (a: any) => [number, number, number];
    readonly iso_639_2t_to_bcp47_js: (a: number, b: number) => [number, number];
    readonly locale_to_internal_language_code_js: (a: number, b: number) => [number, number];
    readonly normalize_ballot_id_js: (a: any) => [number, number, number];
    readonly reportCatalog: () => [number, number, number];
    readonly set_hooks: () => void;
    readonly sign_ballot_cast_js: (a: any, b: any, c: any) => [number, number, number];
    readonly sign_hashable_ballot_with_ephemeral_voter_signing_key_js: (a: any, b: any, c: any) => [number, number, number];
    readonly sign_hashable_multi_ballot_with_ephemeral_voter_signing_key_js: (a: any, b: any, c: any) => [number, number, number];
    readonly sort_candidates_list_js: (a: any, b: any, c: any) => [number, number, number];
    readonly sort_contests_list_js: (a: any, b: any, c: any) => [number, number, number];
    readonly sort_elections_list_js: (a: any, b: any, c: any) => [number, number, number];
    readonly test: () => void;
    readonly test_chaumpedersen: () => void;
    readonly test_contest_reencoding_js: (a: any, b: any) => [number, number, number];
    readonly test_elgamal: () => void;
    readonly test_multi_contest_reencoding_js: (a: any, b: any) => [number, number, number];
    readonly test_rerand: () => void;
    readonly test_schnorr: () => void;
    readonly test_vdecryption: () => void;
    readonly to_hashable_ballot_js: (a: any) => [number, number, number];
    readonly to_hashable_multi_ballot_js: (a: any) => [number, number, number];
    readonly validateMonitoringConfig: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly validate_area_contest_results_js: (a: any, b: any) => [number, number, number];
    readonly validate_ballot_box_blank_ballots_js: (a: any) => [number, number, number];
    readonly verify_ballot_signature_js: (a: any, b: any, c: any) => [number, number, number];
    readonly verify_cast_receipt_js: (a: any, b: any) => [number, number, number];
    readonly verify_multi_ballot_signature_js: (a: any, b: any, c: any) => [number, number, number];
    readonly verify_received_ballot_js: (a: any, b: any) => [number, number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
