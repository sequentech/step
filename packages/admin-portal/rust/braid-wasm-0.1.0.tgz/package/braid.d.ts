/* tslint:disable */
/* eslint-disable */
export function initThreadPool(num_threads: number): Promise<any>;
export function wbg_rayon_start_worker(receiver: number): void;
/**
 * Main WASM session interface
 *
 * Wraps a braid::protocol::session::Session with browser-specific functionality
 * The protocol execution cycle is managed by the inner session.
 */
export class WasmSession {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Create a new trustee from a JSON configuration string
   *
   * Config format:
   * ```json
   * {
   *   "name": "trustee1",
   *   "b4_url": "http://localhost:8000",
   *   "signing_key_sk": "<base64-der>",
   *   "signing_key_pk": "<base64-der>",
   *   "encryption_key": "<base64>"
   * }
   * ```
   */
  constructor(config_json: string);
  /**
   * Initialize a session for a specific board
   *
   * This creates the Trustee object and initializes IndexedDB storage.
   * Must be called before connect_to_board() or step().
   */
  init_session(board_name: string): Promise<void>;
  /**
   * Connect to a board and perform initial synchronization
   *
   * This should be called after init_session() to fetch existing messages
   * from the remote board and update the local board state, without executing
   * any protocol steps. This allows the UI to display the current board state
   * before the user starts stepping through the protocol.
   *
   * Returns the number of messages fetched and added to the local board.
   */
  connect_to_board(): Promise<any>;
  /**
   * Fetch list of available boards from B4
   */
  fetch_boards(): Promise<any>;
  /**
   * Perform one protocol step
   *
   * This:
   * 1. Fetches new messages from B4
   * 2. Processes them through the trustee
   * 3. Posts any resulting messages back to B4
   *
   * Returns information about actions taken
   */
  step(): Promise<any>;
  /**
   * Get current state of the trustee for visualization
   */
  get_state(): any;
  /**
   * Clear persistent storage (for testing)
   *
   * This clears the IndexedDB storage, allowing a fresh start.
   * Note: This does NOT reset the session - you'll need to reload the page
   * or call init_session() again after clearing.
   */
  clear_storage(): Promise<void>;
  /**
   * Update the access token for B4 authentication
   *
   * This should be called when the token is refreshed (tokens typically expire).
   * Because the token is behind `Arc<RwLock<>>`, this update is immediately
   * visible to the `Session`'s board factory (they share the same Arc).
   */
  update_access_token(token: string): void;
  /**
   * Get board summary - list of statements in local board
   */
  get_board_summary(): any;
  /**
   * Get storage diagnostics information
   *
   * Returns information about the storage backend including:
   * - Backend type (IndexedDbStorage)
   * - Total messages stored (hash metadata count)
   * - Maximum internal ID (locally-controlled, security-critical)
   * - Maximum external ID (from bulletin board, optimization only)
   */
  get_storage_info(): any;
  /**
   * Send a heartbeat to B4 for the current board.
   *
   * Call this every `BRAID_B4_HEARTBEAT` seconds from the JS polling loop.
   */
  heartbeat(trustee_name: string): Promise<void>;
  /**
   * Get the current board name (if session initialized)
   */
  readonly board_name: string | undefined;
  /**
   * Get the trustee name
   */
  readonly name: string;
  /**
   * Get the B4 URL
   */
  readonly b4_url: string;
}
/**
 * WASM verifier for browser-based election verification
 */
export class WasmVerifier {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Create a new WASM verifier
   *
   * # Arguments
   * * `b4_url` - URL of the B4 server (e.g., "http://localhost:8000")
   * * `access_token` - JWT access token for B4 authentication
   */
  constructor(b4_url: string, access_token: string);
  /**
   * Verify an election board
   *
   * This performs comprehensive verification including:
   * - Configuration validity
   * - Message signature verification
   * - Public key construction verification
   * - Mixing proofs verification
   * - Decryption proofs verification
   *
   * Returns a JSON summary of verification results
   */
  verify_board(board_name: string): Promise<any>;
  /**
   * Get the current board name being verified
   */
  readonly board_name: string | undefined;
  /**
   * Get the B4 URL
   */
  readonly b4_url: string;
}
export class wbg_rayon_PoolBuilder {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  mainJS(): string;
  numThreads(): number;
  receiver(): number;
  build(): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly __wbg_wasmsession_free: (a: number, b: number) => void;
  readonly wasmsession_new: (a: number, b: number) => [number, number, number];
  readonly wasmsession_init_session: (a: number, b: number, c: number) => any;
  readonly wasmsession_connect_to_board: (a: number) => any;
  readonly wasmsession_fetch_boards: (a: number) => any;
  readonly wasmsession_step: (a: number) => any;
  readonly wasmsession_get_state: (a: number) => [number, number, number];
  readonly wasmsession_clear_storage: (a: number) => any;
  readonly wasmsession_board_name: (a: number) => [number, number];
  readonly wasmsession_name: (a: number) => [number, number];
  readonly wasmsession_b4_url: (a: number) => [number, number];
  readonly wasmsession_update_access_token: (a: number, b: number, c: number) => void;
  readonly wasmsession_get_board_summary: (a: number) => [number, number, number];
  readonly wasmsession_get_storage_info: (a: number) => [number, number, number];
  readonly wasmsession_heartbeat: (a: number, b: number, c: number) => any;
  readonly __wbg_wasmverifier_free: (a: number, b: number) => void;
  readonly wasmverifier_new: (a: number, b: number, c: number, d: number) => number;
  readonly wasmverifier_verify_board: (a: number, b: number, c: number) => any;
  readonly wasmverifier_board_name: (a: number) => [number, number];
  readonly wasmverifier_b4_url: (a: number) => [number, number];
  readonly __wbg_wbg_rayon_poolbuilder_free: (a: number, b: number) => void;
  readonly wbg_rayon_poolbuilder_mainJS: (a: number) => any;
  readonly wbg_rayon_poolbuilder_numThreads: (a: number) => number;
  readonly wbg_rayon_poolbuilder_receiver: (a: number) => number;
  readonly wbg_rayon_poolbuilder_build: (a: number) => void;
  readonly initThreadPool: (a: number) => any;
  readonly wbg_rayon_start_worker: (a: number) => void;
  readonly memory: WebAssembly.Memory;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_5: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_export_7: WebAssembly.Table;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly closure314_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure499_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure644_externref_shim: (a: number, b: number, c: any, d: any) => void;
  readonly __wbindgen_thread_destroy: (a?: number, b?: number, c?: number) => void;
  readonly __wbindgen_start: (a: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number }} module - Passing `SyncInitInput` directly is deprecated.
* @param {WebAssembly.Memory} memory - Deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number } | SyncInitInput, memory?: WebAssembly.Memory): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number }} module_or_path - Passing `InitInput` directly is deprecated.
* @param {WebAssembly.Memory} memory - Deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number } | InitInput | Promise<InitInput>, memory?: WebAssembly.Memory): Promise<InitOutput>;
