/* tslint:disable */
/* eslint-disable */

/**
 * Main WASM session interface
 *
 * Wraps a braid::protocol::session::Session with browser-specific functionality
 * The protocol execution cycle is managed by the inner session.
 */
export class WasmSession {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Clear persistent storage (for testing)
     *
     * This clears the IndexedDB storage, allowing a fresh start.
     * Note: This does NOT reset the session - you'll need to reload the page
     * or call init_session() again after clearing.
     */
    clear_storage(): Promise<void>;
    /**
     * Connect to a board and perform initial synchronization
     *
     * This should be called after init_session() to fetch existing messages
     * from the remote board and update the local board state, without executing
     * any protocol steps. This allows the UI to display the current board state
     * before the user starts stepping through the protocol.
     *
     * Returns the number of messages fetched and added to the local board.
     */
    connect_to_board(): Promise<any>;
    /**
     * Fetch list of available boards from B4
     */
    fetch_boards(): Promise<any>;
    /**
     * Get board summary - list of statements in local board
     */
    get_board_summary(): any;
    /**
     * Get current state of the trustee for visualization
     */
    get_state(): any;
    /**
     * Get storage diagnostics information
     *
     * Returns information about the storage backend including:
     * - Backend type (IndexedDbStorage)
     * - Total messages stored (hash metadata count)
     * - Maximum internal ID (locally-controlled, security-critical)
     * - Maximum external ID (from bulletin board, optimization only)
     */
    get_storage_info(): any;
    /**
     * Initialize a session for a specific board
     *
     * This creates the Trustee object and initializes IndexedDB storage.
     * Must be called before connect_to_board() or step().
     */
    init_session(board_name: string): Promise<void>;
    /**
     * Create a new trustee from a JSON configuration string
     *
     * Config format:
     * ```json
     * {
     *   "name": "trustee1",
     *   "b4_url": "http://localhost:8000",
     *   "signing_key_sk": "<base64-der>",
     *   "signing_key_pk": "<base64-der>",
     *   "encryption_key": "<base64>"
     * }
     * ```
     */
    constructor(config_json: string);
    /**
     * Perform one protocol step
     *
     * This:
     * 1. Fetches new messages from B4
     * 2. Processes them through the trustee
     * 3. Posts any resulting messages back to B4
     *
     * Returns information about actions taken
     */
    step(): Promise<any>;
    /**
     * Get the B4 URL
     */
    readonly b4_url: string;
    /**
     * Get the current board name (if session initialized)
     */
    readonly board_name: string | undefined;
    /**
     * Get the trustee name
     */
    readonly name: string;
}

/**
 * WASM verifier for browser-based election verification
 */
export class WasmVerifier {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a new WASM verifier
     *
     * # Arguments
     * * `b4_url` - URL of the B4 server (e.g., "http://localhost:8000")
     */
    constructor(b4_url: string);
    /**
     * Verify an election board
     *
     * This performs comprehensive verification including:
     * - Configuration validity
     * - Message signature verification
     * - Public key construction verification
     * - Mixing proofs verification
     * - Decryption proofs verification
     *
     * Returns a JSON summary of verification results
     */
    verify_board(board_name: string): Promise<any>;
    /**
     * Get the B4 URL
     */
    readonly b4_url: string;
    /**
     * Get the current board name being verified
     */
    readonly board_name: string | undefined;
}

export function initThreadPool(num_threads: number): Promise<any>;

export class wbg_rayon_PoolBuilder {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    build(): void;
    mainJS(): string;
    numThreads(): number;
    receiver(): number;
}

export function wbg_rayon_start_worker(receiver: number): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly __wbg_wasmsession_free: (a: number, b: number) => void;
    readonly __wbg_wasmverifier_free: (a: number, b: number) => void;
    readonly __wbg_wbg_rayon_poolbuilder_free: (a: number, b: number) => void;
    readonly initThreadPool: (a: number) => any;
    readonly wasmsession_b4_url: (a: number) => [number, number];
    readonly wasmsession_board_name: (a: number) => [number, number];
    readonly wasmsession_clear_storage: (a: number) => any;
    readonly wasmsession_connect_to_board: (a: number) => any;
    readonly wasmsession_fetch_boards: (a: number) => any;
    readonly wasmsession_get_board_summary: (a: number) => [number, number, number];
    readonly wasmsession_get_state: (a: number) => [number, number, number];
    readonly wasmsession_get_storage_info: (a: number) => [number, number, number];
    readonly wasmsession_init_session: (a: number, b: number, c: number) => any;
    readonly wasmsession_name: (a: number) => [number, number];
    readonly wasmsession_new: (a: number, b: number) => [number, number, number];
    readonly wasmsession_step: (a: number) => any;
    readonly wasmverifier_b4_url: (a: number) => [number, number];
    readonly wasmverifier_board_name: (a: number) => [number, number];
    readonly wasmverifier_new: (a: number, b: number) => number;
    readonly wasmverifier_verify_board: (a: number, b: number, c: number) => any;
    readonly wbg_rayon_poolbuilder_build: (a: number) => void;
    readonly wbg_rayon_poolbuilder_mainJS: (a: number) => any;
    readonly wbg_rayon_poolbuilder_numThreads: (a: number) => number;
    readonly wbg_rayon_poolbuilder_receiver: (a: number) => number;
    readonly wbg_rayon_start_worker: (a: number) => void;
    readonly wasm_bindgen_e3f39f4eb4fb78e5___convert__closures_____invoke___js_sys_724edbc1d360853d___Function_fn_wasm_bindgen_e3f39f4eb4fb78e5___JsValue_____wasm_bindgen_e3f39f4eb4fb78e5___sys__Undefined___js_sys_724edbc1d360853d___Function_fn_wasm_bindgen_e3f39f4eb4fb78e5___JsValue_____wasm_bindgen_e3f39f4eb4fb78e5___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_e3f39f4eb4fb78e5___convert__closures_____invoke___wasm_bindgen_e3f39f4eb4fb78e5___JsValue__core_40942630fbe58d9f___result__Result_____wasm_bindgen_e3f39f4eb4fb78e5___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_e3f39f4eb4fb78e5___convert__closures_____invoke___js_sys_724edbc1d360853d___futures__task__wait_async_polyfill__MessageEvent______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_e3f39f4eb4fb78e5___convert__closures_____invoke___wasm_bindgen_e3f39f4eb4fb78e5___JsValue______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_e3f39f4eb4fb78e5___convert__closures_____invoke___wasm_bindgen_e3f39f4eb4fb78e5___JsValue______true__26: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_e3f39f4eb4fb78e5___convert__closures_____invoke___wasm_bindgen_e3f39f4eb4fb78e5___JsValue______true__27: (a: number, b: number, c: any) => void;
    readonly memory: WebAssembly.Memory;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_thread_destroy: (a?: number, b?: number, c?: number) => void;
    readonly __wbindgen_start: (a: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number }} module - Passing `SyncInitInput` directly is deprecated.
 * @param {WebAssembly.Memory} memory - Deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number } | SyncInitInput, memory?: WebAssembly.Memory): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number }} module_or_path - Passing `InitInput` directly is deprecated.
 * @param {WebAssembly.Memory} memory - Deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number } | InitInput | Promise<InitInput>, memory?: WebAssembly.Memory): Promise<InitOutput>;
