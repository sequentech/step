/* tslint:disable */
/* eslint-disable */
export function set_hooks(): void;
/**
 * Export the in-memory private key identified by `key_id` into an encrypted
 * key file JSON object.
 */
export function export_private_key_file_js(key_id: number, election_id: string, trustee_id: string, public_key_b64: string, passphrase: string, iterations: number): any;
/**
 * Import a key file JSON object and restore the private key in memory.
 */
export function import_private_key_file_js(file: any, passphrase: string): any;
/**
 * Compute the SHA-256 hash (hex) of an arbitrary byte array provided from JS.
 */
export function sha256_hex_js(data: Uint8Array): string;
/**
 * Build an ArtifactEnvelope from raw bytes and S3 metadata. This is intended
 * to be used after uploading an artifact to S3 via a presigned URL.
 */
export function make_artifact_envelope_js(bucket: string, key: string, content_type: string, kind: string, data: Uint8Array): any;
/**
 * Sign an arbitrary payload for posting to the bulletin board and package it
 * together with optional artifact metadata.
 *
 * The actual network I/O is performed by the JS/TypeScript side; this helper
 * focuses on computing the signature and producing a serialisable envelope.
 */
export function build_signed_board_message_js(key_id: number, board: string, payload: Uint8Array, artifact: any, public_key_b64: string): any;
export function generate_trustee_keypair_js(election_id: string, trustee_id: string, iterations: number): any;
/**
 * Recompute the deterministic PBKDF2 commitment for an in-memory key
 * identified by `key_id`.
 */
export function recompute_key_commitment_js(key_id: number, election_id: string, trustee_id: string, iterations: number): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly export_private_key_file_js: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number, number];
  readonly import_private_key_file_js: (a: any, b: number, c: number) => [number, number, number];
  readonly sha256_hex_js: (a: any) => [number, number];
  readonly make_artifact_envelope_js: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: any) => [number, number, number];
  readonly build_signed_board_message_js: (a: number, b: number, c: number, d: any, e: any, f: number, g: number) => [number, number, number];
  readonly generate_trustee_keypair_js: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
  readonly recompute_key_commitment_js: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
  readonly set_hooks: () => void;
  readonly ring_core_0_17_14__bn_mul_mont: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_4: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
