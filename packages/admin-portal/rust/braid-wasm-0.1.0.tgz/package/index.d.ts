/* tslint:disable */
/* eslint-disable */
/**
 * Initialize the WASM module with console logging
 */
export function init(): void;
export function initThreadPool(num_threads: number): Promise<any>;
export function wbg_rayon_start_worker(receiver: number): void;
/**
 * Main client that coordinates bulletin board, S3, and local storage
 */
export class Client {
  free(): void;
  constructor(service_url: string);
  /**
   * Post a new message to the bulletin board
   */
  post_message(data: Uint8Array): Promise<any>;
  /**
   * Get a specific message by ID
   */
  get_message(message_id: string): Promise<any>;
  /**
   * List all messages from the bulletin board
   */
  list_messages(): Promise<any>;
  /**
   * Get cached messages from local storage
   */
  get_cached_messages(): Promise<any>;
  /**
   * Clear local cache
   */
  clear_cache(): Promise<void>;
}
/**
 * Main WASM trustee interface
 */
export class WasmTrustee {
  free(): void;
  /**
   * Create a new trustee from a JSON configuration string
   * 
   * Config format:
   * ```json
   * {
   *   "name": "trustee1",
   *   "b4_url": "http://localhost:8000",
   *   "signing_key_sk": "<base64-der>",
   *   "signing_key_pk": "<base64-der>",
   *   "encryption_key": "<base64>"
   * }
   * ```
   */
  constructor(config_json: string);
  /**
   * Initialize a session for a specific board
   * 
   * This creates the Trustee object needed to process messages
   */
  init_session(board_name: string): void;
  /**
   * Connect to a board and perform initial synchronization
   * 
   * This should be called after init_session() to fetch existing messages
   * from the remote board and update the local board state, without executing
   * any protocol steps. This allows the UI to display the current board state
   * before the user starts stepping through the protocol.
   * 
   * Returns the number of messages fetched and added to the local board.
   */
  connect_to_board(): Promise<any>;
  /**
   * Fetch list of available boards from B4
   */
  fetch_boards(): Promise<any>;
  /**
   * Perform one protocol step
   * 
   * This:
   * 1. Fetches new messages from B4
   * 2. Processes them through the trustee
   * 3. Posts any resulting messages back to B4
   * 
   * Returns the number of messages posted and messages added
   */
  step(): Promise<any>;
  /**
   * Get current state of the trustee for visualization
   */
  get_state(): any;
  /**
   * Get board summary - list of statements in local board
   */
  get_board_summary(): any;
  /**
   * Get the current board name (if session initialized)
   */
  readonly board_name: string | undefined;
  /**
   * Get the trustee name
   */
  readonly name: string;
  /**
   * Get the B4 URL
   */
  readonly b4_url: string;
}
export class wbg_rayon_PoolBuilder {
  private constructor();
  free(): void;
  mainJS(): string;
  numThreads(): number;
  receiver(): number;
  build(): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly __wbg_wasmtrustee_free: (a: number, b: number) => void;
  readonly wasmtrustee_new: (a: number, b: number) => [number, number, number];
  readonly wasmtrustee_init_session: (a: number, b: number, c: number) => [number, number];
  readonly wasmtrustee_connect_to_board: (a: number) => any;
  readonly wasmtrustee_fetch_boards: (a: number) => any;
  readonly wasmtrustee_step: (a: number) => any;
  readonly wasmtrustee_get_state: (a: number) => [number, number, number];
  readonly wasmtrustee_board_name: (a: number) => [number, number];
  readonly wasmtrustee_name: (a: number) => [number, number];
  readonly wasmtrustee_b4_url: (a: number) => [number, number];
  readonly wasmtrustee_get_board_summary: (a: number) => [number, number, number];
  readonly __wbg_client_free: (a: number, b: number) => void;
  readonly client_new: (a: number, b: number) => [number, number, number];
  readonly client_post_message: (a: number, b: number, c: number) => any;
  readonly client_get_message: (a: number, b: number, c: number) => any;
  readonly client_list_messages: (a: number) => any;
  readonly client_get_cached_messages: (a: number) => any;
  readonly client_clear_cache: (a: number) => any;
  readonly init: () => void;
  readonly __wbg_wbg_rayon_poolbuilder_free: (a: number, b: number) => void;
  readonly wbg_rayon_poolbuilder_mainJS: (a: number) => any;
  readonly wbg_rayon_poolbuilder_numThreads: (a: number) => number;
  readonly wbg_rayon_poolbuilder_receiver: (a: number) => number;
  readonly wbg_rayon_poolbuilder_build: (a: number) => void;
  readonly initThreadPool: (a: number) => any;
  readonly wbg_rayon_start_worker: (a: number) => void;
  readonly memory: WebAssembly.Memory;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_5: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_export_7: WebAssembly.Table;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly closure145_externref_shim_multivalue_shim: (a: number, b: number, c: any) => [number, number];
  readonly _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__he7bd38e1e7159228: (a: number, b: number) => void;
  readonly closure701_externref_shim: (a: number, b: number, c: any) => void;
  readonly _dyn_core__ops__function__Fn_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h894a15f4bf262677: (a: number, b: number) => void;
  readonly closure722_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure878_externref_shim: (a: number, b: number, c: any, d: any) => void;
  readonly __wbindgen_thread_destroy: (a?: number, b?: number, c?: number) => void;
  readonly __wbindgen_start: (a: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number }} module - Passing `SyncInitInput` directly is deprecated.
* @param {WebAssembly.Memory} memory - Deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput, memory?: WebAssembly.Memory, thread_stack_size?: number } | SyncInitInput, memory?: WebAssembly.Memory): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number }} module_or_path - Passing `InitInput` directly is deprecated.
* @param {WebAssembly.Memory} memory - Deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput>, memory?: WebAssembly.Memory, thread_stack_size?: number } | InitInput | Promise<InitInput>, memory?: WebAssembly.Memory): Promise<InitOutput>;
